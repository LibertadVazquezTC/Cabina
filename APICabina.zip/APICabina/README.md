# Cabina Operativa

[![Build Status](https://acudir.visualstudio.com/TechMed.Services.CabinaOperativa/_apis/build/status/TechMed.Services.CabinaOperativa?branchName=master)](https://acudir.visualstudio.com/TechMed.Services.CabinaOperativa/_build/latest?definitionId=5&branchName=master)