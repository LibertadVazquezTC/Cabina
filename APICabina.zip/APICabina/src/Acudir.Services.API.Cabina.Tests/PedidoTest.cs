using CabinaOperativa.Modelo;
using CabinaOperativa.Repositories;
using Moq;
using NUnit.Framework;

namespace Tests
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Test1()
        {
            Assert.True(true);
        }
    }
}