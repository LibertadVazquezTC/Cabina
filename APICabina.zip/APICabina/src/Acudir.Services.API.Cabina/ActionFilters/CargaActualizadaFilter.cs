﻿using CabinaOperativa.Hubs;
using Microsoft.AspNet.SignalR;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Linq;

namespace CabinaOperativa.ActionFilters
{
    public class CargaActualizadaFilter : ActionFilterAttribute
    {
        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            base.OnActionExecuted(filterContext);
            var hub = GlobalHost.ConnectionManager.GetHubContext<CabinaOperativaHub>();
            hub.Clients.All.cargaActualizada();
        }
    }
}
