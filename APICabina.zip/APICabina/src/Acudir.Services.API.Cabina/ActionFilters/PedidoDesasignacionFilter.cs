﻿using CabinaOperativa.Hubs;
using Microsoft.AspNet.SignalR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace CabinaOperativa.ActionFilters
{

    public class PedidoDesasignacionFilter : ActionFilterAttribute
    {
        public override void OnActionExecuted(ActionExecutedContext context)
        {
            if (context.HttpContext.Response.StatusCode == StatusCodes.Status200OK)
            {

                Controller controller = context.Controller as Controller;
                if (controller != null)
                {
                    var pedidoId = controller.TempData["PedidoId"];
                    var hub = GlobalHost.ConnectionManager.GetHubContext<CabinaOperativaHub>();
                    hub.Clients.All.actualizarPedido(pedidoId);
                }
            }
        }
    }
}
