﻿using CabinaOperativa.Hubs;
using Microsoft.AspNet.SignalR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace CabinaOperativa.ActionFilters
{
    public class PedidoHorariosActualizacionFilter : ActionFilterAttribute
    {
        public override void OnActionExecuted(ActionExecutedContext context)
        {
            //Asi se hace para capturar el StatusCode. Como está hecho no funciona...
            //var statusCode = (context.Result as ObjectResult)?.StatusCode;

            if (context.HttpContext.Response.StatusCode == StatusCodes.Status200OK)
            {
                Controller controller = context.Controller as Controller;
                if (controller != null)
                {
                    var pedidoId = controller.TempData["PedidoId"];
                    var hub = GlobalHost.ConnectionManager.GetHubContext<CabinaOperativaHub>();
                    hub.Clients.All.actualizarPedido(pedidoId);
                }
            }
        }

        public override void OnActionExecuting(ActionExecutingContext context)
        {

        }
    }
}
