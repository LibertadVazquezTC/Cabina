﻿using AutoMapper;
using CabinaOperativa.DTOs;
using CabinaOperativa.DTOs.Alertas;
using CabinaOperativa.DTOs.Asignaciones;
using CabinaOperativa.DTOs.Cargas;
using CabinaOperativa.DTOs.Comentarios;
using CabinaOperativa.DTOs.Configuraciones;
using CabinaOperativa.DTOs.Direccion;
using CabinaOperativa.Modelo;
using CabinaOperativa.ServiciosExternos.DTOs.SISA;
using CabinaOperativa.Utilities;
using static CabinaOperativa.DTOs.Cargas.AsignarCargaDTO;

namespace CabinaOperativa.AutoMapper
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<PedidoAlertaAccionRespuesta, CrearPedidoAlertaAccionRespuestaDTO>().ReverseMap();
            CreateMap<PedidoAlertaAccionRespuesta, PedidoAlertaAccionRespuestaDTO>().ReverseMap();
            CreateMap<PedidoResultadoLaboratorio, PedidoResultadoLaboratorioDTO>().ReverseMap();
            CreateMap<PedidoResultadoLaboratorioTipoPrestacion, PedidoResultadoLaboratorioTipoPrestacionDTO>()
                .ReverseMap();
            CreateMap<PedidoDiagnosticoMedico, PedidoDiagnosticoMedicoDTO>().ReverseMap();
            CreateMap<PedidoTipoCierre, PedidoTipoCierreDTO>().ReverseMap();
            CreateMap<Diagnostico, DiagnosticoDTO>()
                .ForMember(dto => dto.Descripcion, opt => opt.MapFrom(u => u.Descripcion.Trim()));
            CreateMap<CmnConfiguracion, CmnConfiguracionDTO>();
            CreateMap<PedidoAfiliado, AfiliadoDTO>().ReverseMap();
            CreateMap<PedidoTramoDetalle, PedidoTramoDetalleDTO>().ReverseMap();
            CreateMap<Direccion, DireccionDTO>().ReverseMap();
            CreateMap<DireccionLocalidad, DireccionLocalidadDTO>().ReverseMap();
            CreateMap<DireccionLocalidad, DireccionLocalidadLiteDTO>().ReverseMap();
            CreateMap<PedidoComentario, PedidoComentarioDTO>().ReverseMap();
            CreateMap<PedidoTramoProveedorUMovilHorario, HorariosDTO>().ReverseMap();
            CreateMap<TipoPrestacion, TipoPrestacionDTO>().ReverseMap();
            CreateMap<PedidoAdicional, PedidoAdicionalDTO>().ReverseMap();
            CreateMap<Proveedor, ProveedorDTO>().ReverseMap();
            CreateMap<PedidoTramoEfectorHorario, HorariosDTO>().ReverseMap();
            CreateMap<PedidoTramoEfectorHorario, PedidoTramoEfectorHorarioDTO>()
                .ForMember(dto => dto.EfectorDescripcion, opt => opt.MapFrom(u => u.Efector.Descripcion));
            CreateMap<PedidoTramoProveedorUMovilHorario, PedidoTramoProveedorUMovilHorarioDTO>()
                .ForMember(dto => dto.ProveedorDescripcion, opt => opt.MapFrom(u => u.Proveedor.Descripcion))
                .ForMember(dto => dto.ProveedorTelefono, opt => opt.MapFrom(u => u.Proveedor.Telefono))
                .ForMember(dto => dto.UMovilDescripcion, opt => opt.MapFrom(u => u.UMovil.Descripcion));
            CreateMap<PedidoTramoEfectorHorario, NegociacionDTO>()
                .ForMember(dto => dto.Incidente, opt => opt.MapFrom(u => u.NroServicio))
                .ForMember(dto => dto.QuienAtiende, opt => opt.MapFrom(u => u.QuienAtiende))
                .ForMember(dto => dto.VentanaTolerancia, opt => opt.MapFrom(u => u.VentaToleranciaNegociada))
                .ReverseMap();
            CreateMap<PedidoTramoProveedorUMovilHorario, NegociacionDTO>()
                .ForMember(dto => dto.Incidente, opt => opt.MapFrom(u => u.NroServicio))
                .ForMember(dto => dto.QuienAtiende, opt => opt.MapFrom(u => u.QuienAtiende))
                .ForMember(dto => dto.VentanaTolerancia, opt => opt.MapFrom(u => u.VentaToleranciaNegociada))
                .ReverseMap();
            CreateMap<Sintoma, SintomaDTO>().ReverseMap();
            CreateMap<PedidoCoseguroTipoNoCobro, PedidoCoseguroTipoNoCobroDTO>().ReverseMap();
            CreateMap<PedidoCoseguro, PedidoCoseguroDTO>()
                .ForMember(dto => dto.ResponsableDelCobro, opt => opt.MapFrom(u => u.GdiaPersonal != null ? u.GdiaPersonal.Descripcion : "N/A"))
                .ReverseMap();

            CreateMap<Carga, CargaDTO>()
                .ForMember(dto => dto.CargaId, opt => opt.MapFrom(u => u.CargaId))
                .ForMember(dto => dto.Movil, opt => opt.MapFrom(u => u.UMovil.Descripcion))
                .ForMember(dto => dto.Chofer, opt => opt.MapFrom(u => u.ChoferDescripcion))
                .ForMember(dto => dto.Medico, opt => opt.MapFrom(u => u.MedicoDescripcion))
                .ForMember(dto => dto.AsignadoPor, opt => opt.MapFrom(u => u.AuditoriaInsertUser))
                .ForMember(dto => dto.Comentario, opt => opt.MapFrom(u => u.Comentario))
                .ForMember(dto => dto.HoraAsignado, opt => opt.MapFrom(u => u.AuditoriaInsertDate))
                .ForMember(dto => dto.HoraFinal, opt => opt.MapFrom(u => u.HoraFinal))
                .ForMember(dto => dto.HoraConfirmacion, opt => opt.MapFrom(u => u.FechaConfirmaInicio))
                .ForMember(dto => dto.TiempoRestante, opt => opt.MapFrom(u => u.TiempoRestante))
                .ReverseMap();

            CreateMap<Carga, AsignarCargaDTO>()
                .ForMember(dto => dto.uMovilId, opt => opt.MapFrom(u => u.UMovilId))
                .ForPath(dto => dto.chofer.GdiaPersonalId, opt => opt.MapFrom(u => u.ChoferId))
                .ForPath(dto => dto.chofer.Personal, opt => opt.MapFrom(u => u.ChoferDescripcion))
                .ForPath(dto => dto.medico.GdiaPersonalId, opt => opt.MapFrom(u => u.MedicoId))
                .ForPath(dto => dto.medico.Personal, opt => opt.MapFrom(u => u.MedicoDescripcion))
                .ForMember(dto => dto.comentario, opt => opt.MapFrom(u => u.Comentario))
                .ReverseMap();

            CreateMap<CargaGdiaRealPersonal, IntegranteDTO>()
                .ForMember(dto => dto.GdiaRealPersonalDetalleId, opt => opt.MapFrom(u => u.GdiaRealPersonalDetalleId))
                .ForMember(dto => dto.GdiaRealPersonalId, opt => opt.MapFrom(u => u.GdiaRealPersonalId))
                .ReverseMap();

            CreateMap<Pedido, AltaEventoCasoNominalDto>()
               .ForMember(p => p.DocumentoNro, opt => opt.MapFrom(s => DatosAfiliadoUtility.ObtenerNroDocumento(s)))
               .ForMember(p => p.TipoDocumentoId, opt => opt.MapFrom(s => SISAUtility.ObtenerTipoDocumentoId(s)))
               .ForMember(p => p.Sexo, opt => opt.MapFrom(s => DatosAfiliadoUtility.ObtenerSexo(s)))
               .ForMember(p => p.GrupoEventoId, opt => opt.MapFrom(s => 113))
               .ForMember(p => p.EventoId, opt => opt.MapFrom(s => 307))
               .ForMember(p => p.ClasificacionManualCasoId, opt => opt.MapFrom(s => 795))
               .ForMember(p => p.EstablecimientoCargaId, opt => opt.MapFrom(s => "53020012316990"))
               .ForMember(p => p.FechaNacimiento, opt => opt.MapFrom(s => DatosAfiliadoUtility.ObtenerFechaNacimiento(s, "dd-MM-yyyy")))
               .ForMember(p => p.FechaPapel, opt => opt.MapFrom(s => AsignacionUtility.ObtenerFechaArribo(s, "dd-MM-yyyy")));
        }
    }
}
