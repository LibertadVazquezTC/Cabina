﻿namespace CabinaOperativa.Constants
{
    public static class ConstantesCmnConfiguracion
    {
        public const string TIPO_TABLA = "TABLA";
        public const string TIPO_ASIGNACIONES_POR_MEDICO = "ASIGNACIONES_POR_MEDICO";

    }
}
