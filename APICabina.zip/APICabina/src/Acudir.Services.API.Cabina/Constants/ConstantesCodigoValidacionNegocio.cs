﻿namespace CabinaOperativa.Constants
{
    public static class ConstantesCodigoValidacionNegocio
    {
        public const string PEDIDO_YA_ARCHIVADO = "202006051300";

        public const string PEDIDO_CAMBIO_TIPOPRESTACION = "202006051301";
    }
}
