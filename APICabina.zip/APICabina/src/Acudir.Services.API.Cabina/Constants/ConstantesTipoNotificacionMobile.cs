﻿namespace Acudir.Services.API.Cabina.Constants
{
    public static class ConstantesTipoNotificacionMobile
    {
        public const string ARCHIVADO = "PedidoArchivado";
        public const string DESASIGNADO = "PedidoDesasignado";
        public const string ASIGNADO = "PedidoAsignado";
        public const string AUSENTE = "PedidoAusente";

        public const int TIPO_CIERRE_AUSENTE = 7;
    
        public const int LOG_TURNO_GENERADO = 1;
        public const int LOG_ASIGNADA = 9;
        public const int LOG_PREARCHIVADA = 21;

        public const int GDIA_FICTICIA = 265928;
    } 
}
