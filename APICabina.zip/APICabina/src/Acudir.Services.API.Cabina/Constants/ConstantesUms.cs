﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CabinaOperativa.Constants
{
    public static class ConstantesUms
    {
        //TIPOS
        public const string TIPO_MENSAJE_PEDIDO = "P";
        public const string TIPO_MENSAJE_MOVIL = "M";

        //SUBTIPOS
        public const string SUBTIPO_MENSAJE_DESPACHO_COMPLETO = "DC";
        public const string SUBTIPO_MENSAJE_ASIGNACION = "A";
        public const string SUBTIPO_MENSAJE_DESASIGNACION = "G";
        public const string SUBTIPO_MENSAJE_ANULACION = "C";
        public const string SUBTIPO_MENSAJE_PEDIDO_ACTUALIZA_TIPO_PRESTACION = "T";
        public const string SUBTIPO_MENSAJE_PEDIDO_ACTUALIZA_TRAMO = "AT";
        public const string SUBTIPO_MENSAJE_PEDIDO_ORIGEN_ARRIBO = "OA";
        public const string SUBTIPO_MENSAJE_PEDIDO_ORIGEN_PARTIDA = "OP";
        public const string SUBTIPO_MENSAJE_PEDIDO_ACTUALIZA_COSEGURO = "AC";
        public const string SUBTIPO_MENSAJE_MOVIL_INICIO_DE_CARGA = "IC";
        public const string SUBTIPO_MENSAJE_MOVIL_CANCELACION_DE_CARGA = "CC";
        public const string SUBTIPO_MENSAJE_MOVIL_MENSAJE = "MSJ";

        //SEPARADORES
        public const string SEPARADOR_DATOS_PRINCIPALES = "|";
        public const string SEPARADOR_CABECERA = "^";
        public const string SEPARADOR_TRAMOS = "@";
        public const string SEPARADOR_CAMPOS = "#";
    }
}
