﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CabinaOperativa.Repositories;
using CabinaOperativa.DTOs;
using CabinaOperativa.ActionFilters;
using CabinaOperativa.Utilities.Interfaces;
using CabinaOperativa.Enums;
using CabinaOperativa.Modelo;
using System;
using System.Net;
using AutoMapper;
using CabinaOperativa.Exceptions;
using CabinaOperativa.DTOs.Archivar;
using CabinaOperativa.Orquestadores.Interfaces;

namespace TechMed.Services.Cabina.Controllers
{
    [Route("api/v1/Cabina/[controller]")]
    public class AdicionalesController : Controller
    {
        private readonly IMapper _mapper;
        private readonly IPedidoAdicionalRepository _pedidoAdicionalRepository;

        public AdicionalesController(IMapper mapper,
            IPedidoAdicionalRepository pedidoAdicionalRepository)
        {
            _mapper = mapper;
            _pedidoAdicionalRepository = pedidoAdicionalRepository;
        }

        /// <summary>
        /// Devuelve los adicionales de un pedido y tipo específico
        /// </summary>
        /// <response code="200">Devuelve los adicionales de un pedido y tipo específico</response>
        /// <response code="400">Error inesperado</response>            
        /// <response code="404">No se encontró el adicional para ese pedido y tipo</response>            
        [HttpGet("{pedidoAdicionalTipoId}/Pedidos/{pedidoId}")]
        [ProducesResponseType(typeof(PedidoAdicionalDTO), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> ObtenerPorPedidoYTipo(int pedidoAdicionalTipoId, int pedidoId)
        {
            try
            {
                var pedidoAdicional = await _pedidoAdicionalRepository.ObtenerPorPedidoYTipo(pedidoId, pedidoAdicionalTipoId);
                if (pedidoAdicional is null)
                    return NotFound();
                return Ok(_mapper.Map<PedidoAdicionalDTO>(pedidoAdicional));
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }      
    }
}
