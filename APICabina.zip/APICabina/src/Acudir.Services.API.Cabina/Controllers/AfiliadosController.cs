﻿using System;
using System.Net;
using System.Threading.Tasks;
using AutoMapper;
using CabinaOperativa.DTOs;
using CabinaOperativa.Modelo;
using CabinaOperativa.Orquestadores.Interfaces;
using CabinaOperativa.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace TechMed.Services.Cabina.Controllers
{
    [Route("api/v1/Cabina/[controller]")]
    public class AfiliadosController : Controller
    {
        private readonly IMapper _mapper;
        private readonly IOrquestadorCoseguro _orquestadorCoseguro; 
        private readonly IPedidoAfiliadoRepository _afiliadoRepository;

        public AfiliadosController(IMapper mapper,
            IOrquestadorCoseguro orquestadorCoseguro,
            IPedidoAfiliadoRepository afiliadoRepository)
        {
            _mapper = mapper;
            _orquestadorCoseguro = orquestadorCoseguro;
            _afiliadoRepository = afiliadoRepository;
        }

        /// <summary>
        /// Actualiza los datos de un afiliado
        /// </summary>
        /// <param name="pedidoAfiliadoId">PedidoAfiliadoId a actualizar</param>
        /// <param name="afiliadoDTO"></param>
        /// <response code="200">Devuelve el afiliado con los datos actualizados</response>
        /// <response code="404">No se encontró un afiliado con el id provisto</response>
        /// <response code="400">Error inesperado</response> 
        [HttpPut]
        [Route("{pedidoAfiliadoId}")]
        [ProducesResponseType(typeof(AfiliadoDTO), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> ActualizarAfiliado(int pedidoAfiliadoId, [FromBody] AfiliadoDTO afiliadoDTO)
        {
            try
            {
                PedidoAfiliado pedidoAfiliado = await _afiliadoRepository.Obtener(pedidoAfiliadoId);
                if (pedidoAfiliado is null) return NotFound(new { message = $"No se encontró el afiliado con id {pedidoAfiliadoId}." });

                pedidoAfiliado = _mapper.Map(afiliadoDTO, pedidoAfiliado);
                pedidoAfiliado = await _afiliadoRepository.Actualizar(pedidoAfiliado);

                await _orquestadorCoseguro.EjecutarReglasDeCoseguroParaElPedido(pedidoAfiliado.PedidoId, false);

                afiliadoDTO = _mapper.Map<AfiliadoDTO>(pedidoAfiliado);

                return Ok(afiliadoDTO);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }

        }     
    }
}
