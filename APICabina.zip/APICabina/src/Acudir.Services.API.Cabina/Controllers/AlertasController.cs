﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using AutoMapper;
using CabinaOperativa.DTOs;
using CabinaOperativa.DTOs.Alertas;
using CabinaOperativa.Exceptions;
using CabinaOperativa.Modelo;
using CabinaOperativa.Repositories;
using CabinaOperativa.Utilities;
using Microsoft.AspNetCore.Mvc;

namespace TechMed.Services.Cabina.Controllers
{
    [Route("api/v1/Cabina/[controller]")]
    public class AlertasController : Controller
    {
        private readonly IMapper _mapper;
        private readonly IPedidoTramoProveedorUMovilHorarioRepository _pedidoTramoProveedorUMovilHorarioRepository;
        private readonly IPedidoEntidadLogRepository _pedidoEntidadLogRepository;
        private readonly IAlertaAccionRepository _alertaAccionRepository;
        private readonly IPedidoAlertaAccionRespuestaRepository _pedidoAlertaAccionRespuestaRepository;

        public AlertasController(IMapper mapper,
            IPedidoTramoProveedorUMovilHorarioRepository pedidoTramoProveedorUMovilHorarioRepository,
            IPedidoEntidadLogRepository pedidoEntidadLogRepository,
            IAlertaAccionRepository alertaAccionRepository,
            IPedidoAlertaAccionRespuestaRepository pedidoAlertaAccionRespuestaRepository)
        {
            _mapper = mapper;
            _pedidoTramoProveedorUMovilHorarioRepository = pedidoTramoProveedorUMovilHorarioRepository;
            _pedidoEntidadLogRepository = pedidoEntidadLogRepository;
            _alertaAccionRepository = alertaAccionRepository;
            _pedidoAlertaAccionRespuestaRepository = pedidoAlertaAccionRespuestaRepository;
        }

        /// <summary>
        /// Devuelve las acciones asociadas a un tipo de alerta
        /// </summary>
        /// <param name="entidadLogTipoEstadoId">Id del entidadLogTipoEstado asociado a la alerta</param>
        /// <response code="200">Devuelve el listado de acciones para un tipo de alerta</response>
        /// <response code="409">Falla por no cumplirse una regla de negocio o algun dato es erroneo</response>
        /// <response code="400">Error inesperado</response> 
        [HttpGet]
        [Route("Acciones")]
        [ProducesResponseType(typeof(AlertaAccion), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> ListarAccionesPorEntidadLogTipoEstado(int entidadLogTipoEstadoId)
        {
            try
            {
                IEnumerable<AlertaAccion> alertaAcciones = await _alertaAccionRepository.ListarPorEntidadLogTipoEstado(entidadLogTipoEstadoId);
                return Ok(alertaAcciones.Select(x => new
                {
                    x.AlertaAccionId,
                    x.EntidadLogTipoEstadoId,
                    x.Descripcion,
                    x.RequiereDescripcion
                }));
            }
            catch (DatoErroneoException ex)
            {
                return Conflict(new { message = ex.Message });
            }
            catch (ReglaDeNegocioException ex)
            {
                return Conflict(new { message = ex.Message });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Devuelve las respuestas asociadas a un tipo de alerta y tramo
        /// </summary>
        /// <param name="entidadLogTipoEstadoId">Id del entidadLogTipoEstado asociado a la alerta</param>
        /// <param name="pedidoTramoProveedorUMovilHorarioId">id del PedidoTramoProveedorUMovilHorario en cuestión</param>
        /// <response code="200">Devuelve el listado de respuestas para un tipo de alerta y tramo</response>
        /// <response code="409">Falla por no cumplirse una regla de negocio o algun dato es erroneo</response>
        /// <response code="400">Error inesperado</response> 
        [HttpGet]
        [Route("Respuestas")]
        [ProducesResponseType(typeof(AlertaAccion), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> ListarRespuestasPreviasPorEntidadLogTipoEstadoYPedidoTramo(int entidadLogTipoEstadoId, int pedidoTramoProveedorUMovilHorarioId)
        {
            try
            {
                if (pedidoTramoProveedorUMovilHorarioId == 0)
                    return Conflict("El parámetro pedidoTramoProveedorUMovilHorarioId no puede ser 0.");

                PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario = await _pedidoTramoProveedorUMovilHorarioRepository.Obtener(pedidoTramoProveedorUMovilHorarioId);
                if (pedidoTramoProveedorUMovilHorario is null)
                    return Conflict($"No se encontró pedidoTramoProveedorUMovilHorario con id: {pedidoTramoProveedorUMovilHorarioId}.");

                int pedidoId = pedidoTramoProveedorUMovilHorario.PedidoTramo.PedidoId;

                IEnumerable<PedidoAlertaAccionRespuesta> pedidoAlertaAccionRespuestasDb = await _pedidoAlertaAccionRespuestaRepository.ListarPorPedidoYValorYEntidadLogTipoEstado(pedidoId, pedidoTramoProveedorUMovilHorarioId, entidadLogTipoEstadoId);
                IEnumerable<PedidoAlertaAccionRespuestaDTO> pedidoAlertaAccionRespuestasDTO = _mapper.Map<IEnumerable<PedidoAlertaAccionRespuestaDTO>>(pedidoAlertaAccionRespuestasDb);

                return Ok(pedidoAlertaAccionRespuestasDTO);
            }
            catch (DatoErroneoException ex)
            {
                return Conflict(new { message = ex.Message });
            }
            catch (ReglaDeNegocioException ex)
            {
                return Conflict(new { message = ex.Message });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Devuelve las respuestas asociadas a un tipo de alerta y tramo
        /// </summary>
        /// <param name="entidadLogTipoEstadoId">Id del entidadLogTipoEstado asociado a la alerta</param>
        /// <param name="pedidoTramoProveedorUMovilHorarioId">id del PedidoTramoProveedorUMovilHorario en cuestión</param>
        /// <response code="200">Devuelve el listado de respuestas para un tipo de alerta y tramo</response>
        /// <response code="409">Falla por no cumplirse una regla de negocio o algun dato es erroneo</response>
        /// <response code="400">Error inesperado</response> 
        [HttpGet]
        [Route("PedidoEntidadLog")]
        [ProducesResponseType(typeof(AlertaAccion), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> ObtenerPedidoEntidadLogPorEntidadLogTipoEstadoYPedidoTramo(int entidadLogTipoEstadoId, int pedidoTramoProveedorUMovilHorarioId)
        {
            try
            {
                if (pedidoTramoProveedorUMovilHorarioId == 0)
                    return Conflict("El parámetro pedidoTramoProveedorUMovilHorarioId no puede ser 0.");

                PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario = await _pedidoTramoProveedorUMovilHorarioRepository.Obtener(pedidoTramoProveedorUMovilHorarioId);
                if (pedidoTramoProveedorUMovilHorario is null)
                    return Conflict($"No se encontró pedidoTramoProveedorUMovilHorario con id: {pedidoTramoProveedorUMovilHorarioId}.");

                int pedidoId = pedidoTramoProveedorUMovilHorario.PedidoTramo.PedidoId;
                PedidoEntidadLog pedidoEntidadLog = await _pedidoEntidadLogRepository.ObtenerPorPedidoYValorYEntidadLogTipoEstado(pedidoId, pedidoTramoProveedorUMovilHorarioId, entidadLogTipoEstadoId);

                if (pedidoEntidadLog is null)
                    return NotFound();

                return Ok(new
                {
                    pedidoEntidadLogId = pedidoEntidadLog.PedidoEntidadLogId
                });
            }
            catch (DatoErroneoException ex)
            {
                return Conflict(new { message = ex.Message });
            }
            catch (ReglaDeNegocioException ex)
            {
                return Conflict(new { message = ex.Message });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Crea la respuesta a una alerta
        /// </summary>
        /// <param name="crearPedidoAlertaAccionRespuestaDTO">Data transfer object</param>
        /// <response code="200">La respuesta se creo exitosamente</response>
        /// <response code="409">Falla por no cumplirse una regla de negocio o algun dato es erroneo</response>
        /// <response code="400">Error inesperado</response> 
        [HttpPost]
        [Route("Respuestas")]
        [ProducesResponseType(typeof(CrearPedidoAlertaAccionRespuestaDTO), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> CrearRespuesta([FromBody] CrearPedidoAlertaAccionRespuestaDTO crearPedidoAlertaAccionRespuestaDTO)
        {
            try
            {
                PedidoAlertaAccionRespuesta pedidoAlertaAccionRespuesta = _mapper.Map<PedidoAlertaAccionRespuesta>(crearPedidoAlertaAccionRespuestaDTO);
                pedidoAlertaAccionRespuesta = await _pedidoAlertaAccionRespuestaRepository.Crear(pedidoAlertaAccionRespuesta);
                crearPedidoAlertaAccionRespuestaDTO = _mapper.Map<CrearPedidoAlertaAccionRespuestaDTO>(pedidoAlertaAccionRespuesta);
                return Ok(crearPedidoAlertaAccionRespuestaDTO);
            }
            catch (DatoErroneoException ex)
            {
                return Conflict(new { message = ex.Message });
            }
            catch (ReglaDeNegocioException ex)
            {
                return Conflict(new { message = ex.Message });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
    }
}
