﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using AutoMapper;
using CabinaOperativa.ActionFilters;
using CabinaOperativa.DTOs.Asignaciones;
using CabinaOperativa.DTOs.Asignaciones.Efector.MasVidaInterfaz;
using CabinaOperativa.Enums;
using CabinaOperativa.Exceptions;
using CabinaOperativa.Modelo;
using CabinaOperativa.Orquestadores.Interfaces;
using CabinaOperativa.Repositories;
using CabinaOperativa.Utilities;
using CabinaOperativa.Utilities.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace TechMed.Services.Cabina.Controllers
{
    [Route("api/v1/Cabina/[controller]")]
    public class AsignacionesController : Controller
    {
        private readonly IMapper _mapper;

        private readonly IOrquestadorAsignacion _orquestadorAsignacion;
        private readonly IOrquestadorAsignacionEfector _orquestadorAsignacionEfector;
        private readonly IOrquestadorDesasignacion _orquestadorDesasignacion;
        private readonly IOrquestadorDesasignacionEfector _orquestadorDesasignacionEfector;
        private readonly IOrquestadorCoseguro _orquestadorCoseguro;

        private readonly IPedidoTramoRepository _pedidoTramoRepository;
        private readonly IPedidoTramoProveedorUMovilHorarioRepository _pedidoTramoProveedorUMovilHorarioRepository;
        private readonly IPedidoTramoEfectorHorarioRepository _pedidoTramoEfectorHorarioRepository;
        private readonly IPedidoTramoProveedorUMovilHorarioGdiaRealPersonalRepository _pedidoTramoProveedorUMovilHorarioGdiaRealPersonalRepository;
        private readonly IPedidoCoseguroRepository _pedidoCoseguroRepository;
        private readonly IGdiaRealEquipoRepository _gdiaRealEquipoRepository;
        private readonly IGdiaRealPersonalDetalleRepository _gdiaRealPersonalDetalleRepository;
        private readonly IEfectorRepository _efectorRepository;
        private readonly IMasVidaUtility _masVidaUtility;
        private readonly IPedidoEntidadLogRepository _pedidoEntidadLogRepository;

        public AsignacionesController(IMapper mapper,

            IOrquestadorAsignacion orquestadorAsignacion,
            IOrquestadorAsignacionEfector orquestadorAsignacionEfector,
            IOrquestadorDesasignacion orquestadorDesasignacion,
            IOrquestadorDesasignacionEfector orquestadorDesasignacionEfector,
            IOrquestadorCoseguro orquestadorCoseguro,

            IPedidoTramoRepository pedidoTramoRepository,
            IPedidoTramoProveedorUMovilHorarioRepository PedidoTramoProveedorUMovilHorarioRepository,
            IPedidoTramoEfectorHorarioRepository pedidoTramoEfectorHorarioRepository,
            IPedidoTramoProveedorUMovilHorarioGdiaRealPersonalRepository PedidoTramoProveedorUMovilHorarioGdiaRealPersonalRepository,
            IPedidoCoseguroRepository pedidoCoseguroRepository,
            IGdiaRealEquipoRepository gdiaRealEquipoRepository,
            IGdiaRealPersonalDetalleRepository gdiaRealPersonalDetalleRepository,
            ICmnConfiguracionRepository cmnConfiguracionRepository,
            IEfectorRepository efectorRepository,
            IMasVidaUtility masVidaUtility,
            IPedidoEntidadLogRepository pedidoEntidadLogRepository)
        {
            _mapper = mapper;

            _orquestadorAsignacion = orquestadorAsignacion;
            _orquestadorAsignacionEfector = orquestadorAsignacionEfector;
            _orquestadorDesasignacion = orquestadorDesasignacion;
            _orquestadorDesasignacionEfector = orquestadorDesasignacionEfector;
            _orquestadorCoseguro = orquestadorCoseguro;

            _pedidoTramoRepository = pedidoTramoRepository;
            _pedidoTramoProveedorUMovilHorarioRepository = PedidoTramoProveedorUMovilHorarioRepository;
            _pedidoTramoEfectorHorarioRepository = pedidoTramoEfectorHorarioRepository;
            _pedidoTramoProveedorUMovilHorarioGdiaRealPersonalRepository = PedidoTramoProveedorUMovilHorarioGdiaRealPersonalRepository;
            _pedidoCoseguroRepository = pedidoCoseguroRepository;
            _gdiaRealEquipoRepository = gdiaRealEquipoRepository;
            _gdiaRealPersonalDetalleRepository = gdiaRealPersonalDetalleRepository;
            _efectorRepository = efectorRepository;
            _masVidaUtility = masVidaUtility;
            _pedidoEntidadLogRepository = pedidoEntidadLogRepository;
        }

        /// <summary>
        /// Asigna o preasigna un equipo
        /// </summary>
        /// <param name="asignarEquipo"></param>
        /// <response code="200">Devuelve la asignación o preasignacion creada</response>
        /// <response code="409">Devuelve un mensaje de error por no cumplirse una regla de negocio</response>
        /// <response code="400">Error inesperado</response> 
        [HttpPost]
        [PedidoAsignacionFilter]
        [ProducesResponseType(typeof(PedidoTramoProveedorUMovilHorarioDTO), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.Conflict)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> AsignarEquipo([FromBody] AsignarEquipoDTO asignarEquipo)
        {
            try
            {
                TempData["PedidoId"] = asignarEquipo.PedidoId;
                PedidoTramoProveedorUMovilHorario asignacionCreada = await _orquestadorAsignacion.AsignarPropio(asignarEquipo.PedidoId, asignarEquipo.GdiaRealEquipoId, asignarEquipo.ProveedorId, asignarEquipo.EsPreasignacion);
                PedidoTramoProveedorUMovilHorarioDTO asignacionCreadaDTO = _mapper.Map<PedidoTramoProveedorUMovilHorarioDTO>(asignacionCreada);
                if (!asignarEquipo.EsPreasignacion)
                {
                    await _pedidoEntidadLogRepository.Crear(asignarEquipo.PedidoId, asignacionCreada.PedidoTramoProveedorUMovilHorarioId, (int)EntidadLogTipoEstadoEnum.AlertaNoRecibeBB, "AsignacionesController/AsignarEquipo");
                    await _pedidoEntidadLogRepository.Crear(asignarEquipo.PedidoId, asignacionCreada.PedidoTramoProveedorUMovilHorarioId, (int)EntidadLogTipoEstadoEnum.AlertaNoConfirma, "AsignacionesController/AsignarEquipo");
                }

                return Ok(asignacionCreadaDTO);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Desasigna un equipo De Forma Manual
        /// </summary>
        /// <param name="pedidoTramoProveedorUMovilHorarioId">PedidoTramoProveedorUMovilHorarioId a desasignar</param>
        /// <response code="200">Devuelve la asignación desasignada</response>
        /// <response code="400">Error inesperado</response> 
        [HttpDelete]
        [Route("{pedidoTramoProveedorUMovilHorarioId}")]
        [PedidoDesasignacionFilter]
        [ProducesResponseType(typeof(PedidoTramoProveedorUMovilHorarioDTO), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> DesasignarEquipo(int pedidoTramoProveedorUMovilHorarioId)
        {
            try
            {
                PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorarioDesasignado = await _orquestadorDesasignacion.Desasignar(pedidoTramoProveedorUMovilHorarioId);
                PedidoTramoProveedorUMovilHorarioDTO pedidoTramoProveedorUMovilHorarioDesasignadoDTO = _mapper.Map<PedidoTramoProveedorUMovilHorarioDTO>(pedidoTramoProveedorUMovilHorarioDesasignado);
                TempData["PedidoId"] = pedidoTramoProveedorUMovilHorarioDesasignado.PedidoTramo.PedidoId;
                return Ok(pedidoTramoProveedorUMovilHorarioDesasignadoDTO);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Desasigna un equipo por Worker forma Automatica para Amarillo y Amarillo pediatricos
        /// </summary>
        /// <param name="pedidoTramoProveedorUMovilHorarioId">PedidoTramoProveedorUMovilHorarioId a desasignar</param>
        /// <param name="esAmarillo"></param>
        /// <response code="200">Devuelve la asignación desasignada</response>
        /// <response code="400">Error inesperado</response> 
        [HttpDelete]
        [Route("{pedidoTramoProveedorUMovilHorarioId}/Worker/{esAmarillo}")]
        [PedidoDesasignacionFilter]
        [ProducesResponseType(typeof(PedidoTramoProveedorUMovilHorarioDTO), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> DesasignarEquipoWorker(int pedidoTramoProveedorUMovilHorarioId, bool esAmarillo)
        {
            try
            {
                PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorarioDesasignado = await _orquestadorDesasignacion.DesasignarWorker(pedidoTramoProveedorUMovilHorarioId, esAmarillo);
                PedidoTramoProveedorUMovilHorarioDTO pedidoTramoProveedorUMovilHorarioDesasignadoDTO = _mapper.Map<PedidoTramoProveedorUMovilHorarioDTO>(pedidoTramoProveedorUMovilHorarioDesasignado);
                TempData["PedidoId"] = pedidoTramoProveedorUMovilHorarioDesasignado.PedidoTramo.PedidoId;
                return Ok(pedidoTramoProveedorUMovilHorarioDesasignadoDTO);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Actualiza el estado de un PedidoTramoProveedorUMovilHorario
        /// </summary>
        /// <param name="pedidoTramoProveedorUMovilHorarioId">Id del PedidoTramoProveedorUMovilHorario a actualizar el estado</param>
        /// <param name="actualizarEstadoAsignacion"></param>
        /// <response code="200">Devuelve el PedidoTramoProveedorUMovilHorario con el estado actualizado</response>
        /// <response code="400">Error inesperado</response> 
        [HttpPut]
        [Route("{pedidoTramoProveedorUMovilHorarioId}/Estado")]
        [PedidoAsignacionFilter]
        [ProducesResponseType(typeof(PedidoTramoProveedorUMovilHorarioDTO), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> ActualizarEstadoAsignacion(int pedidoTramoProveedorUMovilHorarioId, [FromBody] ActualizarEstadoAsignacionDTO actualizarEstadoAsignacion)
        {
            try
            {
                TempData["PedidoId"] = actualizarEstadoAsignacion.PedidoId;
                PedidoTramoProveedorUMovilHorario asignacionActualizada = await _orquestadorAsignacion.ActualizarEstadoDeLaAsignacion(pedidoTramoProveedorUMovilHorarioId, actualizarEstadoAsignacion.PedidoTramoProveedorUMovilHorarioEstadoId);
                PedidoTramoProveedorUMovilHorarioDTO asignacionActualizadaDTO = _mapper.Map<PedidoTramoProveedorUMovilHorarioDTO>(asignacionActualizada);
                return Ok(asignacionActualizadaDTO);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Al momento de archivar se actualiza el Kilómetro Cero en las asignaciones
        /// </summary>
        /// <param name="pedidoId">Id del Pedido</param>
        /// <response code="200">Devuelve el true si el km 0 fue actualizado</response>
        /// <response code="400">Error inesperado</response> 
        [HttpPut]
        [Route("{pedidoId}/KmCero")]
        [ProducesResponseType(typeof(bool), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> ActualizarKmCero(int pedidoId)
        {
            try
            {
                var resultado = await _orquestadorAsignacion.ActualizarKmCero(pedidoId);
                return Ok(resultado);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Crea un PedidoTramoEfectorHorario como asignación
        /// </summary>
        /// <param name="asignarEfector"></param>
        /// <response code="200">Devuelve el PedidoTramoEfectorHorario creado</response>
        /// <response code="400">Error inesperado</response> 
        [HttpPost]
        [Route("Efectores")]
        [PedidoAsignacionFilter]
        [ProducesResponseType(typeof(PedidoTramoEfectorHorarioDTO), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> AsignarEfector([FromBody] AsignarEfectorDTO asignarEfector)
        {
            try
            {
                TempData["PedidoId"] = asignarEfector.PedidoId;
                PedidoTramoEfectorHorario asignacionCreada = await _orquestadorAsignacionEfector.AsignarEfector(asignarEfector.PedidoId, asignarEfector.EfectorId);
                PedidoTramoEfectorHorarioDTO asignacionCreadaDTO = _mapper.Map<PedidoTramoEfectorHorarioDTO>(asignacionCreada);
                return Ok(asignacionCreadaDTO);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Desasigna el PedidoTramoEfectorHorario
        /// </summary>
        /// <param name="pedidoTramoEfectorHorarioId">Id del PedidoTramoEfectorHorario a desasignar</param>
        /// <response code="200">Devuelve el PedidoTramoEfectorHorario desasignado</response>
        /// <response code="400">Error inesperado</response> 
        [HttpDelete]
        [Route("Efectores/{pedidoTramoEfectorHorarioId}")]
        [PedidoDesasignacionFilter]
        [ProducesResponseType(typeof(PedidoTramoEfectorHorarioDTO), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> DesasignarEfector(int pedidoTramoEfectorHorarioId)
        {
            try
            {
                PedidoTramoEfectorHorario pedidoTramoEfectorHorarioDesasignado = await _orquestadorDesasignacionEfector.DesasignarEfector(pedidoTramoEfectorHorarioId);
                PedidoTramoEfectorHorarioDTO pedidoTramoEfectorHorarioDesasignadoDTO = _mapper.Map<PedidoTramoEfectorHorarioDTO>(pedidoTramoEfectorHorarioDesasignado);
                TempData["PedidoId"] = pedidoTramoEfectorHorarioDesasignado.PedidoTramo.PedidoId;
                return Ok(pedidoTramoEfectorHorarioDesasignadoDTO);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Devuelve los horarios del PedidoTramoProveedorUMovilHorario
        /// </summary>
        /// <param name="pedidoTramoProveedorUMovilHorarioId">Id del PedidoTramoProveedorUMovilHorario a consultar los horarios</param>
        /// <response code="200">Devuelve los horarios del PedidoTramoProveedorUMovilHorario consultado</response>
        /// <response code="400">Error inesperado</response> 
        [HttpGet]
        [Route("{pedidoTramoProveedorUMovilHorarioId}/Horarios")]
        [ProducesResponseType(typeof(HorariosDTO), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> ObtenerHorarios(int pedidoTramoProveedorUMovilHorarioId)
        {
            try
            {
                PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario = await _pedidoTramoProveedorUMovilHorarioRepository.Obtener(pedidoTramoProveedorUMovilHorarioId);
                return Ok(_mapper.Map<HorariosDTO>(pedidoTramoProveedorUMovilHorario));
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Devuelve los horarios del PedidoTramoEfectorHorario
        /// </summary>
        /// <param name="pedidoTramoEfectorHorarioId">Id del PedidoTramoEfectorHorario a consultar los horarios</param>
        /// <response code="200">Devuelve los horarios del PedidoTramoEfectorHorario consultado</response>
        /// <response code="400">Error inesperado</response> 
        [HttpGet]
        [Route("Efectores/{pedidoTramoEfectorHorarioId}/Horarios")]
        [ProducesResponseType(typeof(HorariosDTO), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> ObtenerHorariosEfector(int pedidoTramoEfectorHorarioId)
        {
            try
            {
                PedidoTramoEfectorHorario pedidoTramoEfectorHorario = await _pedidoTramoEfectorHorarioRepository.Obtener(pedidoTramoEfectorHorarioId);
                return Ok(_mapper.Map<HorariosDTO>(pedidoTramoEfectorHorario));
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Actualiza los horarios de un PedidoTramoProveedorUMovilHorario
        /// </summary>
        /// <param name="pedidoTramoProveedorUMovilHorarioId">Id del PedidoTramoProveedorUMovilHorario a actualizar el horario</param>
        /// <param name="actualizarHorariosDTO"></param>
        /// <response code="200">Devuelve los horarios del PedidoTramoProveedorUMovilHorario actualizado</response>
        /// <response code="409">Devuelve un mensaje de error por no cumplirse una regla de negocio</response>
        /// <response code="400">Error inesperado</response> 
        [HttpPut]
        [PedidoHorariosActualizacionFilter]
        [Route("{pedidoTramoProveedorUMovilHorarioId}/Horarios")]
        [ProducesResponseType(typeof(HorariosDTO), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.Conflict)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> ActualizarHorario(int pedidoTramoProveedorUMovilHorarioId, [FromBody] ActualizarHorariosDTO actualizarHorariosDTO)
        {
            try
            {
                TempData["PedidoId"] = actualizarHorariosDTO.PedidoId;

                string[] tipoDeHorariosPermitidos = { "OrigenArribo", "OrigenPartida" };
                if (!tipoDeHorariosPermitidos.Contains(actualizarHorariosDTO.TipoHorario))
                    return BadRequest(new { message = $"El filtro {actualizarHorariosDTO.TipoHorario} no está dentro de los permitidos (OrigenArribo, OrigenPartida)." });

                PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorarioActualizado =
                    await _orquestadorAsignacion.ActualizarHorarios(pedidoTramoProveedorUMovilHorarioId,
                        ConvertidorTipoHorario.Convertir(actualizarHorariosDTO.TipoHorario), 
                        actualizarHorariosDTO.Horario.AddHours(-3));

                HorariosDTO horariosDTO = _mapper.Map<HorariosDTO>(pedidoTramoProveedorUMovilHorarioActualizado);
                return Ok(horariosDTO);
            }
            catch (DatoErroneoException ex)
            {
                return Conflict(new { message = ex.Message });
            }
            catch (ReglaDeNegocioException ex)
            {
                return Conflict(new { message = ex.Message });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Actualiza los horarios de un PedidoTramoEfectorHorario
        /// </summary>
        /// <param name="pedidoTramoEfectorHorarioId">Id del PedidoTramoEfectorHorario a actualizar el horario</param>
        /// <param name="actualizarHorariosDTO"></param>
        /// <response code="200">Devuelve los horarios del PedidoTramoEfectorHorario actualizado</response>
        /// <response code="409">Devuelve un mensaje de error por no cumplirse una regla de negocio</response>
        /// <response code="400">Error inesperado</response> 
        [HttpPut]
        [PedidoHorariosActualizacionFilter]
        [Route("Efectores/{pedidoTramoEfectorHorarioId}/Horarios")]
        [ProducesResponseType(typeof(HorariosDTO), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.Conflict)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> ActualizarHorarioEfector(int pedidoTramoEfectorHorarioId, [FromBody] ActualizarHorariosDTO actualizarHorariosDTO)
        {
            try
            {
                TempData["PedidoId"] = actualizarHorariosDTO.PedidoId;

                string[] tipoDeHorariosPermitidos = { "OrigenArribo", "OrigenPartida" };
                if (!tipoDeHorariosPermitidos.Contains(actualizarHorariosDTO.TipoHorario))
                    return BadRequest(new { message = $"El filtro {actualizarHorariosDTO.TipoHorario} no está dentro de los permitidos (OrigenArribo, OrigenPartida)." });

                PedidoTramoEfectorHorario pedidoTramoEfectorHorarioActualizado =
                    await _orquestadorAsignacionEfector.ActualizarHorario(pedidoTramoEfectorHorarioId, actualizarHorariosDTO.TipoHorario, actualizarHorariosDTO.Horario.AddHours(-3));

                HorariosDTO horariosDTO = _mapper.Map<HorariosDTO>(pedidoTramoEfectorHorarioActualizado);
                return Ok(horariosDTO);
            }
            catch (DatoErroneoException ex)
            {
                return Conflict(new { message = ex.Message });
            }
            catch (ReglaDeNegocioException ex)
            {
                return Conflict(new { message = ex.Message });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Actualiza los datos de negociación de un PedidoTramoEfectorHorario
        /// </summary>
        /// <param name="pedidoTramoEfectorHorarioId">Id del PedidoTramoEfectorHorario a actualizar los datos de negociación</param>
        /// <param name="negociacionEfector"></param>
        /// <response code="200">Devuelve el PedidoTramoEfectorHorario actualizado</response>
        /// <response code="400">Error inesperado</response> 
        [HttpPut]
        [PedidoNegociacionEfectorActualizacionFilter]
        [Route("Efectores/{pedidoTramoEfectorHorarioId}/Negociacion")]
        [ProducesResponseType(typeof(PedidoTramoEfectorHorarioDTO), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> ActualizarNegociacionEfector(int pedidoTramoEfectorHorarioId, [FromBody]NegociacionDTO negociacionEfector)
        {
            try
            {
                TempData["PedidoId"] = negociacionEfector.PedidoId;

                PedidoTramoEfectorHorario pedidoTramoEfectorHorarioExistente = await _pedidoTramoEfectorHorarioRepository.Obtener(pedidoTramoEfectorHorarioId);
                pedidoTramoEfectorHorarioExistente = _mapper.Map(negociacionEfector, pedidoTramoEfectorHorarioExistente);
                pedidoTramoEfectorHorarioExistente = await _pedidoTramoEfectorHorarioRepository.Actualizar(pedidoTramoEfectorHorarioExistente);

                PedidoTramoEfectorHorarioDTO pedidoTramoEfectorHorarioExistenteDTO = _mapper.Map<PedidoTramoEfectorHorarioDTO>(pedidoTramoEfectorHorarioExistente);
                return Ok(pedidoTramoEfectorHorarioExistenteDTO);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Actualiza los datos de negociación de un PedidoTramoProveedorUMovilHorario
        /// </summary>
        /// <param name="pedidoTramoProveedorUMovilHorarioId">Id del PedidoTramoProveedorUMovilHorario a actualizar los datos de negociación</param>
        /// <param name="negociacionEfector"></param>
        /// <response code="200">Devuelve el PedidoTramoEfectorHorario actualizado</response>
        /// <response code="400">Error inesperado</response> 
        [HttpPut]
        [PedidoNegociacionEfectorActualizacionFilter]
        [Route("{pedidoTramoProveedorUMovilHorarioId}/Negociacion")]
        [ProducesResponseType(typeof(PedidoTramoProveedorUMovilHorarioDTO), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> ActualizarNegociacionEfectorACDR(int pedidoTramoProveedorUMovilHorarioId, [FromBody]NegociacionDTO negociacionEfector)
        {
            try
            {
                TempData["PedidoId"] = negociacionEfector.PedidoId;

                PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario = await _pedidoTramoProveedorUMovilHorarioRepository.Obtener(pedidoTramoProveedorUMovilHorarioId);
                pedidoTramoProveedorUMovilHorario = _mapper.Map(negociacionEfector, pedidoTramoProveedorUMovilHorario);
                pedidoTramoProveedorUMovilHorario = await _pedidoTramoProveedorUMovilHorarioRepository.Actualizar(pedidoTramoProveedorUMovilHorario);

                PedidoTramoProveedorUMovilHorarioDTO pedidoTramoProveedorUMovilHorarioDTO = _mapper.Map<PedidoTramoProveedorUMovilHorarioDTO>(pedidoTramoProveedorUMovilHorario);
                return Ok(pedidoTramoProveedorUMovilHorarioDTO);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Actualiza el estado de un PedidoTramoEfectorHorario
        /// </summary>
        /// <param name="pedidoTramoEfectorHorarioId">Id del PedidoTramoEfectorHorario al que se le va a actualizar el estado</param>
        /// <param name="pedidoTramoEfectorHorarioEstadoId">Id del PedidoTramoEfectorHorarioEstado que se quiere marcar</param>
        /// <param name="pedidoId">Id del Pedido correspondiente</param>
        /// <response code="200">Devuelve el PedidoTramoEfectorHorario con el estado actualizado</response>
        /// <response code="400">Error inesperado</response> 
        [HttpPut]
        [PedidoNegociacionEfectorActualizacionFilter]
        [Route("Efectores/{pedidoTramoEfectorHorarioId}/Estado")]
        [ProducesResponseType(typeof(PedidoTramoEfectorHorarioDTO), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> ActualizarEstadoEfector(int pedidoTramoEfectorHorarioId, int pedidoTramoEfectorHorarioEstadoId, int pedidoId)
        {
            try
            {
                TempData["PedidoId"] = pedidoId;
                PedidoTramoEfectorHorario pedidoTramoEfectorHorarioExistente = await _pedidoTramoEfectorHorarioRepository.ActualizarEstado(pedidoTramoEfectorHorarioId, pedidoTramoEfectorHorarioEstadoId);
                PedidoTramoEfectorHorarioDTO pedidoTramoEfectorHorarioExistenteDTO = _mapper.Map<PedidoTramoEfectorHorarioDTO>(pedidoTramoEfectorHorarioExistente);
                return Ok(pedidoTramoEfectorHorarioExistenteDTO);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Enviar el pedido por interfaz a un efector (por ahora solo Mas Vida)
        /// </summary>
        /// <param name="efectorId">Id del Efector al que se le quiere enviar el pedido</param>
        /// <param name="pedidoTramoProveedorUMovilHorarioId">Id del PedidoTramoProveedorUMovilHorario correspondiente al pedidoTramo a enviar por interfaz</param>
        /// <response code="200">Devuelve los datos enviados por el efector</response>
        /// <response code="409">Devuelve un mensaje de error por no cumplirse una regla de negocio</response>
        /// <response code="400">Error inesperado</response> 
        [HttpPost]
        [Route("Efectores/{efectorId}/Interfaz/{pedidoTramoProveedorUMovilHorarioId}")]
        [ProducesResponseType(typeof(MasVidaResponseCrearDTO), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.Conflict)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> EnviarPorInterfaz(int efectorId, int pedidoTramoProveedorUMovilHorarioId)
        {
            try
            {
                if (efectorId == 0)
                    return Conflict(new { message = "El parámetro efectorId no puede ser 0." });

                if (pedidoTramoProveedorUMovilHorarioId == 0)
                    return Conflict(new { message = "El parámetro pedidoTramoProveedorUMovilHorarioId no puede ser 0." });

                PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario = await _pedidoTramoProveedorUMovilHorarioRepository.Obtener(pedidoTramoProveedorUMovilHorarioId);
                if (pedidoTramoProveedorUMovilHorario is null)
                    return Conflict(new { message = $"No se encontró pedidoTramoProveedorUMovilHorario con id {pedidoTramoProveedorUMovilHorarioId}." });

                Efector efector = await _efectorRepository.Obtener(efectorId);
                if (!efector.InterfazPrendida)
                    return Conflict(new { message = $"La interfaz se encuentra apagada." });

                if (string.IsNullOrEmpty(efector.Token))
                    return Conflict(new { message = $"El efector no posee un token." });

                await _orquestadorCoseguro.EjecutarReglasDeCoseguroParaElPedido(pedidoTramoProveedorUMovilHorario.PedidoTramo.PedidoId, true);

                if (efectorId == (int)EfectorEnum.MasVida)
                {
                    MasVidaResponseCrearDTO masVidaResponseCrearDTO = await _masVidaUtility.EnviarPorInterfaz(pedidoTramoProveedorUMovilHorarioId);
                    return Ok(masVidaResponseCrearDTO);
                }


                return Conflict(new { message = "El efector no posee una interfaz." });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = $"Ocurrió un error: {ex.Message}." });
            }
        }

        /// <summary>
        /// Devuelve las asignaciones de un pedido
        /// </summary>
        /// <param name="pedidoId">Id del pedido al cual se le quieren conocer las asignaciones</param>
        /// <param name="conPreasignados">Indica si se quieren tambien los preasignados</param>
        /// <response code="200">Listado de asignaciones del pedido</response>
        /// <response code="404">El pedido no existe o bien no tiene asignaciones</response>
        /// <response code="400">Error inesperado</response> 
        [HttpGet]
        [Route("Pedidos/{pedidoId}")]
        [ProducesResponseType(typeof(IEnumerable<PedidoTramoProveedorUMovilHorarioDTO>), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> ListarAsignacionesPorPedido(int pedidoId, bool conPreasignados = true)
        {
            try
            {
                IEnumerable<PedidoTramoProveedorUMovilHorario> pedidoTramoProveedorUMovilHorarios = await _pedidoTramoProveedorUMovilHorarioRepository.ObtenerPorPedido(pedidoId, conPreasignados);
                if (pedidoTramoProveedorUMovilHorarios is null || pedidoTramoProveedorUMovilHorarios.Count() == 0)
                    return NotFound($"No se encontró asignaciones para el pedido {pedidoId}.");
               
                IEnumerable<PedidoTramoProveedorUMovilHorarioDTO> pedidoTramoProveedorUMovilHorariosDto = _mapper.Map<IEnumerable<PedidoTramoProveedorUMovilHorarioDTO>>(pedidoTramoProveedorUMovilHorarios);
                return Ok(pedidoTramoProveedorUMovilHorariosDto);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = $"Ocurrió un error: {ex.Message}." });
            }
        }
    }
}
