﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using AutoMapper;
using CabinaOperativa.ActionFilters;
using CabinaOperativa.DTOs;
using CabinaOperativa.DTOs.Cargas;
using CabinaOperativa.Modelo;
using CabinaOperativa.Orquestadores.Interfaces;
using CabinaOperativa.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace TechMed.Services.Cabina.Controllers
{
    [Route("api/v1/Cabina/[controller]")]
    public class CargasController : Controller
    {
        private readonly IMapper _mapper;
        private readonly IOrquestadorNotificaciones _orquestadorNotificaciones;
        private readonly ICargaRepository _cargasRepository;
        private readonly ICargaGdiaRealPersonalRepository _cargaGdiaRealPersonalRepository;

        public CargasController(IMapper mapper,
            IOrquestadorNotificaciones orquestadorNotificaciones,
            ICargaRepository cargasRepository, ICargaGdiaRealPersonalRepository cargaGdiaRealPersonalRepository)
        {
            _cargasRepository = cargasRepository;
            _cargaGdiaRealPersonalRepository = cargaGdiaRealPersonalRepository;
            _orquestadorNotificaciones = orquestadorNotificaciones;
            _mapper = mapper;
        }

        /// <summary>
        /// Devuelve las ultimas cargas registradas para el móvil
        /// </summary>
        /// <param name="uMovilId">Id del Móvil que se quieren obtener sus cargas</param>
        /// <response code="200">Devuelve las ultimas 10 cargas registradas</response>
        /// <response code="400">Error inesperado</response> 
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(IEnumerable<CargaDTO>), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [HttpGet]
        [Route("{uMovilId}")]
        public async Task<IActionResult> ObtenerCargas(int uMovilId) //MS: No lo hice asyncronico porque no podia tomar los ultimos 10 ordernado en un getmany asincronico y no hay tiempo ospeddyyyyccc ospeddyyyyyyyyyc // gracias lean
        {
            try
            {
                var cargas = await _cargasRepository.ObtenerUltimas10CargasPorMovil(uMovilId);
                var resultado = _mapper.Map<IEnumerable<CargaDTO>>(cargas);
                return Ok(resultado);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Crea una carga en las tablas de Carga y CargaGdiaRealPersonal
        /// </summary>
        [ProducesResponseType(typeof(Int32), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [HttpPost]
        [Route("")]
        [CargaActualizadaFilter]
        public async Task<IActionResult> AsignarCarga([FromBody]AsignarCargaDTO asignarCargaDTO)
        {
            try
            {
                var carga = _mapper.Map<Carga>(asignarCargaDTO);
                await _cargasRepository.Crear(carga);

                var cargaChofer = _mapper.Map<CargaGdiaRealPersonal>(asignarCargaDTO.chofer);
                cargaChofer.Comentario = asignarCargaDTO.comentario;
                await _cargaGdiaRealPersonalRepository.AsignarCarga(cargaChofer);

                var cargaMedico = _mapper.Map<CargaGdiaRealPersonal>(asignarCargaDTO.medico);
                cargaMedico.Comentario = asignarCargaDTO.comentario;
                await _cargaGdiaRealPersonalRepository.AsignarCarga(cargaMedico);

                //Mati: te dejo los metodos para notificar al dim el inicio de carga y cancelacion de carga. //gracias lean
                await _orquestadorNotificaciones.NotificarInicioDeCarga(asignarCargaDTO.uMovilId);

                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Cancela una carga en las tablas de Carga y CargaGdiaRealPersonal
        /// </summary>
        [ProducesResponseType(typeof(Int32), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [HttpDelete]
        [Route("")]
        [CargaActualizadaFilter]
        public async Task<IActionResult> CancelarCarga([FromBody]AsignarCargaDTO asignarCargaDTO)
        {
            try
            {
                var carga = _mapper.Map<Carga>(asignarCargaDTO);
                await _cargasRepository.Cancelar(carga.CargaId,carga.Comentario);

                var cargaChofer = _mapper.Map<CargaGdiaRealPersonal>(asignarCargaDTO.chofer);
                cargaChofer.Comentario = asignarCargaDTO.comentario;
                await _cargaGdiaRealPersonalRepository.CancelarCarga(cargaChofer);

                var cargaMedico = _mapper.Map<CargaGdiaRealPersonal>(asignarCargaDTO.medico);
                cargaMedico.Comentario = asignarCargaDTO.comentario;
                await _cargaGdiaRealPersonalRepository.CancelarCarga(cargaMedico);

                //Mati: te dejo los metodos para notificar al dim el inicio de carga y cancelacion de carga. //gracias lean
                await _orquestadorNotificaciones.NotificarCancelacionDeCarga(asignarCargaDTO.uMovilId);

                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Cancela una carga en las tablas de Carga y CargaGdiaRealPersonal
        /// </summary>
        [ProducesResponseType(typeof(Int32), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [HttpPut]
        [Route("")]
        [CargaActualizadaFilter]
        public async Task<IActionResult> ReasignarCarga([FromBody]AsignarCargaDTO asignarCargaDTO)
        {
            try
            {
                var carga = _mapper.Map<Carga>(asignarCargaDTO);
                await _cargasRepository.Reasignar(carga.CargaId, carga.Comentario);

                var cargaChofer = _mapper.Map<CargaGdiaRealPersonal>(asignarCargaDTO.chofer);
                cargaChofer.Comentario = asignarCargaDTO.comentario;
                await _cargaGdiaRealPersonalRepository.ReasignarCarga(cargaChofer);

                var cargaMedico = _mapper.Map<CargaGdiaRealPersonal>(asignarCargaDTO.medico);
                cargaMedico.Comentario = asignarCargaDTO.comentario;
                await _cargaGdiaRealPersonalRepository.ReasignarCarga(cargaMedico);

                //gracias lean
                await _orquestadorNotificaciones.NotificarInicioDeCarga(asignarCargaDTO.uMovilId);

                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
    }
}
