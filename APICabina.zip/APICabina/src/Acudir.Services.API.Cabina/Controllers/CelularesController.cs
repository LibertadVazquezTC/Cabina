﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using CabinaOperativa.DTOs;
using CabinaOperativa.DTOs.Asignaciones;
using CabinaOperativa.DTOs.sql_Functions;
using CabinaOperativa.Enums;
using CabinaOperativa.Modelo;
using CabinaOperativa.Orquestadores.Interfaces;
using CabinaOperativa.Repositories;
using CabinaOperativa.Utilities.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace TechMed.Services.Cabina.Controllers
{
    [Route("api/v1/Cabina/[controller]")]
    public class CelularesController : Controller
    {
        private readonly ICmnCelularRepository _cmnCelularRepository;
        private readonly IOrquestadorNotificaciones _orquestadorNotificaciones;

        public CelularesController(ICmnCelularRepository cmnCelularRepository,
            IOrquestadorNotificaciones orquestadorNotificaciones)
        {
            _cmnCelularRepository = cmnCelularRepository;
            _orquestadorNotificaciones = orquestadorNotificaciones;
        }

        /// <summary>
        /// Lista los CmnCelular con su última ubicación y fecha de reporte
        /// </summary>
        /// <response code="200">Devuelve el listado de CmnCelular con su última ubicación y fecha de reporte</response>
        /// <response code="400">Error inesperado</response> 
        [HttpGet]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<string> ObtenerGpsCelulares()
        {
            try
            {
                return await _cmnCelularRepository.ListarGpsCelularesJson();
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        /// <summary>
        /// Devuelve un CmnCelular con su última ubicación y fecha de reporte
        /// </summary>
        /// <param name="cmnCelularId">Id del CmnCelular que se quiere rastrear</param>
        /// <response code="200">Devuelve un CmnCelular con su última ubicación y fecha de reporte</response>
        /// <response code="400">Error inesperado</response> 
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [HttpGet]
        [Route("{cmnCelularId}")]
        public async Task<string> ObtenerGpsCelular(int cmnCelularId)
        {
            try
            {
                return await _cmnCelularRepository.ObtenerGpsCelularJson(cmnCelularId);
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        /// <summary>
        /// Devuelve las ultima 200 ubicaciones que reporto un CmnCelular
        /// </summary>
        /// <param name="cmnCelularId">Id del CmnCelular que se quiere rastrear</param>
        /// <response code="200">Devuelve las ultima 200 ubicaciones que reporto un CmnCelular</response>
        /// <response code="400">Error inesperado</response> 
        [HttpGet]
        [Route("{cmnCelularId}/Recorrido")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<string> ObtenerRecorridoGpsCelular(int cmnCelularId)
        {
            try
            {
                return await _cmnCelularRepository.ListarHistoricoGpsCelularJson(cmnCelularId);
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        /// <summary>
        /// Devuelve el celular asociado a una asignación. Puede ser un médico de visitas o equipo Acudir.
        /// </summary>
        /// <param name="pedidoTramoProveedorUMovilHorarioId">Id del pedidoTramoProveedorUMovilHorario a consultar</param>
        /// <response code="200">Se notifico correctamente</response>
        /// <response code="409">No se pudo notificar por no cumplirse una regla de negocio</response>
        /// <response code="400">Error inesperado</response> 
        [HttpGet]
        [Route("Asignaciones/{pedidoTramoProveedorUMovilHorarioId}")]
        [ProducesResponseType(typeof(fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> ObtenerCmnCelularPorPedidoTramoProveedorUMovilHorarioId(int pedidoTramoProveedorUMovilHorarioId)
        {
            try
            {
                fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular = await _orquestadorNotificaciones.ObtenerCmnCelularPorPedidoTramoProveedorUMovilHorarioId(pedidoTramoProveedorUMovilHorarioId);
                if (cmnCelular is null)
                    return NotFound($"No se encontró celular para la asignación {pedidoTramoProveedorUMovilHorarioId}");

                return Ok(cmnCelular);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
    }
}
