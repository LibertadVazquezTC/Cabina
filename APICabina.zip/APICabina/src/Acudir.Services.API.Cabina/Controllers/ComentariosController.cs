﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CabinaOperativa.Repositories;
using CabinaOperativa.Enums;
using CabinaOperativa.Modelo;
using AutoMapper;
using System.Collections.Generic;
using CabinaOperativa.DTOs.Comentarios;
using System;
using System.Net;

namespace TechMed.Services.Cabina.Controllers
{
    [Route("api/v1/Cabina/[controller]")]
    public class ComentariosController : Controller
    {
        private readonly IMapper _mapper;
        private readonly IPedidoComentarioRepository _pedidoComentarioRepository;

        public ComentariosController(IMapper mapper, IPedidoComentarioRepository pedidoComentarioRepository)
        {
            _mapper = mapper;
            _pedidoComentarioRepository = pedidoComentarioRepository;
        }

        /// <summary>
        /// Lista los PedidoComentario asociados a un Pedido
        /// </summary>
        /// <param name="pedidoId">Id del Pedido al que se le quiere ver los PedidoComentario</param>
        /// <param name="filtro">Los filtros permitidos son: COMENTARIOS o RECLAMOS</param>
        /// <response code="200">Devuelve el listado de PedidoComentario asociados a un Pedido</response>
        /// <response code="409">Devuelve un mensaje de error por no cumplirse una regla de negocio</response>
        /// <response code="400">Error inesperado</response> 
        [HttpGet]
        [Route("{pedidoId}")]
        [ProducesResponseType(typeof(IEnumerable<PedidoComentarioDTO>), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.Conflict)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> Listar(int pedidoId, string filtro)
        {
            try
            {
                List<int> cmnComentarioTipoIds = new List<int>();
                if (filtro.Equals("COMENTARIOS"))
                {
                    cmnComentarioTipoIds.Add((int)CmnComentarioTipoEnum.Interno);
                    cmnComentarioTipoIds.Add((int)CmnComentarioTipoEnum.Externo);
                    cmnComentarioTipoIds.Add((int)CmnComentarioTipoEnum.LinkVideoConsulta);
                    cmnComentarioTipoIds.Add((int)CmnComentarioTipoEnum.ActualizacionDeCoseguro);
                }
                else if (filtro.Equals("RECLAMOS"))
                {
                    cmnComentarioTipoIds.Add((int)CmnComentarioTipoEnum.Reclamo);
                }
                else return Conflict(new { message = $"El filtro {filtro} no está dentro de los permitidos." });

                IEnumerable<PedidoComentario> comentariosDB = await _pedidoComentarioRepository.Listar(pedidoId, cmnComentarioTipoIds.ToArray());
                IEnumerable<PedidoComentarioDTO> comentariosDTO = _mapper.Map<IEnumerable<PedidoComentarioDTO>>(comentariosDB);
                return Ok(comentariosDTO);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Crea un PedidoComentario asociado a un Pedido
        /// </summary>
        /// <param name="pedidoId">Id del Pedido al que se le quiere crear un PedidoComentario</param>
        /// <param name="cmnComentarioTipoId">Id del CmnComentarioTipo que se le quiere asociar al comentario</param>
        /// <param name="comentario">Comentario a agregar</param>
        /// <response code="200">Devuelve el PedidoComentario creado</response>
        /// <response code="400">Error inesperado</response> 
        [HttpPost]
        [Route("{pedidoId}")]
        [ProducesResponseType(typeof(PedidoComentarioDTO), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> Crear(int pedidoId, int cmnComentarioTipoId, string comentario)
        {
            try
            {
                PedidoComentario pedidoComentario = await _pedidoComentarioRepository.Crear(pedidoId, comentario, cmnComentarioTipoId);
                PedidoComentarioDTO pedidoComentarioDTO = _mapper.Map<PedidoComentarioDTO>(pedidoComentario);
                return Ok(pedidoComentario);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
    }
}
