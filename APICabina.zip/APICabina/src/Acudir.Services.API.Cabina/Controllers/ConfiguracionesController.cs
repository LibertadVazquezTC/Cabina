﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CabinaOperativa.Repositories;
using CabinaOperativa.DTOs;
using AutoMapper;
using CabinaOperativa.Modelo;
using CabinaOperativa.DTOs.Configuraciones;
using CabinaOperativa.Utilities;
using System;
using System.Net;
using CabinaOperativa.Constants;
using CabinaOperativa.Exceptions;

namespace TechMed.Services.Cabina.Controllers
{
    [Route("api/v1/Cabina/[controller]")]
    public class ConfiguracionesController : Controller
    {
        private readonly IMapper _mapper;
        private readonly ICmnConfiguracionRepository _cmnConfiguracionRepository;

        public ConfiguracionesController(IMapper mapper, ICmnConfiguracionRepository configuracionRepository)
        {
            _mapper = mapper;
            _cmnConfiguracionRepository = configuracionRepository;
        }

        /// <summary>
        /// Lista las CmnConfiguracion del usuario actual
        /// </summary>
        /// <response code="200">Devuelve el listado de CmnConfiguracion deseado</response>
        /// <response code="400">Error inesperado</response> 
        [HttpGet]
        [Route("{tipo}")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<string> Listar(string tipo)
        {

            try
            {
                bool requiereUsuarioId = tipo == ConstantesCmnConfiguracion.TIPO_TABLA;
                string configuracion = requiereUsuarioId ?
                    await _cmnConfiguracionRepository.ListarPorTipoYUsuario(tipo, SecurityUtility.UsuarioId) :
                    await _cmnConfiguracionRepository.ListarPorTipo(tipo);

                return configuracion;
            }
            catch (ReglaDeNegocioException ex)
            {
                HttpContext.Response.StatusCode = (int)HttpStatusCode.Conflict;
                return ex.Message;
            }
            catch (Exception ex)
            {
                HttpContext.Response.StatusCode = (int)HttpStatusCode.BadRequest;
                return ex.Message;
            }
        }

        /// <summary>
        /// Crea una CmnConfiguracion
        /// </summary>
        /// <param name="crearConfiguracionDTO"></param>
        /// <response code="200">Devuelve el Id de la CmnConfiguracion creada</response>
        /// <response code="400">Error inesperado</response> 
        [HttpPost]
        [Route("")]
        [ProducesResponseType(typeof(Int32), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> Crear([FromBody]CrearConfiguracionDTO crearConfiguracionDTO)
        {
            try
            {
                CmnConfiguracion configuracionNueva = new CmnConfiguracion();
                configuracionNueva.Configuracion = crearConfiguracionDTO.Configuracion;
                configuracionNueva.Tipo = crearConfiguracionDTO.Tipo;

                configuracionNueva = await _cmnConfiguracionRepository.Crear(configuracionNueva);

                return Ok(configuracionNueva.CmnConfiguracionId);
            }
            catch (ReglaDeNegocioException ex)
            {
                return Conflict(new { message = ex.Message });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Actualiza una CmnConfiguracion
        /// </summary>
        /// <param name="cmnConfiguracionId">Id de la CmnConfiguracion que se desea actualizar/param>
        /// <param name="actualizarConfiguracionDTO"></param>
        /// <response code="200">Devuelve el Id de la CmnConfiguracion actualizada</response>
        /// <response code="400">Error inesperado</response> 
        [HttpPut]
        [Route("{cmnConfiguracionId}")]
        [ProducesResponseType(typeof(Int32), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> Actualizar(int cmnConfiguracionId, [FromBody]ActualizarConfiguracionDTO actualizarConfiguracionDTO)
        {
            try
            {
                CmnConfiguracion cmnConfiguracionExistente = await _cmnConfiguracionRepository.Obtener(cmnConfiguracionId);
                if (cmnConfiguracionExistente is null)
                    return NotFound($"No se encontró una configuración con el id {cmnConfiguracionId}.");

                cmnConfiguracionExistente.Configuracion = actualizarConfiguracionDTO.Configuracion;
                cmnConfiguracionExistente = await _cmnConfiguracionRepository.Actualizar(cmnConfiguracionExistente);

                CmnConfiguracionDTO cmnConfiguracionExistenteDTO = _mapper.Map<CmnConfiguracionDTO>(cmnConfiguracionExistente);
                return Ok(cmnConfiguracionExistenteDTO);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Elimina una CmnConfiguracion
        /// </summary>
        /// <param name="cmnConfiguracionId">Id de la CmnConfiguracion que se desea eliminar/param>
        /// <response code="200">La CmnConfiguracion fue eliminada correctamente</response>
        /// <response code="400">Error inesperado</response> 
        [HttpDelete]
        [Route("{cmnConfiguracionId}")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> Eliminar(int cmnConfiguracionId)
        {
            try
            {
                await _cmnConfiguracionRepository.Eliminar(cmnConfiguracionId);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
    }
}
