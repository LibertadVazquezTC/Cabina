﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using AutoMapper;
using CabinaOperativa.DTOs;
using CabinaOperativa.Exceptions;
using CabinaOperativa.Modelo;
using CabinaOperativa.Orquestadores.Interfaces;
using CabinaOperativa.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace TechMed.Services.Cabina.Controllers
{
    [Route("api/v1/Cabina/[controller]")]
    public class CosegurosController : Controller
    {
        private readonly IMapper _mapper;
        private readonly IOrquestadorCoseguro _orquestadorCoseguro;
        private readonly IPedidoCoseguroRepository _pedidoCoseguroRepository;
        private readonly IPedidoCoseguroTipoNoCobroRepository _pedidoCoseguroTipoNoCobroRepository;

        public CosegurosController(IMapper mapper,
            IOrquestadorCoseguro orquestadorCoseguro,
            IPedidoCoseguroRepository pedidoCoseguroRepository,
            IPedidoCoseguroTipoNoCobroRepository pedidoCoseguroTipoNoCobroRepository)
        {
            _mapper = mapper;
            _orquestadorCoseguro = orquestadorCoseguro;
            _pedidoCoseguroRepository = pedidoCoseguroRepository;
            _pedidoCoseguroTipoNoCobroRepository = pedidoCoseguroTipoNoCobroRepository;
        }

        /// <summary>
        /// Devuelve el coseguro de un pedido
        /// </summary>
        /// <param name="pedidoId">Id del Pedido a consultar el coseguro</param>
        /// <response code="200">Devuelve el coseguro asociado al pedido</response>
        /// <response code="404">No se encontró el coseguro asociado al pedido</response>
        /// <response code="400">Error inesperado</response>    
        [HttpGet]
        [Route("{pedidoId}")]
        [ProducesResponseType(typeof(PedidoCoseguroDTO), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> ObtenerCoseguro(int pedidoId)
        {
            try
            {
                PedidoCoseguro pedidoCoseguroDb = await _pedidoCoseguroRepository.ObtenerPorPedido(pedidoId);
                if (pedidoCoseguroDb is null)
                    return NotFound($"No se encontró coseguro para el pedido: {pedidoId}.");

                PedidoCoseguroDTO pedidoCoseguroDTO = _mapper.Map<PedidoCoseguroDTO>(pedidoCoseguroDb);
                return Ok(pedidoCoseguroDTO);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Actualiza de modo forzado el coseguro de un pedido
        /// </summary>
        /// <param name="pedidoId">Id del Pedido al que se le quiere actualizar el coseguro</param>
        /// <param name="coseguroForzadoDTO">Data transfer object</param>
        /// <response code="200">El coseguro se actualizó correctamente</response>
        /// <response code="409">Algún dato enviado es erroneo</response>
        /// <response code="400">Error inesperado</response>    
        [HttpPut]
        [Route("{pedidoId}")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.Conflict)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> ActualizarCoseguroForzadamente(int pedidoId, [FromBody] CoseguroForzadoDTO coseguroForzadoDTO)
        {
            try
            {
                await _orquestadorCoseguro.ActualizarCoseguroForzadamente(pedidoId, coseguroForzadoDTO.ValorCoseguro, coseguroForzadoDTO.MotivoActualizacion);
                return Ok();
            }
            catch (DatoErroneoException ex)
            {
                return Conflict(new { message = ex.Message });
            }
            catch (ReglaDeNegocioException ex)
            {
                return Conflict(new { message = ex.Message });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Devuelve el listado de posibles tipos no cobro de un coseguro
        /// </summary>
        /// <response code="200">Id del Pedido creado</response>
        /// <response code="400">Error inesperado</response>    
        [HttpGet]
        [Route("TiposNoCobro")]
        [ProducesResponseType(typeof(int), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> ListarTiposNoCobro()
        {
            try
            {
                IEnumerable<PedidoCoseguroTipoNoCobro> pedidoCoseguroTipoNoCobroDb = await _pedidoCoseguroTipoNoCobroRepository.Listar();
                if (pedidoCoseguroTipoNoCobroDb is null || pedidoCoseguroTipoNoCobroDb.Count() == 0)
                    return NotFound();

                IEnumerable<PedidoCoseguroTipoNoCobroDTO> pedidoCoseguroTipoNoCobroDTO = _mapper.Map<IEnumerable<PedidoCoseguroTipoNoCobroDTO>>(pedidoCoseguroTipoNoCobroDb);
                return Ok(pedidoCoseguroTipoNoCobroDTO);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
    }
}
