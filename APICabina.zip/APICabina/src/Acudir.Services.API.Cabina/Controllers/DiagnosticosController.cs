﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using AutoMapper;
using CabinaOperativa.DTOs;
using CabinaOperativa.Modelo;
using CabinaOperativa.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace TechMed.Services.Cabina.Controllers
{
    [Route("api/v1/Cabina/[controller]")]
    public class DiagnosticosController : Controller
    {
        private readonly IMapper _mapper;
        private readonly IDiagnosticoRepository _diagnosticoRepository;

        public DiagnosticosController(IMapper mapper,
            IDiagnosticoRepository diagnosticoRepository)
        {
            _mapper = mapper;
            _diagnosticoRepository = diagnosticoRepository;
        }

        /// <summary>
        /// Lista todos los diagnosticos
        /// </summary>
        /// <response code="200">Devuelve el listado de diagnosticos</response>
        /// <response code="404">No se encontraron diagnosticos</response>
        /// <response code="400">Error inesperado</response> 
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<DiagnosticoDTO>), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<ActionResult> ListarDiagnosticos()
        {
            try
            {
                IEnumerable<Diagnostico> diagnosticosDb = await _diagnosticoRepository.Listar();
                if (diagnosticosDb is null || diagnosticosDb.Count() == 0)
                    return NotFound();

                IEnumerable<DiagnosticoDTO> diagnosticosDTO = _mapper.Map<IEnumerable<DiagnosticoDTO>>(diagnosticosDb);
                return Ok(diagnosticosDTO);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
    }
}
