﻿using System;
using System.Net;
using System.Threading.Tasks;
using CabinaOperativa.DTOs;
using CabinaOperativa.Modelo;
using CabinaOperativa.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace TechMed.Services.Cabina.Controllers
{
    [Route("api/v1/Cabina/[controller]")]
    public class EfectoresController : Controller
    {
        private readonly IEfectorRepository _efectorRepository;

        public EfectoresController(IEfectorRepository efectorRepository)
        {
            _efectorRepository = efectorRepository;
        }

        /// <summary>
        /// Lista los Efector de un contrato en especifico
        /// </summary>
        /// <param name="contratoId">Id del Contrato para el que se quiere buscar los Efector</param>
        /// <response code="200">Devuelve el listado de Efector de un contrato en específico</response>
        /// <response code="400">Error inesperado</response> 
        [HttpGet]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<string> ObtenerEfectores(int contratoId)
        {
            try
            {
                return await _efectorRepository.ListarPorContratoJson(contratoId);
            }
            catch (Exception ex)
            {
                HttpContext.Response.StatusCode = (int)HttpStatusCode.BadRequest;
                return ex.Message;
            }
        }
    }
}
