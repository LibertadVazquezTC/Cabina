﻿using System;
using System.Net;
using System.Threading.Tasks;
using AutoMapper;
using CabinaOperativa.DTOs;
using CabinaOperativa.Modelo;
using CabinaOperativa.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace TechMed.Services.Cabina.Controllers
{
    [Route("api/v1/Cabina/[controller]")]
    public class GpsController : Controller
    {
        private readonly IMapper _mapper;
        private readonly IUMovilRepository _uMovilRepository;

        public GpsController(IMapper mapper,
            IUMovilRepository uMovilRepository)
        {
            _mapper = mapper;
            _uMovilRepository = uMovilRepository;
        }

        /// <summary>
        /// Devuelve el ultimo reporte del gps del móvil
        /// </summary>
        /// <param name="gpsMovilId">Id del móvil de gps que se desea consultar</param>
        /// <response code="200">Devuelve el ultimo reporte del gps del móvil</response>
        /// <response code="400">Error inesperado</response> 
        [HttpGet]
        [Route("{gpsMovilId}")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<string> ObtenerUltimoReporteGpsMovilJson(int gpsMovilId)
        {
            try
            {
                string jsonResponse = await _uMovilRepository.ObtenerUltimoReporteGpsMovilJson(gpsMovilId);
                HttpContext.Response.StatusCode = (int)HttpStatusCode.OK;
                return jsonResponse;
            }
            catch (Exception ex)
            {
                HttpContext.Response.StatusCode = (int)HttpStatusCode.BadRequest;
                return ex.Message;
            }
        }     
    }
}
