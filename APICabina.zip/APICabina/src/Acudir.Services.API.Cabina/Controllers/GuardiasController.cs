﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CabinaOperativa.Repositories;
using System.Collections.Generic;
using CabinaOperativa.Modelo;
using System.Linq;
using System.Net;
using System;
using CabinaOperativa.Enums;

namespace TechMed.Services.Cabina.Controllers
{
    [Route("api/v1/Cabina/[controller]")]
    public class GuardiasController : Controller
    {
        private readonly IGdiaRealEquipoRepository _guardiaRepository;
        private readonly IPedidoTramoRepository _pedidoTramoRepository;
        private readonly IGdiaRealEquipoMovilRepository _gdiaRealEquipoMovilRepository;

        public GuardiasController(IGdiaRealEquipoRepository guardiaRepository, IPedidoTramoRepository pedidoTramoRepository, IGdiaRealEquipoMovilRepository gdiaRealEquipoMovilRepository)
        {
            _guardiaRepository = guardiaRepository;
            _pedidoTramoRepository = pedidoTramoRepository;
            _gdiaRealEquipoMovilRepository = gdiaRealEquipoMovilRepository;
        }

        /// <summary>
        /// Lista las guardias que cumplan con el concepto de activas
        /// </summary>
        /// <param name="gdiaEquipoIds">GdiaEquipoIds que se desean ver (separados por coma)</param>
        /// <param name="filtroProveedor">Todos = 0, SoloAcudir = 1, SoloProveedores = 2</param>
        /// <response code="200">Devuelve el listado de guardias que cumplan con el concepto de activas</response>
        /// <response code="400">Error inesperado</response> 
        [HttpGet]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<string> ListarGuardiasActivasJson(string gdiaEquipoIds, int filtroProveedor)
        {
            try
            {
                if (filtroProveedor != 0 && filtroProveedor != 1 && filtroProveedor != 2)
                {
                    HttpContext.Response.StatusCode = (int)HttpStatusCode.Conflict;
                    return $"Los filtroProveedor permitidos son 0, 1 y 2.";
                }

                return await _guardiaRepository.ListarGuardiasActivasJson(gdiaEquipoIds, filtroProveedor);
            }
            catch (Exception ex)
            {
                HttpContext.Response.StatusCode = (int)HttpStatusCode.BadRequest;
                return $"Error cargando las guardias. {ex.Message}.";
            }
        }

        /// <summary>
        /// Lista las guardias que cumplan con el concepto de activas, sugeridas para un Pedido en especifico.
        /// </summary>
        /// <param name="pedidoId">Id del Pedido para el cual se quiere sugerir guardias activas</param>
        /// <param name="gdiaEquipoIds">GdiaEquipoIds que se desean ver (separados por coma)</param>
        /// <param name="filtroProveedor">Todos = 0, SoloAcudir = 1, SoloProveedores = 2</param>
        /// <response code="200">Devuelve el listado de guardias que cumplan con el concepto de activas y sean las mejores para un Pedido</response>
        /// <response code="400">Error inesperado</response> 
        [HttpGet]
        [Route("{pedidoId}/Sugeridas")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<string> ObtenerGuardiasSugeridasPorPedidoTramoJson(int pedidoId, string gdiaEquipoIds, int filtroProveedor)
        {
            try
            {
                if (filtroProveedor != 0 && filtroProveedor != 1 && filtroProveedor != 2)
                {
                    HttpContext.Response.StatusCode = (int)HttpStatusCode.Conflict;
                    return $"Los filtroProveedor permitidos son 0, 1 y 2.";
                }

                IEnumerable<PedidoTramo> pedidoTramos = await _pedidoTramoRepository.ListarPorPedido(pedidoId);
                if (pedidoTramos != null && pedidoTramos.Count() == 1)
                    return await _guardiaRepository.ListarGuardiasActivasSugeridasPorPedidoTramoJson(pedidoTramos.FirstOrDefault().PedidoTramoId, gdiaEquipoIds, filtroProveedor);
                return "[]";
            }
            catch (Exception ex)
            {
                HttpContext.Response.StatusCode = (int)HttpStatusCode.BadRequest;
                return $"Error cargando las guardias. {ex.Message}.";
            }


        }
        /// <summary>
        /// Lista los moviles pausados en tiempo real
        /// </summary>

        /// <response code="200">Devuelve el listado de moviles en pausa</response>
        /// <response code="400">Error inesperado</response> 
        [HttpGet]
        [Route("Equipos/Pausados")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ResponseCache(Duration = 15, Location = ResponseCacheLocation.Any)]
        public async Task<string> ListaMovilesEnPausa()
        {
            try
            {
                 return await _gdiaRealEquipoMovilRepository.ObtenerMovilesPausados();
            }
            catch (Exception ex)
            {
                HttpContext.Response.StatusCode = (int)HttpStatusCode.BadRequest;
                return $"Error cargando los moviles en pausa. {ex.Message}.";
            }
        }
        /// <summary>
        /// Lista moviles pausados que estan por finalizar su pausa
        /// </summary>

        /// <response code="200">Devuelve el listado de moviles en pausa</response>
        /// <response code="400">Error inesperado</response> 
        [HttpGet]
        [Route("Equipos/Pausados/PorFinalizar")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ResponseCache(Duration = 15, Location = ResponseCacheLocation.Any)]
        public async Task<string> ListaMovilesEnPausaporFinalizar()
        {
            try
            {
                return await _gdiaRealEquipoMovilRepository.ObtenerMovilesPausadosPorFinalizar();
            }
            catch (Exception ex)
            {
                HttpContext.Response.StatusCode = (int)HttpStatusCode.BadRequest;
                return $"Error cargando los moviles en pausa. {ex.Message}.";
            }
        }
        /// <summary>
        /// Lista los moviles pausados en tiempo real
        /// </summary>

        /// <response code="200">Devuelve la cantidad de moviles en pausa</response>
        /// <response code="400">Error inesperado</response> 
        [HttpGet]
        [Route("Equipos/Pausados/Cantidad")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ResponseCache(Duration = 15, Location = ResponseCacheLocation.Any)]
        public async Task<string> CantidadMovilesPausados()
        {
            try
            {
                int cantidad = await _gdiaRealEquipoMovilRepository.ObtenerCantidadMovilesPausados();
                return $"{cantidad}";
            }
            catch (Exception ex)
            {
                HttpContext.Response.StatusCode = (int)HttpStatusCode.BadRequest;
                return $"Error cargando los moviles en pausa. {ex.Message}.";
            }
        }
        /// <summary>
        /// Lista los moviles pausados en tiempo real
        /// </summary>

        /// <response code="200">Devuelve la cantidad de moviles en pausa</response>
        /// <response code="400">Error inesperado</response> 
        [HttpGet]
        [Route("Equipos/Pausados/TiempoLimiteAlerta")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<string> TiempoLimiteAlerta()
        {
            try
            {
                int tiempo = await _gdiaRealEquipoMovilRepository.TiempoLimiteAletaPausas();
                return $"{tiempo}";
            }
            catch (Exception ex)
            {
                HttpContext.Response.StatusCode = (int)HttpStatusCode.BadRequest;
                return $"Error en la obtencion del tiempo limite de alerta de pausas. {ex.Message}.";
            }
        }
    }
}
