﻿using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using CabinaOperativa.Utilities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

namespace TechMed.Services.Cabina.Controllers
{
    [Route("api/v1/Cabina/[controller]")]
    public class LlamadasController : Controller
    {
        private readonly IConfiguration _config;
        public LlamadasController(IConfiguration config)
        {
            _config = config;
        }

        /// <summary>
        /// Llama a un número de telefono en especifico
        /// </summary>
        /// <param name="destino">Número de teléfono al que se quiere llamar</param>
        /// <response code="200">El llamado se realizo exitosamente</response>
        /// <response code="400">Error inesperado</response> 
        [HttpPost]
        [Route("{destino}")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> LlamarDestino(string destino)
        {
            try
            {
                destino = 9 + destino;
                string avayaApiUrl = _config.GetValue<string>("AvayaApiUrl");
                string ip = SecurityUtility.RemoteIpAddress;

                using (HttpClient httpClient = new HttpClient())
                {                 
                    httpClient.BaseAddress = new Uri(avayaApiUrl);
                    httpClient.DefaultRequestHeaders.Accept.Clear();
                    httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    await httpClient.PutAsync("/api/Llamada?ip=" + ip + "&destino=" + destino, new StringContent(JsonConvert.SerializeObject(null), Encoding.UTF8, "application/json"));
                }

                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }     
    }
}
