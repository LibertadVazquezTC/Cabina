﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using AutoMapper;
using CabinaOperativa.DTOs;
using CabinaOperativa.DTOs.Direccion;
using CabinaOperativa.Modelo;
using CabinaOperativa.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace TechMed.Services.Cabina.Controllers
{
    [Route("api/v1/Cabina/[controller]")]
    public class LocalidadesController : Controller
    {
        private readonly IMapper _mapper;
        private readonly IDireccionLocalidadRepository _direccionLocalidadRepository;

        public LocalidadesController(IMapper mapper, IDireccionLocalidadRepository direccionLocalidadRepository)
        {
            _mapper = mapper;
            _direccionLocalidadRepository = direccionLocalidadRepository;
        }

        /// <summary>
        /// Lista las DireccionLocalidad
        /// </summary>
        /// <response code="200">Devuelve el listado DireccionLocalidad</response>
        /// <response code="400">Error inesperado</response> 
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<DireccionLocalidadDTO>), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> Listar()
        {
            try
            {
                IEnumerable<DireccionLocalidad> direccionLocalidades = await _direccionLocalidadRepository.Listar();
                IEnumerable<DireccionLocalidadDTO> direccionLocalidadesDTO = _mapper.Map<IEnumerable<DireccionLocalidadDTO>>(direccionLocalidades);
                return Ok(direccionLocalidadesDTO);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Lista las DireccionLocalidad
        /// </summary>
        /// <param name="direccionLocalidadId">Id de la DireccionLocalidad deseada</param>
        /// <response code="200">Devuelva la DireccionLocalidad deseada</response>
        /// <response code="400">Error inesperado</response> 
        [HttpGet]
        [Route("{direccionLocalidadId}")]
        [ProducesResponseType(typeof(DireccionLocalidadDTO), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> Obtener(int direccionLocalidadId)
        {
            try
            {
                DireccionLocalidad direccionLocalidad = await _direccionLocalidadRepository.Obtener(direccionLocalidadId);
                DireccionLocalidadDTO direccionLocalidadDTO = _mapper.Map<DireccionLocalidadDTO>(direccionLocalidad);
                return Ok(direccionLocalidadDTO);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
    }
}
