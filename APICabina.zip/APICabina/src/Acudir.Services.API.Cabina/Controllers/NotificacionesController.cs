﻿using System;
using System.Net;
using System.Threading.Tasks;
using CabinaOperativa.Exceptions;
using CabinaOperativa.Modelo;
using CabinaOperativa.Orquestadores.Interfaces;
using CabinaOperativa.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace TechMed.Services.Cabina.Controllers
{
    [Route("api/v1/Cabina/[controller]")]
    public class NotificacionesController : Controller
    {
        private readonly IOrquestadorNotificaciones _orquestadorNotificaciones;
        private readonly IOrquestadorCoseguro _orquestadorCoseguro;
        private readonly IPedidoTramoProveedorUMovilHorarioRepository _pedidoTramoProveedorUMovilhorarioRepository;

        public NotificacionesController(IOrquestadorNotificaciones orquestadorNotificaciones,
            IOrquestadorCoseguro orquestadorCoseguro,
            IPedidoTramoProveedorUMovilHorarioRepository pedidoTramoProveedorUMovilhorarioRepository)
        {
            _orquestadorNotificaciones = orquestadorNotificaciones;
            _orquestadorCoseguro = orquestadorCoseguro;
            _pedidoTramoProveedorUMovilhorarioRepository = pedidoTramoProveedorUMovilhorarioRepository;
        }

        /// <summary>
        /// Notifica al DIM la asignación
        /// </summary>
        /// <param name="pedidoTramoProveedorUMovilHorarioId">Id del pedidoTramoProveedorUMovilHorario asignado</param>
        /// <response code="200">Se notifico correctamente</response>
        /// <response code="409">No se pudo notificar por no cumplirse una regla de negocio</response>
        /// <response code="400">Error inesperado</response> 
        [HttpPost]
        [Route("Asignaciones/{pedidoTramoProveedorUMovilHorarioId}")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.Conflict)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> NotificarAsignacion(int pedidoTramoProveedorUMovilHorarioId)
        {
            try
            {
                await _orquestadorNotificaciones.NotificarCoronavirus(pedidoTramoProveedorUMovilHorarioId);
                await _orquestadorNotificaciones.NotificarAsignacion(pedidoTramoProveedorUMovilHorarioId);
                PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario = await _pedidoTramoProveedorUMovilhorarioRepository.Obtener(pedidoTramoProveedorUMovilHorarioId);
                await _orquestadorCoseguro.EjecutarReglasDeCoseguroParaElPedido(pedidoTramoProveedorUMovilHorario.PedidoTramo.PedidoId, true);
                return Ok(new { fecha = DateTime.Now });
            }
            catch (FalloDeNotificacionException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
            catch (DatoErroneoException ex)
            {
                return Conflict(new { message = ex.Message });
            }
            catch (ReglaDeNegocioException ex)
            {
                return Conflict(new { message = ex.Message });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Notifica al DIM la desasignación
        /// </summary>
        /// <param name="pedidoTramoProveedorUMovilHorarioId">Id del PedidoTramoProveedorUMovilHorario desasignado</param>
        /// <response code="200">Se notifico correctamente</response>
        /// <response code="409">No se pudo notificar por no cumplirse una regla de negocio</response>
        /// <response code="400">Error inesperado</response> 
        [HttpDelete]
        [Route("Asignaciones/{pedidoTramoProveedorUMovilHorarioId}")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.Conflict)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> NotificarDesasignacion(int pedidoTramoProveedorUMovilHorarioId)
        {
            try
            {
                await _orquestadorNotificaciones.NotificarDesasignacion(pedidoTramoProveedorUMovilHorarioId);
                PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario = await _pedidoTramoProveedorUMovilhorarioRepository.Obtener(pedidoTramoProveedorUMovilHorarioId);
                await _orquestadorCoseguro.EjecutarReglasDeCoseguroParaElPedido(pedidoTramoProveedorUMovilHorario.PedidoTramo.PedidoId, false);
                return Ok(new { fecha = DateTime.Now });
            }
            catch (FalloDeNotificacionException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
            catch (DatoErroneoException ex)
            {
                return Conflict(new { message = ex.Message });
            }
            catch (ReglaDeNegocioException ex)
            {
                return Conflict(new { message = ex.Message });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Notifica al DIM la anulación
        /// </summary>
        /// <param name="pedidoId">Id del Pedido anulado</param>
        /// <response code="200">Se notifico correctamente</response>
        /// <response code="409">No se pudo notificar por no cumplirse una regla de negocio</response>
        /// <response code="400">Error inesperado</response> 
        [HttpDelete]
        [Route("Pedidos/{pedidoId}")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.Conflict)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> NotificarAnulacion(int pedidoId)
        {
            try
            {
                await _orquestadorNotificaciones.NotificarAnulacion(pedidoId);
                return Ok(new { fecha = DateTime.Now });
            }
            catch (FalloDeNotificacionException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
            catch (DatoErroneoException ex)
            {
                return Conflict(new { message = ex.Message });
            }
            catch (ReglaDeNegocioException ex)
            {
                return Conflict(new { message = ex.Message });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Notifica al DIM la actualización de un punto
        /// </summary>
        /// <param name="pedidoTramoDetalleId">Id del PedidoTramoDetalle actualizado</param>
        /// <response code="200">Se notifico correctamente</response>
        /// <response code="409">No se pudo notificar por no cumplirse una regla de negocio</response>
        /// <response code="400">Error inesperado</response> 
        [HttpPut]
        [Route("Punto/{pedidoTramoDetalleId}")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.Conflict)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> NotificarActualizacionPunto(int pedidoTramoDetalleId)
        {
            try
            {
                await _orquestadorNotificaciones.NotificarActualizacionPunto(pedidoTramoDetalleId);
                return Ok(new { fecha = DateTime.Now });
            }
            catch(FalloDeNotificacionException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
            catch (DatoErroneoException ex)
            {
                return Conflict(new { message = ex.Message });
            }
            catch (ReglaDeNegocioException ex)
            {
                return Conflict(new { message = ex.Message });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Notifica al DIM la actualización de un horario
        /// </summary>
        /// <param name="pedidoTramoProveedorUMovilHorarioId">Id del PedidoTramoProveedorUMovilHorario actualizado</param>
        /// <param name="tipoHorario">Horario a notificar. Puede ser 'OrigenArribo' 'OrigenPartida'</param>
        /// <response code="200">Se notifico correctamente</response>
        /// <response code="409">No se pudo notificar por no cumplirse una regla de negocio</response>
        /// <response code="400">Error inesperado</response> 
        [HttpPut]
        [Route("Asignaciones/{pedidoTramoProveedorUMovilHorarioId}/Horarios/{tipoHorario}")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.Conflict)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> NotificarActualizacionHorario(int pedidoTramoProveedorUMovilHorarioId, string tipoHorario)
        {
            try
            {
                await _orquestadorNotificaciones.NotificarActualizacionHorario(pedidoTramoProveedorUMovilHorarioId, tipoHorario);
                return Ok(new { fecha = DateTime.Now });
            }
            catch (FalloDeNotificacionException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
            catch (DatoErroneoException ex)
            {
                return Conflict(new { message = ex.Message });
            }
            catch (ReglaDeNegocioException ex)
            {
                return Conflict(new { message = ex.Message });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
    }
}
