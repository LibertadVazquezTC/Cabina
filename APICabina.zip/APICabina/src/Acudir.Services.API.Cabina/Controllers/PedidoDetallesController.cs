﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CabinaOperativa.Repositories;
using CabinaOperativa.DTOs;
using CabinaOperativa.ActionFilters;
using CabinaOperativa.Utilities.Interfaces;
using CabinaOperativa.Enums;
using CabinaOperativa.Modelo;
using System;
using System.Net;
using AutoMapper;
using CabinaOperativa.Exceptions;
using CabinaOperativa.DTOs.Archivar;
using CabinaOperativa.Orquestadores.Interfaces;

namespace TechMed.Services.Cabina.Controllers
{
    [Route("api/v1/Cabina/[controller]")]
    public class PedidoDetallesController : Controller
    {
        private readonly IPedidoDetalleRepository _pedidoDetalleRepository;

        public PedidoDetallesController(IPedidoDetalleRepository pedidoDetallesRepository)
        {
            _pedidoDetalleRepository = pedidoDetallesRepository;
        }

        /// <summary>
        /// Devuelve el sintoma del pedido especificado por parametro
        /// </summary>
        /// <response code="200">Devuelve el sintoma del pedido</response>
        /// <response code="404">En caso de no encontrar ningun sintoma para el pedido especificado</response>
        /// <response code="400">Error inesperado</response>            
        [HttpGet]
        [Route("{pedidoId}/Sintoma")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> ObtenerSintoma(int pedidoId)
        {
            try
            {
                string sintomaCompleto = await _pedidoDetalleRepository.ObtenerSintomaPorPedido(pedidoId);

                if (sintomaCompleto.Length > 0)
                    return Ok( new { sintomaCompleto });

                return NotFound($"No se encontró ningún sintoma para el pedido {pedidoId}.");
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
    }
}
