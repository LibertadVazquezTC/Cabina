﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CabinaOperativa.Repositories;
using CabinaOperativa.Enums;
using CabinaOperativa.Modelo;
using AutoMapper;
using System.Collections.Generic;
using CabinaOperativa.DTOs.Comentarios;
using System;
using System.Net;
using CabinaOperativa.DTOs;

namespace TechMed.Services.Cabina.Controllers
{
    [Route("api/v1/Cabina/[controller]")]
    public class PedidoDiagnosticoMedicoController : Controller
    {
        private readonly IMapper _mapper;
        private readonly IPedidoDiagnosticoMedicoRepository _pedidoDiagnosticoMedicoRepository;

        public PedidoDiagnosticoMedicoController(IMapper mapper,
            IPedidoDiagnosticoMedicoRepository pedidoDiagnosticoMedicoRepository)
        {
            _mapper = mapper;
            _pedidoDiagnosticoMedicoRepository = pedidoDiagnosticoMedicoRepository;
        }

        /// <summary>
        /// Devuelve el diagnóstico médico de un pedido
        /// </summary>
        /// <param name="pedidoId">Id del pedido al que se le quiere consultar el diagnóstico médico</param>
        /// <response code="200">Devuelve el diagnóstico médico de un pedido</response>
        /// <response code="404">No se encontró el diagnóstico médico del pedido</response>
        /// <response code="400">Error inesperado</response> 
        [HttpGet]
        [Route("{pedidoId}")]
        [ProducesResponseType(typeof(PedidoDiagnosticoMedicoDTO), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> ObtenerDiagnosticoMedicoPorPedido(int pedidoId)
        {
            try
            {
                PedidoDiagnosticoMedico pedidoDiagnosticoMedicoDb = await _pedidoDiagnosticoMedicoRepository.ObtenerPorPedido(pedidoId);
                if (pedidoDiagnosticoMedicoDb is null)
                    return NotFound();

                PedidoDiagnosticoMedicoDTO pedidoDiagnosticoMedicoDTO = _mapper.Map<PedidoDiagnosticoMedicoDTO>(pedidoDiagnosticoMedicoDb);
                return Ok(pedidoDiagnosticoMedicoDTO);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
    }
}
