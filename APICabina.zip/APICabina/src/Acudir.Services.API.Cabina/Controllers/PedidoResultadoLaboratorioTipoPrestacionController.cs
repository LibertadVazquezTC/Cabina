﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CabinaOperativa.Repositories;
using CabinaOperativa.Modelo;
using System;
using System.Net;
using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using CabinaOperativa.DTOs;

namespace TechMed.Services.Cabina.Controllers
{
    [Route("api/v1/Cabina/[controller]")]
    public class PedidoResultadoLaboratorioTipoPrestacionController : Controller
    {
        private readonly IPedidoResultadoLaboratorioTipoPrestacionRepository _pedidoResultadoLaboratorioTipoPrestacionRepository;
        private readonly IPedidoRepository _pedidoRepository;
        private readonly IMapper _mapper;

        public PedidoResultadoLaboratorioTipoPrestacionController(IPedidoRepository pedidoRepository, IPedidoResultadoLaboratorioTipoPrestacionRepository pedidoDetallesRepository, IMapper mapper)
        {
            _pedidoRepository = pedidoRepository;
            _pedidoResultadoLaboratorioTipoPrestacionRepository = pedidoDetallesRepository;
            _mapper = mapper;
        }

        /// <summary>
        /// Devuelve una lista con los resultados de laboratorio segun el tipo de prestacion del pedido
        /// </summary>
        /// <param name="pedidoId"></param>
        /// <response code="200">Devuelve una lista con los resultados de laboratorio segun el tipo de prestacion del pedido</response>
        /// <response code="404">En caso de no encontrar ningun Resultado de Laboratorio para el Tipo Prestacion especificado</response>
        /// <response code="400">Error inesperado</response>            
        [HttpGet("{pedidoId}")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> ObtenerResultadosSegunTipoPrestacion(int pedidoId)
        {
            try
            {
                Pedido pedido = await _pedidoRepository.Obtener(pedidoId);
                int tipoPrestacionId = pedido.TipoPrestacion.TipoPrestacionId;

                IEnumerable<PedidoResultadoLaboratorioTipoPrestacion> pedidoResultadoLaboratorioTipoPrestacion = await _pedidoResultadoLaboratorioTipoPrestacionRepository.ListarByTipoPrestacion(tipoPrestacionId);

                if (pedidoResultadoLaboratorioTipoPrestacion.Count() > 0)
                {
                    IEnumerable<PedidoResultadoLaboratorioTipoPrestacionDTO> pedidoResultadoLaboratorioTipoPrestacionDTO = _mapper.Map<IEnumerable<PedidoResultadoLaboratorioTipoPrestacionDTO>>(pedidoResultadoLaboratorioTipoPrestacion);
                    return Ok(pedidoResultadoLaboratorioTipoPrestacionDTO);
                }

                return NotFound("No se encontró ningún Resultado de Laboratorio para el Tipo de prestacion enviado.");
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
    }
}
