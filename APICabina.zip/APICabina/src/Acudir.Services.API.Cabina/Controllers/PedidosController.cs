﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CabinaOperativa.Repositories;
using CabinaOperativa.DTOs;
using CabinaOperativa.ActionFilters;
using CabinaOperativa.Enums;
using CabinaOperativa.Modelo;
using System;
using System.Net;
using AutoMapper;
using CabinaOperativa.Exceptions;
using CabinaOperativa.DTOs.Archivar;
using CabinaOperativa.Orquestadores.Interfaces;
using CabinaOperativa.Exceptions.SISA;

namespace TechMed.Services.Cabina.Controllers
{
    [Route("api/v1/Cabina/[controller]")]
    public class PedidosController : Controller
    {
        private readonly IMapper _mapper;

        private readonly IOrquestadorParaArchivarPedido _orquestadorParaArchivarPedido;
        private readonly IOrquestadorCoseguro _orquestadorCoseguro;
        private readonly IOrquestadorNotificaciones _orquestadorNotificaciones;
        private readonly IOrquestadorAsignacion _orquestadorAsignacion;

        private readonly IPedidoRepository _pedidoRepository;
        private readonly IPedidoEntidadLogRepository _pedidoEntidadLogRepository;
        private readonly IPedidoComentarioRepository _pedidoComentarioRepository;

        public PedidosController(IMapper mapper,

            IOrquestadorParaArchivarPedido orquestadorParaArchivarPedido,
            IOrquestadorCoseguro orquestadorCoseguro,
            IOrquestadorNotificaciones orquestadorNotificaciones,
            IOrquestadorAsignacion orquestadorAsignacion,

            IPedidoRepository pedidoRepository,
            IPedidoEntidadLogRepository pedidoEntidadLogRepository,
            IPedidoComentarioRepository pedidoComentarioRepository)
        {
            _mapper = mapper;

            _orquestadorParaArchivarPedido = orquestadorParaArchivarPedido;
            _orquestadorCoseguro = orquestadorCoseguro;
            _orquestadorNotificaciones = orquestadorNotificaciones;
            _orquestadorAsignacion = orquestadorAsignacion;

            _pedidoRepository = pedidoRepository;
            _pedidoEntidadLogRepository = pedidoEntidadLogRepository;
            _pedidoComentarioRepository = pedidoComentarioRepository;
        }

        /// <summary>
        /// Lista los pedidos pendientes, en curso y finalizados
        /// </summary>
        /// <response code="200">Devuelve los pedidos pendientes, en curso y finalizados</response>
        /// <response code="400">Error inesperado</response>            
        [HttpGet]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<string> ObtenerPedidos()
        {
            try
            {
                return await _pedidoRepository.ListarJson();
            }
            catch (Exception ex)
            {
                HttpContext.Response.StatusCode = (int)HttpStatusCode.BadRequest;
                return ex.Message;
            }
        }

        /// <summary>
        /// Devuelve un pedido
        /// </summary>
        /// <param name="pedidoId">Id del Pedido deseado</param>
        /// <response code="200">Devuelve un pedido en especifico</response>
        /// <response code="400">Error inesperado</response>    
        [HttpGet]
        [Route("{pedidoId}")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<string> ObtenerPedido(int pedidoId)
        {
            return await _pedidoRepository.ObtenerJson(pedidoId);
        }

        /// <summary>
        /// Devuelve la trazabilidad de un pedido
        /// </summary>
        /// <param name="pedidoId">Id del Pedido del cual se desea obtener la trazabilidad</param>
        /// <response code="200">Devuelve la trazabilidad de un pedido en especifico</response>
        /// <response code="400">Error inesperado</response>      
        [HttpGet]
        [Route("{pedidoId}/Trazabilidad")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<string> Trazabilidad(int pedidoId)
        {
            try
            {
                return await _pedidoRepository.ObtenerTrazabilidadJson(pedidoId);
            }
            catch (Exception ex)
            {
                HttpContext.Response.StatusCode = (int)HttpStatusCode.BadRequest;
                return ex.Message;
            }
        }

        /// <summary>
        /// Actualiza el estado de un pedido
        /// </summary>
        /// <param name="pedidoId">Id del Pedido a actualizar</param>
        /// <param name="anularPedidoDTO">Data transfer object</param>
        /// <response code="200"></response>
        /// <response code="400">Error inesperado</response>     
        [HttpDelete]
        [Route("{pedidoId}")]
        [PedidoEstadoActualizacionFilter]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> AnularPedido(int pedidoId, [FromBody] AnularPedidoDTO anularPedidoDTO)
        {
            try
            {
                TempData["PedidoId"] = pedidoId;
                await _pedidoRepository.ActualizarEstado(pedidoId, (int)PedidoEstadoEnum.Anulado, anularPedidoDTO.PedidoEstadoTipoId, anularPedidoDTO.NuevoComentario);
                await _pedidoEntidadLogRepository.Crear(pedidoId, pedidoId, (int)EntidadLogTipoEstadoEnum.PedidoRechazado, "PedidosController/ActualizarEstado");
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Actualiza el recurso de un pedido, es decir, qué pantalla/s van a ver ese pedido
        /// </summary>
        /// <param name="pedidoId">Id del Pedido a actualizar</param>
        /// <param name="pedidoTipoDespachoId">Id de la pantalla a asignar (codigos, visitas, codigos y visitas, etc) </param>
        /// <response code="200"></response>
        /// <response code="400">Error inesperado</response>     
        [HttpPut]
        [Route("{pedidoId}/Recurso")]
        [PedidoEstadoActualizacionFilter]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> ActualizarRecurso(int pedidoId, int pedidoTipoDespachoId)
        {
            try
            {
                TempData["PedidoId"] = pedidoId;

                Pedido pedidoActualizado = await _pedidoRepository.ActualizarRecurso(pedidoId, pedidoTipoDespachoId);
                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Crea pedido nuevo a partir de otro.
        /// </summary>
        /// <param name="pedidoId">Id del Pedido a recategorizar</param>
        /// <param name="recategorizacionDTO">Data transfer object</param>
        /// <response code="200">Id del Pedido creado</response>
        /// <response code="400">Error inesperado</response>    
        [HttpPost]
        [Route("{pedidoId}/Recategorizacion")]
        [PedidoEstadoActualizacionFilter]
        [ProducesResponseType(typeof(int), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> RecategorizarPedido(int pedidoId, [FromBody] RecategorizacionDTO recategorizacionDTO)
        {
            try
            {
                TempData["PedidoId"] = pedidoId;
                if (recategorizacionDTO.EsPrestacional)
                {
                    int pedidoIdNuevo = await _pedidoRepository.RecategorizarPedido(pedidoId,
                        recategorizacionDTO.TipoPrestacionId,
                        recategorizacionDTO.NuevoSintoma,
                        recategorizacionDTO.Comentario,
                        recategorizacionDTO.SintomaId);

                    return Ok(new { pedidoId = pedidoIdNuevo });
                }
                else
                {
                    await _pedidoRepository.AcualizarTipoPrestacion(pedidoId, recategorizacionDTO.TipoPrestacionId, (int)PedidoTipoDespachoEnum.Codigos, recategorizacionDTO.Comentario);
                    await _orquestadorNotificaciones.NotificarActualizacionTipoPrestacion(pedidoId, recategorizacionDTO.TipoPrestacionId);
                    await _orquestadorCoseguro.EjecutarReglasDeCoseguroParaElPedido(pedidoId, false);
                    return Ok(new { pedidoId = 0 });
                }
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Archivar el pedido
        /// </summary>
        /// <param name="pedidoId">Id del Pedido a archivar</param>
        /// <param name="archivarPedidoDTO">Data transfer object</param>
        /// <response code="200">El pedido se archivo exitosamente</response>
        /// <response code="409">Falló alguna regla de negocio</response>
        /// <response code="400">Error inesperado</response>    
        [HttpPut]
        [Route("{pedidoId}/Archivados")]
        [PedidoEstadoActualizacionFilter]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.Conflict)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> ArchivarPedido(int pedidoId, [FromBody] ArchivarPedidoDTO archivarPedidoDTO)
        {
            try
            {
                TempData["PedidoId"] = pedidoId;
                await _orquestadorParaArchivarPedido.RutinaArchivado(archivarPedidoDTO);
                await _orquestadorAsignacion.ActualizarKmCero(archivarPedidoDTO.PedidoId);
                return Ok();
            }
            catch (ReglaDeNegocioException ex)
            {
                return Conflict(new { message = ex.Message, messageCode = ex.ExceptionCode });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Indica si el pedido corresponde a un paciente psiquiátrico
        /// </summary>
        /// <param name="pedidoId">Id del Pedido a actualizar</param>
        /// <param name="pacientePsiquiatrico">Flag que indica si el paciente es psiquiátrico</param>
        /// <response code="200">El pedido se actualizo correctamente</response>
        /// <response code="404">No se encontró el pedido solicitado</response>
        /// <response code="400">Error inesperado</response>    
        [HttpPut]
        [Route("{pedidoId}/PacientePsiquiatrico")]
        [PedidoEstadoActualizacionFilter]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> ActualizarPacientePsiquiatrico(int pedidoId, bool pacientePsiquiatrico)
        {
            try
            {
                TempData["PedidoId"] = pedidoId;
                await _pedidoRepository.ActualizarPacientePsiquiatrico(pedidoId, pacientePsiquiatrico);
                return Ok();
            }
            catch (ReglaDeNegocioException ex)
            {
                return Conflict(new { message = ex.Message, messageCode = ex.ExceptionCode });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Ingresa el resultado del test rápido en SISA
        /// </summary>
        /// <param name="ingresarEnSISADTO">Data transfer object</param>
        /// <response code="200">El resultado del test rápido se ha ingresado exitosamente</response>
        /// <response code="409">Falló alguna regla de negocio</response>
        /// <response code="400">Error inesperado</response>    
        [HttpPost]
        [Route("{pedidoId}/SISA")]
        [PedidoEstadoActualizacionFilter]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.Conflict)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> IngresarEnSISA([FromBody] IngresarEnSISADTO ingresarEnSISADTO)
        {
            try
            {
                TempData["PedidoId"] = ingresarEnSISADTO.PedidoId;
                await _orquestadorParaArchivarPedido.RutinaIngresoSISA(ingresarEnSISADTO.PedidoId, ingresarEnSISADTO.IngresadoSisaFormato);
                return Ok();
            }
            catch (ReglaDeNegocioException ex)
            {
                return Conflict(new { message = ex.Message, messageCode = ex.ExceptionCode });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
    }
}
