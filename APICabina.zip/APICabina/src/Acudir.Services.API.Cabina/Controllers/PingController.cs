﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using AutoMapper;
using CabinaOperativa.ActionFilters;
using CabinaOperativa.DTOs;
using CabinaOperativa.Modelo;
using CabinaOperativa.Repositories;
using CabinaOperativa.Utilities;
using CabinaOperativa.Utilities.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace TechMed.Services.Cabina.Controllers
{
    [Route("api/v1/Cabina/[controller]")]
    public class PingController : Controller
    {
        public PingController()
        {

        }

        /// <summary>
        /// Ping a la aplicacion
        /// </summary>
        /// <response code="200">Devuelve el ping a la aplicacion</response>
        /// <response code="400">Error inesperado</response> 
        [HttpGet]
        [ProducesResponseType(typeof(PingDTO), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public IActionResult Ping()
        {
            try
            {
                return Ok(new PingDTO()
                {
                    Response = "Pong",
                    Environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT"),
                    Fecha = DateTime.Now
                });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
    }
}
