﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using AutoMapper;
using CabinaOperativa.DTOs;
using CabinaOperativa.Modelo;
using CabinaOperativa.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace TechMed.Services.Cabina.Controllers
{
    [Route("api/v1/Cabina/[controller]")]
    public class PrestacionesController : Controller
    {
        private readonly IMapper _mapper;
        private readonly ITipoPrestacionRepository _tipoPrestacionRepository;
        private readonly ITipoPrestacionContratoRepository _tipoPrestacionContratoRepository;

        public PrestacionesController(IMapper mapper,
            ITipoPrestacionRepository tipoPrestacionRepository,
            ITipoPrestacionContratoRepository tipoPrestacionContratoRepository)
        {
            _mapper = mapper;
            _tipoPrestacionRepository = tipoPrestacionRepository;
            _tipoPrestacionContratoRepository = tipoPrestacionContratoRepository;
        }

        /// <summary>
        /// Lista los TipoPrestacion asociados a un Contrato y un TipoPrestacionCategoria en especifico
        /// </summary>
        /// <param name="contratoId">Id del Contrato correspondiente</param>
        /// <param name="tipoPrestacionCategoriaId">Id del TipoPrestacionCategoria correspondiente (codigos, traslados, etc)</param>
        /// <response code="200">Devuelve el listado de TipoPrestacion</response>
        /// <response code="400">Error inesperado</response> 
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<TipoPrestacionDTO>), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> Listar(int contratoId, int tipoPrestacionCategoriaId)
        {
            try
            {
                IEnumerable<TipoPrestacion> tipoPrestacionesDb = null;
                IEnumerable<TipoPrestacionDTO> tipoPrestacionesDTO = null;

                if (contratoId == 0 && tipoPrestacionCategoriaId == 0)
                {
                    tipoPrestacionesDb = await _tipoPrestacionRepository.Listar();
                    tipoPrestacionesDTO = _mapper.Map<IEnumerable<TipoPrestacionDTO>>(tipoPrestacionesDb);
                }
                else if (contratoId == 0 && tipoPrestacionCategoriaId != 0)
                {
                    tipoPrestacionesDb = await _tipoPrestacionRepository.ListarPorTipoPrestacionCategoria(tipoPrestacionCategoriaId);
                    tipoPrestacionesDTO = _mapper.Map<IEnumerable<TipoPrestacionDTO>>(tipoPrestacionesDb);
                }
                else if (contratoId != 0 && tipoPrestacionCategoriaId != 0)
                {
                    IEnumerable<TipoPrestacionContrato> tipoPrestacionesContratosDb = await _tipoPrestacionContratoRepository.ListarPorContratoYTipoPrestacionCategoria(contratoId, tipoPrestacionCategoriaId);
                    tipoPrestacionesDb = tipoPrestacionesContratosDb?.Select(tpc => tpc.TipoPrestacion);
                    tipoPrestacionesDTO = _mapper.Map<IEnumerable<TipoPrestacionDTO>>(tipoPrestacionesDb);
                }

                if (tipoPrestacionesDTO is null || tipoPrestacionesDTO.Count() == 0)
                    return NotFound();

                return Ok(tipoPrestacionesDTO);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
    }
}
