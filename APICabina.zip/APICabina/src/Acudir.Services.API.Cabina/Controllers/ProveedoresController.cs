﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using AutoMapper;
using CabinaOperativa.DTOs;
using CabinaOperativa.Modelo;
using CabinaOperativa.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace TechMed.Services.Cabina.Controllers
{
    [Route("api/v1/Cabina/[controller]")]
    public class ProveedoresController : Controller
    {
        private readonly IMapper _mapper;
        private readonly IProveedorRepository _proveedorRepository;

        public ProveedoresController(IMapper mapper, IProveedorRepository proveedorRepository)
        {
            _mapper = mapper;
            _proveedorRepository = proveedorRepository;
        }

        /// <summary>
        /// Lista los proveedores
        /// </summary>
        /// <param name="pedidoId">Id del Pedido para poder listar los proveedores mas cercanos al mismo</param>
        /// <param name="mostrarTodos">Flag que indica si se quieren mostrar todos los proveedores</param>
        /// <param name="requiereMovil">Flag que indica si se quieren mostrar solo los proveedores que quieran movil</param>
        /// <response code="200">Devuelve el listado de proveedores</response>
        /// <response code="400">Error inesperado</response> 
        [HttpGet]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<string> Listar(int pedidoId, bool mostrarTodos, bool requiereMovil)
        {
            try
            {
                string proveedoresJson = await _proveedorRepository.ListarJson(pedidoId, mostrarTodos, requiereMovil);
                HttpContext.Response.StatusCode = (int)HttpStatusCode.OK;
                return proveedoresJson;
            }
            catch (Exception ex)
            {
                HttpContext.Response.StatusCode = (int)HttpStatusCode.BadRequest;
                return ex.Message;
            }
        }
    }
}
