﻿using System;
using System.Net;
using System.Threading.Tasks;
using AutoMapper;
using CabinaOperativa.ActionFilters;
using CabinaOperativa.DTOs;
using CabinaOperativa.Modelo;
using CabinaOperativa.Repositories;
using CabinaOperativa.Utilities.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace TechMed.Services.Cabina.Controllers
{
    [Route("api/v1/Cabina/[controller]")]
    public class PuntosController : Controller
    {
        private readonly IMapper _mapper;
        private readonly IPedidoTramoRepository _pedidoTramoRepository;
        private readonly IPedidoTramoDetalleRepository _pedidoTramoDetalleRepository;
        private readonly IDireccionRepository _direccionRepository;
        public PuntosController(IMapper mapper, 
            IPedidoTramoRepository pedidoTramoRepository, 
            IPedidoTramoDetalleRepository pedidoTramoDetalleRepository, 
            IDireccionRepository direccionRepository)
        {
            _mapper = mapper;
            _pedidoTramoRepository = pedidoTramoRepository;
            _pedidoTramoDetalleRepository = pedidoTramoDetalleRepository;
            _direccionRepository = direccionRepository;
        }

        /// <summary>  
        /// Actualiza los datos geógraficos de un punto
        /// </summary>  
        /// <param name="pedidoTramoDetalleId">Id del PedidoTramoDetalle a actualizar</param>
        /// <param name="pedidoTramoDetalleDTO"></param>
        /// <response code="200">Devuelve el punto con los datos geográficos actualizados</response>
        /// <response code="400">Error inesperado</response> 
        [HttpPut]
        [PedidoTramoDetalleActualizacionFilter]
        [Route("{pedidoTramoDetalleId}")]
        [ProducesResponseType(typeof(PedidoTramoDetalleDTO), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> Actualizar(int pedidoTramoDetalleId, [FromBody] PedidoTramoDetalleDTO pedidoTramoDetalleDTO)
        {
            try
            {
                TempData["PedidoId"] = pedidoTramoDetalleDTO.PedidoId;

                Direccion nuevaDireccion = _mapper.Map<Direccion>(pedidoTramoDetalleDTO.Direccion);
                nuevaDireccion = await _direccionRepository.Crear(nuevaDireccion);

                PedidoTramoDetalle pedidoTramoDetalle = await _pedidoTramoDetalleRepository.Obtener(pedidoTramoDetalleId);
                pedidoTramoDetalle.HorarioProgramado = pedidoTramoDetalleDTO.HorarioProgramado;
                pedidoTramoDetalle.Observacion = pedidoTramoDetalleDTO.Observacion;
                pedidoTramoDetalle.DireccionId = nuevaDireccion.DireccionId;
                pedidoTramoDetalle = await _pedidoTramoDetalleRepository.Actualizar(pedidoTramoDetalle);

                var pedidoId = pedidoTramoDetalleDTO.PedidoId;
                pedidoTramoDetalleDTO = _mapper.Map<PedidoTramoDetalleDTO>(pedidoTramoDetalle);
                pedidoTramoDetalleDTO.PedidoId = pedidoId;

                return Ok(pedidoTramoDetalleDTO);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
    }
}
