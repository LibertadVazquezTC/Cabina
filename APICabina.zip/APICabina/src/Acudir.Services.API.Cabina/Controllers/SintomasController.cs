﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using AutoMapper;
using CabinaOperativa.ActionFilters;
using CabinaOperativa.DTOs;
using CabinaOperativa.Modelo;
using CabinaOperativa.Repositories;
using CabinaOperativa.Utilities;
using CabinaOperativa.Utilities.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace TechMed.Services.Cabina.Controllers
{
    [Route("api/v1/Cabina/[controller]")]
    public class SintomasController : Controller
    {
        private readonly IMapper _mapper;
        private readonly ISintomaRepository _sintomaRepository;

        public SintomasController(IMapper mapper, ISintomaRepository sintomaRepository)
        {
            _mapper = mapper;
            _sintomaRepository = sintomaRepository;
        }

        /// <summary>  
        /// Lista los sintomas
        /// </summary> 
        /// <response code="200">Devuelve el listado de sintomas</response>
        /// <response code="400">Error inesperado</response> 
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<SintomaDTO>), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> Listar()
        {
            try
            {
                IEnumerable<Sintoma> sintomas = await _sintomaRepository.Listar();
                IEnumerable<SintomaDTO> sintomasDTO = _mapper.Map<IEnumerable<SintomaDTO>>(sintomas);
                return Ok(sintomasDTO);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
    }
}
