﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CabinaOperativa.Repositories;
using CabinaOperativa.DTOs;
using CabinaOperativa.Modelo;
using System;
using System.Net;
using AutoMapper;
using System.Collections.Generic;
using System.Linq;
using CabinaOperativa.Repositories.Interfaces.Pedido;

namespace TechMed.Services.Cabina.Controllers
{
    [Route("api/v1/Cabina/[controller]")]
    public class TiposDeCierreController : Controller
    {
        private readonly IMapper _mapper;
        private readonly IPedidoTipoCierreRepository _pedidoTipoCierreRepository;
        private readonly IRestriccionTipoCierreDiagnosticoRepository _restriccionTipoCierreDiagnosticoRepository;
        private readonly IRestriccionTipoCierrePrestacionRepository _restriccionTipoCierrePrestacionRepository;

        public TiposDeCierreController(IMapper mapper,
            IPedidoTipoCierreRepository pedidoTipoCierreRepository,
            IRestriccionTipoCierreDiagnosticoRepository restriccionTipoCierreDiagnosticoRepository,
            IRestriccionTipoCierrePrestacionRepository restriccionTipoCierrePrestacionRepository)
        {
            _mapper = mapper;
            _pedidoTipoCierreRepository = pedidoTipoCierreRepository;
            _restriccionTipoCierreDiagnosticoRepository = restriccionTipoCierreDiagnosticoRepository;
            _restriccionTipoCierrePrestacionRepository = restriccionTipoCierrePrestacionRepository;
        }

        /// <summary>
        /// Lista los posibles tipo de cierres para un pedido
        /// </summary>
        /// <response code="200">Devuelve el listado de posibles tipo de cierres para un pedido</response>
        /// <response code="404">No se encontraron tipo de cierres</response>
        /// <response code="400">Error inesperado</response>    
        [HttpGet]
        [Route("")]
        [ProducesResponseType(typeof(IEnumerable<PedidoTipoCierreDTO>), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> ListarTipoDeCierres()
        {
            try
            {
                IEnumerable<PedidoTipoCierre> pedidoTipoCierresDb = await _pedidoTipoCierreRepository.Listar();
                if (pedidoTipoCierresDb is null || pedidoTipoCierresDb.Count() == 0)
                    return NotFound();

                IEnumerable<PedidoTipoCierreDTO> pedidoTipoCierresDTO = _mapper.Map<IEnumerable<PedidoTipoCierreDTO>>(pedidoTipoCierresDb);
                return Ok(pedidoTipoCierresDTO);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Lista los posibles tipo de cierres según el diagnóstico y tipo prestación especificados
        /// </summary>
        /// <response code="200">Devuelve el listado de posibles tipo de cierres para un diagnóstico y tipo de cierre</response>
        /// <response code="404">No se encontraron tipo de cierres</response>
        /// <response code="400">Error inesperado</response>  
        [HttpGet]
        [Route("ObtenerTiposCierreByDiagnosticoYTipoPrestacion")]
        [ProducesResponseType(typeof(IEnumerable<PedidoTipoCierreDTO>), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> ObtenerTiposCierreByDiagnosticoYTipoPrestacion(int? diagnosticoId, int tipoPrestacionId)
        {
            try
            {
                IEnumerable<PedidoTipoCierre> pedidoTipoCierresPermitidos = await _pedidoTipoCierreRepository.Listar();

                if (diagnosticoId != null)
                {
                    IEnumerable<RestriccionTipoCierreDiagnostico> restriccionesDiagnostico = await _restriccionTipoCierreDiagnosticoRepository.ListarByDiagnosticoId((int)diagnosticoId);

                    if (restriccionesDiagnostico.Any())
                        pedidoTipoCierresPermitidos = pedidoTipoCierresPermitidos.Where(ptc => restriccionesDiagnostico.All(tcr => ptc.PedidoTipoCierreId != tcr.PedidoTipoCierreId));
                }

                IEnumerable<RestriccionTipoCierrePrestacion> restriccionesTipoPrestacion = await _restriccionTipoCierrePrestacionRepository.ListarByTipoPrestacionId(tipoPrestacionId);

                if (restriccionesTipoPrestacion.Any())
                    pedidoTipoCierresPermitidos = pedidoTipoCierresPermitidos.Where(ptc => restriccionesTipoPrestacion.All(tcr => ptc.PedidoTipoCierreId != tcr.PedidoTipoCierreId));

                if (!pedidoTipoCierresPermitidos.Any())
                    return NotFound();

                IEnumerable<PedidoTipoCierreDTO> pedidoTipoCierresDTO = _mapper.Map<IEnumerable<PedidoTipoCierreDTO>>(pedidoTipoCierresPermitidos);
                return Ok(pedidoTipoCierresDTO);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
    }
}
