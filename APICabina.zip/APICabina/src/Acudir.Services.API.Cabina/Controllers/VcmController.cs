﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CabinaOperativa.DTOs;
using CabinaOperativa.ActionFilters;
using CabinaOperativa.Enums;
using CabinaOperativa.Modelo;
using System;
using System.Net;
using AutoMapper;
using CabinaOperativa.Exceptions;
using CabinaOperativa.DTOs.Archivar;
using CabinaOperativa.Orquestadores.Interfaces;
using CabinaOperativa.DTOs.Asignaciones;
using Microsoft.Extensions.Configuration;
using Acudir.Services.API.Cabina.Utilities;

namespace TechMed.Services.Cabina.Controllers
{
    [Route("api/v1/Cabina/[controller]")]
    public class VcmController : Controller
    {
        private readonly IMapper _mapper;
        private readonly IConfiguration _configuration;
        private readonly IOrquestadorAsignacion _orquestadorAsignacion;
        private readonly IOrquestadorDesasignacion _orquestadorDesasignacion;
        private readonly IOrquestadorParaArchivarPedido _orquestadorParaArchivarPedido;

        public VcmController(IMapper mapper,
            IConfiguration configuration,
            IOrquestadorAsignacion orquestadorAsignacion,
            IOrquestadorDesasignacion orquestadorDesasignacion,
            IOrquestadorParaArchivarPedido orquestadorParaArchivarPedido)
        {
            _mapper = mapper;
            _configuration = configuration;
            _orquestadorAsignacion = orquestadorAsignacion;
            _orquestadorDesasignacion = orquestadorDesasignacion;
            _orquestadorParaArchivarPedido = orquestadorParaArchivarPedido;
        }

        /// <summary>
        /// Preasigna una video consulta médica
        /// </summary>
        /// <param name="asignarVcm"></param>
        /// <response code="200">Devuelve la asignación o preasignacion creada</response>
        /// <response code="409">Devuelve un mensaje de error por no cumplirse una regla de negocio</response>
        /// <response code="400">Error inesperado</response> 
        [HttpPost]
        [Route("Preasignados")]
        [PedidoAsignacionFilter]
        [ProducesResponseType(typeof(PedidoTramoProveedorUMovilHorarioDTO), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.Conflict)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> PreasignarVcm([FromBody] AsignarVcmDto asignarVcm)
        {
            try
            {
                TempData["PedidoId"] = asignarVcm.PedidoId;

                PedidoTramoProveedorUMovilHorario asignacionCreada = await _orquestadorAsignacion.AsignarPropio(asignarVcm.PedidoId,
                    asignarVcm.GdiaRealEquipoId,
                    asignarVcm.ProveedorId,
                    true);

                PedidoTramoProveedorUMovilHorarioDTO asignacionCreadaDTO = _mapper.Map<PedidoTramoProveedorUMovilHorarioDTO>(asignacionCreada);
                return Ok(asignacionCreadaDTO);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Asigna una video consulta médica
        /// </summary>
        /// <response code="200">Devuelve los adicionales de un pedido y tipo específico</response>
        /// <response code="400">Error inesperado</response>            
        /// <response code="404">No se encontró el adicional para ese pedido y tipo</response>            
        [HttpPost]
        [Route("Asignados")]
        [ProducesResponseType(typeof(PedidoAdicionalDTO), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> AsignarVcm([FromBody] AsignarVcmDto asignarVcm)
        {
            TempData["PedidoId"] = asignarVcm.PedidoId;

            PedidoTramoProveedorUMovilHorario asignacionCreada = null;
            try
            {
                asignacionCreada = await _orquestadorAsignacion.AsignarPropio(
                    asignarVcm.PedidoId,
                    asignarVcm.GdiaRealEquipoId,
                    asignarVcm.ProveedorId,
                    false);
            }
            catch (Exception ex) 
            {
                ExceptionLoggerUtility.LogException(ex);
            }

            if (asignacionCreada != null)
            {
                await _orquestadorAsignacion.ActualizarHorarios(asignacionCreada.PedidoTramoProveedorUMovilHorarioId,
                    TipoHorarioEnum.OrigenArribo,
                    DateTime.Now);
                
                PedidoTramoProveedorUMovilHorarioDTO asignacionCreadaDTO = _mapper.Map<PedidoTramoProveedorUMovilHorarioDTO>(asignacionCreada);
                return Ok(asignacionCreadaDTO);
            }

            return Ok();  
        }

        /// <summary>
        /// Archivar el pedido asociado a una video consulta médica
        /// </summary>
        /// <param name="archivarPedidoVcmDTO">Data transfer object</param>
        /// <response code="200">El pedido se archivo exitosamente</response>
        /// <response code="409">Falló alguna regla de negocio</response>
        /// <response code="400">Error inesperado</response>    
        [HttpPut]
        [Route("Archivados")]
        [PedidoEstadoActualizacionFilter]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.Conflict)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> ArchivarPedidoVcm([FromBody] ArchivarPedidoVcmDTO archivarPedidoVcmDTO)
        {
            try
            {
                TempData["PedidoId"] = archivarPedidoVcmDTO.PedidoId;
         
                await _orquestadorParaArchivarPedido.RutinaArchivadoVCM(archivarPedidoVcmDTO);

                var origenPartida = archivarPedidoVcmDTO.OrigenPartida.HasValue ? 
                    archivarPedidoVcmDTO.OrigenPartida.Value : 
                    DateTime.Now.AddMinutes(1);

                await _orquestadorAsignacion.ActualizarHorarios(
                    archivarPedidoVcmDTO.PedidoId,
                    archivarPedidoVcmDTO.GdiaRealEquipoId,
                    TipoHorarioEnum.OrigenPartida,
                    origenPartida);

                return Ok();
            }
            catch (ReglaDeNegocioException ex)
            {
                return Conflict(new { message = ex.Message, messageCode = ex.ExceptionCode });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>
        /// Archivar el pedido asociado a una video consulta médica
        /// </summary>
        /// <param name="archivarPedidoDTO">Data transfer object</param>
        /// <response code="200">El pedido se archivo exitosamente</response>
        /// <response code="409">Falló alguna regla de negocio</response>
        /// <response code="400">Error inesperado</response>    
        [HttpPost]
        [Route("LogPedidoNoAtendidoCriterioPresencial")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.Conflict)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> LogPedidoNoAtendidoCriterioPresencial([FromBody] ArchivarPedidoDTO archivarPedidoDTO)
        {
            try
            {
                TempData["PedidoId"] = archivarPedidoDTO.PedidoId;

                await _orquestadorParaArchivarPedido.RutinaCreacionLogPedidoNoAtendido(archivarPedidoDTO);
               
                return Ok();
            }
            catch (ReglaDeNegocioException ex)
            {
                return Conflict(new { message = ex.Message, messageCode = ex.ExceptionCode });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
    }
}
