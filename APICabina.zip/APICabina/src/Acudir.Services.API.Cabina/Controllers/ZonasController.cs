﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CabinaOperativa.Repositories;
using System;
using System.Net;
using CabinaOperativa.Modelo;
using System.Collections;
using CabinaOperativa.DTOs.Zona;
using System.Collections.Generic;
using AutoMapper;

namespace TechMed.Services.Cabina.Controllers
{
    [Route("api/v1/Cabina/[controller]")]
    public class ZonasController : Controller
    {
        //private readonly IMapper _mapper;
        //private readonly IZonaRepository _zonaRepository;
        //private readonly IZonaSubZonaRepository _zonaSubZonaRepository;
        //private readonly IZonaSubZonaLocalidadRepository _zonaSubZonaLocalidadRepository;

        //public ZonasController(IMapper mapper, 
        //    IZonaRepository zonaRepository,
        //    IZonaSubZonaRepository zonaSubZonaRepository,
        //    IZonaSubZonaLocalidadRepository zonaSubZonaLocalidadRepository)
        //{
        //    _mapper = mapper;
        //    _zonaRepository = zonaRepository;
        //    _zonaSubZonaRepository = zonaSubZonaRepository;
        //    _zonaSubZonaLocalidadRepository = zonaSubZonaLocalidadRepository;
        //}

        ///// <summary>  
        ///// Lista las zonas activas
        ///// </summary>  
        ///// <response code="200">Devuelve el listado de zonas activas</response>
        ///// <response code="400">Error inesperado</response> 
        //[HttpGet]
        //[ProducesResponseType(typeof(IEnumerable<ZonaDTO>), (int)HttpStatusCode.OK)]
        //[ProducesResponseType((int)HttpStatusCode.BadRequest)]
        //[Route("")]
        //public async Task<IActionResult> ListarZonas()
        //{
        //    try
        //    {
        //        IEnumerable<Zona> zonasDB = await _zonaRepository.Listar();
        //        IEnumerable<ZonaDTO> zonasDTO = _mapper.Map<IEnumerable<ZonaDTO>>(zonasDB);
        //        return Ok(zonasDTO);
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(new { message = ex.Message });
        //    }
        //}

        ///// <summary>  
        ///// Lista las zonas activas
        ///// </summary>  
        ///// <response code="200">Devuelve el listado de zonas activas</response>
        ///// <response code="400">Error inesperado</response> 
        //[HttpGet]
        //[ProducesResponseType(typeof(IEnumerable<ZonaDTO>), (int)HttpStatusCode.OK)]
        //[ProducesResponseType((int)HttpStatusCode.BadRequest)]
        //[Route("{zonaId}")]
        //public async Task<IActionResult> Obtener(int zonaId)
        //{
        //    try
        //    {
        //        Zona zonaDB = await _zonaRepository.Obtener(zonaId);
        //        ZonaDTO zonaDTO = _mapper.Map<ZonaDTO>(zonaDB);
        //        return Ok(zonaDTO);
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(new { message = ex.Message });
        //    }
        //}

        ///// <summary>  
        ///// Lista las sub-zonas activas para una zona en particular
        ///// </summary>  
        ///// <response code="200">Devuelve el listado de las sub-zonas activas para una zona en particular</response>
        ///// <response code="400">Error inesperado</response> 
        //[HttpGet]
        //[ProducesResponseType(typeof(IEnumerable<SubZonaDTO>), (int)HttpStatusCode.OK)]
        //[ProducesResponseType((int)HttpStatusCode.BadRequest)]
        //[Route("{zonaId}/SubZonas")]
        //public async Task<IActionResult> ListarSubZonas(int zonaId)
        //{
        //    try
        //    {
        //        IEnumerable<ZonaSubZona> zonaSubZonasDB = await _zonaSubZonaRepository.ObtenerPorZona(zonaId);
        //        IEnumerable<SubZonaDTO> zonaSubZonasDTO = _mapper.Map<IEnumerable<SubZonaDTO>>(zonaSubZonasDB);
        //        return Ok(zonaSubZonasDTO);
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(new { message = ex.Message });
        //    }
        //}     
    }
}
