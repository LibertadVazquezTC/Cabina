﻿namespace CabinaOperativa.DTOs
{
    public class AfiliadoDTO
    {
        public int PedidoAfiliadoId { get; set; }
        public bool PacienteRecomendado { get; set; }
        public bool PersonajePublico { get; set; }
        public bool PMI { get; set; }
        public bool Discapacidad { get; set; }
        public bool InternacionDomiciliaria { get; set; }
    }
}
