﻿namespace CabinaOperativa.DTOs.Alertas
{
    public class CrearPedidoAlertaAccionRespuestaDTO
    {
        public int AlertaAccionId { get; set; }
        public int PedidoEntidadLogId { get; set; }
        public string Descripcion { get; set; }
    }
}
