﻿using System;

namespace CabinaOperativa.DTOs.Alertas
{
    public class PedidoAlertaAccionRespuestaDTO
    {
        public int PedidoAlertaAccionRespuestaId { get; set; }
        public int AlertaAccionId { get; set; }
        public int PedidoEntidadLogId { get; set; }
        public string Descripcion { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime AuditoriaInsertDate { get; set; }
    }
}
