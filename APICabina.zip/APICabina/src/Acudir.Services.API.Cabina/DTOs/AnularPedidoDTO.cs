﻿namespace CabinaOperativa.DTOs
{
    public class AnularPedidoDTO
    {
        public int PedidoEstadoTipoId { get; set; }
        public string NuevoComentario { get; set; }
    }
}
