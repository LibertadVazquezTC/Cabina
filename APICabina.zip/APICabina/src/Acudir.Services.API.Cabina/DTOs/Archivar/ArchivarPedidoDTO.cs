﻿using CabinaOperativa.Enums;
using System;

namespace CabinaOperativa.DTOs.Archivar
{

    public class ArchivarPedidoDTO
    {
        public int PedidoId { get; set; }
        public IngresadoSisaFormatoEnum? IngresadoSisaFormato { get; set; }
        public CierreDePedidoDTO CierreDePedido { get; set; }
        public CierreDiagnosticoMedicoDTO CierreDiagnosticoMedico { get; set; }
        public CierreCoseguroDTO CierreCoseguro { get; set; }
    }

}
