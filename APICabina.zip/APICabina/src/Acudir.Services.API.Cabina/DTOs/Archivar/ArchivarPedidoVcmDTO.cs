﻿using CabinaOperativa.DTOs.Asignaciones;
using System;

namespace CabinaOperativa.DTOs.Archivar
{

    public class ArchivarPedidoVcmDTO : ArchivarPedidoDTO
    {
        public int GdiaRealEquipoId { get; set; }
        public DateTime? OrigenPartida { get; set; }
    }
}
