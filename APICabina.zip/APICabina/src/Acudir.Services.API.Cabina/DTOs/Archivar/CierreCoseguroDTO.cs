﻿namespace CabinaOperativa.DTOs.Archivar
{

    public class CierreCoseguroDTO
    {
        public bool? CobroCoseguro { get; set; }
        public int? PedidoCoseguroTipoNoCobroId { get; set; }
    }
}
