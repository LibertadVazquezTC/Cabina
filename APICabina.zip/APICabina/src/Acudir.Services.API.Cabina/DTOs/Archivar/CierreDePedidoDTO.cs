﻿namespace CabinaOperativa.DTOs.Archivar
{

    public class CierreDePedidoDTO
    {
        public int PedidoTipoCierreId { get; set; }
        public string ComentarioCierre { get; set; }
        public int? ResultadoLaboratorio { get; set; }
    }
}
