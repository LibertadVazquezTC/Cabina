﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CabinaOperativa.DTOs.Archivar
{
    public class CierreDiagnosticoMedicoDTO
    {
        public int? DiagnosticoId { get; set; }
        public string Descripcion { get; set; }
    }
}
