﻿using System;

namespace CabinaOperativa.DTOs.Asignaciones
{
    public class ActualizarHorariosDTO
    {
        public int PedidoId { get; set; }
        public string TipoHorario { get; set; }
        public DateTime Horario { get; set; }
    }
}
