﻿namespace CabinaOperativa.DTOs.Asignaciones
{
    public class ActualizarEstadoAsignacionDTO
    {
        public int PedidoId { get; set; }
        public int PedidoTramoProveedorUMovilHorarioEstadoId { get; set; }
    }
}
