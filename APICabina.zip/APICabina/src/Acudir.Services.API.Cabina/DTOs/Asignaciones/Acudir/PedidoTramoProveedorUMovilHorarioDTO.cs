﻿using System;

namespace CabinaOperativa.DTOs.Asignaciones
{
    public class PedidoTramoProveedorUMovilHorarioDTO
    {
        public int PedidoTramoProveedorUMovilHorarioId { get; set; }
        public int PedidoTramoProveedorUMovilHorarioEstadoId { get; set; }
        public int? PedidoTramoProveedorUMovilHorarioRelevoId { get; set; }
        public bool Apoyo { get; set; }
        public int? GdiaRealEquipoId { get; set; }
        public bool Origen { get; set; }
        public DateTime? OrigenArribo { get; set; }
        public DateTime? OrigenPartida { get; set; }
        public int ProveedorId { get; set; }
        public string ProveedorDescripcion { get; set; }
        public string ProveedorTelefono { get; set; }
        public int UMovilId { get; set; }
        public string UMovilDescripcion { get; set; }
    }
}
