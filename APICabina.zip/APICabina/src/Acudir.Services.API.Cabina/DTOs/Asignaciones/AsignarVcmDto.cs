﻿namespace CabinaOperativa.DTOs.Asignaciones
{
    public class AsignarVcmDto
    {
        public int PedidoId { get; set; }
        public int GdiaRealEquipoId { get; set; }
        public int ProveedorId { get; set; }
    }
}
