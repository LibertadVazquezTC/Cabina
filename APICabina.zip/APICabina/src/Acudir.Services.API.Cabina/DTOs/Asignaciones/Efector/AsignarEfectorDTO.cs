﻿namespace CabinaOperativa.DTOs.Asignaciones
{
    public class AsignarEfectorDTO
    {
        public int PedidoId { get; set; }
        public int EfectorId { get; set; }
    }
}
