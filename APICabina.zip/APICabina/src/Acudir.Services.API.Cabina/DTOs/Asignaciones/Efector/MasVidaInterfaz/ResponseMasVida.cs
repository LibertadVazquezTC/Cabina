﻿using System;

namespace CabinaOperativa.DTOs.Asignaciones.Efector.MasVidaInterfaz
{
    public class ResponseMasVida
    {
        public int EstadoOperacion { get; set; }
        public string Mensaje { get; set; }
        public string CodigoCliente { get; set; }
        public string ValorOperacion { get; set; }
        public DateTime Fecha { get; set; }
    }
}
