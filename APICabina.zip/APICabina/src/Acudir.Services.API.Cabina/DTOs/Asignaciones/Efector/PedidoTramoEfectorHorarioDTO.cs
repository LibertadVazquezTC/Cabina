﻿using System;

namespace CabinaOperativa.DTOs.Asignaciones
{
    public class PedidoTramoEfectorHorarioDTO
    {
        public int PedidoTramoEfectorHorarioId { get; set; }
        public int EfectorId { get; set; }
        public string EfectorDescripcion { get; set; }
        public int PedidoTramoEfectorHorarioEstadoId { get; set; }
        public int PedidoTramoId { get; set; }
        public string NroServicio { get; set; }
        public string QuienAtiende { get; set; }
        public int VentaToleranciaNegociada { get; set; }
        public DateTime? OrigenArribo { get; set; }
        public DateTime? OrigenPartida { get; set; }
        public bool Origen { get; set; }
        public bool Apoyo { get; set; }
    }
}
