﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CabinaOperativa.DTOs.Asignaciones
{
    public class HorariosDTO
    {
        public DateTime? OrigenArribo { get; set; }
        public DateTime? OrigenPartida { get; set; }
        public DateTime? DestinoArribo { get; set; }
        public DateTime? DestinoPartida { get; set; }
    }
}
