﻿namespace CabinaOperativa.DTOs
{
    public class AsignarPedidoDTO
    {
        public int? GdiaRealEquipoId { get; set; }
    }
}
