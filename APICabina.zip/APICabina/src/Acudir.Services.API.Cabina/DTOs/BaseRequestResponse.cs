﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CabinaOperativa.DTOs
{
    public class BaseRequestResponse
    {
        public bool FueExitoso { get; private set; } = true;
        public string Mensaje { get; private set; } = string.Empty;

        public void SetStatus(bool fueExitoso, string mensaje)
        {
            this.FueExitoso = fueExitoso;
            this.Mensaje = mensaje;
        }
    }
}
