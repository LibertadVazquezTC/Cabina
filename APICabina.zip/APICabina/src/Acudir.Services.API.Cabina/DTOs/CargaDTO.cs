﻿using System;

namespace CabinaOperativa.DTOs
{
    public class CargaDTO
    {
        public int CargaId { get; set; }
        public string Movil { get; set; }
        public string Chofer { get; set; }
        public string Medico { get; set; }
        public string AsignadoPor { get; set; }
        public string Comentario { get; set; }
        public DateTime HoraAsignado { get; set; }
        public DateTime? HoraFinal { get; set; }
        public DateTime? HoraConfirmacion { get; set; }
        public int TiempoRestante { get; set; }
    }
}
