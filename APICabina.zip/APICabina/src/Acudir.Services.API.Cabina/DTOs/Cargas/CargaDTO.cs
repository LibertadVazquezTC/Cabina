﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CabinaOperativa.DTOs.Cargas
{
    public class AsignarCargaDTO
    {
        public int uMovilId { get; set; }
        public int cargaId { get; set; }
        public IntegranteDTO chofer { get; set; }
        public IntegranteDTO medico { get; set; }
        public string comentario { get; set; }

        public class IntegranteDTO
        {
            public int GdiaPersonalId { get; set; }
            public string Personal { get; set; }
            public int GdiaRealPersonalId { get; set; }
            public int GdiaRealPersonalDetalleId { get; set; }
        }
    }

    
}