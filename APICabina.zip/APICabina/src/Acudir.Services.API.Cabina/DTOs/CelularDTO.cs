﻿using System;

namespace CabinaOperativa.DTOs
{
    public class CelularDTO
    {
        public int CmnCelularId { get; set; }
        public string Numero { get; set; }
        public string FcmTokenNotify { get; set; }
        public string Mail { get; set; }
    }
}
