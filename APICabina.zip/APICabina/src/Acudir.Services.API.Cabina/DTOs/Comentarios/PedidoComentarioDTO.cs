﻿using System;

namespace CabinaOperativa.DTOs.Comentarios
{
    public class PedidoComentarioDTO
    {
        public int PedidoComentarioId { get; set; }
        public string Descripcion { get; set; }
        public int PedidoId { get; set; }
        public string Usuario { get; set; }
        public DateTime Hora { get; set; }
        public int CmnComentarioTipoId { get; set; }
    }
}
