﻿namespace CabinaOperativa.DTOs.Configuraciones
{
    public class ActualizarConfiguracionDTO
    {
        public string Configuracion { get; set; }
    }
}
