﻿namespace CabinaOperativa.DTOs.Configuraciones
{
    public class CmnConfiguracionDTO
    {
        public int CmnConfiguracionId { get; set; }
        public string Configuracion { get; set; }
        public string Tipo { get; set; }
    }
}
