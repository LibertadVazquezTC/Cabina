﻿namespace CabinaOperativa.DTOs.Configuraciones
{
    public class CrearConfiguracionDTO
    {
        public string Configuracion { get; set; }
        public string Tipo { get; set; }
    }
}
