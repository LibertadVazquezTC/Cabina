﻿namespace CabinaOperativa.DTOs
{
    public class CoseguroForzadoDTO
    {
        public float ValorCoseguro { get; set; }
        public string MotivoActualizacion { get; set; }
    }
}
