﻿namespace Acudir.Services.API.Cabina.DTOs
{
    public class DatosAfiliadoDTO
    {
       public int ContratoId { get; set; }
       public string Documento {  get; set; }
    }
}
