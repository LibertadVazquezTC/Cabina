﻿namespace CabinaOperativa.DTOs
{
    public class DiagnosticoDTO
    {
        public int DiagnosticoId { get; set; }
        public string Descripcion { get; set; }
        public string CodigoCIE { get; set; }
    }
}
