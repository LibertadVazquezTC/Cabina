﻿namespace CabinaOperativa.DTOs.Direccion
{
    public class DireccionDTO
    {
        public int DireccionId { get; set; }
        public int? DireccionLocalidadId { get; set; }
        public string Domicilio { get; set; }
        public string CalleAdyacente1 { get; set; }
        public string CalleAdyacente2 { get; set; }
        public double Latitud { get; set; }
        public double Longitud { get; set; }
        public int Piso { get; set; }
        public string Depto { get; set; }
    }
}
