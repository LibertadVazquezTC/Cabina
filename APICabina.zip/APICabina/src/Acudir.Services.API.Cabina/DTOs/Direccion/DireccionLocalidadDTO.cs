﻿namespace CabinaOperativa.DTOs.Direccion
{
    public class DireccionLocalidadDTO
    {
        public int DireccionLocalidadId { get; set; }
        public string Descripcion { get; set; }
        public int Kilometros { get; set; }
        public int DireccionPartidoId { get; set; }
        public int DireccionZonaGeograficaId { get; set; }
        public double Latitud { get; set; }
        public double Longitud { get; set; }     
    }
}
