﻿namespace CabinaOperativa.DTOs.Direccion
{
    public class DireccionLocalidadLiteDTO
    {
        public int DireccionLocalidadId { get; set; }
        public string Descripcion { get; set; }    
    }
}
