﻿using CabinaOperativa.Enums;

namespace CabinaOperativa.DTOs
{
    public class IngresarEnSISADTO
    {
        public int PedidoId { get; set; }
        public IngresadoSisaFormatoEnum IngresadoSisaFormato { get; set; }
    }
}
