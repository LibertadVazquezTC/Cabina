﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CabinaOperativa.DTOs.Asignaciones
{
    public class NegociacionDTO
    {
        public int PedidoId { get; set; }
        public int VentanaTolerancia { get; set; }
        public string Incidente { get; set; }
        public string QuienAtiende { get; set; } 
    }
}
