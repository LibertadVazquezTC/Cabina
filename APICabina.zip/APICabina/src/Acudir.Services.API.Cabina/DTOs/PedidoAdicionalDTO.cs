﻿using CabinaOperativa.Modelo;

namespace CabinaOperativa.DTOs
{
    public class PedidoAdicionalDTO
    {
        public int PedidoAdicionalId { get; set; }
        public int PedidoId { get; set; }
        public int PedidoAdicionalTipoId { get; set; }
        public float Cantidad { get; set; }
    }
}
