﻿using CabinaOperativa.Modelo;
using System;

namespace CabinaOperativa.DTOs
{
    public class PedidoCoseguroDTO
    {
        public int PedidoCoseguroId { get; set; }
        public int PedidoId { get; set; }
        public int? PedidoTramoProveedorUMovilHorarioId { get; set; }
        public int? PedidoTramoEfectorHorarioId { get; set; }
        public int? GdiaPersonalId { get; set; }
        public bool Recibido { get; set; }
        public DateTime? FechaRecibido { get; set; }
        public bool Confirmado { get; set; }
        public DateTime? FechaConfirmado { get; set; }
        public bool? Cobrado { get; set; }
        public DateTime? FechaCobrado { get; set; }    
        public double Coseguro { get; set; }
        
        public bool? InformadoCliente { get; set; }
        public string NumeroResolucion { get; set; }
        public string InformadoPor { get; set; }
        public DateTime? InformadoFecha { get; set; }
        public int? PedidoCoseguroTipoNoCobroId { get; set; }
        public string ResponsableDelCobro { get; set; }    
    }
}
