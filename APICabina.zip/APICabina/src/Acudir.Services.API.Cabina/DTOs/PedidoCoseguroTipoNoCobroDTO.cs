﻿namespace CabinaOperativa.DTOs
{
    public class PedidoCoseguroTipoNoCobroDTO
    {
        public int PedidoCoseguroTipoNoCobroId { get; set; }
        public string Descripcion { get; set; }   
    }
}
