﻿using System;

namespace CabinaOperativa.DTOs
{
    public class PedidoDiagnosticoMedicoDTO
    {
        public int PedidoDiagnosticoMedicoId { get; set; }
        public string Descripcion { get; set; }
        public int PedidoId { get; set; }
        public DateTime Hora { get; set; }
        public int? DiagnosticoId { get; set; }
    }
}
