﻿using CabinaOperativa.Modelo;
using System;

namespace CabinaOperativa.DTOs
{
    public class PedidoResultadoLaboratorioDTO
    {
        public int PedidoResultadoLaboratorioId { get; set; }
        public string Descripcion { get; set; }
    }
}
