﻿using CabinaOperativa.Modelo;

namespace CabinaOperativa.DTOs
{
    public class PedidoResultadoLaboratorioTipoPrestacionDTO
    {
        public int PedidoResultadoLaboratorioTipoPrestacionId { get; set; }
        public int TipoPrestacionId { get; set; }
        public PedidoResultadoLaboratorioDTO PedidoResultadoLaboratorio { get; set; }

    }
}
