﻿using CabinaOperativa.Modelo;

namespace CabinaOperativa.DTOs
{
    public class PedidoTipoCierreDTO
    {
        public int PedidoTipoCierreId { get; set; }
        public string Descripcion { get; set; }
    }
}
