﻿using CabinaOperativa.DTOs;
using CabinaOperativa.DTOs.Direccion;
using System;

namespace CabinaOperativa.DTOs
{
    public class PedidoTramoDetalleDTO
    {
        public int PedidoTramoDetalleId { get; set; }
        public int PedidoTramoId { get; set; }
        public int PedidoId { get; set; }
        public int DireccionId { get; set; }
        public DireccionDTO Direccion { get; set; }
        public DateTime? HorarioProgramado { get; set; }
        public int OrigenDestino { get; set; }
        public string Observacion { get; set; }
    }
}
