﻿using System;

namespace CabinaOperativa.DTOs
{
    public class PingDTO
    {
        public string Response { get; set; }
        public string Environment { get; set; }
        public DateTime Fecha { get; set; }
    }
}
