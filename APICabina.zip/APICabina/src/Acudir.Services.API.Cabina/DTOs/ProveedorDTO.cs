﻿using CabinaOperativa.Modelo;

namespace CabinaOperativa.DTOs
{
    public class ProveedorDTO
    {
        public int ProveedorId { get; set; }
        public string Descripcion { get; set; }
        public bool RequiereMovil { get; set; }
    }
}
