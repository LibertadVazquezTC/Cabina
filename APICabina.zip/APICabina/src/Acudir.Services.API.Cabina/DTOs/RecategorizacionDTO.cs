﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CabinaOperativa.DTOs
{
    public class RecategorizacionDTO
    {
        public int TipoPrestacionId { get; set; }
        public bool EsPrestacional { get; set; }
        public int? SintomaId { get; set; }
        public string NuevoSintoma { get; set; }
        public string Comentario { get; set; }
    }
}
