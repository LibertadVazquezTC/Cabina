﻿using System;

namespace CabinaOperativa.DTOs
{
    public class RequestResponseDTO
    {
        public bool Error { get; set; }   
        public string Mensaje { get; set; }
    }
}
