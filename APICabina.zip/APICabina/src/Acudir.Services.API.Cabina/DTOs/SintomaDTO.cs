﻿namespace CabinaOperativa.DTOs
{
    public class SintomaDTO
    {
        public int SintomaId { get; set; }
        public string Descripcion { get; set; }
    }
}
