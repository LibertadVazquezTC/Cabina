﻿namespace CabinaOperativa.DTOs
{
    public class TipoPrestacionDTO
    {
        public int TipoPrestacionId { get; set; }
        public string Descripcion { get; set; }
        public int TipoPrestacionCategoriaId { get; set; }
        public string DescripcionAbreviada { get; set; }        
        public string Background { get; set; }
        public string Color { get; set; }       
    }
}
