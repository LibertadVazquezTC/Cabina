﻿namespace CabinaOperativa.DTOs
{
    public class UmsSendDTO
    {
        public UmsSendDTO()
        {
            EnviadoPor = "CabinaOperativa";
            SMSProvicerServiceId = 1;
            SMSProvicerServiceAccountId = 2;
            SMSLocalServiceId = 1;
        }

        public int? UMovilId { get; set; }
        public string Imei { get; set; }
        public string Title { get; set; }
        public string Contenido { get; set; }
        public string ContenidoSMS { get; set; }
        public string RegistrationFCMId { get; set; }
        public string Celular { get; set; }
        public bool CelularModoPrueba { get; set; }
        public int TipoEnvio { get; set; }
        public string EnviadoPor { get; set; }
        public int SMSProvicerServiceId { get; set; }
        public int SMSProvicerServiceAccountId { get; set; }
        public int SMSLocalServiceId { get; set; }
        public string Tipo { get; set; }
        public string SubTipo { get; set; }
    }
}
