﻿using CabinaOperativa.DTOs.Direccion;
using System.Collections.Generic;

namespace CabinaOperativa.DTOs.Zona
{
    public class SubZonaDTO
    {
        public int SubZonaId { get; set; }
        public int ZonaId { get; set; }
        public string Descripcion { get; set; }
        public virtual IEnumerable<DireccionLocalidadLiteDTO> DireccionLocalidad { get; set; }
    }
}
