﻿namespace CabinaOperativa.DTOs.Zona
{
    public class ZonaDTO
    {
        public int ZonaId { get; set; }
        public string Descripcion { get; set; }
        public int[] SubZonaIds { get; set; }
    }
}
