﻿namespace CabinaOperativa.DTOs.sql_Functions
{
    public class fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId
    {
        public int CmnCelularId { get; set; }
        public string Numero { get; set; }
        public string Imei { get; set; }
        public string FcmTokenNotify { get; set; }
        public bool EsMedicoVisitas { get; set; }
        public bool EstaModoPrueba { get; set; }
    }
}
