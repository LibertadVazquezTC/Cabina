﻿using System;

namespace CabinaOperativa.DTOs.sql_StoreProcedures
{
    public class usp_EquiposActivos_get
    {
        public string Equipo { get; set; }
        public string EquipoEstado { get; set; }
        public string EquipoEstadoComentario { get; set; }
        public int MovilId { get; set; }
        public string Movil { get; set; }
        public string Chofer { get; set; }
        public int ChoferAsignaciones { get; set; }
        public string Medico { get; set; }
        public int MedicoAsignaciones { get; set; }
        public string TercerTripulanteDescripcion { get; set; }
        public string Categoria { get; set; }
        public double Distancia { get; set; }
        public string PedidoEnCurso { get; set; }
        public string Contrato { get; set; }
        public string Estado { get; set; }
        public int? TiempoTotal { get; set; }
        public string Zona { get; set; }
        public string TipoPrestacion { get; set; }
        public string Sintoma { get; set; }
        public int CargaMinutos { get; set; }
        public string MedicoGdiaPersonalEspecialidadDescripcion { get; set; }
        public int? MedicoGdiaPersonalEspecialidadId { get; set; }
        public int Puntaje { get; set; }
        public bool OcupadoTeorico { get; set; }
        public string HorarioDespacho { get; set; }
        public int GPSId { get; set; }
        public string GPSLatitud { get; set; }
        public string GPSLongitud { get; set; }
        public bool GPSReportando { get; set; }
        public string MedicoHastaTeorico { get; set; }
        public string ChoferHastaTeorico { get; set; }
        public int Cargas { get; set; }
        public string UltimaCargaUsuario { get; set; }
        public int TiempoRestanteUltimaCarga { get; set; }
        public DateTime? UltimaCargaFecha { get; set; }
        public int GdiaRealEquipoId { get; set; }
        public bool EsInterrumpible { get; set; }
        public string TipoPausa { get; set; }
        public int TiempoRestante { get; set; }
    }
}
