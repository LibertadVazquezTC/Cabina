﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CabinaOperativa.DTOs.sql_StoreProcedures
{
    public class usp_GdiaMovilesEnPausa
    {
        public int GdiaRealEquipoId { get; set; }
        public string Base { get; set; }
        public string Movil { get; set; }

        public int MinutosRestantes { get; set; }
        public string Comentario { get; set; }
        public DateTime AuditoriaInsertDate { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public string Chofer { get; set; }
        public string Medico { get; set; }
        public bool? EstaporFinalizar { get; set; }
    }
}
