﻿using System;

namespace CabinaOperativa.DTOs.sql_StoreProcedures
{
    public class usp_PedidoTramoDespacho_Visita_get
    {
        public int PedidoId { get; set; }
        public int TipoPrestacionId { get; set; }
        public string ContratoDescripcion { get; set; }
        public string PedidoDetalleObservacion { get; set; }
        public string SexoEdad { get; set; }
        public string CodigoReferenteDeCliente { get; set; }
        public string SintomaTomado { get; set; }
        public bool Art { get; set; }
        public float Coseguro { get; set; }
        public string AfiliadoNombre { get; set; }
        public string ContratoPlan { get; set; }
        public string AfiliadoObservacion { get; set; }
        public string AfiliadoTelefono { get; set; }
        public string PermiteRechazo { get; set; }
        public int PedidoTramoId { get; set; }
        public DateTime? OrigenHorarioProgramado { get; set; }
        public string OrigenDomicilio { get; set; }
        public string OrigenPiso { get; set; }
        public string OrigenDepto { get; set; }
        public string OrigenCalleAdyacente1 { get; set; }
        public string OrigenCalleAdyacente2 { get; set; }
        public int OrigenDireccionLocalidadId { get; set; }
        public string OrigenObservacion { get; set; }
        public int PedidoTramoProveedorUMovilHorarioId { get; set; }
        public int PedidoTramoProveedorUMovilHorarioEstadoId { get; set; }
        public DateTime? OrigenArribo { get; set; }
        public DateTime? OrigenPartida { get; set; }
        public int CmnCelularId { get; set; }
        public string Numero { get; set; }
        public string FcmTokenNotify { get; set; }
        public Double? OrigenLatitud { get; set; }
        public Double? OrigenLongitud { get; set; }

    }
}
