﻿namespace CabinaOperativa.DTOs.sql_StoreProcedures
{
    public class usp_PedidoTramo_get
    {
        public int PedidoId { get; set; }
        public int ContratoId { get; set; }
        public int OrigenLocalidadId { get; set; }
        public string OrigenLocalidad { get; set; }
        public string OrigenDomicilio { get; set; }
        public int? OrigenPiso { get; set; }
        public string OrigenDepto { get; set; }
        public string OrigenCalleAdyacente1 { get; set; }
        public string OrigenCalleAdyacente2 { get; set; }
        public string OrigenObservacion { get; set; }
        public string OrigenZona { get; set; }
        public int DestinoLocalidadId { get; set; }
        public string DestinoLocalidad { get; set; }
        public string DestinoDomicilio { get; set; }
        public int? DestinoPiso { get; set; }
        public string DestinoDepto { get; set; }
        public string DestinoCalleAdyacente1 { get; set; }
        public string DestinoCalleAdyacente2 { get; set; }
        public string DestinoObservacion { get; set; }
        public string DestinoZona { get; set; }
        public string Telefono { get; set; }
        public string Sexo { get; set; }
        public string Edad { get; set; }
        public string SintomaTomado { get; set; }
        public string TipoPrestacionAbreviada { get; set; }
        public string AfiliadoNombre { get; set; }
        public string AfiliadoNro { get; set; }
        public string ContratoPlan { get; set; }
        public string Contrato { get; set; }
        public float Coseguro { get; set; }
        public string Despachador { get; set; }
        public string AfiliadoObservacion { get; set; }
        public string PedidoDetalleObservacion { get; set; }
        public bool EsAtencionPrevia { get; set; }
        public string SintomaAtencionPrevia { get; set; }
    }
}
