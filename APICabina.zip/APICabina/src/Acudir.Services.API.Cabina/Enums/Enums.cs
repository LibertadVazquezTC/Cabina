﻿namespace CabinaOperativa.Enums
{
    public enum TipoPrestacionEnum
    {
        VideoConsulta = 56,
        HISO = 57,
        HIRA = 58,
        SERO = 59
    }

    public enum PedidoResultadoLaboratorioEnum
    {
        Detectable = 1,
        NoDetectable = 2,
        SinResultados = 3,
        ReiterarEstudio = 4
    }

    public enum IngresadoSisaFormatoEnum
    {
        Manual = 1,
        Automatico = 2
    }

    public enum GdiaRealEquipoEnum
    {
        MasVidaGdiaRealEquipoId = 166621,
        MovilFicticioVcmGdiaRealEquipoId = 265928,
    }

    public enum CmnComentarioTipoEnum
    {
        CambioDeEstado = 0,
        Interno = 3,
        Externo = 4,
        Reclamo = 5,
        ActualizacionDeCoseguro = 7,
        LinkVideoConsulta = 22
    }

    public enum PedidoTramoProveedorUMovilHorarioEstadoEnum
    {
        Activo = 1,
        Despachado = 2,
        Inactivo = 3,
        Arribo = 4,
        Partida = 5,
        InicioViaje = 6,
        Desasignado = 7,
        DespachadoProveedor = 8,
        DesasignadoMovilProveedor = 9,
        RechazadoPorProveedor = 10,
        PreDespacho = 11,
        NegociandoProveedor = 13,
        AceptadoProveedor = 14

    }

    public enum PedidoAdicionalTipoEnum
    {
        CoseguroCobrado = 2,
        Laboratorio = 40,
        VideoConsultaMedica = 41
    }

    public enum DireccionLocalidadEnum
    {
        CapitalFederal = 1
    }

    public enum PedidoTipoDespachoEnum
    {
        Codigos = 1,
        Traslados = 2,
        Visitas = 3,
        VisitasEnCodigos = 4
    }

    public enum ComponenteTipoEnum
    {
        Chofer = 1,
        Medico = 2,
        UnidadMovil = 3,
        Base = 4,
        Despachador = 5,
        Tomador = 6,
        TercerTripulante = 7
    }

    public enum PedidoTramoEfectorHorarioEstadoEnum
    {
        Negociando = 1,
        Aceptado = 2,
        Rechazado = 3,
        Anulado = 4,
    }

    public enum EfectorEnum
    {
        MasVida = 11
    }

    public enum TipoHorarioEnum
    {
        OrigenArribo,
        OrigenPartida,
        DestinoArribo,
        DestinoPartida
    }

    public enum OrigenDestinoEnum
    {
        Origen = 1,
        Destino = 2
    }

    public enum ProveedorEnum
    {
        Acudir = 1560,
        MasVida = 1615
    }

    public enum TipoEnvioEnum
    {
        Push = 0,
        Sms = 1,
        Mail = 2,
        PushSms = 3,
        SmsPush = 4,
        SmsMail = 5,
        MailSms = 6,
        PushMail = 7,
        MailPush = 8,
        PushSmsMail = 9,
        PushMailSms = 10,
        SmsPushMail = 11,
        SmsMailPush = 12,
        MailPushSms = 13,
        MailSmsPush = 14
    }

    public enum EntidadLogTipoEstadoEnum
    {
        PedidoRechazado = 4,
        PedidoFinalizado = 8,
        PedidoArchivado = 9,
        PedidoAnulado = 10,
        PedidoDiagnosticoMedicoCargado = 26,
        PedidoDiagnosticoActualizar = 132,
        AsignacionMovil = 30,
        PedidoSupervisarCoseguroCobrado = 127,
        AlertaNoConfirma = 69, //esta alarma se activa cada vez que se asigna un movil
        AlertaNoRecibeBB = 119, //esta alarma se activa cada vez que se asigna un movil
        PedidoTramoProveedorUMovilHorarioAsignacionMovil = 30,
        PedidoTramoProveedorUMovilHorarioAsignacionProveedor = 31,
        UMovilDesasignado = 38,
        PedidoNoAtendidoCriterioPresencial = 302,
    }

    public enum PedidoEstadoEnum
    {
        Rechazo = 4,
        Anulado = 5,
        Finalizado = 10,
        Archivado = 14
    }

    public enum GdiaComponenteEnum
    {
        Chofer = 1,
        Medico = 2,
        UnidadMovil = 3,
        Base = 4,
        Despachador = 5,
        Tomador = 6,
        TercerTripulante = 7,
        EnfermeroNeo = 8
    }

    public enum CargaGdiaRealPersonalEstadoEnum
    {
        Asignado = 1,
        Cancelado = 2,
        Confirmado = 3,
        ReAsignado = 4
    }
}
