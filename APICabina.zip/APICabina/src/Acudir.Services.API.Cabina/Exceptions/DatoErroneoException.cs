﻿using System;

namespace CabinaOperativa.Exceptions
{
    public class DatoErroneoException : Exception
    {
        public DatoErroneoException(string message) : base(message)
        {
        }
    }
}
