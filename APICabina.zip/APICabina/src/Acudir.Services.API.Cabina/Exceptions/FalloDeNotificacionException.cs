﻿using System;

namespace CabinaOperativa.Exceptions
{
    public class FalloDeNotificacionException : Exception
    {
        public FalloDeNotificacionException(string message) : base(message)
        {
        }
    }
}
