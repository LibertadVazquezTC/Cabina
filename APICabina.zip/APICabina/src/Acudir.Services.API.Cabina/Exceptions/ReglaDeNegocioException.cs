﻿using System;

namespace CabinaOperativa.Exceptions
{
    public class ReglaDeNegocioException : Exception
    {
        public string ExceptionCode { get; set; }

        public ReglaDeNegocioException(string message, string exceptionCode = "N/A") : base(message)
        {
            ExceptionCode = exceptionCode;
        }
    }
}
