﻿using System;

namespace CabinaOperativa.Exceptions.SISA
{
    public class SISADatoFaltanteException : Exception
    {
        public SISADatoFaltanteException(string message)
            : base(message)
        {
        }
    }
}
