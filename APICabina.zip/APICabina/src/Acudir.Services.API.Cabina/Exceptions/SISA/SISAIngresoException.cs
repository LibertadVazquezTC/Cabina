﻿using System;

namespace CabinaOperativa.Exceptions.SISA
{
    public class SISAIngresoException : Exception
    {
        public SISAIngresoException(string message) : base(message)
        {
        }
    }
}
