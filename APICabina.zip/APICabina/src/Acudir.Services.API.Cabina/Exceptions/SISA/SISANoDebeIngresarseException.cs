﻿using System;

namespace CabinaOperativa.Exceptions.SISA
{
    public class SISANoDebeIngresarseException : Exception
    {
        public SISANoDebeIngresarseException(string message)
            : base(message)
        {
        }
    }
}
