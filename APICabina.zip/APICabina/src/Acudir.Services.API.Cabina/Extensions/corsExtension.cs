﻿using Microsoft.Extensions.DependencyInjection;

namespace CabinaOperativa.Extensions
{
    public static class CorsServiceExtension
    {
        public static void ConfigureCors(this IServiceCollection services)
        {
            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy",
                    builder => builder.WithOrigins(
                        "http://localhost:8080",
                        "http://localhost:8081",
                        "http://localhost:8082",
                        "http://localhost:8086",
                        "http://localhost:16000",
                        "https://api-cabina-dev.acudir.net",
                        "https://api-cabina-qa.acudir.net",
                        "https://api-cabina-staging.acudir.net",
                        "https://api-cabina.acudir.net",
                        "https://workers-dev.acudir.net",
                        "https://workers-qa.acudir.net",
                        "https://workers.acudir.net",
                        "https://dev.acudir.net",
                        "https://qa.acudir.net",
                        "https://staging.acudir.net",
                        "https://acudir.net",
                        "https://cabina.acudir.net",
                        "https://techmed.acudir.net",
                        "https://si.acudir.net")
                    .AllowAnyMethod()
                    .AllowAnyHeader()
                    .AllowCredentials());
            });

            services.AddMvc();
        }
    }
}