﻿using CabinaOperativa.ServiciosExternos;
using CabinaOperativa.ServiciosExternos.Interfaces;
using Microsoft.Extensions.DependencyInjection;

namespace CabinaOperativa.Extensions
{
    public static class externalServicesExtension
    {
        public static void ConfigureExternalServices(this IServiceCollection services)
        {
            services.AddScoped<ISISAConnector, SISAConnector>();           
        }
    }
}