﻿using Acudir.Services.API.Cabina.ServiciosExternos;
using Acudir.Services.API.Cabina.ServiciosExternos.Interfaces;
using CabinaOperativa.Orquestadores;
using CabinaOperativa.Orquestadores.Interfaces;
using Microsoft.Extensions.DependencyInjection;

namespace CabinaOperativa.Extensions
{
    public static class OrquestadorExtension
    {
        public static void ConfigureBussiness(this IServiceCollection services)
        {
            services.AddScoped<IOrquestadorAsignacion, OrquestadorAsignacion>();
            services.AddScoped<IOrquestadorAsignacionEfector, OrquestadorAsignacionEfector>();
            services.AddScoped<IOrquestadorDesasignacion, OrquestadorDesasignacion>();
            services.AddScoped<IOrquestadorDesasignacionEfector, OrquestadorDesasignacionEfector>();
            services.AddScoped<IOrquestadorParaArchivarPedido, OrquestadorParaArchivarPedido>();
            services.AddScoped<IOrquestadorNotificaciones, OrquestadorNotificaciones>();
            services.AddScoped<IOrquestadorCoseguro, OrquestadorCoseguro>();
            services.AddScoped<IOrquestadorParaValidarSiFinalizoElPedido, OrquestadorParaValidarSiFinalizoElPedido>();
            services.AddScoped<IEnvioNotificacionMobileService, EnvioNotificacionMobileService>();
            services.AddScoped<ISacarSalaPacienteHub, SacarSalaPacienteHubService>();

        }
    }
}