﻿using Acudir.Services.API.Cabina.Repositories.Interfaces.Pedido;
using Acudir.Services.API.Cabina.Repositories.Pedido;
using CabinaOperativa.Repositories;
using CabinaOperativa.Repositories.Interfaces.Pedido;
using CabinaOperativa.Utilities;
using CabinaOperativa.Utilities.Interfaces;
using Microsoft.Extensions.DependencyInjection;

namespace CabinaOperativa.Extensions
{
    public static class RepositoryServiceExtension
    {
        public static void ConfigureRepositories(this IServiceCollection services)
        {
            services.AddScoped<IPedidoRepository, PedidoRepository>();
            services.AddScoped<ICargaRepository, CargasRepository>();
            services.AddScoped<ICargaGdiaRealPersonalRepository, CargaGdiaRealPersonalRepository>();
            services.AddScoped<IPedidoAdicionalRepository, PedidoAdicionalRepository>();
            services.AddScoped<IDiagnosticoRepository, DiagnosticoRepository>();
            services.AddScoped<IPedidoAfiliadoRepository, PedidoAfiliadoRepository>();
            services.AddScoped<IPedidoCoseguroRepository, PedidoCoseguroRepository>();
            services.AddScoped<IPedidoTriageVersionDetalleLogRepository, PedidoTriageVersionDetalleLogRepository>();
            services.AddScoped<IPedidoComentarioRepository, PedidoComentarioRepository>();
            services.AddScoped<IPedidoDetalleRepository, PedidoDetalleRepository>();
            services.AddScoped<IPedidoTramoRepository, PedidoTramoRepository>();
            services.AddScoped<IPedidoTramoDetalleRepository, PedidoTramoDetalleRepository>();
            services.AddScoped<IPedidoTramoEfectorHorarioRepository, PedidoTramoEfectorHorarioRepository>();
            services.AddScoped<IPedidoTramoProveedorUMovilHorarioRepository, PedidoTramoProveedorUMovilHorarioRepository>();
            services.AddScoped<IPedidoTramoProveedorUMovilHorarioGdiaRealPersonalRepository, PedidoTramoProveedorUMovilHorarioGdiaRealPersonalRepository>();
            services.AddScoped<IPedidoEntidadLogRepository, PedidoEntidadLogRepository>();
            services.AddScoped<IDireccionRepository, DireccionRepository>();
            services.AddScoped<IDireccionLocalidadRepository, DireccionLocalidadRepository>();
            services.AddScoped<IGdiaRealEquipoRepository, GdiaRealEquipoRepository>();
            services.AddScoped<IGdiaRealEquipoMovilRepository, GdiaRealEquipoMovilRepository>();
            services.AddScoped<IGdiaRealPersonalDetalleRepository, GdiaRealPersonalDetalleRepository>();
            services.AddScoped<ICmnCelularRepository, CmnCelularRepository>();
            services.AddScoped<ICmnConfiguracionRepository, CmnConfiguracionRepository>();
            services.AddScoped<IEfectorRepository, EfectorRepository>();
            services.AddScoped<ISintomaRepository, SintomaRepository>();
            services.AddScoped<ITipoPrestacionRepository, TipoPrestacionRepository>();
            services.AddScoped<ITipoPrestacionContratoRepository, TipoPrestacionContratoRepository>();
            services.AddScoped<IProveedorRepository, ProveedorRepository>();
            services.AddScoped<IPedidoCoseguroTipoNoCobroRepository, PedidoCoseguroTipoNoCobroRepository>();
            services.AddScoped<IPedidoTipoCierreRepository, PedidoTipoCierreRepository>();
            services.AddScoped<IPedidoDiagnosticoMedicoRepository, PedidoDiagnosticoMedicoRepository>();
            services.AddScoped<IUMovilRepository, UMovilRepository>();
            services.AddScoped<IAlertaAccionRepository, AlertaAccionRepository>();
            services.AddScoped<IPedidoAlertaAccionRespuestaRepository, PedidoAlertaAccionRespuestaRepository>();
            services.AddScoped<IPedidoResultadoLaboratorioTipoPrestacionRepository, PedidoResultadoLaboratorioTipoPrestacionRepository>();
            services.AddScoped<IRestriccionTipoCierreDiagnosticoRepository, RestriccionTipoCierreDiagnosticoRepository>();
            services.AddScoped<IRestriccionTipoCierrePrestacionRepository, RestriccionTipoCierrePrestacionRepository>();
            services.AddScoped<IVideoConsultaRepository, VideoConsultaRepository>();

            services.AddScoped<IAppConfigUtility, AppConfigUtility>();
            services.AddScoped<IMasVidaUtility, MasVidaUtility>();
            services.AddScoped<INotificadorEquipoAcudir, NotificadorEquipoAcudir>();
            services.AddScoped<INotificadorMedicoDeVisitas, NotificadorMedicoDeVisitas>();
            services.AddScoped<IDireccionLocalidadDistanciaRepository, DireccionLocalidadDistanciaRepository>();
        }
    }
}