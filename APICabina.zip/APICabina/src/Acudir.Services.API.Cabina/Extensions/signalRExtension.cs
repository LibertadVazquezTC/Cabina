﻿using Microsoft.AspNet.SignalR;
using Microsoft.AspNetCore.Builder;
using Microsoft.Owin.Builder;
using Microsoft.Owin.Cors;
using Owin;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CabinaOperativa.Extensions
{
    using AppFunc = Func<IDictionary<string, object>, Task>;

    public static class SignalRAppExtension
    {
        public static IApplicationBuilder UseAppBuilder(this IApplicationBuilder app, Action<IAppBuilder> configure)
        {
            app.UseOwin(addToPipeline =>
            {
                addToPipeline(next =>
                {
                    var appBuilder = new AppBuilder();
                    appBuilder.Properties["builder.DefaultApp"] = next;

                    configure(appBuilder);

                    return appBuilder.Build<AppFunc>();
                });
            });

            return app;
        }

        public static void UseSignalR(this IApplicationBuilder app, string conn)
        {
            app.UseAppBuilder(appBuilder =>
            {
                GlobalHost.DependencyResolver.UseSqlServer(conn);
                var hubConfiguration = new HubConfiguration { EnableJSONP = true };
                appBuilder.UseCors(CorsOptions.AllowAll);
                appBuilder.MapSignalR("/signalr", hubConfiguration);
            });
        }
    }
}