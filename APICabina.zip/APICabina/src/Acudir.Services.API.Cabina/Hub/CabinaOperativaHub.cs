﻿using System.Threading.Tasks;
using Microsoft.AspNet.SignalR;
using Microsoft.AspNet.SignalR.Hubs;

namespace CabinaOperativa.Hubs
{
    [HubName("CabinaOperativaServiceHub")]
    public class CabinaOperativaHub : Hub
    {

    }
}
