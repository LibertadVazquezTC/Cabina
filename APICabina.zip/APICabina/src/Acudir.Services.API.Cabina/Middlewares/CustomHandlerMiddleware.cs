﻿using Acudir.Services.API.Cabina.Utilities;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using System;
using System.Threading.Tasks;

namespace Acudir.Services.API.Cabina.Middlewares
{
    public class CustomHandlerMiddleware
    {
        private readonly RequestDelegate _next;
        public CustomHandlerMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (Exception ex)
            {
               ExceptionLoggerUtility.LogException(ex);
            }
        }
    }

    public static class CustomHandlerMiddlewareExtensions
    {
        public static IApplicationBuilder UseCustomHandler(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<CustomHandlerMiddleware>();
        }
    }
}
