﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class AlertaAccion
    {
        public AlertaAccion()
        {
            PedidoAlertaAccionRespuesta = new HashSet<PedidoAlertaAccionRespuesta>();
        }

        public int AlertaAccionId { get; set; }
        public int EntidadLogTipoEstadoId { get; set; }
        public string Descripcion { get; set; }
        public bool GeneraEvento { get; set; }
        public bool RequiereDescripcion { get; set; }

        public virtual ICollection<PedidoAlertaAccionRespuesta> PedidoAlertaAccionRespuesta { get; set; }
    }
}
