﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class CargaGdiaRealPersonal
    {
        public int CargaGdiaRealPersonalId { get; set; }
        public int CargaGdiaRealPersonalEstadoId { get; set; }
        public int? GdiaRealPersonalId { get; set; }
        public int? GdiaRealPersonalDetalleId { get; set; }
        public string Comentario { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime AuditoriaInsertDate { get; set; }
        public bool CargaCompleta { get; set; }

        public virtual GdiaRealPersonal GdiaRealPersonal { get; set; }
        public virtual GdiaRealPersonalDetalle GdiaRealPersonalDetalle { get; set; }
    }
}
