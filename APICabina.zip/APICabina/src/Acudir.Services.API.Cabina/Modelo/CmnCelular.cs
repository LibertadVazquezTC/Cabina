﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class CmnCelular
    {
        public CmnCelular()
        {
            GdiaPersonal = new HashSet<GdiaPersonal>();
            UMovilCmnCelular = new HashSet<UMovil>();
            UMovilCmnCelularAlterno = new HashSet<UMovil>();
        }

        public int CmnCelularId { get; set; }
        public string Descripcion { get; set; }
        public string Mail { get; set; }
        public string Numero { get; set; }
        public bool Activo { get; set; }
        public string GcmTokenNotify { get; set; }
        public string Imei { get; set; }
        public string FcmTokenNotify { get; set; }
        public bool ModoPrueba { get; set; }

        public virtual ICollection<GdiaPersonal> GdiaPersonal { get; set; }
        public virtual ICollection<UMovil> UMovilCmnCelular { get; set; }
        public virtual ICollection<UMovil> UMovilCmnCelularAlterno { get; set; }
    }
}
