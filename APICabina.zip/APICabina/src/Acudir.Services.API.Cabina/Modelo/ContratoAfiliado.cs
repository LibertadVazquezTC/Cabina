﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class ContratoAfiliado
    {
        public ContratoAfiliado()
        {
            GdiaPersonal = new HashSet<GdiaPersonal>();
            PedidoAfiliado = new HashSet<PedidoAfiliado>();
        }

        public int ContratoAfiliadoId { get; set; }
        public int ContratoId { get; set; }
        public string AfiliadoNro { get; set; }
        public string AfiliadoNombre { get; set; }
        public string AfiliadoObservacion { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime? AuditoriaInsertDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }
        public int AfiliadoTipo { get; set; }
        public bool Activo { get; set; }
        public string AfiliadoTelefono { get; set; }
        public string AfiliadoEmail { get; set; }
        public int? TipoDocumentoId { get; set; }
        public string DocumentoNro { get; set; }
        public int? HistoriaClinicaPacienteId { get; set; }
        public DateTime? FechaNacimiento { get; set; }

        public virtual HistoriaClinicaPaciente HistoriaClinicaPaciente { get; set; }
        public virtual TipoDocumento TipoDocumento { get; set; }
        public virtual ICollection<GdiaPersonal> GdiaPersonal { get; set; }
        public virtual ICollection<PedidoAfiliado> PedidoAfiliado { get; set; }
    }
}
