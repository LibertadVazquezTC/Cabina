﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class ContratoPlan
    {
        public ContratoPlan()
        {
            PedidoAfiliado = new HashSet<PedidoAfiliado>();
            TipoPrestacionPlanCoseguro = new HashSet<TipoPrestacionPlanCoseguro>();
        }

        public int ContratoPlanId { get; set; }
        public int ContratoId { get; set; }
        public string Descripcion { get; set; }
        public decimal? IVA { get; set; }
        public bool? Activo { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime? AuditoriaInsertDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }
        public string CodigoDelPlan { get; set; }
        public int? ContratoPlanIdExterno { get; set; }

        public virtual ICollection<PedidoAfiliado> PedidoAfiliado { get; set; }
        public virtual ICollection<TipoPrestacionPlanCoseguro> TipoPrestacionPlanCoseguro { get; set; }
    }
}
