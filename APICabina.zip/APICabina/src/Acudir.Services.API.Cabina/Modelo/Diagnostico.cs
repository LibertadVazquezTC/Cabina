﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class Diagnostico
    {
        public Diagnostico()
        {
            PedidoDetalle = new HashSet<PedidoDetalle>();
            PedidoDiagnosticoMedico = new HashSet<PedidoDiagnosticoMedico>();
            RestriccionTipoCierreDiagnostico = new HashSet<RestriccionTipoCierreDiagnostico>();
        }

        public int DiagnosticoId { get; set; }
        public string Descripcion { get; set; }
        public string CodigoCIE { get; set; }
        public bool Activo { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime? AuditoriaInsertDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }
        public int? DiagnosticoGrupoId { get; set; }

        public virtual ICollection<PedidoDetalle> PedidoDetalle { get; set; }
        public virtual ICollection<PedidoDiagnosticoMedico> PedidoDiagnosticoMedico { get; set; }
        public virtual ICollection<RestriccionTipoCierreDiagnostico> RestriccionTipoCierreDiagnostico { get; set; }
    }
}
