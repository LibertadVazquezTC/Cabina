﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class Direccion
    {
        public Direccion()
        {
            HistoriaClinicaPaciente = new HashSet<HistoriaClinicaPaciente>();
            PedidoTramoDetalle = new HashSet<PedidoTramoDetalle>();
        }

        public int DireccionId { get; set; }
        public string Domicilio { get; set; }
        public string CalleAdyacente1 { get; set; }
        public string CalleAdyacente2 { get; set; }
        public string Zona { get; set; }
        public double Latitud { get; set; }
        public double Longitud { get; set; }
        public bool Borrado { get; set; }
        public int Piso { get; set; }
        public string Depto { get; set; }
        public int? DireccionLocalidadId { get; set; }
        public DateTime AuditoriaInsertDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }
        public string AuditoriaInsertUser { get; set; }

        public virtual DireccionLocalidad DireccionLocalidad { get; set; }
        public virtual ICollection<HistoriaClinicaPaciente> HistoriaClinicaPaciente { get; set; }
        public virtual ICollection<PedidoTramoDetalle> PedidoTramoDetalle { get; set; }
    }
}
