﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class DireccionLocalidad
    {
        public DireccionLocalidad()
        {
            Direccion = new HashSet<Direccion>();
            DireccionLocalidadDistanciaDireccionLocalidad1 = new HashSet<DireccionLocalidadDistancia>();
            DireccionLocalidadDistanciaDireccionLocalidad2 = new HashSet<DireccionLocalidadDistancia>();
            PedidoDesdeLocalidad = new HashSet<Pedido>();
            PedidoHastaLocalidad = new HashSet<Pedido>();
            Proveedor = new HashSet<Proveedor>();
        }

        public int DireccionLocalidadId { get; set; }
        public string Descripcion { get; set; }
        public int Kilometros { get; set; }
        public int DireccionPartidoId { get; set; }
        public int DireccionZonaGeograficaId { get; set; }
        public double Latitud { get; set; }
        public double Longitud { get; set; }
        public bool Borrado { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime? AuditoriaInsertDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }
        public int? ZonaVersionDetalleId { get; set; }
        public int? DireccionCordonId { get; set; }

        public virtual DireccionPartido DireccionPartido { get; set; }
        public virtual ICollection<Direccion> Direccion { get; set; }
        public virtual ICollection<DireccionLocalidadDistancia> DireccionLocalidadDistanciaDireccionLocalidad1 { get; set; }
        public virtual ICollection<DireccionLocalidadDistancia> DireccionLocalidadDistanciaDireccionLocalidad2 { get; set; }
        public virtual ICollection<Pedido> PedidoDesdeLocalidad { get; set; }
        public virtual ICollection<Pedido> PedidoHastaLocalidad { get; set; }
        public virtual ICollection<Proveedor> Proveedor { get; set; }
    }
}
