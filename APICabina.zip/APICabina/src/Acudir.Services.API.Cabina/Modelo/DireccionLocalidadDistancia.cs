﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class DireccionLocalidadDistancia
    {
        public int DireccionLocalidadDistanciaId { get; set; }
        public int DireccionLocalidad1Id { get; set; }
        public int DireccionLocalidad2Id { get; set; }
        public int CantidadKilometro { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime? AuditoriaInsertDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }

        public virtual DireccionLocalidad DireccionLocalidad1 { get; set; }
        public virtual DireccionLocalidad DireccionLocalidad2 { get; set; }
    }
}
