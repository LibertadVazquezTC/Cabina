﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class DireccionPartido
    {
        public DireccionPartido()
        {
            DireccionLocalidad = new HashSet<DireccionLocalidad>();
        }

        public int DireccionPartidoId { get; set; }
        public string Descripcion { get; set; }
        public int DireccionProvinciaId { get; set; }
        public bool Borrado { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime? AuditoriaInsertDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }

        public virtual DireccionProvincia DireccionProvincia { get; set; }
        public virtual ICollection<DireccionLocalidad> DireccionLocalidad { get; set; }
    }
}
