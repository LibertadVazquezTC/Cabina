﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class DireccionProvincia
    {
        public DireccionProvincia()
        {
            DireccionPartido = new HashSet<DireccionPartido>();
        }

        public int DireccionProvinciaId { get; set; }
        public string Descripcion { get; set; }
        public string Jurisdiccion { get; set; }
        public bool Borrado { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime? AuditoriaInsertDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }
        public int? CapitalDireccionLocalidadId { get; set; }

        public virtual ICollection<DireccionPartido> DireccionPartido { get; set; }
    }
}
