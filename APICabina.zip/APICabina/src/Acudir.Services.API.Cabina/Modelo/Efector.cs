﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class Efector
    {
        public Efector()
        {
            PedidoTramoEfectorHorario = new HashSet<PedidoTramoEfectorHorario>();
        }

        public int EfectorId { get; set; }
        public string Descripcion { get; set; }
        public string Telefono1 { get; set; }
        public string Telefono2 { get; set; }
        public bool Activo { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime? AuditoriaInsertDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }
        public bool HacePsiquiatrico { get; set; }
        public string Token { get; set; }
        public bool InterfazPrendida { get; set; }
        public bool EsFacturable { get; set; }
        public int? GdiaRealEquipoIdFacturable { get; set; }

        public virtual ICollection<PedidoTramoEfectorHorario> PedidoTramoEfectorHorario { get; set; }
    }
}
