﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class GdiaPersonal
    {
        public GdiaPersonal()
        {
            GdiaRealPersonal = new HashSet<GdiaRealPersonal>();
            PedidoCoseguro = new HashSet<PedidoCoseguro>();
        }

        public int GdiaPersonalId { get; set; }
        public int? SoftlandPersonalId { get; set; }
        public string Descripcion { get; set; }
        public bool Activo { get; set; }
        public byte[] Timestamp { get; set; }
        public DateTime AuditoriaInsertDate { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public string DatosContacto { get; set; }
        public int? BioStarnUserIdn { get; set; }
        public int? GdiaPersonalEspecialidadId { get; set; }
        public int ProveedorId { get; set; }
        public bool Suspendido { get; set; }
        public string Legajo { get; set; }
        public int? CategoriaId { get; set; }
        public string Telefono { get; set; }
        public string Mail { get; set; }
        public bool EnviarSms { get; set; }
        public bool EnviarMail { get; set; }
        public string Dni { get; set; }
        public bool UsuarioTGO { get; set; }
        public int? GdiaPersonalSuspendidoId { get; set; }
        public int? BioStarnUserId { get; set; }
        public DateTime? ProcesoRaetUpdateDate { get; set; }
        public bool MedicoVisitas { get; set; }
        public bool MovilidadPropia { get; set; }
        public int? CmnCelularId { get; set; }
        public int? ContratoAfiliadoId { get; set; }
        public string Observacion { get; set; }
        public int LimiteServiciosDia { get; set; }
        public bool SoloHombres { get; set; }
        public bool SoloMujeres { get; set; }
        public string Sexo { get; set; }
        public string Matricula { get; set; }

        public virtual CmnCelular CmnCelular { get; set; }
        public virtual ContratoAfiliado ContratoAfiliado { get; set; }
        public virtual Proveedor Proveedor { get; set; }
        public virtual ICollection<GdiaRealPersonal> GdiaRealPersonal { get; set; }
        public virtual ICollection<PedidoCoseguro> PedidoCoseguro { get; set; }
    }
}
