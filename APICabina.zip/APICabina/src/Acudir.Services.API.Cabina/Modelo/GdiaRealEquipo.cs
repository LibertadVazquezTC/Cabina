﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class GdiaRealEquipo
    {
        public GdiaRealEquipo()
        {
            GdiaRealEquipoMovil = new HashSet<GdiaRealEquipoMovil>();
            GdiaRealPersonalDetalle = new HashSet<GdiaRealPersonalDetalle>();
            PedidoTramoProveedorUMovilHorario = new HashSet<PedidoTramoProveedorUMovilHorario>();
        }

        public int GdiaRealEquipoId { get; set; }
        public int? GdiaTeoricaId { get; set; }
        public int? GdiaLogicaDetalleId { get; set; }
        public int GdiaBaseTipoId { get; set; }
        public DateTime DesdeTeorico { get; set; }
        public DateTime HastaTeorico { get; set; }
        public DateTime? DesdeOperativo { get; set; }
        public DateTime? HastaOperativo { get; set; }
        public byte[] Timestamp { get; set; }
        public DateTime AuditoriaInsertDate { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public int? GdiaEquipoId { get; set; }
        public bool RequiereMovil { get; set; }

        public virtual ICollection<GdiaRealEquipoMovil> GdiaRealEquipoMovil { get; set; }
        public virtual ICollection<GdiaRealPersonalDetalle> GdiaRealPersonalDetalle { get; set; }
        public virtual ICollection<PedidoTramoProveedorUMovilHorario> PedidoTramoProveedorUMovilHorario { get; set; }
        public int CantidadDesasignaciones { get; set; }
    }

}
