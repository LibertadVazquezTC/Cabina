﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class GdiaRealEquipoMovil
    {
        public int GdiaRealEquipoMovilId { get; set; }
        public int UMovilId { get; set; }
        public int GdiaRealEquipoId { get; set; }
        public byte[] Timestamp { get; set; }
        public DateTime AuditoriaInsertDate { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public int? GdiaTeoricaEquipoMovilId { get; set; }

        public virtual GdiaRealEquipo GdiaRealEquipo { get; set; }
        public virtual UMovil UMovil { get; set; }
    }
}
