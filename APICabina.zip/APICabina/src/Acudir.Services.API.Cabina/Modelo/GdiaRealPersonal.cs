﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class GdiaRealPersonal
    {
        public GdiaRealPersonal()
        {
            CargaGdiaRealPersonal = new HashSet<CargaGdiaRealPersonal>();
            GdiaRealPersonalDetalle = new HashSet<GdiaRealPersonalDetalle>();
            InverseReemplazo = new HashSet<GdiaRealPersonal>();
            PedidoTramoProveedorUMovilHorarioGdiaRealPersonal = new HashSet<PedidoTramoProveedorUMovilHorarioGdiaRealPersonal>();
        }

        public int GdiaRealPersonalId { get; set; }
        public int GdiaPersonalId { get; set; }
        public int GdiaBaseTipoId { get; set; }
        public DateTime DesdeTeorico { get; set; }
        public DateTime HastaTeorico { get; set; }
        public DateTime? DesdeOperativo { get; set; }
        public DateTime? HastaOperativo { get; set; }
        public byte[] Timestamp { get; set; }
        public DateTime AuditoriaInsertDate { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public int? GdiaTeoricaPersonalId { get; set; }
        public DateTime? DesdeFichaje { get; set; }
        public DateTime? HastaFichaje { get; set; }
        public int? GdiaRealPersonalEstadoTipoId { get; set; }
        public string Comentario { get; set; }
        public bool FichajeAltaPorTgo { get; set; }
        public bool FichajeBajaPorTgo { get; set; }
        public int? ReemplazoId { get; set; }
        public decimal? TemperaturaCorporal { get; set; }
        public bool? PuedeIngresar { get; set; }
        public DateTime? RegistroTemperatura { get; set; }
        public bool? PresentaTos { get; set; }
        public bool? PresentaOdinofagia { get; set; }
        public bool? PresentaDificultadRespiratoria { get; set; }
        public bool? PresentaAnosmia { get; set; }

        public virtual GdiaPersonal GdiaPersonal { get; set; }
        public virtual GdiaRealPersonal Reemplazo { get; set; }
        public virtual ICollection<CargaGdiaRealPersonal> CargaGdiaRealPersonal { get; set; }
        public virtual ICollection<GdiaRealPersonalDetalle> GdiaRealPersonalDetalle { get; set; }
        public virtual ICollection<GdiaRealPersonal> InverseReemplazo { get; set; }
        public virtual ICollection<PedidoTramoProveedorUMovilHorarioGdiaRealPersonal> PedidoTramoProveedorUMovilHorarioGdiaRealPersonal { get; set; }
    }
}
