﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class GdiaRealPersonalDetalle
    {
        public GdiaRealPersonalDetalle()
        {
            CargaGdiaRealPersonal = new HashSet<CargaGdiaRealPersonal>();
            PedidoTramoProveedorUMovilHorarioGdiaRealPersonal = new HashSet<PedidoTramoProveedorUMovilHorarioGdiaRealPersonal>();
        }

        public int GdiaRealPersonalDetalleId { get; set; }
        public int GdiaRealPersonalId { get; set; }
        public int? GdiaRealEquipoId { get; set; }
        public int GdiaBaseTipoId { get; set; }
        public int? GdiaTeoricaPersonalDetalleId { get; set; }
        public DateTime DesdeTeorico { get; set; }
        public DateTime HastaTeorico { get; set; }
        public DateTime? DesdeOperativo { get; set; }
        public DateTime? HastaOperativo { get; set; }
        public bool? TercerTripulante { get; set; }
        public int? GdiaRealPersonalDetalleEstadoTipoId { get; set; }
        public string Comentario { get; set; }
        public byte[] Timestamp { get; set; }
        public DateTime AuditoriaInsertDate { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }

        public virtual GdiaRealEquipo GdiaRealEquipo { get; set; }
        public virtual GdiaRealPersonal GdiaRealPersonal { get; set; }
        public virtual ICollection<CargaGdiaRealPersonal> CargaGdiaRealPersonal { get; set; }
        public virtual ICollection<PedidoTramoProveedorUMovilHorarioGdiaRealPersonal> PedidoTramoProveedorUMovilHorarioGdiaRealPersonal { get; set; }
    }
}
