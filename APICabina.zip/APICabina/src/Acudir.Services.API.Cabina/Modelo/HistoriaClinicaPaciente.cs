﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class HistoriaClinicaPaciente
    {
        public HistoriaClinicaPaciente()
        {
            ContratoAfiliado = new HashSet<ContratoAfiliado>();
        }

        public int HistoriaClinicaPacienteId { get; set; }
        public int TipoDocumentoId { get; set; }
        public string DocumentoNro { get; set; }
        public string Nombre { get; set; }
        public string Telefono { get; set; }
        public int DireccionId { get; set; }
        public string Edad { get; set; }
        public string Email { get; set; }
        public string Sexo { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime? AuditoriaInsertDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }
        public DateTime? FechaNacimiento { get; set; }

        public virtual Direccion Direccion { get; set; }
        public virtual TipoDocumento TipoDocumento { get; set; }
        public virtual ICollection<ContratoAfiliado> ContratoAfiliado { get; set; }
    }
}
