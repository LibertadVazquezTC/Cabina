﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class Pedido
    {
        public Pedido()
        {
            InversePedidoPadre = new HashSet<Pedido>();
            PedidoAdicional = new HashSet<PedidoAdicional>();
            PedidoAfiliado = new HashSet<PedidoAfiliado>();
            PedidoComentario = new HashSet<PedidoComentario>();
            PedidoCoseguro = new HashSet<PedidoCoseguro>();
            PedidoDetalle = new HashSet<PedidoDetalle>();
            PedidoDiagnosticoMedico = new HashSet<PedidoDiagnosticoMedico>();
            PedidoEntidadLog = new HashSet<PedidoEntidadLog>();
            PedidoMuestra = new HashSet<PedidoMuestra>();
            PedidoTramo = new HashSet<PedidoTramo>();
            PedidoTriageVersionDetalleLog = new HashSet<PedidoTriageVersionDetalleLog>();
        }

        public int PedidoId { get; set; }
        public string QuienLlama { get; set; }
        public int ContratoId { get; set; }
        public int PedidoEstadoId { get; set; }
        public DateTime Fecha { get; set; }
        public string Zona { get; set; }
        public int TipoPrestacionId { get; set; }
        public string Edad { get; set; }
        public string Sexo { get; set; }
        public string Tomador { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime? AuditoriaInsertDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }
        public bool ConDerivacion { get; set; }
        public bool EsProgramacion { get; set; }
        public int? VentanaTolerancia { get; set; }
        public int CantidadApoyos { get; set; }
        public bool PacientePsiquiatrico { get; set; }
        public bool SuperRojo { get; set; }
        public int? PedidoTipoCierreId { get; set; }
        public string ZonaHasta { get; set; }
        public int? EventoDetalleLocacionId { get; set; }
        public string ContratoTransaccionId { get; set; }
        public int? PedidoPadreId { get; set; }
        public int? TriageVersionId { get; set; }
        public int? DesdeLocalidadId { get; set; }
        public int? HastaLocalidadId { get; set; }
        public DateTime? FechaAtencion { get; set; }
        public DateTime? FechaInicioToma { get; set; }
        public DateTime? FechaInicioNegociacion { get; set; }
        public DateTime? FechaHabilitacionDespacho { get; set; }
        public DateTime? FechaFinToma { get; set; }
        public DateTime? FechaFinalizado { get; set; }
        public DateTime? FechaArchivado { get; set; }
        public int? GestionId { get; set; }
        public int? PedidoEstadoTipoId { get; set; }
        public bool EsTurno { get; set; }
        public int? VentanaToleranciaDespachador { get; set; }
        public bool EsProtocoloIAM { get; set; }
        public bool EsProtocoloStroke { get; set; }
        public int? EventoDetalleEquipoId { get; set; }
        public int PedidoTipoDespachoId { get; set; }
        public bool EsProtocoloSepsis { get; set; }
        public bool? TrasladoMultipleNoFacturable { get; set; }
        public int? PedidoResultadoLaboratorioId { get; set; }
        public int? ProtocoloTipoId { get; set; }
        public bool? IngresadoSisa { get; set; }
        public DateTime? IngresadoSisaFecha { get; set; }
        public int? IngresadoSisaFormato { get; set; }
        public string IngresadoSisaRequest { get; set; }
        public string IngresadoSisaResponse { get; set; }

        public virtual DireccionLocalidad DesdeLocalidad { get; set; }
        public virtual DireccionLocalidad HastaLocalidad { get; set; }
        public virtual Pedido PedidoPadre { get; set; }
        public virtual PedidoResultadoLaboratorio PedidoResultadoLaboratorio { get; set; }
        public virtual PedidoTipoCierre PedidoTipoCierre { get; set; }
        public virtual TipoPrestacion TipoPrestacion { get; set; }
        public virtual ICollection<Pedido> InversePedidoPadre { get; set; }
        public virtual ICollection<PedidoAdicional> PedidoAdicional { get; set; }
        public virtual ICollection<PedidoAfiliado> PedidoAfiliado { get; set; }
        public virtual ICollection<PedidoComentario> PedidoComentario { get; set; }
        public virtual ICollection<PedidoCoseguro> PedidoCoseguro { get; set; }
        public virtual ICollection<PedidoDetalle> PedidoDetalle { get; set; }
        public virtual ICollection<PedidoDiagnosticoMedico> PedidoDiagnosticoMedico { get; set; }
        public virtual ICollection<PedidoEntidadLog> PedidoEntidadLog { get; set; }
        public virtual ICollection<PedidoMuestra> PedidoMuestra { get; set; }
        public virtual ICollection<PedidoTramo> PedidoTramo { get; set; }
        public virtual ICollection<PedidoTriageVersionDetalleLog> PedidoTriageVersionDetalleLog { get; set; }
    }
}
