﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class PedidoAdicional
    {
        public int PedidoAdicionalId { get; set; }
        public int PedidoId { get; set; }
        public float Cantidad { get; set; }
        public int PedidoAdicionalTipoId { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime? AuditoriaInsertDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }
        public bool? Activo { get; set; }

        public virtual Pedido Pedido { get; set; }
    }
}
