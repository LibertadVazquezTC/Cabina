﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class PedidoAfiliado
    {
        public PedidoAfiliado()
        {
            InversePedidoAfiliadoReemplazo = new HashSet<PedidoAfiliado>();
        }

        public int PedidoAfiliadoId { get; set; }
        public int PedidoId { get; set; }
        public int? ContratoPlanId { get; set; }
        public int? ContratoAfiliadoId { get; set; }
        public bool PacienteRecomendado { get; set; }
        public int? PedidoAnteriorId { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime? AuditoriaInsertDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }
        public bool? CobraCoseguro { get; set; }
        public bool Discapacidad { get; set; }
        public bool PMI { get; set; }
        public int? PedidoAfiliadoReemplazoId { get; set; }
        public bool Activo { get; set; }
        public bool PersonajePublico { get; set; }
        public int? SoftlandIndicadorEstadoPadron { get; set; }
        public bool InternacionDomiciliaria { get; set; }

        public string ObservacionesAfiliado { get; set; }
        public virtual ContratoAfiliado ContratoAfiliado { get; set; }
        public virtual ContratoPlan ContratoPlan { get; set; }
        public virtual Pedido Pedido { get; set; }
        public virtual PedidoAfiliado PedidoAfiliadoReemplazo { get; set; }
        public virtual ICollection<PedidoAfiliado> InversePedidoAfiliadoReemplazo { get; set; }
    }
}
