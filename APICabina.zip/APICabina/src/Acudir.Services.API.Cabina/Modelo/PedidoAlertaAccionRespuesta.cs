﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class PedidoAlertaAccionRespuesta
    {
        public int PedidoAlertaAccionRespuestaId { get; set; }
        public int AlertaAccionId { get; set; }
        public int PedidoEntidadLogId { get; set; }
        public string Descripcion { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime? AuditoriaInsertDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }

        public virtual AlertaAccion AlertaAccion { get; set; }
        public virtual PedidoEntidadLog PedidoEntidadLog { get; set; }
    }
}
