﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class PedidoComentario
    {
        public int PedidoComentarioId { get; set; }
        public string Descripcion { get; set; }
        public int PedidoId { get; set; }
        public string Usuario { get; set; }
        public DateTime Hora { get; set; }
        public int CmnComentarioTipoId { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime? AuditoriaInsertDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }
        public bool Leido { get; set; }
        public string LeidoUpdateUser { get; set; }
        public DateTime? LeidoUpdateDate { get; set; }

        public virtual Pedido Pedido { get; set; }
    }
}
