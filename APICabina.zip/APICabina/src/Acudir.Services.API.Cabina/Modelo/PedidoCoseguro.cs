﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class PedidoCoseguro
    {
        public int PedidoCoseguroId { get; set; }
        public int PedidoId { get; set; }
        public int? PedidoTramoProveedorUMovilHorarioId { get; set; }
        public int? GdiaPersonalId { get; set; }
        public bool Recibido { get; set; }
        public DateTime? FechaRecibido { get; set; }
        public bool Confirmado { get; set; }
        public DateTime? FechaConfirmado { get; set; }
        public bool? Cobrado { get; set; }
        public DateTime? FechaCobrado { get; set; }
        public bool Activo { get; set; }
        public DateTime? AuditadoFecha { get; set; }
        public string AuditadoPor { get; set; }
        public int? PedidoCoseguroAuditoriaResolucionId { get; set; }
        public double Coseguro { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime? AuditoriaInsertDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }
        public bool? InformadoCliente { get; set; }
        public string NumeroResolucion { get; set; }
        public string InformadoPor { get; set; }
        public DateTime? InformadoFecha { get; set; }
        public int? PedidoCoseguroTipoNoCobroId { get; set; }
        public int? PedidoTramoEfectorHorarioId { get; set; }

        public virtual GdiaPersonal GdiaPersonal { get; set; }
        public virtual Pedido Pedido { get; set; }
        public virtual PedidoCoseguroTipoNoCobro PedidoCoseguroTipoNoCobro { get; set; }
        public virtual PedidoTramoEfectorHorario PedidoTramoEfectorHorario { get; set; }
        public virtual PedidoTramoProveedorUMovilHorario PedidoTramoProveedorUMovilHorario { get; set; }
    }
}
