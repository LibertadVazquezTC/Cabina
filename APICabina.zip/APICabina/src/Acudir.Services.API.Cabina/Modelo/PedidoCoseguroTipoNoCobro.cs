﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class PedidoCoseguroTipoNoCobro
    {
        public PedidoCoseguroTipoNoCobro()
        {
            PedidoCoseguro = new HashSet<PedidoCoseguro>();
        }

        public int PedidoCoseguroTipoNoCobroId { get; set; }
        public string Descripcion { get; set; }
        public bool RequiereV2 { get; set; }
        public bool AuditoriaCoseguro { get; set; }
        public bool RespuestaAndroid { get; set; }
        public bool Activo { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime? AuditoriaInsertDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }

        public virtual ICollection<PedidoCoseguro> PedidoCoseguro { get; set; }
    }
}
