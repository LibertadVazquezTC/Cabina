﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class PedidoDetalle
    {
        public int PedidoDetalleId { get; set; }
        public int PedidoId { get; set; }
        public string Telefono { get; set; }
        public int? SintomaId { get; set; }
        public string Observacion { get; set; }
        public string CodigoReferenteDeCliente { get; set; }
        public float Coseguro { get; set; }
        public string SintomaTomado { get; set; }
        public int? DiagnosticoId { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime? AuditoriaInsertDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }
        public string DiagnosticoTomado { get; set; }
        public int? MotivoTrasladoId { get; set; }

        public virtual Diagnostico Diagnostico { get; set; }
        public virtual Pedido Pedido { get; set; }
        public virtual Sintoma Sintoma { get; set; }
    }
}
