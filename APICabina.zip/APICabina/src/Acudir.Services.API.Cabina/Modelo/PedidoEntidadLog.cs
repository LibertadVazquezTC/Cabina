﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class PedidoEntidadLog
    {
        public PedidoEntidadLog()
        {
            PedidoAlertaAccionRespuesta = new HashSet<PedidoAlertaAccionRespuesta>();
        }

        public int PedidoEntidadLogId { get; set; }
        public int PedidoId { get; set; }
        public int Valor { get; set; }
        public int EntidadLogTipoEstadoId { get; set; }
        public DateTime Fecha { get; set; }
        public string Usuario { get; set; }
        public string Accion { get; set; }
        public string IP { get; set; }
        public int GrabacionId { get; set; }
        public int? UsuarioId { get; set; }
        public string DireccionIP { get; set; }
        public string WsError { get; set; }
        public int? WsMsgEstadoId { get; set; }
        public string WsMsgEstadoDesc { get; set; }
        public string WsOperador { get; set; }
        public int? WsFiller { get; set; }
        public int? WsContratoId { get; set; }
        public string WsContenido { get; set; }
        public string WsCorrelationId { get; set; }
        public DateTime? AuditoriaInsertDate { get; set; }
        public string Descripcion { get; set; }

        public virtual Pedido Pedido { get; set; }
        public virtual ICollection<PedidoAlertaAccionRespuesta> PedidoAlertaAccionRespuesta { get; set; }
    }
}
