﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class PedidoMuestra
    {
        public int PedidoMuestraId { get; set; }
        public int PedidoId { get; set; }
        public int ProveedorId { get; set; }
        public string CodigoMuestra { get; set; }
        public DateTime? FechaIngresoFarmacia { get; set; }
        public DateTime? FechaEgresoFarmacia { get; set; }
        public DateTime? FechaIngresoLaboratorio { get; set; }
        public bool Activo { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime AuditoriaInsertDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }
        public bool IngresoManual { get; set; }

        public virtual Pedido Pedido { get; set; }
        public virtual Proveedor Proveedor { get; set; }
    }
}
