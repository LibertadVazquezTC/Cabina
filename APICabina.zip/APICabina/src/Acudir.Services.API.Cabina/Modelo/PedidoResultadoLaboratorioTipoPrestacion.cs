﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class PedidoResultadoLaboratorioTipoPrestacion
    {
        public int PedidoResultadoLaboratorioTipoPrestacionId { get; set; }
        public int PedidoResultadoLaboratorioId { get; set; }
        public int TipoPrestacionId { get; set; }
        public bool Activo { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime? AuditoriaInsertDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }

        public virtual PedidoResultadoLaboratorio PedidoResultadoLaboratorio { get; set; }
        public virtual TipoPrestacion TipoPrestacion { get; set; }
    }
}
