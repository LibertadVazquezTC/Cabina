﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class PedidoTipoCierre
    {
        public PedidoTipoCierre()
        {
            Pedido = new HashSet<Pedido>();
            RestriccionTipoCierreDiagnostico = new HashSet<RestriccionTipoCierreDiagnostico>();
            RestriccionTipoCierrePrestacion = new HashSet<RestriccionTipoCierrePrestacion>();
        }

        public int PedidoTipoCierreId { get; set; }
        public string Descripcion { get; set; }
        public string DescAbreviada { get; set; }
        public bool Activo { get; set; }

        public virtual ICollection<Pedido> Pedido { get; set; }
        public virtual ICollection<RestriccionTipoCierreDiagnostico> RestriccionTipoCierreDiagnostico { get; set; }
        public virtual ICollection<RestriccionTipoCierrePrestacion> RestriccionTipoCierrePrestacion { get; set; }
    }
}
