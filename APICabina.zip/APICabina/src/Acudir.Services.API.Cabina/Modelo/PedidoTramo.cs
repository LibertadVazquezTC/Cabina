﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class PedidoTramo
    {
        public PedidoTramo()
        {
            PedidoTramoDetalle = new HashSet<PedidoTramoDetalle>();
            PedidoTramoEfectorHorario = new HashSet<PedidoTramoEfectorHorario>();
            PedidoTramoProveedorUMovilHorario = new HashSet<PedidoTramoProveedorUMovilHorario>();
        }

        public int PedidoTramoId { get; set; }
        public int PedidoId { get; set; }
        public int TramoNro { get; set; }
        public bool Activo { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime? AuditoriaInsertDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }
        public DateTime? HorarioDespacho { get; set; }
        public int? DuracionEstimadaViaje { get; set; }
        public DateTime? DesdeTeorico { get; set; }
        public DateTime? HastaTeorico { get; set; }

        public virtual Pedido Pedido { get; set; }
        public virtual ICollection<PedidoTramoDetalle> PedidoTramoDetalle { get; set; }
        public virtual ICollection<PedidoTramoEfectorHorario> PedidoTramoEfectorHorario { get; set; }
        public virtual ICollection<PedidoTramoProveedorUMovilHorario> PedidoTramoProveedorUMovilHorario { get; set; }
    }
}
