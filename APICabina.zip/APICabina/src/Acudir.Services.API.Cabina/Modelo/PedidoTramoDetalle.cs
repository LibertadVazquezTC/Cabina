﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class PedidoTramoDetalle
    {
        public int PedidoTramoDetalleId { get; set; }
        public int PedidoTramoId { get; set; }
        public int DireccionId { get; set; }
        public DateTime? HorarioProgramado { get; set; }
        public int OrigenDestino { get; set; }
        public bool Activo { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime? AuditoriaInsertDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }
        public DateTime? HorarioTeorico { get; set; }
        public string Observacion { get; set; }

        public virtual Direccion Direccion { get; set; }
        public virtual PedidoTramo PedidoTramo { get; set; }
    }
}
