﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class PedidoTramoEfectorHorario
    {
        public PedidoTramoEfectorHorario()
        {
            PedidoCoseguro = new HashSet<PedidoCoseguro>();
        }

        public int PedidoTramoEfectorHorarioId { get; set; }
        public int EfectorId { get; set; }
        public int PedidoTramoEfectorHorarioEstadoId { get; set; }
        public int PedidoTramoId { get; set; }
        public string NroServicio { get; set; }
        public int VentaToleranciaNegociada { get; set; }
        public DateTime? OrigenArribo { get; set; }
        public DateTime? OrigenPartida { get; set; }
        public DateTime? DestinoArribo { get; set; }
        public DateTime? DestinoPartida { get; set; }
        public bool Origen { get; set; }
        public bool Destino { get; set; }
        public bool Apoyo { get; set; }
        public bool Activo { get; set; }
        public string QuienAtiende { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime? AuditoriaInsertDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }
        public DateTime? HorarioAceptacion { get; set; }
        public int? PedidoTramoEfectorHorarioEstadoTipoId { get; set; }

        public virtual Efector Efector { get; set; }
        public virtual PedidoTramo PedidoTramo { get; set; }
        public virtual ICollection<PedidoCoseguro> PedidoCoseguro { get; set; }
    }
}
