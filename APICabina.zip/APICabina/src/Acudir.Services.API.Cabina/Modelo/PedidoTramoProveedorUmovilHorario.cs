﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class PedidoTramoProveedorUMovilHorario
    {
        public PedidoTramoProveedorUMovilHorario()
        {
            InversePedidoTramoProveedorUMovilHorarioRelevo = new HashSet<PedidoTramoProveedorUMovilHorario>();
            PedidoCoseguro = new HashSet<PedidoCoseguro>();
            PedidoTramoProveedorUMovilHorarioGdiaRealPersonal = new HashSet<PedidoTramoProveedorUMovilHorarioGdiaRealPersonal>();
        }

        public int PedidoTramoProveedorUMovilHorarioId { get; set; }
        public int ProveedorId { get; set; }
        public int? UMovilId { get; set; }
        public int PedidoTramoId { get; set; }
        public int PedidoTramoProveedorUMovilHorarioEstadoId { get; set; }
        public DateTime? OrigenArribo { get; set; }
        public DateTime? OrigenPartida { get; set; }
        public DateTime? DestinoArribo { get; set; }
        public DateTime? DestinoPartida { get; set; }
        public bool Origen { get; set; }
        public bool Destino { get; set; }
        public bool Apoyo { get; set; }
        public bool Activo { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime? AuditoriaInsertDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }
        public bool ReportIngresado { get; set; }
        public DateTime? FechaIngresoReport { get; set; }
        public string UsurarioIngresoReport { get; set; }
        public DateTime? OrigenArriboGps { get; set; }
        public DateTime? OrigenPartidaGps { get; set; }
        public DateTime? DestinoArriboGps { get; set; }
        public DateTime? DestinoPartidaGps { get; set; }
        public int? RankingDespacho { get; set; }
        public int? GpsId { get; set; }
        public bool PoseeFirma { get; set; }
        public DateTime? FechaIngresoFirma { get; set; }
        public string UsuarioIngresoFirma { get; set; }
        public string ReportNumero { get; set; }
        public bool ReportEscaneado { get; set; }
        public int? PedidoTramoProveedorUMovilHorarioRelevoId { get; set; }
        public DateTime? FechaAsignacion { get; set; }
        public DateTime? FechaRecibido { get; set; }
        public DateTime? FechaConfirmado { get; set; }
        public DateTime? FechaIniciodeViaje { get; set; }
        public DateTime? FechaSolicitudDerivacion { get; set; }
        public DateTime? FechaContactoObraSocial { get; set; }
        public DateTime? FechaCargaDerivacion { get; set; }
        public DateTime? FechaAsignacionDerivacion { get; set; }
        public DateTime? FechaRecibidoDerivacion { get; set; }
        public DateTime? FechaConfirmadoDerivacion { get; set; }
        public int? GdiaRealEquipoId { get; set; }
        public int? PedidoTramoProveedorUMovilHorarioEstadoTipoId { get; set; }
        public string NroServicio { get; set; }
        public string QuienAtiende { get; set; }
        public DateTime? HorarioAceptacion { get; set; }
        public int? VentaToleranciaNegociada { get; set; }
        public int? OrigenKMCero { get; set; }
        public int? DestinoKMCero { get; set; }
        public int? OrigenDestinoKmCero { get; set; }
        public bool Factura { get; set; }
        public bool Audita { get; set; }
        public bool RequiereMovil { get; set; }
        public int? OrigenProvinciaKm { get; set; }
        public int? DestinoProvinciaKm { get; set; }
        public float CotizacionProveedor { get; set; }
        public int CantidadKitsBioseguridadUsados { get; set; }

        public virtual GdiaRealEquipo GdiaRealEquipo { get; set; }
        public virtual PedidoTramo PedidoTramo { get; set; }
        public virtual PedidoTramoProveedorUMovilHorario PedidoTramoProveedorUMovilHorarioRelevo { get; set; }
        public virtual Proveedor Proveedor { get; set; }
        public virtual UMovil UMovil { get; set; }
        public virtual ICollection<PedidoTramoProveedorUMovilHorario> InversePedidoTramoProveedorUMovilHorarioRelevo { get; set; }
        public virtual ICollection<PedidoCoseguro> PedidoCoseguro { get; set; }
        public virtual ICollection<PedidoTramoProveedorUMovilHorarioGdiaRealPersonal> PedidoTramoProveedorUMovilHorarioGdiaRealPersonal { get; set; }
    }
}
