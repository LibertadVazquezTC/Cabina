﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class PedidoTramoProveedorUMovilHorarioGdiaRealPersonal
    {
        public int PedidoTramoProveedorUMovilHorarioGdiaRealPersonalId { get; set; }
        public int PedidoTramoProveedorUMovilHorarioId { get; set; }
        public bool Activo { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime? AuditoriaInsertDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }
        public int? GdiaRealPersonalId { get; set; }
        public int? GdiaComponenteId { get; set; }
        public int? GdiaRealPersonalDetalleId { get; set; }

        public virtual GdiaRealPersonal GdiaRealPersonal { get; set; }
        public virtual GdiaRealPersonalDetalle GdiaRealPersonalDetalle { get; set; }
        public virtual PedidoTramoProveedorUMovilHorario PedidoTramoProveedorUMovilHorario { get; set; }
    }
}
