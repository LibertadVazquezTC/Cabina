﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class PedidoTriageVersionDetalleLog
    {
        public int PedidoTriageVersionDetalleLogId { get; set; }
        public int TriageVersionDetalleId { get; set; }
        public int PedidoId { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime? AuditoriaInsertDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }

        public virtual Pedido Pedido { get; set; }
        public virtual TriageVersionDetalle TriageVersionDetalle { get; set; }
    }
}
