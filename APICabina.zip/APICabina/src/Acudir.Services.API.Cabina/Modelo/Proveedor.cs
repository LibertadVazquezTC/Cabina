﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class Proveedor
    {
        public Proveedor()
        {
            GdiaPersonal = new HashSet<GdiaPersonal>();
            PedidoMuestra = new HashSet<PedidoMuestra>();
            PedidoTramoProveedorUMovilHorario = new HashSet<PedidoTramoProveedorUMovilHorario>();
            UMovil = new HashSet<UMovil>();
        }

        public int ProveedorId { get; set; }
        public string Descripcion { get; set; }
        public string Domicilio { get; set; }
        public string softlandPVMPRH_NROCTA { get; set; }
        public bool Activo { get; set; }
        public string Mail { get; set; }
        public bool GeneraAlertaSistema { get; set; }
        public bool GeneraAlertaGPS { get; set; }
        public bool GeneraAlertaDIM { get; set; }
        public string Telefono { get; set; }
        public bool Factura { get; set; }
        public bool Audita { get; set; }
        public bool RequiereMovil { get; set; }
        public string AuditoriaInserUser { get; set; }
        public int? DireccionLocalidadId { get; set; }
        public bool EsLaboratorio { get; set; }

        public virtual DireccionLocalidad DireccionLocalidad { get; set; }
        public virtual ICollection<GdiaPersonal> GdiaPersonal { get; set; }
        public virtual ICollection<PedidoMuestra> PedidoMuestra { get; set; }
        public virtual ICollection<PedidoTramoProveedorUMovilHorario> PedidoTramoProveedorUMovilHorario { get; set; }
        public virtual ICollection<UMovil> UMovil { get; set; }
    }
}
