﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class RestriccionTipoCierreDiagnostico
    {
        public int RestriccionTipoCierreDiagnosticoId { get; set; }
        public int PedidoTipoCierreId { get; set; }
        public int DiagnosticoId { get; set; }
        public bool Activo { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime AuditoriaInsertDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }

        public virtual Diagnostico Diagnostico { get; set; }
        public virtual PedidoTipoCierre PedidoTipoCierre { get; set; }
    }
}
