﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class RestriccionTipoCierrePrestacion
    {
        public int RestriccionTipoCierrePrestacionId { get; set; }
        public int PedidoTipoCierreId { get; set; }
        public int TipoPrestacionId { get; set; }
        public bool Activo { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime AuditoriaInsertDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }

        public virtual PedidoTipoCierre PedidoTipoCierre { get; set; }
        public virtual TipoPrestacion TipoPrestacion { get; set; }
    }
}
