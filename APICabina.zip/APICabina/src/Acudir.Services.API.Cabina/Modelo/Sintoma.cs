﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class Sintoma
    {
        public Sintoma()
        {
            PedidoDetalle = new HashSet<PedidoDetalle>();
            TriageVersionDetalle = new HashSet<TriageVersionDetalle>();
        }

        public int SintomaId { get; set; }
        public string Descripcion { get; set; }
        public bool SuperRojo { get; set; }
        public bool? Activo { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime? AuditoriaInsertDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }
        public bool RequiereDerivacionSegundaAtencion { get; set; }

        public virtual ICollection<PedidoDetalle> PedidoDetalle { get; set; }
        public virtual ICollection<TriageVersionDetalle> TriageVersionDetalle { get; set; }
    }
}
