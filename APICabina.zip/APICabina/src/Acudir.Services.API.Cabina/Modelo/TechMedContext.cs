﻿using System;
using Acudir.Services.API.Cabina.Modelo;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace CabinaOperativa.Modelo
{
    public partial class TechMedContext : DbContext
    {
        public TechMedContext()
        {
        }

        public TechMedContext(DbContextOptions<TechMedContext> options)
            : base(options)
        {
        }

        public virtual DbSet<AlertaAccion> AlertaAccion { get; set; }
        public virtual DbSet<Carga> Carga { get; set; }
        public virtual DbSet<CargaGdiaRealPersonal> CargaGdiaRealPersonal { get; set; }
        public virtual DbSet<CmnCelular> CmnCelular { get; set; }
        public virtual DbSet<CmnConfiguracion> CmnConfiguracion { get; set; }
        public virtual DbSet<ContratoAfiliado> ContratoAfiliado { get; set; }
        public virtual DbSet<ContratoPlan> ContratoPlan { get; set; }
        public virtual DbSet<Diagnostico> Diagnostico { get; set; }
        public virtual DbSet<Direccion> Direccion { get; set; }
        public virtual DbSet<DireccionLocalidad> DireccionLocalidad { get; set; }
        public virtual DbSet<DireccionLocalidadDistancia> DireccionLocalidadDistancia { get; set; }
        public virtual DbSet<DireccionPartido> DireccionPartido { get; set; }
        public virtual DbSet<DireccionProvincia> DireccionProvincia { get; set; }
        public virtual DbSet<Efector> Efector { get; set; }
        public virtual DbSet<GdiaPersonal> GdiaPersonal { get; set; }
        public virtual DbSet<GdiaRealEquipo> GdiaRealEquipo { get; set; }
        public virtual DbSet<GdiaRealEquipoMovil> GdiaRealEquipoMovil { get; set; }
        public virtual DbSet<GdiaRealPersonal> GdiaRealPersonal { get; set; }
        public virtual DbSet<GdiaRealPersonalDetalle> GdiaRealPersonalDetalle { get; set; }
        public virtual DbSet<HistoriaClinicaPaciente> HistoriaClinicaPaciente { get; set; }
        public virtual DbSet<Pedido> Pedido { get; set; }
        public virtual DbSet<PedidoAdicional> PedidoAdicional { get; set; }
        public virtual DbSet<PedidoAfiliado> PedidoAfiliado { get; set; }
        public virtual DbSet<PedidoAlertaAccionRespuesta> PedidoAlertaAccionRespuesta { get; set; }
        public virtual DbSet<PedidoComentario> PedidoComentario { get; set; }
        public virtual DbSet<PedidoCoseguro> PedidoCoseguro { get; set; }
        public virtual DbSet<PedidoCoseguroTipoNoCobro> PedidoCoseguroTipoNoCobro { get; set; }
        public virtual DbSet<PedidoDetalle> PedidoDetalle { get; set; }
        public virtual DbSet<PedidoDiagnosticoMedico> PedidoDiagnosticoMedico { get; set; }
        public virtual DbSet<PedidoEntidadLog> PedidoEntidadLog { get; set; }
        public virtual DbSet<PedidoMuestra> PedidoMuestra { get; set; }
        public virtual DbSet<PedidoResultadoLaboratorio> PedidoResultadoLaboratorio { get; set; }
        public virtual DbSet<PedidoResultadoLaboratorioTipoPrestacion> PedidoResultadoLaboratorioTipoPrestacion { get; set; }
        public virtual DbSet<PedidoTipoCierre> PedidoTipoCierre { get; set; }
        public virtual DbSet<PedidoTramo> PedidoTramo { get; set; }
        public virtual DbSet<PedidoTramoDetalle> PedidoTramoDetalle { get; set; }
        public virtual DbSet<PedidoTramoEfectorHorario> PedidoTramoEfectorHorario { get; set; }
        public virtual DbSet<PedidoTramoProveedorUMovilHorario> PedidoTramoProveedorUMovilHorario { get; set; }
        public virtual DbSet<PedidoTramoProveedorUMovilHorarioGdiaRealPersonal> PedidoTramoProveedorUMovilHorarioGdiaRealPersonal { get; set; }
        public virtual DbSet<PedidoTriageVersionDetalleLog> PedidoTriageVersionDetalleLog { get; set; }
        public virtual DbSet<Proveedor> Proveedor { get; set; }
        public virtual DbSet<RestriccionTipoCierreDiagnostico> RestriccionTipoCierreDiagnostico { get; set; }
        public virtual DbSet<RestriccionTipoCierrePrestacion> RestriccionTipoCierrePrestacion { get; set; }
        public virtual DbSet<Sintoma> Sintoma { get; set; }
        public virtual DbSet<TipoDocumento> TipoDocumento { get; set; }
        public virtual DbSet<TipoPrestacion> TipoPrestacion { get; set; }
        public virtual DbSet<TipoPrestacionContrato> TipoPrestacionContrato { get; set; }
        public virtual DbSet<TipoPrestacionPlanCoseguro> TipoPrestacionPlanCoseguro { get; set; }
        public virtual DbSet<TriageVersionDetalle> TriageVersionDetalle { get; set; }
        public virtual DbSet<UMovil> UMovil { get; set; }
        public virtual DbSet<VideoConsulta> VideoConsulta { get; set; }
        public virtual DbSet<VideoConsultaLog> VideoConsultaLog { get; set; }
        public virtual DbSet<VideoConsultaLogTipo> VideoConsultaLogTipo { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=192.168.1.150;Database=TechMed_InternalTest;User ID=tmuser;Password=pepito_123;MultipleActiveResultSets=true");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.6-servicing-10079");

            modelBuilder.Entity<AlertaAccion>(entity =>
            {
                entity.HasIndex(e => e.EntidadLogTipoEstadoId)
                    .HasName("IX_EntidadLogTipoEstadoId");
            });

            modelBuilder.Entity<Carga>(entity =>
            {
                entity.HasIndex(e => new { e.CargaId, e.HoraFinal, e.ChoferId, e.ChoferDescripcion, e.AuditoriaInsertDate, e.MedicoId, e.MedicoDescripcion, e.TiempoRestante, e.UMovilId })
                    .HasName("IX_UMovilId");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser)
                    .IsRequired()
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasDefaultValueSql("('')");

                entity.Property(e => e.ChoferDescripcion).HasColumnType("nvarchar(max)");

                entity.Property(e => e.FechaConfirmaCancelacion).HasColumnType("datetime");

                entity.Property(e => e.FechaConfirmaInicio).HasColumnType("datetime");

                entity.Property(e => e.HoraFinal).HasColumnType("datetime");

                entity.Property(e => e.MedicoDescripcion).HasColumnType("nvarchar(max)");

                entity.HasOne(d => d.UMovil)
                    .WithMany(p => p.Carga)
                    .HasForeignKey(d => d.UMovilId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.Carga_dbo.UMovil_UMovilId");
            });

            modelBuilder.Entity<CargaGdiaRealPersonal>(entity =>
            {
                entity.HasIndex(e => e.CargaGdiaRealPersonalEstadoId)
                    .HasName("IX_CargaGdiaRealPersonalEstadoId");

                entity.HasIndex(e => e.GdiaRealPersonalDetalleId)
                    .HasName("IX_GdiaRealPersonalDetalleId");

                entity.HasIndex(e => e.GdiaRealPersonalId)
                    .HasName("IX_GdiaRealPersonalId");

                entity.HasIndex(e => new { e.CargaGdiaRealPersonalId, e.GdiaRealPersonalId, e.AuditoriaInsertDate, e.CargaGdiaRealPersonalEstadoId })
                    .HasName("IX_CargaGdiaRealPersonal_CargaGdiaRealPersonalEstadoId");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.HasOne(d => d.GdiaRealPersonalDetalle)
                    .WithMany(p => p.CargaGdiaRealPersonal)
                    .HasForeignKey(d => d.GdiaRealPersonalDetalleId)
                    .HasConstraintName("FK_dbo.CargaGdiaRealPersonal_dbo.GdiaRealPersonalDetalle_GdiaRealPersonalDetalleId");

                entity.HasOne(d => d.GdiaRealPersonal)
                    .WithMany(p => p.CargaGdiaRealPersonal)
                    .HasForeignKey(d => d.GdiaRealPersonalId)
                    .HasConstraintName("FK_dbo.CargaGdiaRealPersonal_dbo.GdiaRealPersonal_GdiaRealPersonalId");
            });

            modelBuilder.Entity<CmnCelular>(entity =>
            {
                entity.Property(e => e.FcmTokenNotify).HasMaxLength(250);

                entity.Property(e => e.GcmTokenNotify).HasMaxLength(250);

                entity.Property(e => e.Imei).HasMaxLength(50);
            });

            modelBuilder.Entity<CmnConfiguracion>(entity =>
            {
                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasMaxLength(50);

                entity.Property(e => e.Tipo).HasMaxLength(128);
            });

            modelBuilder.Entity<ContratoAfiliado>(entity =>
            {
                entity.HasIndex(e => e.HistoriaClinicaPacienteId)
                    .HasName("IX_HistoriaClinicaPacienteId");

                entity.HasIndex(e => e.TipoDocumentoId)
                    .HasName("IX_TipoDocumentoId");

                entity.HasIndex(e => new { e.AfiliadoNro, e.AfiliadoNombre, e.AfiliadoObservacion, e.ContratoAfiliadoId })
                    .HasName("_dta_index_ContratoAfiliado_7_53575229__K1_4_5_6");

                entity.HasIndex(e => new { e.ContratoAfiliadoId, e.AfiliadoNro, e.AfiliadoNombre, e.AfiliadoObservacion, e.ContratoId })
                    .HasName("_MS_Sys_3");

                entity.HasIndex(e => new { e.ContratoAfiliadoId, e.AfiliadoNro, e.AfiliadoNombre, e.AfiliadoObservacion, e.AuditoriaInsertUser, e.AuditoriaInsertDate, e.AuditoriaUpdateUser, e.AuditoriaUpdateDate, e.ContratoId })
                    .HasName("IX_ContratoId");

                entity.HasIndex(e => new { e.ContratoAfiliadoId, e.AfiliadoNro, e.AfiliadoNombre, e.AfiliadoObservacion, e.AuditoriaInsertUser, e.AuditoriaInsertDate, e.AuditoriaUpdateUser, e.AuditoriaUpdateDate, e.AfiliadoTelefono, e.ContratoId, e.AfiliadoTipo, e.Activo })
                    .HasName("IX_ContratoAfiliadoContratoAfiliadoTipoActivo");

                entity.HasIndex(e => new { e.ContratoAfiliadoId, e.AfiliadoNro, e.AfiliadoNombre, e.AfiliadoObservacion, e.AuditoriaInsertUser, e.AuditoriaInsertDate, e.AuditoriaUpdateUser, e.AuditoriaUpdateDate, e.AfiliadoTipo, e.Activo, e.AfiliadoTelefono, e.ContratoId })
                    .HasName("IX_ContratoAfiliado_ContratoId");

                entity.Property(e => e.AfiliadoEmail).HasMaxLength(512);

                entity.Property(e => e.AfiliadoNombre).HasColumnType("nvarchar(max)");

                entity.Property(e => e.AfiliadoNro).HasColumnType("nvarchar(max)");

                entity.Property(e => e.AfiliadoObservacion).HasColumnType("nvarchar(max)");

                entity.Property(e => e.AfiliadoTelefono).HasMaxLength(100);

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasDefaultValueSql("('N/A')");

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasMaxLength(50);

                entity.Property(e => e.DocumentoNro).HasMaxLength(256);

                entity.Property(e => e.FechaNacimiento).HasColumnType("datetime");

                entity.HasOne(d => d.HistoriaClinicaPaciente)
                    .WithMany(p => p.ContratoAfiliado)
                    .HasForeignKey(d => d.HistoriaClinicaPacienteId)
                    .HasConstraintName("FK_dbo.ContratoAfiliado_dbo.HistoriaClinicaPaciente_HistoriaClinicaPacienteId");

                entity.HasOne(d => d.TipoDocumento)
                    .WithMany(p => p.ContratoAfiliado)
                    .HasForeignKey(d => d.TipoDocumentoId)
                    .HasConstraintName("FK_dbo.ContratoAfiliado_dbo.TipoDocumento_TipoDocumentoId");
            });

            modelBuilder.Entity<ContratoPlan>(entity =>
            {
                entity.HasIndex(e => e.ContratoId)
                    .HasName("IX_ContratoId");

                entity.HasIndex(e => new { e.ContratoId, e.Activo });

                entity.Property(e => e.Activo)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasDefaultValueSql("('N/A')");

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasMaxLength(50);

                entity.Property(e => e.CodigoDelPlan).HasMaxLength(50);

                entity.Property(e => e.Descripcion).IsRequired();

                entity.Property(e => e.IVA).HasColumnType("decimal(5, 2)");
            });

            modelBuilder.Entity<Diagnostico>(entity =>
            {
                entity.HasIndex(e => e.DiagnosticoGrupoId)
                    .HasName("IX_DiagnosticoGrupoId");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser).HasMaxLength(50);

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasMaxLength(50);
            });

            modelBuilder.Entity<Direccion>(entity =>
            {
                entity.HasIndex(e => e.DireccionLocalidadId)
                    .HasName("IX_DireccionLocalidadId");

                entity.HasIndex(e => new { e.Domicilio, e.DireccionId })
                    .HasName("_dta_index_Direccion_7_117575457__K1_2");

                entity.HasIndex(e => new { e.DireccionId, e.Domicilio, e.DireccionLocalidadId })
                    .HasName("_MS_Sys_11");

                entity.HasIndex(e => new { e.Latitud, e.Longitud, e.DireccionId })
                    .HasName("_dta_index_Direccion_7_117575457__K1_6_7");

                entity.HasIndex(e => new { e.DireccionId, e.Domicilio, e.CalleAdyacente1, e.CalleAdyacente2, e.Zona, e.Latitud, e.Longitud, e.Piso, e.Depto, e.DireccionLocalidadId })
                    .HasName("_dta_index_Direccion_7_117575457__K11_1_2_3_4_5_6_7_9_10");

                entity.HasIndex(e => new { e.DireccionId, e.Domicilio, e.CalleAdyacente1, e.CalleAdyacente2, e.Zona, e.Latitud, e.Longitud, e.Borrado, e.Depto, e.Piso, e.DireccionLocalidadId })
                    .HasName("_MS_Sys_9_11");

                entity.Property(e => e.AuditoriaInsertDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.AuditoriaInsertUser)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasDefaultValueSql("('SISTEMAS')");

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasMaxLength(50);

                entity.Property(e => e.CalleAdyacente1).HasColumnType("nvarchar(max)");

                entity.Property(e => e.CalleAdyacente2).HasColumnType("nvarchar(max)");

                entity.Property(e => e.Depto).HasColumnType("nvarchar(max)");

                entity.Property(e => e.Domicilio)
                    .IsRequired()
                    .HasColumnType("nvarchar(max)");

                entity.Property(e => e.Zona).HasColumnType("nvarchar(max)");

                entity.HasOne(d => d.DireccionLocalidad)
                    .WithMany(p => p.Direccion)
                    .HasForeignKey(d => d.DireccionLocalidadId)
                    .HasConstraintName("FK_dbo.Direccion_dbo.DireccionLocalidad_DireccionLocalidadId");
            });

            modelBuilder.Entity<DireccionLocalidad>(entity =>
            {
                entity.HasIndex(e => e.Borrado)
                    .HasName("IX_Borrado");

                entity.HasIndex(e => e.DireccionCordonId)
                    .HasName("IX_DireccionCordonId");

                entity.HasIndex(e => e.DireccionPartidoId)
                    .HasName("IX_DireccionPartidoId");

                entity.HasIndex(e => e.DireccionZonaGeograficaId)
                    .HasName("IX_DireccionZonaGeograficaId");

                entity.HasIndex(e => new { e.Descripcion, e.DireccionLocalidadId })
                    .HasName("_dta_index_DireccionLocalidad_7_1131151075__K1_2");

                entity.HasIndex(e => new { e.DireccionLocalidadId, e.Descripcion })
                    .HasName("IX_Descripcion");

                entity.HasIndex(e => new { e.Descripcion, e.Kilometros, e.DireccionPartidoId, e.DireccionZonaGeograficaId, e.DireccionLocalidadId })
                    .HasName("_dta_index_DireccionLocalidad_7_1131151075__K4_K5_K1_2_3");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasMaxLength(50);

                entity.Property(e => e.Descripcion)
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.HasOne(d => d.DireccionPartido)
                    .WithMany(p => p.DireccionLocalidad)
                    .HasForeignKey(d => d.DireccionPartidoId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.DireccionLocalidad_dbo.DireccionPartido_DireccionPartidoId");
            });

            modelBuilder.Entity<DireccionLocalidadDistancia>(entity =>
            {
                entity.HasIndex(e => e.DireccionLocalidad1Id)
                    .HasName("IX_DireccionLocalidad1Id");

                entity.HasIndex(e => e.DireccionLocalidad2Id)
                    .HasName("IX_DireccionLocalidad2Id");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasMaxLength(50);

                entity.HasOne(d => d.DireccionLocalidad1)
                    .WithMany(p => p.DireccionLocalidadDistanciaDireccionLocalidad1)
                    .HasForeignKey(d => d.DireccionLocalidad1Id)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.DireccionLocalidadDistancia_dbo.DireccionLocalidad_DireccionLocalidad1Id");

                entity.HasOne(d => d.DireccionLocalidad2)
                    .WithMany(p => p.DireccionLocalidadDistanciaDireccionLocalidad2)
                    .HasForeignKey(d => d.DireccionLocalidad2Id)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.DireccionLocalidadDistancia_dbo.DireccionLocalidad_DireccionLocalidad2Id");
            });

            modelBuilder.Entity<DireccionPartido>(entity =>
            {
                entity.HasIndex(e => e.Borrado)
                    .HasName("IX_Borrado");

                entity.HasIndex(e => e.DireccionProvinciaId)
                    .HasName("IX_DireccionProvinciaId");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasMaxLength(50);

                entity.HasOne(d => d.DireccionProvincia)
                    .WithMany(p => p.DireccionPartido)
                    .HasForeignKey(d => d.DireccionProvinciaId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.DireccionPartido_dbo.DireccionProvincia_DireccionProvinciaId");
            });

            modelBuilder.Entity<DireccionProvincia>(entity =>
            {
                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasMaxLength(50);
            });

            modelBuilder.Entity<Efector>(entity =>
            {
                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasMaxLength(50);

                entity.Property(e => e.Descripcion).HasMaxLength(200);

                entity.Property(e => e.Telefono1).HasMaxLength(50);

                entity.Property(e => e.Telefono2).HasMaxLength(50);

                entity.Property(e => e.Token).HasMaxLength(512);
            });

            modelBuilder.Entity<GdiaPersonal>(entity =>
            {
                entity.HasIndex(e => e.CategoriaId)
                    .HasName("IX_CategoriaId");

                entity.HasIndex(e => e.CmnCelularId)
                    .HasName("IX_CmnCelularId");

                entity.HasIndex(e => e.ContratoAfiliadoId)
                    .HasName("IX_ContratoAfiliadoId");

                entity.HasIndex(e => e.GdiaPersonalEspecialidadId)
                    .HasName("IX_GdiaPersonalEspecialidadId");

                entity.HasIndex(e => e.GdiaPersonalSuspendidoId)
                    .HasName("IX_GdiaPersonalSuspendidoId");

                entity.HasIndex(e => e.ProveedorId)
                    .HasName("IX_ProveedorId");

                entity.HasIndex(e => new { e.Descripcion, e.GdiaPersonalId })
                    .HasName("IX_GdiaPersonald")
                    .IsUnique();

                entity.HasIndex(e => new { e.GdiaPersonalId, e.Activo, e.ProveedorId, e.Legajo, e.BioStarnUserId })
                    .HasName("NonClusteredIndex-20180111-110521");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.Descripcion).HasColumnType("nvarchar(max)");

                entity.Property(e => e.Dni).HasMaxLength(50);

                entity.Property(e => e.Legajo).HasMaxLength(150);

                entity.Property(e => e.Mail).HasMaxLength(50);

                entity.Property(e => e.Matricula).HasMaxLength(50);

                entity.Property(e => e.Observacion).HasMaxLength(500);

                entity.Property(e => e.ProcesoRaetUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.ProveedorId).HasDefaultValueSql("((1560))");

                entity.Property(e => e.Sexo).HasMaxLength(2);

                entity.Property(e => e.Telefono).HasMaxLength(50);

                entity.Property(e => e.Timestamp)
                    .IsRequired()
                    .IsRowVersion();

                entity.HasOne(d => d.CmnCelular)
                    .WithMany(p => p.GdiaPersonal)
                    .HasForeignKey(d => d.CmnCelularId)
                    .HasConstraintName("FK_dbo.GdiaPersonal_dbo.CmnCelular_CmnCelularId");

                entity.HasOne(d => d.ContratoAfiliado)
                    .WithMany(p => p.GdiaPersonal)
                    .HasForeignKey(d => d.ContratoAfiliadoId)
                    .HasConstraintName("FK_dbo.GdiaPersonal_dbo.ContratoAfiliado_ContratoAfiliadoId");

                entity.HasOne(d => d.Proveedor)
                    .WithMany(p => p.GdiaPersonal)
                    .HasForeignKey(d => d.ProveedorId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.GdiaPersonal_dbo.Proveedor_ProveedorId");
            });

            modelBuilder.Entity<GdiaRealEquipo>(entity =>
            {
                entity.HasIndex(e => e.GdiaBaseTipoId)
                    .HasName("IX_GdiaBaseTipoId");

                entity.HasIndex(e => e.GdiaEquipoId)
                    .HasName("IX_GdiaEquipoId");

                entity.HasIndex(e => e.GdiaLogicaDetalleId)
                    .HasName("IX_GdiaLogicaDetalleId");

                entity.HasIndex(e => e.GdiaTeoricaId)
                    .HasName("IX_GdiaTeoricaId");

                entity.HasIndex(e => new { e.HastaOperativo, e.DesdeOperativo });

                entity.HasIndex(e => new { e.GdiaRealEquipoId, e.GdiaLogicaDetalleId, e.DesdeTeorico, e.HastaTeorico, e.DesdeOperativo, e.HastaOperativo, e.GdiaEquipoId, e.GdiaBaseTipoId })
                    .HasName("IX_GdiaRealEquipo_GdiaBaseTipoId");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.DesdeOperativo).HasColumnType("datetime");

                entity.Property(e => e.DesdeTeorico).HasColumnType("datetime");

                entity.Property(e => e.HastaOperativo).HasColumnType("datetime");

                entity.Property(e => e.HastaTeorico).HasColumnType("datetime");

                entity.Property(e => e.Timestamp)
                    .IsRequired()
                    .IsRowVersion();
            });

            modelBuilder.Entity<GdiaRealEquipoMovil>(entity =>
            {
                entity.HasIndex(e => e.GdiaRealEquipoId)
                    .HasName("IX_GdiaRealEquipoId");

                entity.HasIndex(e => e.GdiaTeoricaEquipoMovilId)
                    .HasName("IX_GdiaTeoricaEquipoMovilId");

                entity.HasIndex(e => new { e.GdiaRealEquipoMovilId, e.GdiaRealEquipoId, e.Timestamp, e.AuditoriaInsertDate, e.AuditoriaInsertUser, e.AuditoriaUpdateDate, e.AuditoriaUpdateUser, e.GdiaTeoricaEquipoMovilId, e.UMovilId })
                    .HasName("IX_UMovilId");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser).HasColumnType("nvarchar(max)");

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasColumnType("nvarchar(max)");

                entity.Property(e => e.Timestamp)
                    .IsRequired()
                    .IsRowVersion();

                entity.HasOne(d => d.GdiaRealEquipo)
                    .WithMany(p => p.GdiaRealEquipoMovil)
                    .HasForeignKey(d => d.GdiaRealEquipoId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.GdiaRealEquipoMovil_dbo.GdiaRealEquipo_GdiaRealEquipoId");

                entity.HasOne(d => d.UMovil)
                    .WithMany(p => p.GdiaRealEquipoMovil)
                    .HasForeignKey(d => d.UMovilId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.GdiaRealEquipoMovil_dbo.UMovil_UMovilId");
            });

            modelBuilder.Entity<GdiaRealPersonal>(entity =>
            {
                entity.HasIndex(e => e.GdiaBaseTipoId)
                    .HasName("IX_GdiaBaseTipoId");

                entity.HasIndex(e => e.GdiaRealPersonalEstadoTipoId)
                    .HasName("IX_GdiaRealPersonalEstadoTipoId");

                entity.HasIndex(e => e.GdiaTeoricaPersonalId)
                    .HasName("IX_GdiaTeoricaPersonalId");

                entity.HasIndex(e => e.HastaFichaje)
                    .HasName("_dta_index_GdiaRealPersonal_6_1705773134__K19");

                entity.HasIndex(e => e.ReemplazoId)
                    .HasName("IX_ReemplazoId");

                entity.HasIndex(e => new { e.HastaFichaje, e.DesdeFichaje })
                    .HasName("missing_index_39916_39915_GdiaRealPersonal");

                entity.HasIndex(e => new { e.DesdeOperativo, e.HastaFichaje, e.DesdeFichaje });

                entity.HasIndex(e => new { e.DesdeOperativo, e.HastaOperativo, e.HastaFichaje, e.DesdeFichaje });

                entity.HasIndex(e => new { e.GdiaPersonalId, e.GdiaRealPersonalEstadoTipoId, e.GdiaBaseTipoId, e.DesdeTeorico })
                    .HasName("IX_GdiaBaseTipoId_DesdeTeorico");

                entity.HasIndex(e => new { e.HastaOperativo, e.HastaFichaje, e.DesdeOperativo, e.DesdeFichaje })
                    .HasName("missing_index_677_676_GdiaRealPersonal");

                entity.HasIndex(e => new { e.GdiaRealPersonalId, e.GdiaPersonalId, e.GdiaBaseTipoId, e.HastaTeorico, e.FichajeAltaPorTgo, e.FichajeBajaPorTgo, e.DesdeTeorico, e.DesdeOperativo, e.HastaOperativo, e.DesdeFichaje, e.HastaFichaje })
                    .HasName("IX_GdiaRealPersonal_FichajeAltaPorTgo_FichajeBajaPorTgo_DesdeTeorico_DesdeOperativo_HastaOperativo_DesdeFichaje_HastaFichaje");

                entity.HasIndex(e => new { e.GdiaRealPersonalId, e.GdiaBaseTipoId, e.DesdeTeorico, e.HastaTeorico, e.DesdeOperativo, e.HastaOperativo, e.Timestamp, e.AuditoriaInsertDate, e.AuditoriaInsertUser, e.AuditoriaUpdateDate, e.AuditoriaUpdateUser, e.GdiaTeoricaPersonalId, e.DesdeFichaje, e.HastaFichaje, e.GdiaRealPersonalEstadoTipoId, e.Comentario, e.FichajeAltaPorTgo, e.FichajeBajaPorTgo, e.ReemplazoId, e.GdiaPersonalId })
                    .HasName("IX_GdiaPersonalId");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser).HasColumnType("nvarchar(max)");

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasColumnType("nvarchar(max)");

                entity.Property(e => e.Comentario).HasColumnType("nvarchar(max)");

                entity.Property(e => e.DesdeFichaje).HasColumnType("datetime");

                entity.Property(e => e.DesdeOperativo).HasColumnType("datetime");

                entity.Property(e => e.DesdeTeorico).HasColumnType("datetime");

                entity.Property(e => e.HastaFichaje).HasColumnType("datetime");

                entity.Property(e => e.HastaOperativo).HasColumnType("datetime");

                entity.Property(e => e.HastaTeorico).HasColumnType("datetime");

                entity.Property(e => e.RegistroTemperatura).HasColumnType("datetime");

                entity.Property(e => e.TemperaturaCorporal).HasColumnType("decimal(18, 2)");

                entity.Property(e => e.Timestamp)
                    .IsRequired()
                    .IsRowVersion();

                entity.HasOne(d => d.GdiaPersonal)
                    .WithMany(p => p.GdiaRealPersonal)
                    .HasForeignKey(d => d.GdiaPersonalId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.GdiaRealPersonal_dbo.GdiaPersonal_GdiaPersonalId");

                entity.HasOne(d => d.Reemplazo)
                    .WithMany(p => p.InverseReemplazo)
                    .HasForeignKey(d => d.ReemplazoId)
                    .HasConstraintName("FK_dbo.GdiaRealPersonal_dbo.GdiaRealPersonal_ReemplazoId");
            });

            modelBuilder.Entity<GdiaRealPersonalDetalle>(entity =>
            {
                entity.HasIndex(e => e.DesdeOperativo)
                    .HasName("missing_index_39918_39917_GdiaRealPersonalDetalle");

                entity.HasIndex(e => e.GdiaBaseTipoId)
                    .HasName("IX_GdiaBaseTipoId");

                entity.HasIndex(e => e.GdiaRealEquipoId)
                    .HasName("IX_GdiaRealEquipoId");

                entity.HasIndex(e => e.GdiaRealPersonalDetalleEstadoTipoId)
                    .HasName("IX_GdiaRealPersonalDetalleEstadoTipoId");

                entity.HasIndex(e => e.GdiaRealPersonalId)
                    .HasName("IX_GdiaRealPersonalId");

                entity.HasIndex(e => e.GdiaTeoricaPersonalDetalleId)
                    .HasName("IX_GdiaTeoricaPersonalDetalleId");

                entity.HasIndex(e => new { e.GdiaRealEquipoId, e.GdiaBaseTipoId });

                entity.HasIndex(e => new { e.HastaOperativo, e.DesdeOperativo });

                entity.HasIndex(e => new { e.GdiaRealEquipoId, e.HastaOperativo, e.DesdeOperativo });

                entity.HasIndex(e => new { e.HastaOperativo, e.GdiaRealEquipoId, e.DesdeOperativo });

                entity.HasIndex(e => new { e.GdiaRealPersonalId, e.GdiaRealEquipoId, e.GdiaTeoricaPersonalDetalleId, e.GdiaRealPersonalDetalleEstadoTipoId })
                    .HasName("IX_GdiaRealPersonalDetalle_GdiaRealPersonalDetalleEstadoTipoId");

                entity.HasIndex(e => new { e.GdiaRealEquipoId, e.GdiaBaseTipoId, e.GdiaTeoricaPersonalDetalleId, e.DesdeTeorico, e.HastaTeorico, e.HastaOperativo, e.TercerTripulante, e.GdiaRealPersonalDetalleEstadoTipoId, e.Comentario, e.Timestamp, e.AuditoriaInsertDate, e.AuditoriaInsertUser, e.AuditoriaUpdateDate, e.AuditoriaUpdateUser, e.DesdeOperativo, e.GdiaRealPersonalId, e.GdiaRealPersonalDetalleId })
                    .HasName("_dta_index_GdiaRealPersonalDetalle_6_840390063__K8_K2_K1_3_4_5_6_7_9_10_11_12_13_14_15_16_17");

                entity.HasIndex(e => new { e.GdiaRealPersonalDetalleId, e.GdiaBaseTipoId, e.GdiaTeoricaPersonalDetalleId, e.DesdeTeorico, e.HastaTeorico, e.DesdeOperativo, e.TercerTripulante, e.GdiaRealPersonalDetalleEstadoTipoId, e.Comentario, e.Timestamp, e.AuditoriaInsertDate, e.AuditoriaInsertUser, e.AuditoriaUpdateDate, e.AuditoriaUpdateUser, e.HastaOperativo, e.GdiaRealEquipoId, e.GdiaRealPersonalId })
                    .HasName("_dta_index_GdiaRealPersonalDetalle_6_840390063__K9_K3_K2_1_4_5_6_7_8_10_11_12_13_14_15_16_17");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser).HasColumnType("nvarchar(max)");

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasColumnType("nvarchar(max)");

                entity.Property(e => e.Comentario).HasColumnType("nvarchar(max)");

                entity.Property(e => e.DesdeOperativo).HasColumnType("datetime");

                entity.Property(e => e.DesdeTeorico).HasColumnType("datetime");

                entity.Property(e => e.HastaOperativo).HasColumnType("datetime");

                entity.Property(e => e.HastaTeorico).HasColumnType("datetime");

                entity.Property(e => e.Timestamp)
                    .IsRequired()
                    .IsRowVersion();

                entity.HasOne(d => d.GdiaRealEquipo)
                    .WithMany(p => p.GdiaRealPersonalDetalle)
                    .HasForeignKey(d => d.GdiaRealEquipoId)
                    .HasConstraintName("FK_dbo.GdiaRealPersonalDetalle_dbo.GdiaRealEquipo_GdiaRealEquipoId");

                entity.HasOne(d => d.GdiaRealPersonal)
                    .WithMany(p => p.GdiaRealPersonalDetalle)
                    .HasForeignKey(d => d.GdiaRealPersonalId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.GdiaRealPersonalDetalle_dbo.GdiaRealPersonal_GdiaRealPersonalId");
            });

            modelBuilder.Entity<HistoriaClinicaPaciente>(entity =>
            {
                entity.HasIndex(e => e.DireccionId)
                    .HasName("IX_DireccionId");

                entity.HasIndex(e => e.TipoDocumentoId)
                    .HasName("IX_TipoDocumentoId");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasMaxLength(50);

                entity.Property(e => e.DocumentoNro).HasMaxLength(256);

                entity.Property(e => e.Edad).HasMaxLength(8);

                entity.Property(e => e.Email).HasMaxLength(512);

                entity.Property(e => e.FechaNacimiento).HasColumnType("datetime");

                entity.Property(e => e.Nombre).HasMaxLength(512);

                entity.Property(e => e.Sexo).HasMaxLength(8);

                entity.Property(e => e.Telefono).HasMaxLength(512);

                entity.HasOne(d => d.Direccion)
                    .WithMany(p => p.HistoriaClinicaPaciente)
                    .HasForeignKey(d => d.DireccionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.HistoriaClinicaPaciente_dbo.Direccion_DireccionId");

                entity.HasOne(d => d.TipoDocumento)
                    .WithMany(p => p.HistoriaClinicaPaciente)
                    .HasForeignKey(d => d.TipoDocumentoId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.HistoriaClinicaPaciente_dbo.TipoDocumento_TipoDocumentoId");
            });

            modelBuilder.Entity<Pedido>(entity =>
            {
                entity.HasIndex(e => e.ContratoId)
                    .HasName("IX_SQLdoctor_7_1_82af874ec9a24fb1a2563e683607a3b6");

                entity.HasIndex(e => e.DesdeLocalidadId)
                    .HasName("IX_DesdeLocalidadId");

                entity.HasIndex(e => e.EventoDetalleEquipoId)
                    .HasName("IX_EventoDetalleEquipoId");

                entity.HasIndex(e => e.EventoDetalleLocacionId)
                    .HasName("IX_EventoDetalleLocacionId");

                entity.HasIndex(e => e.GestionId)
                    .HasName("IX_GestionId");

                entity.HasIndex(e => e.HastaLocalidadId)
                    .HasName("IX_HastaLocalidadId");

                entity.HasIndex(e => e.PedidoEstadoTipoId)
                    .HasName("IX_PedidoEstadoTipoId");

                entity.HasIndex(e => e.PedidoPadreId)
                    .HasName("IX_PedidoPadreId");

                entity.HasIndex(e => e.PedidoResultadoLaboratorioId)
                    .HasName("IX_PedidoResultadoLaboratorioId");

                entity.HasIndex(e => e.ProtocoloTipoId)
                    .HasName("IX_ProtocoloTipoId");

                entity.HasIndex(e => e.TipoPrestacionId)
                    .HasName("IX_TipoPrestacionId");

                entity.HasIndex(e => new { e.ContratoId, e.PedidoEstadoId })
                    .HasName("IX_SQLdoctor_5_1_83e6213a5d274fdabd6fed064dd5fd62");

                entity.HasIndex(e => new { e.PedidoId, e.PedidoEstadoId })
                    .HasName("_dta_index_Pedido_7_149575571__K1_K4");

                entity.HasIndex(e => new { e.PedidoId, e.PedidoTipoCierreId })
                    .HasName("IX_PedidoTipoCierreId");

                entity.HasIndex(e => new { e.PedidoId, e.Fecha, e.PedidoEstadoId })
                    .HasName("_MS_Sys_5");

                entity.HasIndex(e => new { e.TipoPrestacionId, e.PedidoId, e.PedidoEstadoId })
                    .HasName("_dta_index_Pedido_6_149575571__K1_K4_7");

                entity.HasIndex(e => new { e.TipoPrestacionId, e.Fecha, e.PedidoId, e.PedidoEstadoId })
                    .HasName("_dta_index_Pedido_7_149575571__K7_K5_K1_K4");

                entity.HasIndex(e => new { e.PedidoId, e.ContratoId, e.PedidoEstadoId, e.Fecha, e.ContratoTransaccionId })
                    .HasName("missing_index_4_3_Pedido");

                entity.HasIndex(e => new { e.PedidoId, e.ContratoId, e.PedidoEstadoId, e.TipoPrestacionId, e.EventoDetalleEquipoId })
                    .HasName("IX_Pedido_EventoDetalleEquipoId");

                entity.HasIndex(e => new { e.PedidoId, e.ContratoId, e.TipoPrestacionId, e.EventoDetalleEquipoId, e.PedidoEstadoId })
                    .HasName("IX_Pedido_PedidoEstadoId");

                entity.HasIndex(e => new { e.PedidoId, e.PedidoEstadoId, e.ContratoId, e.Fecha, e.ContratoTransaccionId })
                    .HasName("IX_SQLdoctor_4_1_03b02f16b7eb4b90baedfdf5ad096fb6");

                entity.HasIndex(e => new { e.Edad, e.Sexo, e.TipoPrestacionId, e.PedidoId, e.PedidoEstadoId, e.ContratoId })
                    .HasName("_dta_index_Pedido_12_149575571__K7_K1_K4_K3_8_9");

                entity.HasIndex(e => new { e.PedidoId, e.PedidoEstadoId, e.TipoPrestacionId, e.EsProgramacion, e.ContratoId, e.Fecha })
                    .HasName("_MS_Sys_16_3_5");

                entity.HasIndex(e => new { e.PedidoId, e.TipoPrestacionId, e.ContratoId, e.PedidoEstadoId, e.Fecha, e.ContratoTransaccionId })
                    .HasName("IX_Pedido_ContratoId_PedidoEstadoId_Fecha_ContratoTransaccionId");

                entity.HasIndex(e => new { e.PedidoId, e.ContratoId, e.Fecha, e.TipoPrestacionId, e.Edad, e.Sexo, e.Tomador, e.PedidoEstadoId, e.EsProgramacion })
                    .HasName("_MS_Sys_4_16");

                entity.HasIndex(e => new { e.QuienLlama, e.Fecha, e.Zona, e.Edad, e.Sexo, e.Tomador, e.VentanaTolerancia, e.CantidadApoyos, e.PacientePsiquiatrico, e.SuperRojo, e.PedidoId, e.ContratoId, e.TipoPrestacionId })
                    .HasName("_dta_index_Pedido_7_149575571__K1_K3_K7_2_5_6_8_9_10_17_18_19_20");

                entity.HasIndex(e => new { e.PedidoId, e.QuienLlama, e.Fecha, e.Zona, e.Edad, e.Sexo, e.Tomador, e.AuditoriaUpdateUser, e.EsProgramacion, e.VentanaTolerancia, e.PedidoTipoCierreId, e.ContratoId, e.PedidoEstadoId, e.TipoPrestacionId })
                    .HasName("IX_Pedido_ContratoId_PedidoEstadoId_TipoPrestacionId");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser).IsRequired();

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasColumnType("nvarchar(max)");

                entity.Property(e => e.ContratoTransaccionId).HasMaxLength(50);

                entity.Property(e => e.Edad).HasColumnType("nvarchar(max)");

                entity.Property(e => e.Fecha).HasColumnType("datetime");

                entity.Property(e => e.FechaArchivado).HasColumnType("datetime");

                entity.Property(e => e.FechaAtencion).HasColumnType("datetime");

                entity.Property(e => e.FechaFinToma).HasColumnType("datetime");

                entity.Property(e => e.FechaFinalizado).HasColumnType("datetime");

                entity.Property(e => e.FechaHabilitacionDespacho).HasColumnType("datetime");

                entity.Property(e => e.FechaInicioNegociacion).HasColumnType("datetime");

                entity.Property(e => e.FechaInicioToma).HasColumnType("datetime");

                entity.Property(e => e.IngresadoSisaFecha).HasColumnType("datetime");

                entity.Property(e => e.QuienLlama)
                    .IsRequired()
                    .HasColumnType("nvarchar(max)");

                entity.Property(e => e.Sexo).HasColumnType("nvarchar(max)");

                entity.Property(e => e.Tomador).HasColumnType("nvarchar(max)");

                entity.Property(e => e.Zona).HasColumnType("nvarchar(max)");

                entity.HasOne(d => d.DesdeLocalidad)
                    .WithMany(p => p.PedidoDesdeLocalidad)
                    .HasForeignKey(d => d.DesdeLocalidadId)
                    .HasConstraintName("FK_dbo.Pedido_dbo.DireccionLocalidad_DesdeLocalidadId");

                entity.HasOne(d => d.HastaLocalidad)
                    .WithMany(p => p.PedidoHastaLocalidad)
                    .HasForeignKey(d => d.HastaLocalidadId)
                    .HasConstraintName("FK_dbo.Pedido_dbo.DireccionLocalidad_HastaLocalidadId");

                entity.HasOne(d => d.PedidoPadre)
                    .WithMany(p => p.InversePedidoPadre)
                    .HasForeignKey(d => d.PedidoPadreId)
                    .HasConstraintName("FK_dbo.Pedido_dbo.Pedido_PedidoPadreId");

                entity.HasOne(d => d.PedidoResultadoLaboratorio)
                    .WithMany(p => p.Pedido)
                    .HasForeignKey(d => d.PedidoResultadoLaboratorioId)
                    .HasConstraintName("FK_dbo.Pedido_dbo.PedidoResultadoLaboratorio_PedidoResultadoLaboratorioId");

                entity.HasOne(d => d.PedidoTipoCierre)
                    .WithMany(p => p.Pedido)
                    .HasForeignKey(d => d.PedidoTipoCierreId)
                    .HasConstraintName("FK_dbo.Pedido_dbo.PedidoTipoCierre_PedidoTipoCierreId");

                entity.HasOne(d => d.TipoPrestacion)
                    .WithMany(p => p.Pedido)
                    .HasForeignKey(d => d.TipoPrestacionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.Pedido_dbo.TipoPrestacion_TipoPrestacionId");
            });

            modelBuilder.Entity<PedidoAdicional>(entity =>
            {
                entity.HasIndex(e => e.PedidoId)
                    .HasName("IX_PedidoId");

                entity.HasIndex(e => new { e.PedidoId, e.PedidoAdicionalTipoId, e.Cantidad })
                    .HasName("IX_PedidoAdicional_Cantidad");

                entity.HasIndex(e => new { e.PedidoAdicionalId, e.PedidoId, e.Cantidad, e.PedidoAdicionalTipoId })
                    .HasName("IX_PedidoAdicionalTipoId");

                entity.Property(e => e.Activo)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasDefaultValueSql("('N/A')");

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasMaxLength(50);

                entity.HasOne(d => d.Pedido)
                    .WithMany(p => p.PedidoAdicional)
                    .HasForeignKey(d => d.PedidoId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.PedidoAdicional_dbo.Pedido_PedidoId");
            });

            modelBuilder.Entity<PedidoAfiliado>(entity =>
            {
                entity.HasIndex(e => e.ContratoAfiliadoId)
                    .HasName("IX_ContratoAfiliadoId");

                entity.HasIndex(e => e.ContratoPlanId)
                    .HasName("IX_ContratoPlan_ContratoPlanId");

                entity.HasIndex(e => e.PedidoAfiliadoReemplazoId)
                    .HasName("IX_PedidoAfiliadoReemplazoId");

                entity.HasIndex(e => new { e.PedidoAfiliadoId, e.PedidoId, e.ContratoAfiliadoId, e.PedidoAnteriorId })
                    .HasName("PedidoAfiliado_PedidoAnteriorId");

                entity.HasIndex(e => new { e.ContratoPlanId, e.PacienteRecomendado, e.PedidoAfiliadoId, e.PedidoId, e.ContratoAfiliadoId })
                    .HasName("_dta_index_PedidoAfiliado_7_501576825__K3_K12_11_13");

                entity.HasIndex(e => new { e.PedidoAfiliadoId, e.ContratoPlanId, e.ContratoAfiliadoId, e.PacienteRecomendado, e.PedidoId })
                    .HasName("IX_PedidoId");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasDefaultValueSql("('N/A')");

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasMaxLength(50);

                entity.Property(e => e.CobraCoseguro)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.HasOne(d => d.ContratoAfiliado)
                    .WithMany(p => p.PedidoAfiliado)
                    .HasForeignKey(d => d.ContratoAfiliadoId)
                    .HasConstraintName("FK_dbo.PedidoAfiliado_dbo.ContratoAfiliado_ContratoAfiliadoId");

                entity.HasOne(d => d.ContratoPlan)
                    .WithMany(p => p.PedidoAfiliado)
                    .HasForeignKey(d => d.ContratoPlanId)
                    .HasConstraintName("FK_dbo.PedidoAfiliado_dbo.ContratoPlan_ContratoPlan_ContratoPlanId");

                entity.HasOne(d => d.PedidoAfiliadoReemplazo)
                    .WithMany(p => p.InversePedidoAfiliadoReemplazo)
                    .HasForeignKey(d => d.PedidoAfiliadoReemplazoId)
                    .HasConstraintName("FK_dbo.PedidoAfiliado_dbo.PedidoAfiliado_PedidoAfiliadoReemplazoId");

                entity.HasOne(d => d.Pedido)
                    .WithMany(p => p.PedidoAfiliado)
                    .HasForeignKey(d => d.PedidoId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.PedidoAfiliado_dbo.Pedido_PedidoId");
            });

            modelBuilder.Entity<PedidoAlertaAccionRespuesta>(entity =>
            {
                entity.HasIndex(e => e.AlertaAccionId)
                    .HasName("IX_AlertaAccionId");

                entity.HasIndex(e => e.PedidoEntidadLogId)
                    .HasName("IX_PedidoEntidadLogId");

                entity.HasIndex(e => new { e.PedidoEntidadLogId, e.PedidoAlertaAccionRespuestaId })
                    .HasName("_dta_index_PedidoAlertaAccionRespuesta_6_1241771481__K3_K1");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser).IsRequired();

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.HasOne(d => d.AlertaAccion)
                    .WithMany(p => p.PedidoAlertaAccionRespuesta)
                    .HasForeignKey(d => d.AlertaAccionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.PedidoAlertaAccionRespuesta_dbo.AlertaAccion_AlertaAccionId");

                entity.HasOne(d => d.PedidoEntidadLog)
                    .WithMany(p => p.PedidoAlertaAccionRespuesta)
                    .HasForeignKey(d => d.PedidoEntidadLogId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.PedidoAlertaAccionRespuesta_dbo.PedidoEntidadLog_PedidoEntidadLogId");
            });

            modelBuilder.Entity<PedidoComentario>(entity =>
            {
                entity.HasIndex(e => e.PedidoId)
                    .HasName("IX_PedidoId");

                entity.HasIndex(e => new { e.PedidoId, e.CmnComentarioTipoId })
                    .HasName("IX_PedidoId_CmnComentarioTipoId");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasDefaultValueSql("('N/A')");

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasMaxLength(50);

                entity.Property(e => e.CmnComentarioTipoId).HasDefaultValueSql("((3))");

                entity.Property(e => e.Hora).HasColumnType("datetime");

                entity.Property(e => e.LeidoUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.LeidoUpdateUser).HasMaxLength(250);

                entity.HasOne(d => d.Pedido)
                    .WithMany(p => p.PedidoComentario)
                    .HasForeignKey(d => d.PedidoId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.PedidoComentario_dbo.Pedido_PedidoId");
            });

            modelBuilder.Entity<PedidoCoseguro>(entity =>
            {
                entity.HasIndex(e => e.GdiaPersonalId)
                    .HasName("IX_GdiaPersonalId");

                entity.HasIndex(e => e.PedidoCoseguroAuditoriaResolucionId)
                    .HasName("IX_PedidoCoseguroAuditoriaResolucionId");

                entity.HasIndex(e => e.PedidoCoseguroTipoNoCobroId)
                    .HasName("IX_PedidoCoseguroTipoNoCobroId");

                entity.HasIndex(e => e.PedidoTramoEfectorHorarioId)
                    .HasName("IX_PedidoTramoEfectorHorarioId");

                entity.HasIndex(e => e.PedidoTramoProveedorUMovilHorarioId)
                    .HasName("IX_PedidoTramoProveedorUMovilHorarioId");

                entity.HasIndex(e => new { e.PedidoCoseguroId, e.PedidoTramoProveedorUMovilHorarioId, e.Cobrado, e.Activo, e.Coseguro, e.PedidoId })
                    .HasName("IX_PedidoId");

                entity.Property(e => e.AuditadoFecha).HasColumnType("datetime");

                entity.Property(e => e.AuditadoPor).HasMaxLength(50);

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasMaxLength(50);

                entity.Property(e => e.FechaCobrado).HasColumnType("datetime");

                entity.Property(e => e.FechaConfirmado).HasColumnType("datetime");

                entity.Property(e => e.FechaRecibido).HasColumnType("datetime");

                entity.Property(e => e.InformadoFecha).HasColumnType("datetime");

                entity.Property(e => e.InformadoPor).HasMaxLength(50);

                entity.Property(e => e.NumeroResolucion).HasMaxLength(50);

                entity.HasOne(d => d.GdiaPersonal)
                    .WithMany(p => p.PedidoCoseguro)
                    .HasForeignKey(d => d.GdiaPersonalId)
                    .HasConstraintName("FK_dbo.PedidoCoseguro_dbo.GdiaPersonal_GdiaPersonalId");

                entity.HasOne(d => d.PedidoCoseguroTipoNoCobro)
                    .WithMany(p => p.PedidoCoseguro)
                    .HasForeignKey(d => d.PedidoCoseguroTipoNoCobroId)
                    .HasConstraintName("FK_dbo.PedidoCoseguro_dbo.PedidoCoseguroTipoNoCobro_PedidoCoseguroTipoNoCobroId");

                entity.HasOne(d => d.Pedido)
                    .WithMany(p => p.PedidoCoseguro)
                    .HasForeignKey(d => d.PedidoId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.PedidoCoseguro_dbo.Pedido_PedidoId");

                entity.HasOne(d => d.PedidoTramoEfectorHorario)
                    .WithMany(p => p.PedidoCoseguro)
                    .HasForeignKey(d => d.PedidoTramoEfectorHorarioId)
                    .HasConstraintName("FK_dbo.PedidoCoseguro_dbo.PedidoTramoEfectorHorario_PedidoTramoEfectorHorarioId");

                entity.HasOne(d => d.PedidoTramoProveedorUMovilHorario)
                    .WithMany(p => p.PedidoCoseguro)
                    .HasForeignKey(d => d.PedidoTramoProveedorUMovilHorarioId)
                    .HasConstraintName("FK_dbo.PedidoCoseguro_dbo.PedidoTramoProveedorUMovilHorario_PedidoTramoProveedorUMovilHorarioId");
            });

            modelBuilder.Entity<PedidoCoseguroTipoNoCobro>(entity =>
            {
                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasMaxLength(50);

                entity.Property(e => e.Descripcion).HasMaxLength(255);
            });

            modelBuilder.Entity<PedidoDetalle>(entity =>
            {
                entity.HasIndex(e => e.DiagnosticoId)
                    .HasName("IX_DiagnosticoId");

                entity.HasIndex(e => e.MotivoTrasladoId)
                    .HasName("IX_MotivoTrasladoId");

                entity.HasIndex(e => e.SintomaId)
                    .HasName("IX_SintomaId");

                entity.HasIndex(e => new { e.Coseguro, e.PedidoId, e.PedidoDetalleId })
                    .HasName("_dta_index_PedidoDetalle_7_245575913__K2_K1_9");

                entity.HasIndex(e => new { e.PedidoDetalleId, e.PedidoId, e.SintomaId, e.DiagnosticoId, e.CodigoReferenteDeCliente })
                    .HasName("IX_CodigoReferenteDeCliente");

                entity.HasIndex(e => new { e.SintomaId, e.Coseguro, e.DiagnosticoId, e.CodigoReferenteDeCliente, e.PedidoId })
                    .HasName("IX_PedidoId");

                entity.HasIndex(e => new { e.Telefono, e.Observacion, e.SintomaTomado, e.SintomaId, e.DiagnosticoId, e.CodigoReferenteDeCliente, e.PedidoId, e.PedidoDetalleId })
                    .HasName("_dta_index_PedidoDetalle_7_245575913__K2_K1_3_5_8_11");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasDefaultValueSql("('N/A')");

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasMaxLength(50);

                entity.Property(e => e.CodigoReferenteDeCliente)
                    .HasMaxLength(128)
                    .IsUnicode(false);

                entity.Property(e => e.DiagnosticoTomado).HasMaxLength(255);

                entity.Property(e => e.Observacion).HasColumnType("nvarchar(max)");

                entity.Property(e => e.SintomaTomado).HasColumnType("nvarchar(max)");

                entity.Property(e => e.Telefono).HasColumnType("nvarchar(max)");

                entity.HasOne(d => d.Diagnostico)
                    .WithMany(p => p.PedidoDetalle)
                    .HasForeignKey(d => d.DiagnosticoId)
                    .HasConstraintName("FK_dbo.PedidoDetalle_dbo.Diagnostico_DiagnosticoId");

                entity.HasOne(d => d.Pedido)
                    .WithMany(p => p.PedidoDetalle)
                    .HasForeignKey(d => d.PedidoId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.PedidoDetalle_dbo.Pedido_PedidoId");

                entity.HasOne(d => d.Sintoma)
                    .WithMany(p => p.PedidoDetalle)
                    .HasForeignKey(d => d.SintomaId)
                    .HasConstraintName("FK_dbo.PedidoDetalle_dbo.Sintoma_SintomaId");
            });

            modelBuilder.Entity<PedidoDiagnosticoMedico>(entity =>
            {
                entity.HasIndex(e => e.DiagnosticoId)
                    .HasName("IX_DiagnosticoId");

                entity.HasIndex(e => e.PedidoId)
                    .HasName("IX_PedidoId");

                entity.HasIndex(e => new { e.Descripcion, e.PedidoId, e.PedidoDiagnosticoMedicoId })
                    .HasName("_dta_index_PedidoDiagnosticoMedico_7_2078630448__K3_K1_2");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasDefaultValueSql("('N/A')");

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasMaxLength(50);

                entity.Property(e => e.Descripcion).HasColumnType("nvarchar(max)");

                entity.Property(e => e.Hora).HasColumnType("datetime");

                entity.HasOne(d => d.Diagnostico)
                    .WithMany(p => p.PedidoDiagnosticoMedico)
                    .HasForeignKey(d => d.DiagnosticoId)
                    .HasConstraintName("FK_dbo.PedidoDiagnosticoMedico_dbo.Diagnostico_DiagnosticoId");

                entity.HasOne(d => d.Pedido)
                    .WithMany(p => p.PedidoDiagnosticoMedico)
                    .HasForeignKey(d => d.PedidoId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.PedidoDiagnosticoMedico_dbo.Pedido_PedidoId");
            });

            modelBuilder.Entity<PedidoEntidadLog>(entity =>
            {
                entity.HasIndex(e => e.UsuarioId)
                    .HasName("IX_UsuarioId");

                entity.HasIndex(e => e.WsCorrelationId)
                    .HasName("IX_WsCorrelationId_PedidoEntidadLog");

                entity.HasIndex(e => new { e.EntidadLogTipoEstadoId, e.Fecha })
                    .HasName("IX_EntidadLogTipoEstadoId");

                entity.HasIndex(e => new { e.EntidadLogTipoEstadoId, e.PedidoEntidadLogId, e.Valor, e.PedidoId })
                    .HasName("_dta_index_PedidoEntidadLog_6_1040722760__K4_K1_K3_K2");

                entity.HasIndex(e => new { e.PedidoEntidadLogId, e.PedidoId, e.Valor, e.EntidadLogTipoEstadoId })
                    .HasName("IX_PedidoEntidadLog_EntidadLogTipoEstadoId");

                entity.HasIndex(e => new { e.PedidoEntidadLogId, e.Fecha, e.PedidoId, e.EntidadLogTipoEstadoId, e.Valor })
                    .HasName("RA_PedidoEntidadLog_001");

                entity.HasIndex(e => new { e.PedidoEntidadLogId, e.Fecha, e.Usuario, e.Valor, e.EntidadLogTipoEstadoId })
                    .HasName("_dta_index_PedidoEntidadLog_7_1040722760__K3_K4_1_5_6");

                entity.HasIndex(e => new { e.Fecha, e.Usuario, e.PedidoId, e.EntidadLogTipoEstadoId, e.PedidoEntidadLogId, e.Valor })
                    .HasName("_dta_index_PedidoEntidadLog_7_1040722760__K2_K4_K1_K3_5_6");

                entity.Property(e => e.Accion).HasColumnType("nvarchar(max)");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.Descripcion).HasMaxLength(128);

                entity.Property(e => e.DireccionIP)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.Fecha).HasColumnType("datetime");

                entity.Property(e => e.IP).HasColumnType("nvarchar(max)");

                entity.Property(e => e.Usuario).HasColumnType("nvarchar(max)");

                entity.Property(e => e.WsCorrelationId).HasMaxLength(50);

                entity.Property(e => e.WsMsgEstadoDesc).HasMaxLength(100);

                entity.Property(e => e.WsOperador).HasMaxLength(100);

                entity.HasOne(d => d.Pedido)
                    .WithMany(p => p.PedidoEntidadLog)
                    .HasForeignKey(d => d.PedidoId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.PedidoEntidadLog_dbo.Pedido_PedidoId");
            });

            modelBuilder.Entity<PedidoMuestra>(entity =>
            {
                entity.HasIndex(e => e.PedidoId)
                    .HasName("IX_PedidoId");

                entity.HasIndex(e => e.ProveedorId)
                    .HasName("IX_ProveedorId");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.CodigoMuestra).HasMaxLength(128);

                entity.Property(e => e.FechaEgresoFarmacia).HasColumnType("datetime");

                entity.Property(e => e.FechaIngresoFarmacia).HasColumnType("datetime");

                entity.Property(e => e.FechaIngresoLaboratorio).HasColumnType("datetime");

                entity.HasOne(d => d.Pedido)
                    .WithMany(p => p.PedidoMuestra)
                    .HasForeignKey(d => d.PedidoId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.PedidoMuestra_dbo.Pedido_PedidoId");

                entity.HasOne(d => d.Proveedor)
                    .WithMany(p => p.PedidoMuestra)
                    .HasForeignKey(d => d.ProveedorId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.PedidoMuestra_dbo.Proveedor_ProveedorId");
            });

            modelBuilder.Entity<PedidoResultadoLaboratorio>(entity =>
            {
                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasMaxLength(50);

                entity.Property(e => e.Descripcion).HasMaxLength(512);
            });

            modelBuilder.Entity<PedidoResultadoLaboratorioTipoPrestacion>(entity =>
            {
                entity.HasIndex(e => e.PedidoResultadoLaboratorioId)
                    .HasName("IX_PedidoResultadoLaboratorioId");

                entity.HasIndex(e => e.TipoPrestacionId)
                    .HasName("IX_TipoPrestacionId");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasMaxLength(50);

                entity.HasOne(d => d.PedidoResultadoLaboratorio)
                    .WithMany(p => p.PedidoResultadoLaboratorioTipoPrestacion)
                    .HasForeignKey(d => d.PedidoResultadoLaboratorioId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.PedidoResultadoLaboratorioTipoPrestacion_dbo.PedidoResultadoLaboratorio_PedidoResultadoLaboratorioId");

                entity.HasOne(d => d.TipoPrestacion)
                    .WithMany(p => p.PedidoResultadoLaboratorioTipoPrestacion)
                    .HasForeignKey(d => d.TipoPrestacionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.PedidoResultadoLaboratorioTipoPrestacion_dbo.TipoPrestacion_TipoPrestacionId");
            });

            modelBuilder.Entity<PedidoTipoCierre>(entity =>
            {
                entity.Property(e => e.Descripcion).IsRequired();
            });

            modelBuilder.Entity<PedidoTramo>(entity =>
            {
                entity.HasIndex(e => e.PedidoId)
                    .HasName("IX_PedidoId");

                entity.HasIndex(e => new { e.Activo, e.PedidoTramoId, e.PedidoId })
                    .HasName("_dta_index_PedidoTramo_7_400720480__K4_K1_K2");

                entity.HasIndex(e => new { e.PedidoTramoId, e.PedidoId, e.Activo })
                    .HasName("RA_PedidoTramo_001");

                entity.HasIndex(e => new { e.PedidoId, e.TramoNro, e.Activo, e.PedidoTramoId })
                    .HasName("_dta_index_PedidoTramo_7_400720480__K2_K3_K4_K1");

                entity.HasIndex(e => new { e.PedidoTramoId, e.PedidoId, e.TramoNro, e.Activo, e.DesdeTeorico })
                    .HasName("IX_DesdeTeorico");

                entity.HasIndex(e => new { e.TramoNro, e.HorarioDespacho, e.Activo, e.PedidoTramoId, e.PedidoId })
                    .HasName("_dta_index_PedidoTramo_7_400720480__K4_K1_K2_3_9");

                entity.HasIndex(e => new { e.TramoNro, e.HorarioDespacho, e.PedidoTramoId, e.Activo, e.PedidoId })
                    .HasName("_dta_index_PedidoTramo_7_400720480__K1_K4_K2_3_9");

                entity.HasIndex(e => new { e.HorarioDespacho, e.HastaTeorico, e.Activo, e.DesdeTeorico, e.PedidoId, e.PedidoTramoId })
                    .HasName("_dta_index_PedidoTramo_12_400720480__K4_K11_K2_K1_9_12");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.DesdeTeorico).HasColumnType("datetime");

                entity.Property(e => e.HastaTeorico).HasColumnType("datetime");

                entity.Property(e => e.HorarioDespacho).HasColumnType("datetime");

                entity.HasOne(d => d.Pedido)
                    .WithMany(p => p.PedidoTramo)
                    .HasForeignKey(d => d.PedidoId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.PedidoTramo_dbo.Pedido_PedidoId");
            });

            modelBuilder.Entity<PedidoTramoDetalle>(entity =>
            {
                entity.HasIndex(e => e.DireccionId)
                    .HasName("IX_DireccionId");

                entity.HasIndex(e => e.PedidoTramoId)
                    .HasName("IX_PedidoTramoId");

                entity.HasIndex(e => new { e.PedidoTramoId, e.Activo, e.HorarioProgramado })
                    .HasName("IX_Activo");

                entity.HasIndex(e => new { e.OrigenDestino, e.Activo, e.PedidoTramoId, e.DireccionId })
                    .HasName("_dta_index_PedidoTramoDetalle_7_432720594__K5_K6_K2_K3");

                entity.HasIndex(e => new { e.DireccionId, e.HorarioProgramado, e.OrigenDestino, e.Activo, e.PedidoTramoId })
                    .HasName("_dta_index_PedidoTramoDetalle_7_432720594__K2_3_4_5_6");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.HorarioProgramado).HasColumnType("datetime");

                entity.Property(e => e.HorarioTeorico).HasColumnType("datetime");

                entity.Property(e => e.Observacion).HasMaxLength(500);

                entity.HasOne(d => d.Direccion)
                    .WithMany(p => p.PedidoTramoDetalle)
                    .HasForeignKey(d => d.DireccionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.PedidoTramoDetalle_dbo.Direccion_DireccionId");

                entity.HasOne(d => d.PedidoTramo)
                    .WithMany(p => p.PedidoTramoDetalle)
                    .HasForeignKey(d => d.PedidoTramoId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.PedidoTramoDetalle_dbo.PedidoTramo_PedidoTramoId");
            });

            modelBuilder.Entity<PedidoTramoEfectorHorario>(entity =>
            {
                entity.HasIndex(e => e.EfectorId)
                    .HasName("IX_EfectorId");

                entity.HasIndex(e => e.PedidoTramoEfectorHorarioEstadoId)
                    .HasName("IX_PedidoTramoEfectorHorarioEstadoId");

                entity.HasIndex(e => e.PedidoTramoEfectorHorarioEstadoTipoId)
                    .HasName("IX_PedidoTramoEfectorHorarioEstadoTipoId");

                entity.HasIndex(e => e.PedidoTramoId)
                    .HasName("IX_PedidoTramoId");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasMaxLength(50);

                entity.Property(e => e.DestinoArribo).HasColumnType("datetime");

                entity.Property(e => e.DestinoPartida).HasColumnType("datetime");

                entity.Property(e => e.HorarioAceptacion).HasColumnType("datetime");

                entity.Property(e => e.NroServicio).HasMaxLength(40);

                entity.Property(e => e.OrigenArribo).HasColumnType("datetime");

                entity.Property(e => e.OrigenPartida).HasColumnType("datetime");

                entity.Property(e => e.QuienAtiende).HasMaxLength(50);

                entity.HasOne(d => d.Efector)
                    .WithMany(p => p.PedidoTramoEfectorHorario)
                    .HasForeignKey(d => d.EfectorId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.PedidoTramoEfectorHorario_dbo.Efector_EfectorId");

                entity.HasOne(d => d.PedidoTramo)
                    .WithMany(p => p.PedidoTramoEfectorHorario)
                    .HasForeignKey(d => d.PedidoTramoId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.PedidoTramoEfectorHorario_dbo.PedidoTramo_PedidoTramoId");
            });

            modelBuilder.Entity<PedidoTramoProveedorUMovilHorario>(entity =>
            {
                entity.HasIndex(e => e.GdiaRealEquipoId)
                    .HasName("IX_GdiaRealEquipoId");

                entity.HasIndex(e => e.PedidoTramoProveedorUMovilHorarioEstadoId)
                    .HasName("IX_PedidoTramoProveedorUMovilHorarioEstadoId");

                entity.HasIndex(e => e.PedidoTramoProveedorUMovilHorarioEstadoTipoId)
                    .HasName("IX_PedidoTramoProveedorUMovilHorarioEstadoTipoId");

                entity.HasIndex(e => e.PedidoTramoProveedorUMovilHorarioRelevoId)
                    .HasName("IX_PedidoTramoProveedorUMovilHorarioRelevoId");

                entity.HasIndex(e => e.ProveedorId)
                    .HasName("IX_ProveedorId");

                entity.HasIndex(e => new { e.Activo, e.PedidoTramoProveedorUMovilHorarioId, e.PedidoTramoId })
                    .HasName("_dta_index_PedidoTramoProveedorUMovilHorari_7_560721050__K13_K1_K4");

                entity.HasIndex(e => new { e.UMovilId, e.PedidoTramoId, e.Activo })
                    .HasName("RA_PedidoTramoProveedorUMovilHorario_001");

                entity.HasIndex(e => new { e.PedidoTramoProveedorUMovilHorarioId, e.UMovilId, e.PedidoTramoId, e.Activo, e.ReportNumero })
                    .HasName("IX_PedidoTramoProveedorUMovilHorario_ReportNumero");

                entity.HasIndex(e => new { e.PedidoTramoProveedorUMovilHorarioId, e.ReportIngresado, e.Activo, e.PedidoTramoId, e.UMovilId, e.ProveedorId })
                    .HasName("_dta_index_PedidoTramoProveedorUMovilHorari_7_560721050__K18_K13_K4_K3_K2_1");

                entity.HasIndex(e => new { e.FechaIngresoReport, e.UsurarioIngresoReport, e.PoseeFirma, e.Activo, e.UMovilId, e.ProveedorId, e.PedidoTramoId, e.PedidoTramoProveedorUMovilHorarioId })
                    .HasName("_dta_index_PedidoTramoProveedorUMovilHorari_12_560721050__K27_K13_K3_K2_K4_K1_19_20");

                entity.HasIndex(e => new { e.PedidoTramoProveedorUMovilHorarioId, e.OrigenArribo, e.OrigenPartida, e.DestinoArribo, e.DestinoPartida, e.Origen, e.Destino, e.PedidoTramoId })
                    .HasName("IX_PedidoTramoId");

                entity.HasIndex(e => new { e.PedidoTramoProveedorUMovilHorarioId, e.ProveedorId, e.PedidoTramoId, e.OrigenArribo, e.OrigenPartida, e.DestinoArribo, e.DestinoPartida, e.Origen, e.Destino, e.Apoyo, e.UMovilId, e.Activo })
                    .HasName("IX_UMovilId");

                entity.HasIndex(e => new { e.PedidoTramoProveedorUMovilHorarioId, e.ProveedorId, e.UMovilId, e.PedidoTramoProveedorUMovilHorarioEstadoId, e.OrigenArribo, e.OrigenPartida, e.DestinoArribo, e.DestinoPartida, e.Origen, e.Destino, e.OrigenArriboGps, e.OrigenPartidaGps, e.DestinoArriboGps, e.DestinoPartidaGps, e.Activo, e.PedidoTramoId })
                    .HasName("_dta_index_PedidoTramoProveedorUMovilHorari_7_560721050__K13_K4_1_2_3_5_6_7_8_9_10_11_21_22_23_24");

                entity.HasIndex(e => new { e.ProveedorId, e.PedidoTramoProveedorUMovilHorarioEstadoId, e.OrigenArribo, e.OrigenPartida, e.DestinoArribo, e.DestinoPartida, e.Origen, e.Destino, e.Apoyo, e.OrigenArriboGps, e.OrigenPartidaGps, e.DestinoArriboGps, e.DestinoPartidaGps, e.PedidoTramoId, e.Activo, e.PedidoTramoProveedorUMovilHorarioId, e.GpsId, e.UMovilId })
                    .HasName("_dta_index_PedidoTramoProveedorUMovilHorari_12_560721050__K4_K13_K1_K26_K3_2_5_6_7_8_9_10_11_12_21_22_23_24");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.DestinoArribo).HasColumnType("datetime");

                entity.Property(e => e.DestinoArriboGps).HasColumnType("datetime");

                entity.Property(e => e.DestinoPartida).HasColumnType("datetime");

                entity.Property(e => e.DestinoPartidaGps).HasColumnType("datetime");

                entity.Property(e => e.FechaAsignacion).HasColumnType("datetime");

                entity.Property(e => e.FechaAsignacionDerivacion).HasColumnType("datetime");

                entity.Property(e => e.FechaCargaDerivacion).HasColumnType("datetime");

                entity.Property(e => e.FechaConfirmado).HasColumnType("datetime");

                entity.Property(e => e.FechaConfirmadoDerivacion).HasColumnType("datetime");

                entity.Property(e => e.FechaContactoObraSocial).HasColumnType("datetime");

                entity.Property(e => e.FechaIngresoFirma).HasColumnType("datetime");

                entity.Property(e => e.FechaIngresoReport).HasColumnType("datetime");

                entity.Property(e => e.FechaIniciodeViaje).HasColumnType("datetime");

                entity.Property(e => e.FechaRecibido).HasColumnType("datetime");

                entity.Property(e => e.FechaRecibidoDerivacion).HasColumnType("datetime");

                entity.Property(e => e.FechaSolicitudDerivacion).HasColumnType("datetime");

                entity.Property(e => e.HorarioAceptacion).HasColumnType("datetime");

                entity.Property(e => e.NroServicio).HasMaxLength(128);

                entity.Property(e => e.OrigenArribo).HasColumnType("datetime");

                entity.Property(e => e.OrigenArriboGps).HasColumnType("datetime");

                entity.Property(e => e.OrigenPartida).HasColumnType("datetime");

                entity.Property(e => e.OrigenPartidaGps).HasColumnType("datetime");

                entity.Property(e => e.QuienAtiende).HasMaxLength(50);

                entity.Property(e => e.ReportNumero)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UsurarioIngresoReport).HasColumnType("nvarchar(max)");

                entity.HasOne(d => d.GdiaRealEquipo)
                    .WithMany(p => p.PedidoTramoProveedorUMovilHorario)
                    .HasForeignKey(d => d.GdiaRealEquipoId)
                    .HasConstraintName("FK_dbo.PedidoTramoProveedorUMovilHorario_dbo.GdiaRealEquipo_GdiaRealEquipoId");

                entity.HasOne(d => d.PedidoTramo)
                    .WithMany(p => p.PedidoTramoProveedorUMovilHorario)
                    .HasForeignKey(d => d.PedidoTramoId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.PedidoTramoProveedorUMovilHorario_dbo.PedidoTramo_PedidoTramoId");

                entity.HasOne(d => d.PedidoTramoProveedorUMovilHorarioRelevo)
                    .WithMany(p => p.InversePedidoTramoProveedorUMovilHorarioRelevo)
                    .HasForeignKey(d => d.PedidoTramoProveedorUMovilHorarioRelevoId)
                    .HasConstraintName("FK_dbo.PedidoTramoProveedorUMovilHorario_dbo.PedidoTramoProveedorUMovilHorario_PedidoTramoProveedorUMovilHorarioRelevoId");

                entity.HasOne(d => d.Proveedor)
                    .WithMany(p => p.PedidoTramoProveedorUMovilHorario)
                    .HasForeignKey(d => d.ProveedorId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.PedidoTramoProveedorUMovilHorario_dbo.Proveedor_ProveedorId");

                entity.HasOne(d => d.UMovil)
                    .WithMany(p => p.PedidoTramoProveedorUMovilHorario)
                    .HasForeignKey(d => d.UMovilId)
                    .HasConstraintName("FK_dbo.PedidoTramoProveedorUMovilHorario_dbo.UMovil_UMovilId");
            });

            modelBuilder.Entity<PedidoTramoProveedorUMovilHorarioGdiaRealPersonal>(entity =>
            {
                entity.HasIndex(e => e.GdiaComponenteId)
                    .HasName("IX_GdiaComponenteId");

                entity.HasIndex(e => e.GdiaRealPersonalDetalleId)
                    .HasName("IX_GdiaRealPersonalDetalleId");

                entity.HasIndex(e => e.GdiaRealPersonalId)
                    .HasName("IX_GdiaRealPersonalId");

                entity.HasIndex(e => e.PedidoTramoProveedorUMovilHorarioId)
                    .HasName("IX_PedidoTramoProveedorUMovilHorarioId");

                entity.HasIndex(e => new { e.PedidoTramoProveedorUMovilHorarioId, e.GdiaRealPersonalId, e.Activo, e.GdiaComponenteId })
                    .HasName("IX_PedidoTramoProveedorUMovilHorarioGdiaRealPersonal_Activo_GdiaComponenteId");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser).HasMaxLength(50);

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasMaxLength(50);

                entity.HasOne(d => d.GdiaRealPersonalDetalle)
                    .WithMany(p => p.PedidoTramoProveedorUMovilHorarioGdiaRealPersonal)
                    .HasForeignKey(d => d.GdiaRealPersonalDetalleId)
                    .HasConstraintName("FK_dbo.PedidoTramoProveedorUMovilHorarioGdiaRealPersonal_dbo.GdiaRealPersonalDetalle_GdiaRealPersonalDetalleId");

                entity.HasOne(d => d.GdiaRealPersonal)
                    .WithMany(p => p.PedidoTramoProveedorUMovilHorarioGdiaRealPersonal)
                    .HasForeignKey(d => d.GdiaRealPersonalId)
                    .HasConstraintName("FK_dbo.PedidoTramoProveedorUMovilHorarioGdiaRealPersonal_dbo.GdiaRealPersonal_GdiaRealPersonalId");

                entity.HasOne(d => d.PedidoTramoProveedorUMovilHorario)
                    .WithMany(p => p.PedidoTramoProveedorUMovilHorarioGdiaRealPersonal)
                    .HasForeignKey(d => d.PedidoTramoProveedorUMovilHorarioId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.PedidoTramoProveedorUMovilHorarioGdiaRealPersonal_dbo.PedidoTramoProveedorUMovilHorario_PedidoTramoProveedorUMovilHorario");
            });

            modelBuilder.Entity<PedidoTriageVersionDetalleLog>(entity =>
            {
                entity.HasIndex(e => e.PedidoId)
                    .HasName("IX_PedidoId");

                entity.HasIndex(e => e.TriageVersionDetalleId)
                    .HasName("IX_TriageVersionDetalleId");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasMaxLength(50);

                entity.HasOne(d => d.Pedido)
                    .WithMany(p => p.PedidoTriageVersionDetalleLog)
                    .HasForeignKey(d => d.PedidoId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.PedidoTriageVersionDetalleLog_dbo.Pedido_PedidoId");

                entity.HasOne(d => d.TriageVersionDetalle)
                    .WithMany(p => p.PedidoTriageVersionDetalleLog)
                    .HasForeignKey(d => d.TriageVersionDetalleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.PedidoTriageVersionDetalleLog_dbo.TriageVersionDetalle_TriageVersionDetalleId");
            });

            modelBuilder.Entity<Proveedor>(entity =>
            {
                entity.HasIndex(e => e.DireccionLocalidadId)
                    .HasName("IX_DireccionLocalidadId");

                entity.Property(e => e.AuditoriaInserUser).HasMaxLength(50);

                entity.Property(e => e.Descripcion).IsRequired();

                entity.Property(e => e.Domicilio).HasMaxLength(256);

                entity.Property(e => e.Mail)
                    .IsRequired()
                    .HasMaxLength(256)
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.Telefono).HasMaxLength(256);

                entity.HasOne(d => d.DireccionLocalidad)
                    .WithMany(p => p.Proveedor)
                    .HasForeignKey(d => d.DireccionLocalidadId)
                    .HasConstraintName("FK_dbo.Proveedor_dbo.DireccionLocalidad_DireccionLocalidadId");
            });

            modelBuilder.Entity<RestriccionTipoCierreDiagnostico>(entity =>
            {
                entity.HasIndex(e => e.DiagnosticoId)
                    .HasName("IX_DiagnosticoId");

                entity.HasIndex(e => e.PedidoTipoCierreId)
                    .HasName("IX_PedidoTipoCierreId");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser).HasMaxLength(50);

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasMaxLength(50);

                entity.HasOne(d => d.Diagnostico)
                    .WithMany(p => p.RestriccionTipoCierreDiagnostico)
                    .HasForeignKey(d => d.DiagnosticoId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.RestriccionTipoCierreDiagnostico_dbo.Diagnostico_DiagnosticoId");

                entity.HasOne(d => d.PedidoTipoCierre)
                    .WithMany(p => p.RestriccionTipoCierreDiagnostico)
                    .HasForeignKey(d => d.PedidoTipoCierreId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.RestriccionTipoCierreDiagnostico_dbo.PedidoTipoCierre_PedidoTipoCierreId");
            });

            modelBuilder.Entity<RestriccionTipoCierrePrestacion>(entity =>
            {
                entity.HasIndex(e => e.PedidoTipoCierreId)
                    .HasName("IX_PedidoTipoCierreId");

                entity.HasIndex(e => e.TipoPrestacionId)
                    .HasName("IX_TipoPrestacionId");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser).HasMaxLength(50);

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasMaxLength(50);

                entity.HasOne(d => d.PedidoTipoCierre)
                    .WithMany(p => p.RestriccionTipoCierrePrestacion)
                    .HasForeignKey(d => d.PedidoTipoCierreId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.RestriccionTipoCierrePrestacion_dbo.PedidoTipoCierre_PedidoTipoCierreId");

                entity.HasOne(d => d.TipoPrestacion)
                    .WithMany(p => p.RestriccionTipoCierrePrestacion)
                    .HasForeignKey(d => d.TipoPrestacionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.RestriccionTipoCierrePrestacion_dbo.TipoPrestacion_TipoPrestacionId");
            });

            modelBuilder.Entity<Sintoma>(entity =>
            {
                entity.Property(e => e.Activo)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasDefaultValueSql("('N/A')");

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasMaxLength(50);

                entity.Property(e => e.Descripcion).IsRequired();
            });

            modelBuilder.Entity<TipoDocumento>(entity =>
            {
                entity.Property(e => e.Descripcion).HasMaxLength(256);
            });

            modelBuilder.Entity<TipoPrestacion>(entity =>
            {
                entity.Property(e => e.Background).HasMaxLength(150);

                entity.Property(e => e.Color).HasMaxLength(150);
            });

            modelBuilder.Entity<TipoPrestacionContrato>(entity =>
            {
                entity.HasIndex(e => e.ContratoId)
                    .HasName("IX_ContratoId");

                entity.HasIndex(e => e.TipoPrestacionId)
                    .HasName("IX_TipoPrestacionId");

                entity.HasIndex(e => new { e.ContratoId, e.TipoPrestacionId, e.TipoPrestacionContratoId })
                    .HasName("_dta_index_TipoPrestacionContrato_6_446624634__K3_K2_K1");

                entity.HasIndex(e => new { e.TipoPrestacionId, e.ContratoId, e.Activo })
                    .HasName("IX_TipoPrestacionContrato_Activo");

                entity.HasIndex(e => new { e.TipoPrestacionContratoId, e.ContratoId, e.MinutosTolerancia, e.PuntajeMinimo, e.PuntajeMaximo, e.EdadMinima, e.EdadMaxima, e.PermiteEditarHorarios, e.RequiereGuardia, e.AuditoriaInsertUser, e.AuditoriaInsertDate, e.AuditoriaUpdateUser, e.AuditoriaUpdateDate, e.TipoPrestacionId, e.Activo })
                    .HasName("IX_TipoPrestacionContrato_TipoPrestacionId_Activo");

                entity.Property(e => e.Activo)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasDefaultValueSql("('N/A')");

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasMaxLength(50);

                entity.HasOne(d => d.TipoPrestacion)
                    .WithMany(p => p.TipoPrestacionContrato)
                    .HasForeignKey(d => d.TipoPrestacionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.TipoPrestacionContrato_dbo.TipoPrestacion_TipoPrestacionId");
            });

            modelBuilder.Entity<TipoPrestacionPlanCoseguro>(entity =>
            {
                entity.HasIndex(e => e.ContratoPlanId)
                    .HasName("IX_ContratoPlanId");

                entity.HasIndex(e => e.TipoPrestacionContratoId)
                    .HasName("IX_TipoPrestacionContratoId");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasMaxLength(50);

                entity.HasOne(d => d.ContratoPlan)
                    .WithMany(p => p.TipoPrestacionPlanCoseguro)
                    .HasForeignKey(d => d.ContratoPlanId)
                    .HasConstraintName("FK_dbo.TipoPrestacionPlanCoseguro_dbo.ContratoPlan_ContratoPlanId");

                entity.HasOne(d => d.TipoPrestacionContrato)
                    .WithMany(p => p.TipoPrestacionPlanCoseguro)
                    .HasForeignKey(d => d.TipoPrestacionContratoId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.TipoPrestacionPlanCoseguro_dbo.TipoPrestacionContrato_TipoPrestacionContratoId");
            });

            modelBuilder.Entity<TriageVersionDetalle>(entity =>
            {
                entity.HasIndex(e => e.SintomaId)
                    .HasName("IX_SintomaId");

                entity.HasIndex(e => e.TipoPrestacionId)
                    .HasName("IX_TipoPrestacionId");

                entity.HasIndex(e => e.TriageVersionId)
                    .HasName("IX_TriageVersionId");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasMaxLength(50);

                entity.Property(e => e.Descripcion).HasMaxLength(255);

                entity.HasOne(d => d.Sintoma)
                    .WithMany(p => p.TriageVersionDetalle)
                    .HasForeignKey(d => d.SintomaId)
                    .HasConstraintName("FK_dbo.TriageVersionDetalle_dbo.Sintoma_SintomaId");

                entity.HasOne(d => d.TipoPrestacion)
                    .WithMany(p => p.TriageVersionDetalle)
                    .HasForeignKey(d => d.TipoPrestacionId)
                    .HasConstraintName("FK_dbo.TriageVersionDetalle_dbo.TipoPrestacion_TipoPrestacionId");
            });

            modelBuilder.Entity<UMovil>(entity =>
            {
                entity.HasIndex(e => e.CategoriaId)
                    .HasName("IX_CategoriaId");

                entity.HasIndex(e => e.CmnCelularAlternoId)
                    .HasName("IX_CmnCelularAlternoId");

                entity.HasIndex(e => e.CmnCelularId)
                    .HasName("IX_CmnCelularId");

                entity.HasIndex(e => e.ProveedorId)
                    .HasName("IX_ProveedorId");

                entity.HasIndex(e => new { e.Descripcion, e.UMovilId })
                    .HasName("_dta_index_UMovil_6_985770569__K1_2");

                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser)
                    .IsRequired()
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.ConfirmaAprovUltimaFecha).HasColumnType("datetime");

                entity.Property(e => e.Descripcion).HasColumnType("nvarchar(max)");

                entity.Property(e => e.EspereEnLugarUltimoHorario)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("('1900-01-01T00:00:00.000')");

                entity.HasOne(d => d.CmnCelularAlterno)
                    .WithMany(p => p.UMovilCmnCelularAlterno)
                    .HasForeignKey(d => d.CmnCelularAlternoId)
                    .HasConstraintName("FK_dbo.UMovil_dbo.CmnCelular_CmnCelularAlternoId");

                entity.HasOne(d => d.CmnCelular)
                    .WithMany(p => p.UMovilCmnCelular)
                    .HasForeignKey(d => d.CmnCelularId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_dbo.UMovil_dbo.CmnCelular_CmnCelularId");

                entity.HasOne(d => d.Proveedor)
                    .WithMany(p => p.UMovil)
                    .HasForeignKey(d => d.ProveedorId)
                    .HasConstraintName("FK_dbo.UMovil_dbo.Proveedor_ProveedorId");
            });
        }
    }
}
