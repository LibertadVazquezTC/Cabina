﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class TipoDocumento
    {
        public TipoDocumento()
        {
            ContratoAfiliado = new HashSet<ContratoAfiliado>();
            HistoriaClinicaPaciente = new HashSet<HistoriaClinicaPaciente>();
        }

        public int TipoDocumentoId { get; set; }
        public string Descripcion { get; set; }
        public bool Activo { get; set; }

        public virtual ICollection<ContratoAfiliado> ContratoAfiliado { get; set; }
        public virtual ICollection<HistoriaClinicaPaciente> HistoriaClinicaPaciente { get; set; }
    }
}
