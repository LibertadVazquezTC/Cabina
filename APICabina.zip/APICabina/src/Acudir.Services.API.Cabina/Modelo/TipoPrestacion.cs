﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class TipoPrestacion
    {
        public TipoPrestacion()
        {
            Pedido = new HashSet<Pedido>();
            PedidoResultadoLaboratorioTipoPrestacion = new HashSet<PedidoResultadoLaboratorioTipoPrestacion>();
            RestriccionTipoCierrePrestacion = new HashSet<RestriccionTipoCierrePrestacion>();
            TipoPrestacionContrato = new HashSet<TipoPrestacionContrato>();
            TriageVersionDetalle = new HashSet<TriageVersionDetalle>();
        }

        public int TipoPrestacionId { get; set; }
        public string Descripcion { get; set; }
        public int TipoPrestacionCategoriaId { get; set; }
        public string DescripcionAbreviada { get; set; }
        public int? DemoraEncendidoSirena { get; set; }
        public int? DemoraMovimiento { get; set; }
        public string Background { get; set; }
        public string Color { get; set; }
        public int? MinutosTolerancia { get; set; }
        public int? PuntajeMinimo { get; set; }
        public int? PuntajeMaximo { get; set; }
        public int? EdadMinima { get; set; }
        public int? EdadMaxima { get; set; }
        public bool? PermiteEditarHorarios { get; set; }
        public bool? RequiereGuardia { get; set; }
        public bool PSI { get; set; }

        public virtual ICollection<Pedido> Pedido { get; set; }
        public virtual ICollection<PedidoResultadoLaboratorioTipoPrestacion> PedidoResultadoLaboratorioTipoPrestacion { get; set; }
        public virtual ICollection<RestriccionTipoCierrePrestacion> RestriccionTipoCierrePrestacion { get; set; }
        public virtual ICollection<TipoPrestacionContrato> TipoPrestacionContrato { get; set; }
        public virtual ICollection<TriageVersionDetalle> TriageVersionDetalle { get; set; }
    }
}
