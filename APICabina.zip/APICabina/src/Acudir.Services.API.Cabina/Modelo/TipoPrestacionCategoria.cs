﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class TipoPrestacionCategoria
    {
        public TipoPrestacionCategoria()
        {
            TipoPrestacion = new HashSet<TipoPrestacion>();
        }

        public int TipoPrestacionCategoriaId { get; set; }
        public string Descripcion { get; set; }

        public virtual ICollection<TipoPrestacion> TipoPrestacion { get; set; }
    }
}
