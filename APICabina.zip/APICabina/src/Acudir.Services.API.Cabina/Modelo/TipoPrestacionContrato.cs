﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class TipoPrestacionContrato
    {
        public TipoPrestacionContrato()
        {
            TipoPrestacionPlanCoseguro = new HashSet<TipoPrestacionPlanCoseguro>();
        }

        public int TipoPrestacionContratoId { get; set; }
        public int TipoPrestacionId { get; set; }
        public int ContratoId { get; set; }
        public int MinutosTolerancia { get; set; }
        public int PuntajeMinimo { get; set; }
        public int PuntajeMaximo { get; set; }
        public int EdadMinima { get; set; }
        public int EdadMaxima { get; set; }
        public bool? PermiteEditarHorarios { get; set; }
        public bool RequiereGuardia { get; set; }
        public bool? Activo { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime? AuditoriaInsertDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }
        public bool EsperaAutorizadaIlimitada { get; set; }
        public TimeSpan EsperaAutorizadaPrestador { get; set; }

        public virtual TipoPrestacion TipoPrestacion { get; set; }
        public virtual ICollection<TipoPrestacionPlanCoseguro> TipoPrestacionPlanCoseguro { get; set; }
    }
}
