﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class TipoPrestacionPlanCoseguro
    {
        public int TipoPrestacionPlanCoseguroId { get; set; }
        public int TipoPrestacionContratoId { get; set; }
        public int? ContratoPlanId { get; set; }
        public double CoseguroACobrar { get; set; }
        public bool NoAplicaConDerivacion { get; set; }
        public bool Activo { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime? AuditoriaInsertDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }

        public virtual ContratoPlan ContratoPlan { get; set; }
        public virtual TipoPrestacionContrato TipoPrestacionContrato { get; set; }
    }
}
