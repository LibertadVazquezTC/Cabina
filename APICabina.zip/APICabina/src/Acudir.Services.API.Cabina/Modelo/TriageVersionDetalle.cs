﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class TriageVersionDetalle
    {
        public TriageVersionDetalle()
        {
            PedidoTriageVersionDetalleLog = new HashSet<PedidoTriageVersionDetalleLog>();
        }

        public int TriageVersionDetalleId { get; set; }
        public string Descripcion { get; set; }
        public int? TriageVersionDetalleDerivaId { get; set; }
        public int? TipoPrestacionId { get; set; }
        public int? SintomaId { get; set; }
        public int TriageVersionId { get; set; }
        public int? TriageVersionDetallePadreId { get; set; }
        public bool Activo { get; set; }
        public bool PSI { get; set; }
        public bool Prioritario { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime? AuditoriaInsertDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }
        public string InstruccionesPreArribo { get; set; }
        public string InstruccionesAlArribo { get; set; }
        public string InstruccionesDespachador { get; set; }
        public int Orden { get; set; }

        public virtual Sintoma Sintoma { get; set; }
        public virtual TipoPrestacion TipoPrestacion { get; set; }
        public virtual ICollection<PedidoTriageVersionDetalleLog> PedidoTriageVersionDetalleLog { get; set; }
    }
}
