﻿using System;
using System.Collections.Generic;

namespace CabinaOperativa.Modelo
{
    public partial class UMovil
    {
        public UMovil()
        {
            Carga = new HashSet<Carga>();
            GdiaRealEquipoMovil = new HashSet<GdiaRealEquipoMovil>();
            PedidoTramoProveedorUMovilHorario = new HashSet<PedidoTramoProveedorUMovilHorario>();
        }

        public int UMovilId { get; set; }
        public string Descripcion { get; set; }
        public bool Activo { get; set; }
        public int EstadoId { get; set; }
        public int PedidoId { get; set; }
        public int CmnCelularId { get; set; }
        public int? ProveedorId { get; set; }
        public int? GPSId { get; set; }
        public string Patente { get; set; }
        public bool Codigos { get; set; }
        public bool Traslados { get; set; }
        public bool EspereEnLugar { get; set; }
        public string EspereEnLugarUltimoResponsable { get; set; }
        public DateTime? EspereEnLugarUltimoHorario { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime? AuditoriaInsertDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }
        public bool ConfirmaAprov { get; set; }
        public DateTime? ConfirmaAprovUltimaFecha { get; set; }
        public int? CategoriaId { get; set; }
        public int? GpsMovilId { get; set; }
        public int? GpsProveedorId { get; set; }
        public int? CmnCelularAlternoId { get; set; }

        public virtual CmnCelular CmnCelular { get; set; }
        public virtual CmnCelular CmnCelularAlterno { get; set; }
        public virtual Proveedor Proveedor { get; set; }
        public virtual ICollection<Carga> Carga { get; set; }
        public virtual ICollection<GdiaRealEquipoMovil> GdiaRealEquipoMovil { get; set; }
        public virtual ICollection<PedidoTramoProveedorUMovilHorario> PedidoTramoProveedorUMovilHorario { get; set; }
    }
}
