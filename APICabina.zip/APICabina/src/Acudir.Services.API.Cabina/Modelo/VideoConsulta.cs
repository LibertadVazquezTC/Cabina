﻿using CabinaOperativa.Modelo;
using System;
using System.Collections.Generic;

namespace Acudir.Services.API.Cabina.Modelo
{
    public class VideoConsulta
    {
        public int VideoConsultaId { get; set; }
        public DateTime FechaHoraTurno { get; set; }
        public string Anotaciones { get; set; }
        public string Token { get; set; }
        public string ChannelName { get; set; }
        public int PedidoId { get; set; }
        public virtual Pedido Pedido { get; set; }
        public int ContratoAfiliadoId { get; set; }
        public virtual ContratoAfiliado ContratoAfiliado { get; set; }
        public bool FueVideoConsulta { get; set; }
        public bool Activo { get; set; }
        public virtual ICollection<VideoConsultaLog> VideoConsultaLog { get; set; }

    }
}
