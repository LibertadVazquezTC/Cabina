﻿namespace Acudir.Services.API.Cabina.Modelo
{
    public class VideoConsultaLog
    {
        public int VideoConsultaLogId { get; set; }
        public int VideoConsultaId { get; set; }
        public virtual VideoConsulta VideoConsulta { get; set; }
        public int VideoConsultaLogTipoId { get; set; }
        public int? VideoConsultaAcceso { get; set; }
        public virtual VideoConsultaLogTipo VideoConsultaLogTipo { get; set; }
    }
}
