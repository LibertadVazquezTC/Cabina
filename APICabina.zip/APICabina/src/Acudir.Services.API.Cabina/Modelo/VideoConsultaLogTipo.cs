﻿namespace Acudir.Services.API.Cabina.Modelo
{
    public class VideoConsultaLogTipo
    {
        public int VideoConsultaLogTipoId { get; set; }
        public string Descripcion { get; set; }
    }
}
