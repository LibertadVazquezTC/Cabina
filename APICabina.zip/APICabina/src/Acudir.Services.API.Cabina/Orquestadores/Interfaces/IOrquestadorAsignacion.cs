﻿using CabinaOperativa.Enums;
using CabinaOperativa.Modelo;
using System;
using System.Threading.Tasks;

namespace CabinaOperativa.Orquestadores.Interfaces
{
    public interface IOrquestadorAsignacion
    {
        Task<PedidoTramoProveedorUMovilHorario> AsignarPropio(int pedidoId, int gdiaRealEquipoId, int proveedorId, bool esPreasignacion);  
        Task<PedidoTramoProveedorUMovilHorario> ActualizarEstadoDeLaAsignacion(int pedidoTramoProveedorUMovilHorarioId, int pedidoTramoProveedorUMovilHorarioEstadoId);
        Task<PedidoTramoProveedorUMovilHorario> ActualizarHorarios(int pedidoTramoProveedorUMovilHorarioId, TipoHorarioEnum tipoHorario, DateTime fechaHora);
        Task<PedidoTramoProveedorUMovilHorario> ActualizarHorarios(int pedidoId, int gdiaRealEquipoId, TipoHorarioEnum tipoHorario, DateTime fechaHora);
        Task<bool> ActualizarKmCero(int pedidoId);
    }
}
