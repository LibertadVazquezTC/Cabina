﻿using CabinaOperativa.Modelo;
using System;
using System.Threading.Tasks;

namespace CabinaOperativa.Orquestadores.Interfaces
{
    public interface IOrquestadorAsignacionEfector
    {
        Task<PedidoTramoEfectorHorario> AsignarEfector(int pedidoId, int efectorId);
        Task<PedidoTramoEfectorHorario> ActualizarHorario(int pedidoTramoEfectorHorarioId, string tipoHorario, DateTime horario);
    }
}
