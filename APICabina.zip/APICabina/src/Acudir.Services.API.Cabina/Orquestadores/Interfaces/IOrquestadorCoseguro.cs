﻿using CabinaOperativa.Modelo;

using System.Threading.Tasks;

namespace CabinaOperativa.Orquestadores.Interfaces
{
    public interface IOrquestadorCoseguro
    {
        Task ActualizarCoseguroForzadamente(int pedidoId, float valorCoseguro, string motivoActualizacion);
        Task EjecutarReglasDeCoseguroParaElPedido(int pedidoId, bool esAsignacionNueva);
    }
}
