﻿using CabinaOperativa.Modelo;

using System.Threading.Tasks;

namespace CabinaOperativa.Orquestadores.Interfaces
{
    public interface IOrquestadorDesasignacion
    {
        Task DesasignarPorPedido(int pedidoId);
        Task<PedidoTramoProveedorUMovilHorario> Desasignar(int pedidoTramoProveedorUMovilHorarioId);
        Task<PedidoTramoProveedorUMovilHorario> DesasignarWorker(int pedidoTramoProveedorUMovilHorarioId, bool esAmarillo);
        Task<PedidoTramoProveedorUMovilHorario> Desasignar(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario);
    }
}
