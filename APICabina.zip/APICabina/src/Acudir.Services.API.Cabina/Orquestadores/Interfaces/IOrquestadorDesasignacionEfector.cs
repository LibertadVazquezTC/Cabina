﻿using CabinaOperativa.Modelo;

using System.Threading.Tasks;

namespace CabinaOperativa.Orquestadores.Interfaces
{
    public interface IOrquestadorDesasignacionEfector
    {
        Task<PedidoTramoEfectorHorario> DesasignarEfector(int pedidoTramoEfectorHorarioId);
    }
}
