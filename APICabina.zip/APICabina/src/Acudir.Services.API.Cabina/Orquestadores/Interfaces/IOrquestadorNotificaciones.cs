﻿using CabinaOperativa.DTOs.sql_Functions;
using CabinaOperativa.Modelo;
using System.Threading.Tasks;

namespace CabinaOperativa.Orquestadores.Interfaces
{
    public interface IOrquestadorNotificaciones
    {
        Task NotificarCoronavirus(int pedidoTramoProveedorUMovilHorarioId);
        Task NotificarAsignacion(int pedidoTramoProveedorUMovilHorarioId);
        Task NotificarDesasignacion(int pedidoTramoProveedorUMovilHorarioId);
        Task NotificarAnulacion(int pedidoId);
        Task NotificarActualizacionPunto(int pedidoTramoDetalleId);
        Task NotificarActualizacionHorario(int pedidoTramoProveedorUMovilHorarioId, string tipoHorario);
        Task NotificarActualizacionCoseguro(int pedidoTramoProveedorUMovilHorarioId, float coseguro);
        Task NotificarActualizacionTipoPrestacion(int pedidoId, int tipoPrestacionId);
        Task NotificarCancelacionDeCarga(int uMovilId);
        Task NotificarInicioDeCarga(int uMovilId);
        Task<fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId> ObtenerCmnCelularPorPedidoTramoProveedorUMovilHorarioId(int pedidoTramoProveedorUMovilHorarioId);
    }
}
