﻿using CabinaOperativa.DTOs.Archivar;
using CabinaOperativa.Enums;
using System.Threading.Tasks;

namespace CabinaOperativa.Orquestadores.Interfaces
{
    public interface IOrquestadorParaArchivarPedido
    {
        Task RutinaArchivado(ArchivarPedidoDTO archivarPedido);
        Task RutinaIngresoSISA(int pedidoId, IngresadoSisaFormatoEnum ingresadoSisaFormato);
        Task RutinaArchivadoVCM(ArchivarPedidoDTO archivarPedido);
        Task RutinaCreacionLogPedidoNoAtendido(ArchivarPedidoDTO archivarPedidoDTO);
    }
}
