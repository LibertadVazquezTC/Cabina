﻿using System.Threading.Tasks;

namespace CabinaOperativa.Orquestadores.Interfaces
{
    public interface IOrquestadorParaValidarSiFinalizoElPedido
    {
        Task ValidarSiDebeFinalizar(int pedidoId);
    }
}
