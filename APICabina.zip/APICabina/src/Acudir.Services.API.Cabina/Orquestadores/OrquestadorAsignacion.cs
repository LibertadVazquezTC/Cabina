﻿using Acudir.Services.API.Cabina.Constants;
using Acudir.Services.API.Cabina.ServiciosExternos;
using Acudir.Services.API.Cabina.ServiciosExternos.Interfaces;
using CabinaOperativa.Enums;
using CabinaOperativa.Exceptions;
using CabinaOperativa.Modelo;
using CabinaOperativa.Orquestadores.Interfaces;
using CabinaOperativa.Repositories;
using CabinaOperativa.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace CabinaOperativa.Orquestadores
{
    public class OrquestadorAsignacion : IOrquestadorAsignacion
    {
        private readonly IOrquestadorNotificaciones _orquestadorNotificaciones;
        private readonly IOrquestadorCoseguro _orquestadorCoseguro;
        private readonly ICmnConfiguracionRepository _cmnConfiguracionRepository;
        private readonly IPedidoTramoRepository _pedidoTramoRepository;
        private readonly IPedidoRepository _pedidoRepository;
        private readonly IPedidoTramoProveedorUMovilHorarioRepository _pedidoTramoProveedorUMovilHorarioRepository;
        private readonly IPedidoTramoProveedorUMovilHorarioGdiaRealPersonalRepository _pedidoTramoProveedorUMovilHorarioGdiaRealPersonalRepository;
        private readonly IPedidoTramoEfectorHorarioRepository _pedidoTramoEfectorHorarioRepository;
        private readonly IDireccionLocalidadDistanciaRepository _direccionLocalidadDistanciaRepository;
        private readonly IDireccionLocalidadRepository _direccionLocalidadRepository;
        private readonly IPedidoEntidadLogRepository _pedidoEntidadLogRepository;
        private readonly IPedidoCoseguroRepository _pedidoCoseguroRepository;
        private readonly IOrquestadorDesasignacion _orquestadorDesasignacion;
        private readonly IEnvioNotificacionMobileService _envioNotificacionMobileService;

        public OrquestadorAsignacion(IOrquestadorNotificaciones orquestadorNotificaciones,
            IOrquestadorCoseguro orquestadorCoseguro,
            ICmnConfiguracionRepository cmnConfiguracionRepository,
            IPedidoTramoRepository pedidoTramoRepository,
            IPedidoTramoProveedorUMovilHorarioRepository pedidoTramoProveedorUMovilHorarioRepository,
            IPedidoTramoProveedorUMovilHorarioGdiaRealPersonalRepository pedidoTramoProveedorUMovilHorarioGdiaRealPersonalRepository,
            IPedidoTramoEfectorHorarioRepository pedidoTramoEfectorHorarioRepository,
            IPedidoRepository pedidoRepository,
            IDireccionLocalidadDistanciaRepository direccionLocalidadDistanciaRepository,
            IDireccionLocalidadRepository direccionLocalidadRepository,
            IPedidoEntidadLogRepository pedidoEntidadLogRepository,
            IPedidoCoseguroRepository pedidoCoseguroRepository,
            IOrquestadorDesasignacion orquestadorDesasignacion,
            IEnvioNotificacionMobileService envioNotificacionMobileService)
        {
            _orquestadorNotificaciones = orquestadorNotificaciones;
            _orquestadorCoseguro = orquestadorCoseguro;
            _cmnConfiguracionRepository = cmnConfiguracionRepository;
            _pedidoRepository = pedidoRepository;
            _pedidoTramoRepository = pedidoTramoRepository;
            _pedidoTramoProveedorUMovilHorarioRepository = pedidoTramoProveedorUMovilHorarioRepository;
            _pedidoTramoProveedorUMovilHorarioGdiaRealPersonalRepository = pedidoTramoProveedorUMovilHorarioGdiaRealPersonalRepository;
            _pedidoTramoEfectorHorarioRepository = pedidoTramoEfectorHorarioRepository;
            _direccionLocalidadDistanciaRepository = direccionLocalidadDistanciaRepository;
            _direccionLocalidadRepository = direccionLocalidadRepository;
            _pedidoEntidadLogRepository = pedidoEntidadLogRepository;
            _pedidoCoseguroRepository = pedidoCoseguroRepository;
            _orquestadorDesasignacion = orquestadorDesasignacion;
            _envioNotificacionMobileService = envioNotificacionMobileService;
        }

        public async Task<PedidoTramoProveedorUMovilHorario> AsignarPropio(int pedidoId, int gdiaRealEquipoId, int proveedorId, bool esPreasignacion)
        {
            if (pedidoId == 0)
                throw new DatoErroneoException("El pedidoId no puede ser 0.");

            IEnumerable<PedidoTramo> pedidoTramos = await _pedidoTramoRepository.ListarPorPedido(pedidoId);

            if (pedidoTramos is null || !pedidoTramos.Any())
                throw new DatoErroneoException($"No se encontraron pedidoTramos para el pedido con id: {pedidoId}");

            int pedidoTramoId = pedidoTramos.First().PedidoTramoId;

            //Desasignaciones solo para VCM
            if (pedidoTramos.First().Pedido.TipoPrestacionId == (int)TipoPrestacionEnum.VideoConsulta)
            {
                if (await _pedidoTramoProveedorUMovilHorarioRepository.ExisteDespachadoActivo(pedidoTramoId))
                    throw new DatoErroneoException($"El pedido {pedidoId} ya tiene un proveedor asignado");
                var tieneAsignacion = await ValidarSiLaGdiaRealEquipoYaSeEncuentraAsignadoAlPedidoTramoVCM(pedidoTramoId, gdiaRealEquipoId);
                if (!tieneAsignacion)
                {
                    if(gdiaRealEquipoId != ConstantesTipoNotificacionMobile.GDIA_FICTICIA)
                    {
                        await _envioNotificacionMobileService.BuscarAfiliadoMobileYEnviarNotificacion(pedidoId, ConstantesTipoNotificacionMobile.ASIGNADO);
                    }
                }
                int cantidadDeAsignacionesPrincipales = await _pedidoTramoProveedorUMovilHorarioRepository.CantidadDeAsignacionesPrincipales(pedidoTramoId);
                int cantidadDeAsignacionesPrincipalesEfector = await _pedidoTramoEfectorHorarioRepository.CantidadDeAsignacionesPrincipales(pedidoTramoId);
                bool esApoyo = cantidadDeAsignacionesPrincipales > 0 || cantidadDeAsignacionesPrincipalesEfector > 0;

                var preasignacion =  esPreasignacion ?
                await Preasignar(pedidoTramoId, gdiaRealEquipoId, proveedorId, esApoyo) :
                await Asignar(pedidoTramoId, gdiaRealEquipoId, proveedorId, esApoyo);

                await _orquestadorDesasignacion.DesasignarPorPedido(pedidoId);
                
                return preasignacion;
            }
            else
            {
                await ValidarSiLaGdiaRealEquipoYaSeEncuentraAsignadoAlPedidoTramo(pedidoTramoId, gdiaRealEquipoId);

                int cantidadDeAsignacionesPrincipales = await _pedidoTramoProveedorUMovilHorarioRepository.CantidadDeAsignacionesPrincipales(pedidoTramoId);
                int cantidadDeAsignacionesPrincipalesEfector = await _pedidoTramoEfectorHorarioRepository.CantidadDeAsignacionesPrincipales(pedidoTramoId);
                bool esApoyo = cantidadDeAsignacionesPrincipales > 0 || cantidadDeAsignacionesPrincipalesEfector > 0;

                return esPreasignacion ?
                    await Preasignar(pedidoTramoId, gdiaRealEquipoId, proveedorId, esApoyo) :
                    await Asignar(pedidoTramoId, gdiaRealEquipoId, proveedorId, esApoyo);
            }
        }

        private async Task VerificarYEnviarNotificacionAMobile(int pedidoId)
        {

            await _envioNotificacionMobileService.BuscarAfiliadoMobileYEnviarNotificacion(pedidoId, ConstantesTipoNotificacionMobile.ASIGNADO);

        }

        public async Task<PedidoTramoProveedorUMovilHorario> ActualizarEstadoDeLaAsignacion(int pedidoTramoProveedorUMovilHorarioId, int pedidoTramoProveedorUMovilHorarioEstadoId)
        {
            PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario = await _pedidoTramoProveedorUMovilHorarioRepository.Obtener(pedidoTramoProveedorUMovilHorarioId);
            if (pedidoTramoProveedorUMovilHorario is null)
                throw new DatoErroneoException($"No se encontró un pedidoTramoProveedorUMovilHorario con id: {pedidoTramoProveedorUMovilHorarioId}.");

            int pedidoTramoProveedorUMovilHorarioIdViejo = pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioEstadoId;

            pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioEstadoId = pedidoTramoProveedorUMovilHorarioEstadoId;
            await _pedidoTramoProveedorUMovilHorarioRepository.Actualizar(pedidoTramoProveedorUMovilHorario);

            //Si estoy pasando de preasignado a asignado o de asignado a asignado, asigno los integrantes y calculo el coseguro.
            if ((pedidoTramoProveedorUMovilHorarioIdViejo == (int)PedidoTramoProveedorUMovilHorarioEstadoEnum.PreDespacho 
                && pedidoTramoProveedorUMovilHorarioEstadoId == (int)PedidoTramoProveedorUMovilHorarioEstadoEnum.Despachado) 
                
                || (pedidoTramoProveedorUMovilHorarioIdViejo == (int)PedidoTramoProveedorUMovilHorarioEstadoEnum.Despachado
                && pedidoTramoProveedorUMovilHorarioEstadoId == (int)PedidoTramoProveedorUMovilHorarioEstadoEnum.Despachado))
            {
                await _pedidoTramoProveedorUMovilHorarioGdiaRealPersonalRepository.GenerarIntegrantesDelEquipo(pedidoTramoProveedorUMovilHorarioId, pedidoTramoProveedorUMovilHorario.GdiaRealEquipoId);
                await _orquestadorNotificaciones.NotificarAsignacion(pedidoTramoProveedorUMovilHorarioId);
                await _orquestadorCoseguro.EjecutarReglasDeCoseguroParaElPedido(pedidoTramoProveedorUMovilHorario.PedidoTramo.PedidoId, true);

                if (pedidoTramoProveedorUMovilHorario.PedidoTramo != null)
                {
                    var pedidoCoseguro = await _pedidoCoseguroRepository.ObtenerPorPedido(pedidoTramoProveedorUMovilHorario.PedidoTramo.PedidoId);
                    if (pedidoCoseguro != null)
                    {
                        await _pedidoCoseguroRepository.Actualizar(pedidoCoseguro, Convert.ToInt32(pedidoCoseguro.Coseguro), pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioId, pedidoCoseguro.PedidoTramoEfectorHorario?.PedidoTramoEfectorHorarioId, pedidoCoseguro.GdiaPersonalId);
                    }
                }
            }

            return pedidoTramoProveedorUMovilHorario;
        }

        public async Task<PedidoTramoProveedorUMovilHorario> ActualizarHorarios(int pedidoTramoProveedorUMovilHorarioId, TipoHorarioEnum tipoHorario, DateTime fechaHora)
        {
            await _pedidoTramoProveedorUMovilHorarioRepository.ValidarSiPuedeActualizarHorarios(pedidoTramoProveedorUMovilHorarioId, tipoHorario, fechaHora);

            PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorarioActualizado = await _pedidoTramoProveedorUMovilHorarioRepository.ActualizarHorarios(pedidoTramoProveedorUMovilHorarioId, tipoHorario, fechaHora);

            ValidarSiLosHorariosSeActualizaronCorrectamente(pedidoTramoProveedorUMovilHorarioActualizado, tipoHorario, fechaHora);

            return pedidoTramoProveedorUMovilHorarioActualizado;
        }

        public async Task<PedidoTramoProveedorUMovilHorario> ActualizarHorarios(int pedidoId, int gdiaRealEquipoId, TipoHorarioEnum tipoHorario, DateTime fechaHora)
        {
            PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario = await _pedidoTramoProveedorUMovilHorarioRepository.ObtenerPorPedidoYGdiaRealEquipo(pedidoId, gdiaRealEquipoId);
            if (pedidoTramoProveedorUMovilHorario != null)
            {
                pedidoTramoProveedorUMovilHorario = await ActualizarHorarios(pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioId, tipoHorario, fechaHora);
                return pedidoTramoProveedorUMovilHorario;
            }
            else
            {
                pedidoTramoProveedorUMovilHorario = _pedidoTramoProveedorUMovilHorarioRepository.ObtenerPorPedido(pedidoId).Result.LastOrDefault(x => x.OrigenArribo != null && x.Activo);
                if (pedidoTramoProveedorUMovilHorario != null)
                {
                    pedidoTramoProveedorUMovilHorario = await ActualizarHorarios(pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioId, tipoHorario, fechaHora);
                    return pedidoTramoProveedorUMovilHorario;
                }
            }
            return null;
        }

        #region Métodos privados
        private async Task<PedidoTramoProveedorUMovilHorario> Asignar(int pedidoTramoId, int gdiaRealEquipoId, int proveedorId, bool esApoyo)
        {
            try
            {
                //1) Valido si el medico supera la cantidad maxima de asignaciones que puede tener en simultaneo
                //await ValidarSiElMedicoSuperaLaCantidadMaximaDeAsignaciones(gdiaRealEquipoId);
                proveedorId = GenerarProveedorIdAdecuado(gdiaRealEquipoId, proveedorId);

                //2) Creo la asignacion
                PedidoTramoProveedorUMovilHorario asignacionCreada = await _pedidoTramoProveedorUMovilHorarioRepository.CrearAsignacion(pedidoTramoId, gdiaRealEquipoId, proveedorId, esApoyo);

                int pedidoId = asignacionCreada.PedidoTramo.PedidoId;
                int pedidoTramoProveedorUMovilHorarioId = asignacionCreada.PedidoTramoProveedorUMovilHorarioId;

                //3) Creo el pedidoEntidadLog correspondiente a la asignación
                await _pedidoEntidadLogRepository.Crear(pedidoId,
                  pedidoTramoProveedorUMovilHorarioId,
                  (proveedorId == (int)ProveedorEnum.Acudir ?
                      (int)EntidadLogTipoEstadoEnum.PedidoTramoProveedorUMovilHorarioAsignacionMovil :
                      (int)EntidadLogTipoEstadoEnum.PedidoTramoProveedorUMovilHorarioAsignacionProveedor),
                  $"OrquestadorAsignacion/Asignar({pedidoTramoId}, {gdiaRealEquipoId}, {proveedorId}, {esApoyo})");

                //4) Asigno los integrantes del equipo
                await _pedidoTramoProveedorUMovilHorarioGdiaRealPersonalRepository.GenerarIntegrantesDelEquipo(pedidoTramoProveedorUMovilHorarioId, gdiaRealEquipoId);

                return asignacionCreada;
            }
            catch (Exception)
            {
                throw;
            }
        }

        private int GenerarProveedorIdAdecuado(int gdiaRealEquipoId, int proveedorId)
        {
            if (gdiaRealEquipoId == (int)GdiaRealEquipoEnum.MasVidaGdiaRealEquipoId)
                proveedorId = (int)ProveedorEnum.MasVida;
            proveedorId = proveedorId == 0 ? (int)ProveedorEnum.Acudir : proveedorId;
            return proveedorId;
        }

        private async Task<PedidoTramoProveedorUMovilHorario> Preasignar(int pedidoTramoId, int gdiaRealEquipoId, int proveedorId, bool esApoyo)
        {
            proveedorId = GenerarProveedorIdAdecuado(gdiaRealEquipoId, proveedorId);

            //1) Creo la preasignación
            PedidoTramoProveedorUMovilHorario preasignacionCreada = await _pedidoTramoProveedorUMovilHorarioRepository.CrearPreasignacion(pedidoTramoId, gdiaRealEquipoId, proveedorId, esApoyo);

            //2) Asigno los integrantes del equipo
            await _pedidoTramoProveedorUMovilHorarioGdiaRealPersonalRepository.GenerarIntegrantesDelEquipo(preasignacionCreada.PedidoTramoProveedorUMovilHorarioId, gdiaRealEquipoId);

            return preasignacionCreada;
        }

        private async Task ValidarSiElMedicoSuperaLaCantidadMaximaDeAsignaciones(int gdiaRealEquipoId)
        {
            int cantidadMaximaDeAsignacionesPermitadas = await _cmnConfiguracionRepository.ObtenerCantidadMaximaDeAsignacionesPermitadas();
            int cantidadAsignacionesDelEquipo = await _pedidoTramoProveedorUMovilHorarioRepository.CantidadAsignacionesDelEquipo(gdiaRealEquipoId);

            if (cantidadMaximaDeAsignacionesPermitadas != 0 && cantidadAsignacionesDelEquipo > cantidadMaximaDeAsignacionesPermitadas)
                throw new ReglaDeNegocioException($"El equipo superó la cantidad máxima de asignaciones ({cantidadMaximaDeAsignacionesPermitadas}).");
        }

        public async Task<bool> ActualizarKmCero(int pedidoId)
        {
            var pedido = _pedidoRepository.Obtener(pedidoId).Result;
            var asignaciones = _pedidoTramoProveedorUMovilHorarioRepository.ObtenerPorPedido(pedidoId).Result;

            foreach (var asignacion in asignaciones)
            {
                PedidoTramoDetalle origen = asignacion.PedidoTramo.PedidoTramoDetalle.FirstOrDefault(x => x.Activo && x.OrigenDestino == (int)OrigenDestinoEnum.Origen);
                DireccionLocalidad puntoA; //hacer el if en una línea
                puntoA = (origen?.Direccion != null) ? origen?.Direccion.DireccionLocalidad : pedido.DesdeLocalidad; //Obtengo el punto A-B entrando al tramo

                PedidoTramoDetalle destino = asignacion.PedidoTramo.PedidoTramoDetalle.FirstOrDefault(x => x.Activo && x.OrigenDestino == (int)OrigenDestinoEnum.Destino);
                DireccionLocalidad puntoB;
                puntoB = (destino?.Direccion != null) ? destino?.Direccion.DireccionLocalidad : puntoB = pedido.HastaLocalidad; //Si no lo tengo, utilizo el pedido como último recurso

                #region Calculo Km0 - Desde Prestador
                if (asignacion.ProveedorId != (int)ProveedorEnum.Acudir &&
                    asignacion.Proveedor != null &&
                    asignacion.Proveedor.DireccionLocalidadId != null &&
                    asignacion.Proveedor.DireccionLocalidadId != (int)DireccionLocalidadEnum.CapitalFederal &&
                    asignacion.Proveedor.DireccionLocalidad != null &&
                    asignacion.Proveedor.DireccionLocalidad.Latitud != 0 &&
                    asignacion.Proveedor.DireccionLocalidad.Longitud != 0)
                {

                    DireccionLocalidad pivotePrestador = asignacion.Proveedor.DireccionLocalidad; //equivale al KmCero del Prestador

                    if (puntoA != null)
                    {
                        int? distanciaOrigenKmCero = _direccionLocalidadDistanciaRepository.CalcularKilometros(pivotePrestador, puntoA);

                        if (distanciaOrigenKmCero is null) //Si no existe el registro en la tabla: lo cálculo, inserto y asigno.
                        {
                            asignacion.OrigenKMCero = CalculoDistanciaEInsertoRegistroDireccionLocalidadDistancia(pivotePrestador, puntoA);
                        }
                        else
                        {
                            asignacion.OrigenKMCero = distanciaOrigenKmCero;
                        }
                    }

                    if (puntoB != null)
                    {
                        int? distanciaDestinoKmCero = _direccionLocalidadDistanciaRepository.CalcularKilometros(pivotePrestador, puntoB);

                        if (distanciaDestinoKmCero is null) //Si no existe el registro en la tabla: lo cálculo, inserto y asigno.
                        {
                            asignacion.DestinoKMCero = CalculoDistanciaEInsertoRegistroDireccionLocalidadDistancia(pivotePrestador, puntoB);
                        }
                        else
                        {
                            asignacion.DestinoKMCero = distanciaDestinoKmCero;
                        }
                    }

                    if (puntoB != null && puntoA != null)
                    {
                        int? distanciaOrigenDestinoKmCero = _direccionLocalidadDistanciaRepository.CalcularKilometros(puntoA, puntoB);

                        if (distanciaOrigenDestinoKmCero is null) //Si no existe el registro en la tabla: lo cálculo, inserto y asigno.
                        {
                            asignacion.OrigenDestinoKmCero = CalculoDistanciaEInsertoRegistroDireccionLocalidadDistancia(puntoA, puntoB);
                        }
                        else
                        {
                            asignacion.OrigenDestinoKmCero = distanciaOrigenDestinoKmCero;
                        }
                    }
                }
                #endregion

                #region Calculo Pivote (Provincia) a Origen

                var direccionLocalidadProvinciaID = origen.Direccion?.DireccionLocalidad?.DireccionPartido?.DireccionProvincia?.CapitalDireccionLocalidadId; //equivale al KmCero de la Provincia

                if (direccionLocalidadProvinciaID != null)
                {
                    DireccionLocalidad pivoteProvincia = await _direccionLocalidadRepository.Obtener((int)direccionLocalidadProvinciaID);

                    if (pivoteProvincia != null)
                    {
                        if (puntoA != null)
                        {
                            int? distanciaLocalidadProvinciaOrigen = _direccionLocalidadDistanciaRepository.CalcularKilometros(pivoteProvincia, puntoA);

                            if (distanciaLocalidadProvinciaOrigen is null) //Si no existe el registro en la tabla: lo cálculo, inserto y asigno.
                            {
                                asignacion.OrigenProvinciaKm = CalculoDistanciaEInsertoRegistroDireccionLocalidadDistancia(pivoteProvincia, puntoA);
                            }
                            else
                            {
                                asignacion.OrigenProvinciaKm = distanciaLocalidadProvinciaOrigen;
                            }
                        }

                        if (puntoB != null)
                        {
                            int? distanciaLocalidadProvinciaDestino = _direccionLocalidadDistanciaRepository.CalcularKilometros(pivoteProvincia, puntoB);

                            if (distanciaLocalidadProvinciaDestino is null) //Si no existe el registro en la tabla: lo cálculo, inserto y asigno.
                            {
                                asignacion.DestinoProvinciaKm = CalculoDistanciaEInsertoRegistroDireccionLocalidadDistancia(pivoteProvincia, puntoB);
                            }
                            else
                            {
                                asignacion.DestinoProvinciaKm = distanciaLocalidadProvinciaDestino;
                            }
                        }
                    }
                }
                #endregion
            }
            await _pedidoTramoProveedorUMovilHorarioRepository.Actualizar(asignaciones);
            return true;
        }

        private int CalculoDistanciaEInsertoRegistroDireccionLocalidadDistancia(DireccionLocalidad pivote, DireccionLocalidad puntoAB)
        {
            int distanciaOrigenDestinoKmCero = 0;

            if (puntoAB.Latitud != 0 && puntoAB.Longitud != 0)
            {
                distanciaOrigenDestinoKmCero = CalcularKilometros(pivote.Latitud.ToString(), pivote.Longitud.ToString(), puntoAB.Latitud.ToString(), puntoAB.Longitud.ToString());
                _direccionLocalidadDistanciaRepository.Insertar(pivote, puntoAB, distanciaOrigenDestinoKmCero);
            }

            return distanciaOrigenDestinoKmCero;
        }

        private int CalcularKilometros(string latori, string lonori, string latdest, string londest)
        {
            string url = string.Format("https://maps.googleapis.com/maps/api/distancematrix/xml?origins={0},{1}&destinations={2},{3}&mode=driving&units=metric&sensor=false&key=AIzaSyAFMBxdqM9ZZB_rCTicDVhqY-vrafzVr_Y", latori.Replace(',', '.'), lonori.Replace(',', '.'), latdest.Replace(',', '.'), londest.Replace(',', '.'));

            XElement xml = XElement.Load(url);

            if (xml.Element("status").Value == "OK")
            {
                int CantidadKilometros = Int32.Parse(xml.Element("row").Element("element").Element("distance").Element("value").Value);
                CantidadKilometros /= CantidadKilometros; //Divido el valor de longitud resultante entre 1000 para calcular la cantidad de Kilometros
                return CantidadKilometros;
            }
            else
            {
                return 0;
            }
        }

        private void ValidarSiLosHorariosSeActualizaronCorrectamente(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario, TipoHorarioEnum tipoHorario, DateTime fechaHora)
        {
            if (tipoHorario == TipoHorarioEnum.OrigenArribo)
            {
                if (pedidoTramoProveedorUMovilHorario.OrigenArribo is null)
                    throw new ReglaDeNegocioException("No se pudo actualizar el horario.");

                if(!DateTimeComparerUtility.AreEqual(fechaHora, pedidoTramoProveedorUMovilHorario.OrigenArribo.Value))
                    throw new ReglaDeNegocioException("No se pudo actualizar el horario.");
            }
            else if (tipoHorario == TipoHorarioEnum.OrigenPartida)
            {
                if (pedidoTramoProveedorUMovilHorario.OrigenPartida is null)
                    throw new ReglaDeNegocioException("No se pudo actualizar el horario.");

                if (!DateTimeComparerUtility.AreEqual(fechaHora, pedidoTramoProveedorUMovilHorario.OrigenPartida.Value))
                    throw new ReglaDeNegocioException("No se pudo actualizar el horario.");
            }
        }

        private async Task ValidarSiLaGdiaRealEquipoYaSeEncuentraAsignadoAlPedidoTramo(int pedidoTramoId, int gdiaRealEquipoId)
        {
            PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorarioExistente =
                await _pedidoTramoProveedorUMovilHorarioRepository.ObtenerPorPedidoTramoYGdiaRealEquipo(pedidoTramoId, gdiaRealEquipoId);

            if (pedidoTramoProveedorUMovilHorarioExistente != null)
                throw new ReglaDeNegocioException("El equipo ya se encuentra asignado al mismo pedido.");
        }

        private async Task<bool> ValidarSiLaGdiaRealEquipoYaSeEncuentraAsignadoAlPedidoTramoVCM(int pedidoTramoId, int gdiaRealEquipoId)
        {
            PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorarioExistente =
                await _pedidoTramoProveedorUMovilHorarioRepository.ObtenerPorPedidoTramoYGdiaRealEquipo(pedidoTramoId, gdiaRealEquipoId);

            if (pedidoTramoProveedorUMovilHorarioExistente != null) return true;
            else return false;
        }

        #endregion
    }
}
