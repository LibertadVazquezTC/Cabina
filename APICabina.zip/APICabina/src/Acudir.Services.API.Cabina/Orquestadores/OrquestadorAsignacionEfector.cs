﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CabinaOperativa.Exceptions;
using CabinaOperativa.Modelo;
using CabinaOperativa.Orquestadores.Interfaces;
using CabinaOperativa.Repositories;

namespace CabinaOperativa.Orquestadores
{
    public class OrquestadorAsignacionEfector : IOrquestadorAsignacionEfector
    {
        private readonly IOrquestadorCoseguro _orquestadorCoseguro;
        private readonly IPedidoTramoRepository _pedidoTramoRepository;
        private readonly IPedidoTramoProveedorUMovilHorarioRepository _pedidoTramoProveedorUMovilHorarioRepository;
        private readonly IPedidoTramoEfectorHorarioRepository _pedidoTramoEfectorHorarioRepository;
        private readonly IPedidoCoseguroRepository _pedidoCoseguroRepository;
        private readonly IPedidoAfiliadoRepository _pedidoAfiliadoRepository;
        private readonly IEfectorRepository _efectorRepository;

        public OrquestadorAsignacionEfector(IOrquestadorCoseguro orquestadorCoseguro,
            IPedidoTramoRepository pedidoTramoRepository,
            IPedidoTramoProveedorUMovilHorarioRepository pedidoTramoProveedorUMovilHorarioRepository,
            IPedidoTramoEfectorHorarioRepository pedidoTramoEfectorHorarioRepository,
            IPedidoCoseguroRepository pedidoCoseguroRepository,
            IPedidoAfiliadoRepository pedidoAfiliadoRepository,
            IEfectorRepository efectorRepository)
        {
            _orquestadorCoseguro = orquestadorCoseguro;
            _pedidoTramoRepository = pedidoTramoRepository;
            _pedidoTramoProveedorUMovilHorarioRepository = pedidoTramoProveedorUMovilHorarioRepository;
            _pedidoTramoEfectorHorarioRepository = pedidoTramoEfectorHorarioRepository;
            _pedidoCoseguroRepository = pedidoCoseguroRepository;
            _pedidoAfiliadoRepository = pedidoAfiliadoRepository;
            _efectorRepository = efectorRepository;
        }
      
        public async Task<PedidoTramoEfectorHorario> AsignarEfector(int pedidoId, int efectorId)
        {
            if (pedidoId == 0)
                throw new DatoErroneoException("El pedidoTramoId no puede ser 0.");

            IEnumerable<PedidoTramo> pedidoTramos = await _pedidoTramoRepository.ListarPorPedido(pedidoId);
            if (pedidoTramos is null || pedidoTramos.Count() == 0)
                throw new DatoErroneoException($"No se encontraron tramos para el pedido con id: {pedidoId}.");

            int pedidoTramoId = pedidoTramos.FirstOrDefault().PedidoTramoId;

            int cantidadDeAsignacionesPrincipales = await _pedidoTramoProveedorUMovilHorarioRepository.CantidadDeAsignacionesPrincipales(pedidoTramoId);
            int cantidadDeAsignacionesPrincipalesEfector = await _pedidoTramoEfectorHorarioRepository.CantidadDeAsignacionesPrincipales(pedidoTramoId);

            bool esApoyo = cantidadDeAsignacionesPrincipales > 0 || cantidadDeAsignacionesPrincipalesEfector > 0;

            return await AsignarEfector(pedidoTramoId, efectorId, esApoyo);
        }

        public async Task<PedidoTramoEfectorHorario> ActualizarHorario(int pedidoTramoEfectorHorarioId, string tipoHorario, DateTime horario)
        {
            await _pedidoTramoEfectorHorarioRepository.ValidarSiPuedeActualizarHorarios(pedidoTramoEfectorHorarioId, tipoHorario, horario);

            PedidoTramoEfectorHorario pedidoTramoEfectorHorarioActualizado = await _pedidoTramoEfectorHorarioRepository.ActualizarHorario(pedidoTramoEfectorHorarioId, tipoHorario, horario);

            ValidarSiLosHorariosSeActualizaronCorrectamente(pedidoTramoEfectorHorarioActualizado, tipoHorario, horario);

            return pedidoTramoEfectorHorarioActualizado;
        }

        #region Métodos privados     
        private async Task<PedidoTramoEfectorHorario> AsignarEfector(int pedidoTramoId, int efectorId, bool esApoyo)
        {
            try
            {
                PedidoTramoEfectorHorario asignacionCreada = await _pedidoTramoEfectorHorarioRepository.CrearAsignacion(pedidoTramoId, efectorId, esApoyo);
                asignacionCreada.Efector = await _efectorRepository.Obtener(efectorId);

                int pedidoId = asignacionCreada.PedidoTramo.PedidoId;
                await _orquestadorCoseguro.EjecutarReglasDeCoseguroParaElPedido(pedidoId, false);

                return asignacionCreada;
            }
            catch (Exception)
            {
                throw;
            }
        }

        private void ValidarSiLosHorariosSeActualizaronCorrectamente(PedidoTramoEfectorHorario pedidoTramoEfectorHorario, string tipoHorario, DateTime horario)
        {
            if (tipoHorario == "OrigenArribo")
            {
                if (pedidoTramoEfectorHorario.OrigenArribo is null)
                    throw new ReglaDeNegocioException("No se pudo actualizar el horario.");

                DateTime dt1 = horario.AddMilliseconds(-horario.Millisecond);
                DateTime dt2 = pedidoTramoEfectorHorario.OrigenArribo.Value.AddMilliseconds(-pedidoTramoEfectorHorario.OrigenArribo.Value.Millisecond);

                if (dt1 != dt2)
                    throw new ReglaDeNegocioException("No se pudo actualizar el horario.");
            }
            else if (tipoHorario == "OrigenPartida")
            {
                if (pedidoTramoEfectorHorario.OrigenPartida is null)
                    throw new ReglaDeNegocioException("No se pudo actualizar el horario.");

                DateTime dt1 = horario.AddMilliseconds(-horario.Millisecond);
                DateTime dt2 = pedidoTramoEfectorHorario.OrigenPartida.Value.AddMilliseconds(-pedidoTramoEfectorHorario.OrigenPartida.Value.Millisecond);

                if (dt1 != dt2)
                    throw new ReglaDeNegocioException("No se pudo actualizar el horario.");
            }
        }
        #endregion
    }
}
