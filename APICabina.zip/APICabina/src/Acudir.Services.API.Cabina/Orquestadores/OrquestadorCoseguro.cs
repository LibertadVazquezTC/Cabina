﻿using System.Collections.Generic;
using System.Threading.Tasks;
using CabinaOperativa.Enums;
using CabinaOperativa.Exceptions;
using CabinaOperativa.Modelo;
using CabinaOperativa.Orquestadores.Interfaces;
using CabinaOperativa.Repositories;

namespace CabinaOperativa.Orquestadores
{
    public class OrquestadorCoseguro : IOrquestadorCoseguro
    {
        private readonly IOrquestadorNotificaciones _orquestadorNotificaciones;

        private readonly IPedidoAfiliadoRepository _pedidoAfiliadoRepository;
        private readonly IPedidoDetalleRepository _pedidoDetalleRepository;
        private readonly IPedidoComentarioRepository _pedidoComentarioRepository;
        private readonly IPedidoTramoProveedorUMovilHorarioRepository _pedidoTramoProveedorUMovilHorarioRepository;
        private readonly IPedidoTramoProveedorUMovilHorarioGdiaRealPersonalRepository _pedidoTramoProveedorUMovilHorarioGdiaRealPersonalRepository;
        private readonly IPedidoTramoEfectorHorarioRepository _pedidoTramoEfectorHorarioRepository;
        private readonly IPedidoCoseguroRepository _pedidoCoseguroRepository;

        public OrquestadorCoseguro(IOrquestadorNotificaciones orquestadorNotificaciones,
            IPedidoAfiliadoRepository pedidoAfiliadoRepository,
            IPedidoDetalleRepository pedidoDetalleRepository,
            IPedidoComentarioRepository pedidoComentarioRepository,
            IPedidoTramoProveedorUMovilHorarioRepository pedidoTramoProveedorUMovilHorarioRepository,
            IPedidoTramoProveedorUMovilHorarioGdiaRealPersonalRepository pedidoTramoProveedorUMovilHorarioGdiaRealPersonalRepository,
            IPedidoTramoEfectorHorarioRepository pedidoTramoEfectorHorarioRepository,
            IPedidoCoseguroRepository pedidoCoseguroRepository)
        {
            _orquestadorNotificaciones = orquestadorNotificaciones;
            _pedidoAfiliadoRepository = pedidoAfiliadoRepository;
            _pedidoDetalleRepository = pedidoDetalleRepository;
            _pedidoComentarioRepository = pedidoComentarioRepository;
            _pedidoTramoProveedorUMovilHorarioRepository = pedidoTramoProveedorUMovilHorarioRepository;
            _pedidoTramoProveedorUMovilHorarioGdiaRealPersonalRepository = pedidoTramoProveedorUMovilHorarioGdiaRealPersonalRepository;
            _pedidoTramoEfectorHorarioRepository = pedidoTramoEfectorHorarioRepository;
            _pedidoCoseguroRepository = pedidoCoseguroRepository;
        }

        public async Task ActualizarCoseguroForzadamente(int pedidoId, float valorCoseguro, string motivoActualizacion)
        {
            if (pedidoId == 0)
                throw new DatoErroneoException($"El parámetro pedidoId no puede ser 0.");

            PedidoDetalle pedidoDetalle = await _pedidoDetalleRepository.ObtenerPorPedido(pedidoId);
            if (pedidoDetalle is null)
                throw new DatoErroneoException($"No se encontró pedidoDetalle con pedidoId: {pedidoId}.");

            if (pedidoDetalle.Coseguro != valorCoseguro)
            {
                pedidoDetalle.Coseguro = valorCoseguro;
                await _pedidoDetalleRepository.Actualizar(pedidoDetalle);
            }

            await _pedidoComentarioRepository.Crear(pedidoId, motivoActualizacion, (int)CmnComentarioTipoEnum.ActualizacionDeCoseguro);

            PedidoCoseguro pedidoCoseguro = await _pedidoCoseguroRepository.ObtenerPorPedidoIncluyendoInactivos(pedidoId);
            if (pedidoCoseguro != null)
                await _pedidoCoseguroRepository.Actualizar(pedidoCoseguro, 0, pedidoCoseguro.PedidoTramoProveedorUMovilHorarioId, pedidoCoseguro.PedidoTramoEfectorHorarioId, pedidoCoseguro.GdiaPersonalId);

            await EjecutarReglasDeCoseguroParaElPedido(pedidoId, false);
        }

        public async Task EjecutarReglasDeCoseguroParaElPedido(int pedidoId, bool esAsignacionNueva)
        {
            PedidoCoseguro pedidoCoseguro = await _pedidoCoseguroRepository.ObtenerPorPedidoIncluyendoInactivos(pedidoId);

            if (pedidoCoseguro != null)
                await _pedidoCoseguroRepository.Inactivar(pedidoCoseguro);

            PedidoDetalle pedidoDetalle = await _pedidoDetalleRepository.ObtenerPorPedido(pedidoId);
            if (pedidoDetalle != null)
            {
                pedidoDetalle.Coseguro = 0;
                await _pedidoDetalleRepository.Actualizar(pedidoDetalle);
            }

            IEnumerable<PedidoTramoProveedorUMovilHorario> asignacionesDelPedido = await _pedidoTramoProveedorUMovilHorarioRepository.ObtenerPorPedido(pedidoId);
            foreach (PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario in asignacionesDelPedido)
                await GestionarLogicaCoseguroParaUnaAsignacion(pedidoTramoProveedorUMovilHorario, esAsignacionNueva);

            IEnumerable<PedidoTramoEfectorHorario> asignacionesEfectoresDelPedido = await _pedidoTramoEfectorHorarioRepository.ObtenerPorPedido(pedidoId);
            foreach (PedidoTramoEfectorHorario pedidoTramoEfectorHorario in asignacionesEfectoresDelPedido)
                await GestionarLogicaCoseguroParaUnaAsignacionEfector(pedidoTramoEfectorHorario);
        }

        private async Task GestionarLogicaCoseguroParaUnaAsignacion(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario, bool esAsignacionNueva)
        {
            if (pedidoTramoProveedorUMovilHorario.GdiaRealEquipoId == (int)GdiaRealEquipoEnum.MasVidaGdiaRealEquipoId)
                return;

            if (pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioEstadoId == (int)PedidoTramoProveedorUMovilHorarioEstadoEnum.PreDespacho)
                return;

            int pedidoId = pedidoTramoProveedorUMovilHorario.PedidoTramo.PedidoId;
            int pedidoTramoProveedorUMovilHorarioId = pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioId;

            PedidoTramoProveedorUMovilHorarioGdiaRealPersonal pedidoTramoProveedorUMovilHorarioGdiaRealPersonal = await _pedidoTramoProveedorUMovilHorarioGdiaRealPersonalRepository.ObtenerResponsableCoseguro(pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioId);
            int? gdiaPersonalId = pedidoTramoProveedorUMovilHorarioGdiaRealPersonal?.GdiaRealPersonalDetalle?.GdiaRealPersonal?.GdiaPersonalId;

            PedidoCoseguro pedidoCoseguro = await _pedidoCoseguroRepository.ObtenerPorPedidoIncluyendoInactivos(pedidoId);

            int coseguro = await CalcularCoseguro(pedidoId, pedidoTramoProveedorUMovilHorarioId);
            if (coseguro > 0)
            {
                if (pedidoCoseguro != null)
                {
                    bool estabaDesativado = !pedidoCoseguro.Activo;
                    double valorCoseguroAnterior = double.Parse(pedidoCoseguro.Coseguro.ToString());
                    int? pedidoTramoProveedorUMovilHorarioIdAnterior = pedidoCoseguro.PedidoTramoProveedorUMovilHorarioId;

                    await _pedidoCoseguroRepository.Actualizar(pedidoCoseguro, coseguro, pedidoTramoProveedorUMovilHorarioId, null, gdiaPersonalId);

                    await NotificarSoloSiCumpleLasReglas(pedidoCoseguro,
                        estabaDesativado, valorCoseguroAnterior, pedidoTramoProveedorUMovilHorarioIdAnterior);
                }
                else
                {
                    pedidoCoseguro = await _pedidoCoseguroRepository.Crear(pedidoId, coseguro, pedidoTramoProveedorUMovilHorarioId, null, gdiaPersonalId);
                    await _orquestadorNotificaciones.NotificarActualizacionCoseguro(pedidoTramoProveedorUMovilHorarioId, coseguro);
                }

                PedidoDetalle pedidoDetalle = await _pedidoDetalleRepository.ObtenerPorPedido(pedidoId);
                if (pedidoDetalle != null)
                {
                    pedidoDetalle.Coseguro = coseguro;
                    await _pedidoDetalleRepository.Actualizar(pedidoDetalle);
                }
            }
            else
            {
                if (pedidoCoseguro != null && pedidoCoseguro.PedidoTramoProveedorUMovilHorarioId == pedidoTramoProveedorUMovilHorarioId)
                {
                    await _pedidoCoseguroRepository.Inactivar(pedidoCoseguro);
                    await _orquestadorNotificaciones.NotificarActualizacionCoseguro(pedidoTramoProveedorUMovilHorarioId, coseguro);
                }
                else if (esAsignacionNueva)
                {
                    await _orquestadorNotificaciones.NotificarActualizacionCoseguro(pedidoTramoProveedorUMovilHorarioId, coseguro);
                }
            }
        }

        private async Task GestionarLogicaCoseguroParaUnaAsignacionEfector(PedidoTramoEfectorHorario pedidoTramoEfectorHorario)
        {
            int pedidoId = pedidoTramoEfectorHorario.PedidoTramo.PedidoId;
            int pedidoTramoEfectorHorarioId = pedidoTramoEfectorHorario.PedidoTramoEfectorHorarioId;

            PedidoCoseguro pedidoCoseguro = await _pedidoCoseguroRepository.ObtenerPorPedidoIncluyendoInactivos(pedidoId);

            PedidoAfiliado pedidoAfiliado = await _pedidoAfiliadoRepository.ObtenerPorPedido(pedidoId);
            if (pedidoAfiliado is null) return;
            if (!pedidoAfiliado.ContratoPlanId.HasValue) return;
            int tipoPrestacionId = pedidoAfiliado.Pedido.TipoPrestacionId;
            int contratoPlanId = pedidoAfiliado.ContratoPlanId.Value;
            bool pmi = pedidoAfiliado.PMI;
            bool discapacidad = pedidoAfiliado.Discapacidad;
            bool internacionDomiciliaria = pedidoAfiliado.InternacionDomiciliaria;

            int coseguro = await _pedidoCoseguroRepository.ObtenerCoseguroSugerido(tipoPrestacionId, contratoPlanId, pedidoId, pmi, discapacidad, internacionDomiciliaria);
            if (coseguro > 0 && (pedidoTramoEfectorHorario.Apoyo || !pedidoTramoEfectorHorario.Activo)) coseguro = 0;

            if (coseguro > 0)
            {
                if (pedidoCoseguro != null)
                    await _pedidoCoseguroRepository.Actualizar(pedidoCoseguro, coseguro, null, pedidoTramoEfectorHorarioId, null);
                else
                    await _pedidoCoseguroRepository.Crear(pedidoId, coseguro, null, pedidoTramoEfectorHorarioId, null);
            }
            else
            {
                if (pedidoCoseguro != null && pedidoCoseguro.PedidoTramoEfectorHorarioId == pedidoTramoEfectorHorarioId)
                    await _pedidoCoseguroRepository.Inactivar(pedidoCoseguro);
            }
        }

        private async Task NotificarSoloSiCumpleLasReglas(PedidoCoseguro pedidoCoseguroNuevo,
            bool estabaDesactivado,
            double valorCoseguroAnterior,
            int? pedidoTramoProveedorUMovilHorarioIdAnterior)
        {
            double valorCoseguroNuevo = pedidoCoseguroNuevo.Coseguro;
            int? pedidoTramoProveedorUMovilHorarioIdNuevo = pedidoCoseguroNuevo.PedidoTramoProveedorUMovilHorarioId;

            //Solo notifico si:
            //1) cambió el PedidoTramoProveedorUMovilHorarioId...sino le voy a notificar varias veces al mismo equipo.                    
            if (pedidoTramoProveedorUMovilHorarioIdAnterior != pedidoTramoProveedorUMovilHorarioIdNuevo)
            {
                await _orquestadorNotificaciones.NotificarActualizacionCoseguro(pedidoTramoProveedorUMovilHorarioIdNuevo.Value, (float)valorCoseguroNuevo);
                return;
            }

            bool estaActivo = pedidoCoseguroNuevo.Activo;

            //2) cambió de inactivo a activo
            if (estabaDesactivado && estaActivo)
            {
                await _orquestadorNotificaciones.NotificarActualizacionCoseguro(pedidoTramoProveedorUMovilHorarioIdNuevo.Value, (float)valorCoseguroNuevo);
                return;
            }

            //3) cambió el valor del coseguro
            if (valorCoseguroAnterior != valorCoseguroNuevo)
            {
                await _orquestadorNotificaciones.NotificarActualizacionCoseguro(pedidoTramoProveedorUMovilHorarioIdNuevo.Value, (float)valorCoseguroNuevo);
                return;
            }
        }

        private async Task<int> CalcularCoseguro(int pedidoId, int pedidoTramoProveedorUMovilHorarioId)
        {
            bool esPmi = false;
            bool esDiscapacitado = false;
            bool esInternacionDomiciliaria = false;
            PedidoAfiliado pedidoAfiliado = await _pedidoAfiliadoRepository.ObtenerPorPedido(pedidoId);
            if (pedidoAfiliado != null)
            {
                esPmi = pedidoAfiliado.PMI;
                esDiscapacitado = pedidoAfiliado.Discapacidad;
                esInternacionDomiciliaria = pedidoAfiliado.InternacionDomiciliaria;

            }
            return await _pedidoCoseguroRepository.ObtenerCoseguroACobrar(pedidoTramoProveedorUMovilHorarioId, esPmi, esDiscapacitado, esInternacionDomiciliaria);
        }
    }
}