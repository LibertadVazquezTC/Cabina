﻿using Acudir.Services.API.Cabina.Constants;
using Acudir.Services.API.Cabina.ServiciosExternos.Interfaces;
using CabinaOperativa.Enums;
using CabinaOperativa.Exceptions;
using CabinaOperativa.Modelo;
using CabinaOperativa.Orquestadores.Interfaces;
using CabinaOperativa.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CabinaOperativa.Orquestadores
{
    public class OrquestadorDesasignacion : IOrquestadorDesasignacion
    {
        private readonly IOrquestadorParaValidarSiFinalizoElPedido _orquestadorParaValidarSiFinalizoElPedido;
        private readonly IOrquestadorNotificaciones _orquestadorNotificaciones;
        private readonly IOrquestadorCoseguro _orquestadorCoseguro;

        private readonly IPedidoTramoProveedorUMovilHorarioRepository _pedidoTramoProveedorUMovilHorarioRepository;
        private readonly IPedidoTramoEfectorHorarioRepository _pedidoTramoEfectorHorarioRepository;
        private readonly IPedidoEntidadLogRepository _pedidoEntidadLogRepository;
        private readonly IPedidoAfiliadoRepository _pedidoAfiliadoRepository;
        private readonly IEnvioNotificacionMobileService _envioNotificacionMobileService;
        private readonly ISacarSalaPacienteHub _sacarSalaPacienteHub;
        public OrquestadorDesasignacion(IOrquestadorParaValidarSiFinalizoElPedido orquestadorParaValidarSiFinalizoElPedido,
            IOrquestadorNotificaciones orquestadorNotificaciones,
            IOrquestadorCoseguro orquestadorCoseguro,
            IPedidoTramoProveedorUMovilHorarioRepository pedidoTramoProveedorUMovilHorarioRepository,
            IPedidoTramoEfectorHorarioRepository pedidoTramoEfectorHorarioRepository,
            IPedidoEntidadLogRepository pedidoEntidadLogRepository,
            IPedidoAfiliadoRepository pedidoAfiliadoRepository,
            IEnvioNotificacionMobileService envioNotificacionMobileService,
            ISacarSalaPacienteHub sacarSalaPacienteHub)
        {
            _orquestadorParaValidarSiFinalizoElPedido = orquestadorParaValidarSiFinalizoElPedido;
            _orquestadorNotificaciones = orquestadorNotificaciones;
            _orquestadorCoseguro = orquestadorCoseguro;
            _pedidoTramoProveedorUMovilHorarioRepository = pedidoTramoProveedorUMovilHorarioRepository;
            _pedidoTramoEfectorHorarioRepository = pedidoTramoEfectorHorarioRepository;
            _pedidoEntidadLogRepository = pedidoEntidadLogRepository;
            _pedidoAfiliadoRepository = pedidoAfiliadoRepository;
            _envioNotificacionMobileService = envioNotificacionMobileService;
            _sacarSalaPacienteHub = sacarSalaPacienteHub;
        }

        public async Task DesasignarPorPedido(int pedidoId)
        {
            try
            {
                if (pedidoId == 0)
                    throw new DatoErroneoException($"El parámetro pedidoId no puede ser 0.");

                IEnumerable<PedidoTramoProveedorUMovilHorario> pedidoTramoProveedorUMovilHorarioList =
                    await _pedidoTramoProveedorUMovilHorarioRepository.ObtenerPorPedido(pedidoId);

                //Saco de la lista el ptpumh recien creado de la sala
                var ptpumhActivo = pedidoTramoProveedorUMovilHorarioList.ToList().LastOrDefault();
                pedidoTramoProveedorUMovilHorarioList = pedidoTramoProveedorUMovilHorarioList.Where(x => x.PedidoTramoProveedorUMovilHorarioId != ptpumhActivo.PedidoTramoProveedorUMovilHorarioId).ToList();

                //Desasigno tramos activos
                if (pedidoTramoProveedorUMovilHorarioList != null && pedidoTramoProveedorUMovilHorarioList.Any())
                {
                    for (int i = 0; i < pedidoTramoProveedorUMovilHorarioList.ToList().Count(); i++)
                    {
                        await DesasignarArchivar(pedidoTramoProveedorUMovilHorarioList.ToList()[i]);
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<PedidoTramoProveedorUMovilHorario> Desasignar(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario)
        {
            try
            {
                pedidoTramoProveedorUMovilHorario = await _pedidoTramoProveedorUMovilHorarioRepository.Desasignar(pedidoTramoProveedorUMovilHorario);

                int pedidoId = pedidoTramoProveedorUMovilHorario.PedidoTramo.PedidoId;

                await _pedidoEntidadLogRepository.Crear(pedidoId,
                    pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioId,
                    (int)EntidadLogTipoEstadoEnum.UMovilDesasignado,
                    $"OrquestadorAsignacion/DesasignarPropio({pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioId})");

              

                //Si era la asignación principal necesito buscar una nueva (si es que hay).
                if (!pedidoTramoProveedorUMovilHorario.Apoyo)
                    await BuscarNuevaAsignacionPrincipalDelTramo(pedidoTramoProveedorUMovilHorario.PedidoTramoId);

                await _orquestadorParaValidarSiFinalizoElPedido.ValidarSiDebeFinalizar(pedidoId);

                return pedidoTramoProveedorUMovilHorario;
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        public async Task<PedidoTramoProveedorUMovilHorario> DesasignarWorker(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario, bool esAmarillo)
        {
            try
            {
                pedidoTramoProveedorUMovilHorario = await _pedidoTramoProveedorUMovilHorarioRepository.DesasignarPedidoWorker(pedidoTramoProveedorUMovilHorario, esAmarillo);

                int pedidoId = pedidoTramoProveedorUMovilHorario.PedidoTramo.PedidoId;

                await _pedidoEntidadLogRepository.Crear(pedidoId,
                    pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioId,
                    (int)EntidadLogTipoEstadoEnum.UMovilDesasignado,
                    $"OrquestadorAsignacion/DesasignarPropio({pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioId})");



                //Si era la asignación principal necesito buscar una nueva (si es que hay).
                if (!pedidoTramoProveedorUMovilHorario.Apoyo)
                    await BuscarNuevaAsignacionPrincipalDelTramo(pedidoTramoProveedorUMovilHorario.PedidoTramoId);

                await _orquestadorParaValidarSiFinalizoElPedido.ValidarSiDebeFinalizar(pedidoId);

                
                await _sacarSalaPacienteHub.SacarPacienteSalaHub(pedidoId);

                await _envioNotificacionMobileService.BuscarAfiliadoMobileYEnviarNotificacion(pedidoId, ConstantesTipoNotificacionMobile.DESASIGNADO);
                
                return pedidoTramoProveedorUMovilHorario;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<PedidoTramoProveedorUMovilHorario> DesasignarArchivar(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario)
        {
            try
            {
                pedidoTramoProveedorUMovilHorario = await _pedidoTramoProveedorUMovilHorarioRepository.DesasignarArchivar(pedidoTramoProveedorUMovilHorario);

                int pedidoId = pedidoTramoProveedorUMovilHorario.PedidoTramo.PedidoId;

                await _pedidoEntidadLogRepository.Crear(pedidoId,
                    pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioId,
                    (int)EntidadLogTipoEstadoEnum.UMovilDesasignado,
                    $"OrquestadorAsignacion/DesasignarPropio({pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioId})");



                //Si era la asignación principal necesito buscar una nueva (si es que hay).
                if (!pedidoTramoProveedorUMovilHorario.Apoyo)
                    await BuscarNuevaAsignacionPrincipalDelTramo(pedidoTramoProveedorUMovilHorario.PedidoTramoId);

                await _orquestadorParaValidarSiFinalizoElPedido.ValidarSiDebeFinalizar(pedidoId);

                return pedidoTramoProveedorUMovilHorario;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<PedidoTramoProveedorUMovilHorario> Desasignar(int pedidoTramoProveedorUMovilHorarioId)
        {
            try
            {
                if (pedidoTramoProveedorUMovilHorarioId == 0)
                    throw new DatoErroneoException($"El parámetro pedidoTramoProveedorUMovilHorarioId no puede ser 0.");

                PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario = await _pedidoTramoProveedorUMovilHorarioRepository.Obtener(pedidoTramoProveedorUMovilHorarioId);
                if (pedidoTramoProveedorUMovilHorario is null)
                    throw new DatoErroneoException($"No se encontró pedidoTramoProveedorUMovilHorario con id: {pedidoTramoProveedorUMovilHorarioId}");

                pedidoTramoProveedorUMovilHorario = await Desasignar(pedidoTramoProveedorUMovilHorario);
                return pedidoTramoProveedorUMovilHorario;
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }
        
        public async Task<PedidoTramoProveedorUMovilHorario> DesasignarWorker(int pedidoTramoProveedorUMovilHorarioId, bool esAmarillo)
        {
            try
            {
                if (pedidoTramoProveedorUMovilHorarioId == 0)
                    throw new DatoErroneoException($"El parámetro pedidoTramoProveedorUMovilHorarioId no puede ser 0.");

                PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario = await _pedidoTramoProveedorUMovilHorarioRepository.Obtener(pedidoTramoProveedorUMovilHorarioId);
                if (pedidoTramoProveedorUMovilHorario is null)
                    throw new DatoErroneoException($"No se encontró pedidoTramoProveedorUMovilHorario con id: {pedidoTramoProveedorUMovilHorarioId}");

                pedidoTramoProveedorUMovilHorario = await DesasignarWorker(pedidoTramoProveedorUMovilHorario, esAmarillo);
                return pedidoTramoProveedorUMovilHorario;
            }
            catch (Exception)
            {
                throw;
            }
        }

        private async Task BuscarNuevaAsignacionPrincipalDelTramo(int pedidoTramoId)
        {
            PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorarioApoyo = await _pedidoTramoProveedorUMovilHorarioRepository.ObtenerPrimeraAsignacionApoyoPorTramo(pedidoTramoId);
            if (pedidoTramoProveedorUMovilHorarioApoyo != null)
            {
                await _pedidoTramoProveedorUMovilHorarioRepository.ConvertirEnAsignacionPrincipal(pedidoTramoProveedorUMovilHorarioApoyo);
                return;
            }

            PedidoTramoEfectorHorario pedidoTramoEfectorHorarioApoyo = await _pedidoTramoEfectorHorarioRepository.ObtenerPrimeraAsignacionApoyoPorTramo(pedidoTramoId);
            if (pedidoTramoEfectorHorarioApoyo != null)
            {
                await _pedidoTramoEfectorHorarioRepository.ConvertirEnAsignacionPrincipal(pedidoTramoEfectorHorarioApoyo);
                return;
            }

        }
    }
}
