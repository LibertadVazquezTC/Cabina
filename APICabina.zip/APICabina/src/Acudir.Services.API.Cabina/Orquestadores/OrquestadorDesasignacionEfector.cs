﻿using System;
using System.Threading.Tasks;
using CabinaOperativa.Exceptions;
using CabinaOperativa.Modelo;
using CabinaOperativa.Orquestadores.Interfaces;
using CabinaOperativa.Repositories;

namespace CabinaOperativa.Orquestadores
{
    public class OrquestadorDesasignacionEfector : IOrquestadorDesasignacionEfector
    {
        private readonly IOrquestadorParaValidarSiFinalizoElPedido _orquestadorParaValidarSiFinalizoElPedido;
        private readonly IOrquestadorCoseguro _orquestadorCoseguro;
        private readonly IPedidoTramoProveedorUMovilHorarioRepository _pedidoTramoProveedorUMovilHorarioRepository;
        private readonly IPedidoTramoEfectorHorarioRepository _pedidoTramoEfectorHorarioRepository;

        public OrquestadorDesasignacionEfector(IOrquestadorParaValidarSiFinalizoElPedido orquestadorParaValidarSiFinalizoElPedido, 
            IOrquestadorCoseguro orquestadorCoseguro,
            IPedidoTramoProveedorUMovilHorarioRepository pedidoTramoProveedorUMovilHorarioRepository,
            IPedidoTramoEfectorHorarioRepository pedidoTramoEfectorHorarioRepository)
        {
            _orquestadorParaValidarSiFinalizoElPedido = orquestadorParaValidarSiFinalizoElPedido;
            _orquestadorCoseguro = orquestadorCoseguro;
            _pedidoTramoProveedorUMovilHorarioRepository = pedidoTramoProveedorUMovilHorarioRepository;
            _pedidoTramoEfectorHorarioRepository = pedidoTramoEfectorHorarioRepository;
        }

        public async Task<PedidoTramoEfectorHorario> DesasignarEfector(int pedidoTramoEfectorHorarioId)
        {
            try
            {
                if (pedidoTramoEfectorHorarioId == 0)
                    throw new DatoErroneoException($"El parámetro pedidoTramoEfectorHorarioId no puede ser 0.");

                PedidoTramoEfectorHorario pedidoTramoEfectorHorario = await _pedidoTramoEfectorHorarioRepository.Obtener(pedidoTramoEfectorHorarioId);
                if (pedidoTramoEfectorHorario is null)
                    throw new DatoErroneoException($"No se encontró pedidoTramoEfectorHorario con id: {pedidoTramoEfectorHorarioId}");

                pedidoTramoEfectorHorario = await _pedidoTramoEfectorHorarioRepository.Desasignar(pedidoTramoEfectorHorario);

                //Si era la asignación principal necesito buscar una nueva (si es que hay).
                if (!pedidoTramoEfectorHorario.Apoyo)
                    await BuscarNuevaAsignacionPrincipalDelTramo(pedidoTramoEfectorHorario.PedidoTramoId);

                int pedidoId = pedidoTramoEfectorHorario.PedidoTramo.PedidoId;
                await _orquestadorCoseguro.EjecutarReglasDeCoseguroParaElPedido(pedidoId, false);

                await _orquestadorParaValidarSiFinalizoElPedido.ValidarSiDebeFinalizar(pedidoId);

                return pedidoTramoEfectorHorario;
            }
            catch (Exception)
            {
                throw;
            }
        }

        private async Task BuscarNuevaAsignacionPrincipalDelTramo(int pedidoTramoId)
        {
            PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorarioApoyo = await _pedidoTramoProveedorUMovilHorarioRepository.ObtenerPrimeraAsignacionApoyoPorTramo(pedidoTramoId);
            if (pedidoTramoProveedorUMovilHorarioApoyo != null)
            {
                await _pedidoTramoProveedorUMovilHorarioRepository.ConvertirEnAsignacionPrincipal(pedidoTramoProveedorUMovilHorarioApoyo);
                return;
            }

            PedidoTramoEfectorHorario pedidoTramoEfectorHorarioApoyo = await _pedidoTramoEfectorHorarioRepository.ObtenerPrimeraAsignacionApoyoPorTramo(pedidoTramoId);
            if (pedidoTramoEfectorHorarioApoyo != null)
            {
                await _pedidoTramoEfectorHorarioRepository.ConvertirEnAsignacionPrincipal(pedidoTramoEfectorHorarioApoyo);
                return;
            }
        }
    }
}
