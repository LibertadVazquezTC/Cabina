﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using CabinaOperativa.DTOs.sql_Functions;
using CabinaOperativa.Enums;
using CabinaOperativa.Exceptions;
using CabinaOperativa.Modelo;
using CabinaOperativa.Orquestadores.Interfaces;
using CabinaOperativa.Repositories;
using CabinaOperativa.Utilities.Interfaces;
using Dapper;
using Microsoft.Extensions.Configuration;

namespace CabinaOperativa.Orquestadores
{
    public class OrquestadorNotificaciones : IOrquestadorNotificaciones
    {
        private readonly IConfiguration _config;
        private readonly INotificadorEquipoAcudir _notificadorEquipoAcudir;
        private readonly INotificadorMedicoDeVisitas _notificadorMedicoDeVisitas;
        private readonly IPedidoCoseguroRepository _pedidoCoseguroRepository;
        private readonly IPedidoTramoDetalleRepository _pedidoTramoDetalleRepository;
        private readonly IUMovilRepository _uMovilRepository;
        private readonly IPedidoTramoProveedorUMovilHorarioRepository _pedidoTramoProveedorUMovilHorarioRepository;
        private readonly IPedidoAdicionalRepository _pedidoAdicionalRepository;

        public OrquestadorNotificaciones(IConfiguration config,
            INotificadorEquipoAcudir notificadorEquipoAcudir,
            INotificadorMedicoDeVisitas notificadorMedicoDeVisitas,
            IPedidoCoseguroRepository pedidoCoseguroRepository,
            IPedidoTramoDetalleRepository pedidoTramoDetalleRepository,
            IUMovilRepository uMovilRepository,
            IPedidoTramoProveedorUMovilHorarioRepository pedidoTramoProveedorUMovilHorarioRepository,
            IPedidoAdicionalRepository pedidoAdicionalRepository)
        {
            _config = config;
            _notificadorEquipoAcudir = notificadorEquipoAcudir;
            _notificadorMedicoDeVisitas = notificadorMedicoDeVisitas;
            _pedidoCoseguroRepository = pedidoCoseguroRepository;
            _pedidoTramoDetalleRepository = pedidoTramoDetalleRepository;
            _uMovilRepository = uMovilRepository;
            _pedidoTramoProveedorUMovilHorarioRepository = pedidoTramoProveedorUMovilHorarioRepository;
            _pedidoAdicionalRepository = pedidoAdicionalRepository;
        }

        public IDbConnection Connection => new SqlConnection(_config.GetConnectionString("TechMedDatabase"));

        public async Task NotificarCoronavirus(int pedidoTramoProveedorUMovilHorarioId)
        {
            try
            {
                if (pedidoTramoProveedorUMovilHorarioId == 0)
                    throw new DatoErroneoException($"El parámetro pedidoTramoProveedorUMovilHorarioId no puede ser 0");

                PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario = await _pedidoTramoProveedorUMovilHorarioRepository.Obtener(pedidoTramoProveedorUMovilHorarioId);
                if (pedidoTramoProveedorUMovilHorario is null)
                    throw new DatoErroneoException($"No se encontró pedidoTramoProveedorUMovilHorario con id: {pedidoTramoProveedorUMovilHorarioId}");

                fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular = await ObtenerCmnCelularPorPedidoTramoProveedorUMovilHorarioId(pedidoTramoProveedorUMovilHorarioId);
                if (cmnCelular is null)
                    return;

                var pedidoAdicional = await _pedidoAdicionalRepository.ObtenerPorPedidoYTipo(pedidoTramoProveedorUMovilHorario.PedidoTramo.PedidoId, (int)PedidoAdicionalTipoEnum.Laboratorio);

                if (pedidoAdicional is null)
                    return;

                if (pedidoTramoProveedorUMovilHorario.GdiaRealEquipoId == (int)GdiaRealEquipoEnum.MasVidaGdiaRealEquipoId)
                    return;

                if (pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioEstadoId == (int)PedidoTramoProveedorUMovilHorarioEstadoEnum.PreDespacho)
                    return;

                if (cmnCelular.EsMedicoVisitas) return;
                else await _notificadorEquipoAcudir.NotificarCoronavirus(pedidoTramoProveedorUMovilHorario, cmnCelular);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task NotificarAsignacion(int pedidoTramoProveedorUMovilHorarioId)
        {
            try
            {
                if (pedidoTramoProveedorUMovilHorarioId == 0)
                    throw new DatoErroneoException($"El parámetro pedidoTramoProveedorUMovilHorarioId no puede ser 0");

                PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario = await _pedidoTramoProveedorUMovilHorarioRepository.Obtener(pedidoTramoProveedorUMovilHorarioId);
                if (pedidoTramoProveedorUMovilHorario is null)
                    throw new DatoErroneoException($"No se encontró pedidoTramoProveedorUMovilHorario con id: {pedidoTramoProveedorUMovilHorarioId}");

                fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular = await ObtenerCmnCelularPorPedidoTramoProveedorUMovilHorarioId(pedidoTramoProveedorUMovilHorarioId);
                if (cmnCelular is null)
                    return;

                if (pedidoTramoProveedorUMovilHorario.GdiaRealEquipoId == (int)GdiaRealEquipoEnum.MasVidaGdiaRealEquipoId)
                    return;

                if (pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioEstadoId == (int)PedidoTramoProveedorUMovilHorarioEstadoEnum.PreDespacho)
                    return;

                if (cmnCelular.EsMedicoVisitas) await _notificadorMedicoDeVisitas.NotificarAsignacion(pedidoTramoProveedorUMovilHorario, cmnCelular);
                else await _notificadorEquipoAcudir.NotificarAsignacion(pedidoTramoProveedorUMovilHorario, cmnCelular);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task NotificarDesasignacion(int pedidoTramoProveedorUMovilHorarioId)
        {
            try
            {
                if (pedidoTramoProveedorUMovilHorarioId == 0)
                    throw new DatoErroneoException($"El parámetro pedidoTramoProveedorUMovilHorarioId no puede ser 0");

                PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario = await _pedidoTramoProveedorUMovilHorarioRepository.Obtener(pedidoTramoProveedorUMovilHorarioId);
                if (pedidoTramoProveedorUMovilHorario is null)
                    throw new DatoErroneoException($"No se encontró pedidoTramoProveedorUMovilHorario con id: {pedidoTramoProveedorUMovilHorarioId}");

                fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular = await ObtenerCmnCelularPorPedidoTramoProveedorUMovilHorarioId(pedidoTramoProveedorUMovilHorarioId);
                if (cmnCelular is null)
                    return;

                if (pedidoTramoProveedorUMovilHorario.GdiaRealEquipoId == (int)GdiaRealEquipoEnum.MasVidaGdiaRealEquipoId)
                    return;

                if (cmnCelular.EsMedicoVisitas) await _notificadorMedicoDeVisitas.NotificarDesasignacion(pedidoTramoProveedorUMovilHorario, cmnCelular);
                else await _notificadorEquipoAcudir.NotificarDesasignacion(pedidoTramoProveedorUMovilHorario, cmnCelular);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task NotificarAnulacion(int pedidoId)
        {
            try
            {
                if (pedidoId == 0)
                    throw new DatoErroneoException($"El parámetro pedidoId no puede ser 0");

                IEnumerable<PedidoTramoProveedorUMovilHorario> asignacionesDelPedido = await _pedidoTramoProveedorUMovilHorarioRepository.ObtenerPorPedido(pedidoId);
                if (asignacionesDelPedido is null || asignacionesDelPedido.Count() == 0)
                    return;

                foreach (PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario in asignacionesDelPedido)
                {
                    fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular = await ObtenerCmnCelularPorPedidoTramoProveedorUMovilHorarioId(pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioId);
                    if (cmnCelular is null)
                        continue;

                    if (pedidoTramoProveedorUMovilHorario.GdiaRealEquipoId == (int)GdiaRealEquipoEnum.MasVidaGdiaRealEquipoId)
                        continue;

                    if (cmnCelular.EsMedicoVisitas) await _notificadorMedicoDeVisitas.NotificarAnulacion(pedidoId, cmnCelular);
                    else await _notificadorEquipoAcudir.NotificarAnulacion(pedidoTramoProveedorUMovilHorario, cmnCelular);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task NotificarActualizacionPunto(int pedidoTramoDetalleId)
        {
            try
            {
                if (pedidoTramoDetalleId == 0)
                    throw new DatoErroneoException($"El parámetro pedidoTramoDetalleId no puede ser 0");

                PedidoTramoDetalle pedidoTramoDetalle = await _pedidoTramoDetalleRepository.Obtener(pedidoTramoDetalleId);
                if (pedidoTramoDetalle is null)
                    throw new DatoErroneoException($"No se encontró pedidoTramoDetalle con id: {pedidoTramoDetalleId}");

                IEnumerable<PedidoTramoProveedorUMovilHorario> asignacionesDelPedido = await _pedidoTramoProveedorUMovilHorarioRepository.ObtenerPorPedidoTramoDetalle(pedidoTramoDetalleId);
                if (asignacionesDelPedido is null || asignacionesDelPedido.Count() == 0)
                    return;

                foreach (PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario in asignacionesDelPedido)
                {
                    fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular = await ObtenerCmnCelularPorPedidoTramoProveedorUMovilHorarioId(pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioId);
                    if (cmnCelular is null)
                        continue;

                    if (pedidoTramoProveedorUMovilHorario.GdiaRealEquipoId == (int)GdiaRealEquipoEnum.MasVidaGdiaRealEquipoId)
                        continue;

                    if (cmnCelular.EsMedicoVisitas) await _notificadorMedicoDeVisitas.NotificarActualizacionPunto(pedidoTramoProveedorUMovilHorario, pedidoTramoDetalle, cmnCelular);
                    else return;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task NotificarActualizacionCoseguro(int pedidoTramoProveedorUMovilHorarioId, float coseguro)
        {
            try
            {
                if (pedidoTramoProveedorUMovilHorarioId == 0)
                    throw new DatoErroneoException($"El parámetro pedidoTramoProveedorUMovilHorarioId no puede ser 0");

                PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario = await _pedidoTramoProveedorUMovilHorarioRepository.Obtener(pedidoTramoProveedorUMovilHorarioId);
                if (pedidoTramoProveedorUMovilHorario is null)
                    throw new DatoErroneoException($"No se encontró pedidoTramoProveedorUMovilHorario con id: {pedidoTramoProveedorUMovilHorarioId}");

                fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular = await ObtenerCmnCelularPorPedidoTramoProveedorUMovilHorarioId(pedidoTramoProveedorUMovilHorarioId);
                if (cmnCelular is null)
                    return;

                if (pedidoTramoProveedorUMovilHorario.GdiaRealEquipoId == (int)GdiaRealEquipoEnum.MasVidaGdiaRealEquipoId)
                    return;

                if (cmnCelular.EsMedicoVisitas) return;
                else await _notificadorEquipoAcudir.NotificarActualizacionCoseguro(pedidoTramoProveedorUMovilHorario, coseguro, cmnCelular);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task NotificarActualizacionHorario(int pedidoTramoProveedorUMovilHorarioId, string tipoHorario)
        {
            try
            {
                if (pedidoTramoProveedorUMovilHorarioId == 0)
                    throw new DatoErroneoException($"El parámetro pedidoTramoProveedorUMovilHorarioId no puede ser 0");

                if (tipoHorario != "OrigenArribo" && tipoHorario != "OrigenPartida")
                    throw new ReglaDeNegocioException($"Los tipoHorario permitidos son 'OrigenArribo' y 'OrigenPartida'");

                PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario = await _pedidoTramoProveedorUMovilHorarioRepository.Obtener(pedidoTramoProveedorUMovilHorarioId);
                if (pedidoTramoProveedorUMovilHorario is null)
                    throw new DatoErroneoException($"No se encontró pedidoTramoProveedorUMovilHorario con id: {pedidoTramoProveedorUMovilHorarioId}");

                if (tipoHorario == "OrigenArribo" && !pedidoTramoProveedorUMovilHorario.OrigenArribo.HasValue)
                    return;

                if (tipoHorario == "OrigenPartida" && !pedidoTramoProveedorUMovilHorario.OrigenPartida.HasValue)
                    return;

                fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular = await ObtenerCmnCelularPorPedidoTramoProveedorUMovilHorarioId(pedidoTramoProveedorUMovilHorarioId);
                if (cmnCelular is null)
                    return;

                if (pedidoTramoProveedorUMovilHorario.GdiaRealEquipoId == (int)GdiaRealEquipoEnum.MasVidaGdiaRealEquipoId)
                    return;

                if (cmnCelular.EsMedicoVisitas) await _notificadorMedicoDeVisitas.NotificarActualizacionHorario(pedidoTramoProveedorUMovilHorario, tipoHorario, cmnCelular);
                else await _notificadorMedicoDeVisitas.NotificarActualizacionHorario(pedidoTramoProveedorUMovilHorario, tipoHorario, cmnCelular);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task NotificarActualizacionTipoPrestacion(int pedidoId, int tipoPrestacionId)
        {
            try
            {
                if (pedidoId == 0)
                    throw new DatoErroneoException($"El parámetro pedidoId no puede ser 0");

                if (tipoPrestacionId == 0)
                    throw new DatoErroneoException($"El parámetro tipoPrestacionId no puede ser 0");

                IEnumerable<PedidoTramoProveedorUMovilHorario> asignacionesDelPedido = await _pedidoTramoProveedorUMovilHorarioRepository.ObtenerPorPedido(pedidoId);
                if (asignacionesDelPedido is null || asignacionesDelPedido.Count() == 0)
                    return;

                foreach (PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario in asignacionesDelPedido)
                {
                    fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular = await ObtenerCmnCelularPorPedidoTramoProveedorUMovilHorarioId(pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioId);
                    if (cmnCelular is null)
                        continue;

                    if (pedidoTramoProveedorUMovilHorario.GdiaRealEquipoId == (int)GdiaRealEquipoEnum.MasVidaGdiaRealEquipoId)
                        continue;

                    if (cmnCelular.EsMedicoVisitas) return;
                    else await _notificadorEquipoAcudir.NotificarActualizacionTipoPrestacion(pedidoTramoProveedorUMovilHorario, tipoPrestacionId, cmnCelular);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task NotificarInicioDeCarga(int uMovilId)
        {
            try
            {
                if (uMovilId == 0)
                    throw new DatoErroneoException($"El parámetro uMovilId no puede ser 0");

                UMovil uMovil = await _uMovilRepository.Obtener(uMovilId);
                if (uMovil is null)
                    throw new DatoErroneoException($"No se encontró uMovil con id: {uMovilId}");

                if(uMovil.CmnCelular is null)
                    return;

                fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular = new fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId();
                cmnCelular.CmnCelularId = uMovil.CmnCelular.CmnCelularId;
                cmnCelular.Numero = uMovil.CmnCelular.Numero;
                cmnCelular.Imei = uMovil.CmnCelular.Imei;
                cmnCelular.FcmTokenNotify = uMovil.CmnCelular.FcmTokenNotify;
                cmnCelular.EsMedicoVisitas = false;
                cmnCelular.EstaModoPrueba = uMovil.CmnCelular.ModoPrueba;

                await _notificadorEquipoAcudir.NotificarInicioDeCarga(cmnCelular);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task NotificarCancelacionDeCarga(int uMovilId)
        {
            try
            {
                if (uMovilId == 0)
                    throw new DatoErroneoException($"El parámetro uMovilId no puede ser 0");

                UMovil uMovil = await _uMovilRepository.Obtener(uMovilId);
                if (uMovil is null)
                    throw new DatoErroneoException($"No se encontró uMovil con id: {uMovilId}");

                if (uMovil.CmnCelular is null)
                    return;

                fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular = new fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId();
                cmnCelular.CmnCelularId = uMovil.CmnCelular.CmnCelularId;
                cmnCelular.Numero = uMovil.CmnCelular.Numero;
                cmnCelular.Imei = uMovil.CmnCelular.Imei;
                cmnCelular.FcmTokenNotify = uMovil.CmnCelular.FcmTokenNotify;
                cmnCelular.EsMedicoVisitas = false;
                cmnCelular.EstaModoPrueba = uMovil.CmnCelular.ModoPrueba;

                await _notificadorEquipoAcudir.NotificarCancelacionDeCarga(cmnCelular);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId> ObtenerCmnCelularPorPedidoTramoProveedorUMovilHorarioId(int pedidoTramoProveedorUMovilHorarioId)
        {
            using (IDbConnection conn = Connection)
            {
                fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular =
                    (await conn.QueryAsync<fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId>
                    ($"SELECT * FROM dbo.fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId({pedidoTramoProveedorUMovilHorarioId})"))
                    .FirstOrDefault();
                return cmnCelular;
            }
        }
    }
}
