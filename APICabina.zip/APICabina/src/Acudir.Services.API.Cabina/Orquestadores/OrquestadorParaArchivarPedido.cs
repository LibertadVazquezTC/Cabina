﻿using Acudir.Services.API.Cabina.Constants;
using Acudir.Services.API.Cabina.ServiciosExternos.Interfaces;
using CabinaOperativa.Constants;
using CabinaOperativa.DTOs.Archivar;
using CabinaOperativa.Enums;
using CabinaOperativa.Exceptions;
using CabinaOperativa.Exceptions.SISA;
using CabinaOperativa.Modelo;
using CabinaOperativa.Orquestadores.Interfaces;
using CabinaOperativa.Repositories;
using CabinaOperativa.ServiciosExternos.Interfaces;
using Newtonsoft.Json;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace CabinaOperativa.Orquestadores
{
    public class OrquestadorParaArchivarPedido : IOrquestadorParaArchivarPedido
    {
        private readonly IPedidoRepository _pedidoRepository;
        private readonly IPedidoAdicionalRepository _pedidoAdicionalRepository;
        private readonly IPedidoDiagnosticoMedicoRepository _pedidoDiagnosticoMedicoRepository;
        private readonly IPedidoCoseguroRepository _pedidoCoseguroRepository;
        private readonly IPedidoEntidadLogRepository _pedidoEntidadLogRepository;
        private readonly IPedidoComentarioRepository _pedidoComentarioRepository;
        private readonly ISISAConnector _sisaConnector;
        private readonly IEnvioNotificacionMobileService _envioNotificacionMobileService;

        public OrquestadorParaArchivarPedido(IPedidoRepository pedidoRepository,
            IPedidoAdicionalRepository pedidoAdicionalRepository,
            IPedidoDiagnosticoMedicoRepository pedidoDiagnosticoMedicoRepository,
            IPedidoCoseguroRepository pedidoCoseguroRepository,
            IPedidoEntidadLogRepository pedidoEntidadLogRepository,
            IPedidoComentarioRepository pedidoComentarioRepository,
            ISISAConnector sisaConnector, IEnvioNotificacionMobileService envioNotificacionMobileService)
        {
            _pedidoRepository = pedidoRepository;
            _pedidoAdicionalRepository = pedidoAdicionalRepository;
            _pedidoDiagnosticoMedicoRepository = pedidoDiagnosticoMedicoRepository;
            _pedidoCoseguroRepository = pedidoCoseguroRepository;
            _pedidoEntidadLogRepository = pedidoEntidadLogRepository;
            _pedidoComentarioRepository = pedidoComentarioRepository;
            _sisaConnector = sisaConnector;
            _envioNotificacionMobileService = envioNotificacionMobileService;
        }

        
        public async Task RutinaCreacionLogPedidoNoAtendido(ArchivarPedidoDTO archivarPedido)
        {
            try
            {
                await GenerarLogPedidoNoAtendido(archivarPedido);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task RutinaArchivado(ArchivarPedidoDTO archivarPedido)
        {
            try
            {
                Pedido pedido = await _pedidoRepository.Obtener(archivarPedido.PedidoId);

                ValidarAntesDeArchivar(pedido);

                await IngresarResultadoLaboratorio(archivarPedido, pedido);

                if (archivarPedido.IngresadoSisaFormato != null)
                    await GestionarIngresoSISA(pedido, archivarPedido.IngresadoSisaFormato.Value);

                await ArchivarPedido(archivarPedido, pedido);

                await GestionarDiagnosticoMedico(archivarPedido.PedidoId, archivarPedido.CierreDiagnosticoMedico.Descripcion, archivarPedido.CierreDiagnosticoMedico.DiagnosticoId);

                PedidoCoseguro pedidoCoseguro = await _pedidoCoseguroRepository.ObtenerPorPedido(archivarPedido.PedidoId);

                if (pedidoCoseguro != null)
                {
                    await _pedidoCoseguroRepository.InformarCierreCoseguro(pedidoCoseguro,
                        archivarPedido.CierreCoseguro.CobroCoseguro.HasValue ? archivarPedido.CierreCoseguro.CobroCoseguro.Value : false,
                        archivarPedido.CierreCoseguro.PedidoCoseguroTipoNoCobroId);

                    await GestionarPedidoAdicional(pedidoCoseguro);
                }

                if (!string.IsNullOrEmpty(archivarPedido.CierreDePedido.ComentarioCierre))
                    await GenerarComentarioCierre(archivarPedido.PedidoId, archivarPedido.CierreDePedido.ComentarioCierre);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task RutinaIngresoSISA(int pedidoId, IngresadoSisaFormatoEnum ingresadoSisaFormato)
        {
            Pedido pedido = await _pedidoRepository.Obtener(pedidoId);
            if (pedido is null)
                throw new DatoErroneoException("No se encontró un pedido con el id especificado.");

            await GestionarIngresoSISA(pedido, ingresadoSisaFormato);
        }

        private async Task GestionarIngresoSISA(Pedido pedido, IngresadoSisaFormatoEnum ingresadoSisaFormato)
        {
            if (DebeIngresarEnSISA(pedido))
            {
                if (ingresadoSisaFormato == IngresadoSisaFormatoEnum.Manual) await IngresarManualmenteEnSISA(pedido);
                else if (ingresadoSisaFormato == IngresadoSisaFormatoEnum.Automatico) await IngresarAutomaticamenteEnSISA(pedido);
            }
        }

        private void ValidarQueLaMuestraEsteEnLaboratorio(Pedido pedido)
        {
            if (pedido.PedidoMuestra is null ||
                pedido.PedidoMuestra.Count == 0 ||
                !pedido.PedidoMuestra.Any(pm => pm.Activo) ||
                pedido.PedidoMuestra.LastOrDefault(pm => pm.Activo).FechaIngresoLaboratorio is null)
            {
                throw new ReglaDeNegocioException("No se puede archivar el servicio porque la muestra no se encuentra en el laboratorio.");
            }
        }

        private bool DebeIngresarEnSISA(Pedido pedido)
        {
            if (pedido.TipoPrestacionId != (int)TipoPrestacionEnum.HIRA)
                return false;

            if (pedido.PedidoResultadoLaboratorioId is null)
                return false;

            if (pedido.PedidoResultadoLaboratorioId != (int)PedidoResultadoLaboratorioEnum.Detectable)
                return false;

            return true;
        }

        private async Task IngresarResultadoLaboratorio(ArchivarPedidoDTO archivarPedido, Pedido pedido)
        {
            if (archivarPedido.CierreDePedido.ResultadoLaboratorio != null)
            {
                pedido.PedidoResultadoLaboratorioId = archivarPedido.CierreDePedido.ResultadoLaboratorio.Value;
                await _pedidoRepository.Actualizar(pedido);
            }
        }

        private async Task ArchivarPedido(ArchivarPedidoDTO archivarPedido, Pedido pedido)
        {
            pedido.PedidoEstadoId = (int)PedidoEstadoEnum.Archivado;
            pedido.PedidoTipoCierreId = archivarPedido.CierreDePedido.PedidoTipoCierreId;
            await _pedidoRepository.Actualizar(pedido);

            await _pedidoEntidadLogRepository.Crear(
                archivarPedido.PedidoId,
                archivarPedido.PedidoId,
                (int)EntidadLogTipoEstadoEnum.PedidoArchivado,
                $"OrquestadorParaArchivarPedido/Archivar({archivarPedido.PedidoId})");
        }

        private async Task GenerarLogPedidoNoAtendido(ArchivarPedidoDTO archivarPedido)
        {
            await _pedidoEntidadLogRepository.Crear(
                archivarPedido.PedidoId,
                archivarPedido.PedidoId,
                (int)EntidadLogTipoEstadoEnum.PedidoNoAtendidoCriterioPresencial,
                $"OrquestadorParaArchivarPedido/GenerarLogPedidoNoAtendido({archivarPedido.PedidoId})");
        }


        private void ValidarAntesDeArchivar(Pedido pedido)
        {
            if (pedido is null)
                throw new DatoErroneoException("No se encontró un pedido con el id especificado.");

            if (pedido.PedidoEstadoId == (int)PedidoEstadoEnum.Archivado)
                throw new ReglaDeNegocioException($"El pedido {pedido.PedidoId} ya se encuentra archivado.",
                    ConstantesCodigoValidacionNegocio.PEDIDO_YA_ARCHIVADO);

            if (pedido.TipoPrestacionId == (int)TipoPrestacionEnum.HISO && EsMovilAcudir(pedido))
                ValidarQueLaMuestraEsteEnLaboratorio(pedido);
        }

        private bool EsMovilAcudir(Pedido pedido)
        {
            return pedido.PedidoTramo.FirstOrDefault(x => x.Activo)
                 .PedidoTramoProveedorUMovilHorario.Any(x => x.Activo && x.ProveedorId == (int)ProveedorEnum.Acudir);
           
        }

        private async Task IngresarManualmenteEnSISA(Pedido pedido)
        {
            pedido.IngresadoSisa = true;
            pedido.IngresadoSisaFecha = DateTime.Now;
            pedido.IngresadoSisaFormato = (int)IngresadoSisaFormatoEnum.Manual;
            pedido.IngresadoSisaRequest = "INGRESO MANUAL";
            pedido.IngresadoSisaResponse = "INGRESO MANUAL";
            await _pedidoRepository.Actualizar(pedido);
        }

        private async Task IngresarAutomaticamenteEnSISA(Pedido pedido)
        {
            var ingresarResponse = await _sisaConnector.IngresarEnSISA(pedido);
            if (!ingresarResponse.FueIngresadoSISA)
            {
                if (ingresarResponse.CrearEventoSISAResponse != null)
                {
                    if (!string.IsNullOrEmpty(ingresarResponse.CrearEventoSISAResponse.Descripcion))
                        throw new SISAIngresoException(
                            $"{ingresarResponse.CrearEventoSISAResponse.Respuesta}: {ingresarResponse.CrearEventoSISAResponse.Descripcion}");
                }
                if (!string.IsNullOrEmpty(ingresarResponse.Mensaje))
                    throw new SISAIngresoException(ingresarResponse.Mensaje);
            }

            string methodRequest = ingresarResponse.CrearEventoSISARequest != null ?
                    JsonConvert.SerializeObject(ingresarResponse.CrearEventoSISARequest) :
                    null;

            string methodResponse = ingresarResponse.CrearEventoSISAResponse != null ?
                JsonConvert.SerializeObject(ingresarResponse.CrearEventoSISAResponse) :
                null;

            pedido.IngresadoSisa = ingresarResponse.FueIngresadoSISA;
            pedido.IngresadoSisaFecha = DateTime.Now;
            pedido.IngresadoSisaFormato = (int)IngresadoSisaFormatoEnum.Automatico;
            pedido.IngresadoSisaRequest = methodRequest;
            pedido.IngresadoSisaResponse = methodResponse;
            await _pedidoRepository.Actualizar(pedido);
        }

        private async Task GestionarDiagnosticoMedico(int pedidoId, string diagnosticoDescripcion, int? diagnosticoId)
        {
            try
            {
                PedidoDiagnosticoMedico pedidoDiagnosticoMedico = await _pedidoDiagnosticoMedicoRepository.ObtenerPorPedido(pedidoId);
                if (pedidoDiagnosticoMedico is null)
                {
                    pedidoDiagnosticoMedico = await _pedidoDiagnosticoMedicoRepository.Crear(
                        pedidoId,
                        diagnosticoDescripcion,
                        diagnosticoId);

                    await _pedidoEntidadLogRepository.Crear(pedidoId,
                        pedidoDiagnosticoMedico.PedidoDiagnosticoMedicoId,
                        (int)EntidadLogTipoEstadoEnum.PedidoDiagnosticoMedicoCargado,
                        $"OrquestadorParaArchivarPedido/GestionarDiagnosticoMedico({pedidoId}, {diagnosticoDescripcion}, {diagnosticoId})");
                }
                else
                {
                    await _pedidoDiagnosticoMedicoRepository.Actualizar(
                        pedidoDiagnosticoMedico,
                        diagnosticoDescripcion,
                        diagnosticoId);

                    await _pedidoEntidadLogRepository.Crear(pedidoId,
                        pedidoDiagnosticoMedico.PedidoDiagnosticoMedicoId,
                        (int)EntidadLogTipoEstadoEnum.PedidoDiagnosticoActualizar,
                        $"OrquestadorParaArchivarPedido/GestionarDiagnosticoMedico({pedidoId}, {diagnosticoDescripcion}, {diagnosticoId})");
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        private async Task GestionarPedidoAdicional(PedidoCoseguro pedidoCoseguro)
        {
            try
            {
                PedidoAdicional pedidoAdicional = await _pedidoAdicionalRepository.ObtenerPorPedidoYTipo(pedidoCoseguro.PedidoId, (int)PedidoAdicionalTipoEnum.CoseguroCobrado);
                if (pedidoAdicional is null)
                {
                    pedidoAdicional = new PedidoAdicional();
                    pedidoAdicional.PedidoId = pedidoCoseguro.PedidoId;
                    pedidoAdicional.Cantidad = pedidoCoseguro.Cobrado.HasValue && pedidoCoseguro.Cobrado.Value ? (float)pedidoCoseguro.Coseguro : 0;
                    pedidoAdicional.PedidoAdicionalTipoId = (int)PedidoAdicionalTipoEnum.CoseguroCobrado;

                    await _pedidoAdicionalRepository.Crear(pedidoAdicional);
                }
                else
                {
                    pedidoAdicional.PedidoId = pedidoCoseguro.PedidoId;
                    pedidoAdicional.Cantidad = pedidoCoseguro.Cobrado.HasValue && pedidoCoseguro.Cobrado.Value ? (float)pedidoCoseguro.Coseguro : 0;
                    pedidoAdicional.PedidoAdicionalTipoId = (int)PedidoAdicionalTipoEnum.CoseguroCobrado;

                    await _pedidoAdicionalRepository.Actualizar(pedidoAdicional);
                }

                await _pedidoEntidadLogRepository.Crear(pedidoCoseguro.PedidoId,
                       pedidoAdicional.PedidoAdicionalId,
                       (int)EntidadLogTipoEstadoEnum.PedidoSupervisarCoseguroCobrado,
                       $"OrquestadorParaArchivarPedido/GestionarPedidoAdicional(pedidoCoseguro)");
            }
            catch (Exception)
            {
                throw;
            }
        }

        private async Task GenerarComentarioCierre(int pedidoId, string comentarioCierre)
        {
            try
            {
                await _pedidoComentarioRepository.Crear(pedidoId,
                    comentarioCierre,
                    (int)CmnComentarioTipoEnum.Interno);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task RutinaArchivadoVCM(ArchivarPedidoDTO archivarPedido)
        {
            try
            {
                Pedido pedido = await _pedidoRepository.Obtener(archivarPedido.PedidoId);
                if (pedido.TipoPrestacionId == (int)TipoPrestacionEnum.VideoConsulta)
                {
                    ValidarAntesDeArchivar(pedido);

                    await IngresarResultadoLaboratorio(archivarPedido, pedido);

                    if (archivarPedido.IngresadoSisaFormato != null)
                        await GestionarIngresoSISA(pedido, archivarPedido.IngresadoSisaFormato.Value);

                    await ArchivarPedido(archivarPedido, pedido);

                    await GestionarDiagnosticoMedico(archivarPedido.PedidoId, archivarPedido.CierreDiagnosticoMedico.Descripcion, archivarPedido.CierreDiagnosticoMedico.DiagnosticoId);

                    PedidoCoseguro pedidoCoseguro = await _pedidoCoseguroRepository.ObtenerPorPedido(archivarPedido.PedidoId);

                    if (pedidoCoseguro != null)
                    {
                        await _pedidoCoseguroRepository.InformarCierreCoseguro(pedidoCoseguro,
                            pedidoCoseguro.Cobrado == true ? pedidoCoseguro.Cobrado.Value : false,
                            archivarPedido.CierreCoseguro.PedidoCoseguroTipoNoCobroId);

                        await GestionarPedidoAdicional(pedidoCoseguro);
                    }

                    if (!string.IsNullOrEmpty(archivarPedido.CierreDePedido.ComentarioCierre))
                        await GenerarComentarioCierre(archivarPedido.PedidoId, archivarPedido.CierreDePedido.ComentarioCierre);
                    if(archivarPedido.CierreDePedido.PedidoTipoCierreId == ConstantesTipoNotificacionMobile.TIPO_CIERRE_AUSENTE)
                    {
                        await _envioNotificacionMobileService.BuscarAfiliadoMobileYEnviarNotificacion(pedido.PedidoId, ConstantesTipoNotificacionMobile.AUSENTE);
                    }
                    else
                    {
                        await _envioNotificacionMobileService.BuscarAfiliadoMobileYEnviarNotificacion(pedido.PedidoId, ConstantesTipoNotificacionMobile.ARCHIVADO);
                    }
                }
                else{

                    throw new ReglaDeNegocioException($"Se le realizó un cambio de tipo de prestación en el pedido {pedido.PedidoId}.",
                  ConstantesCodigoValidacionNegocio.PEDIDO_CAMBIO_TIPOPRESTACION);
                   
                }
        
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
