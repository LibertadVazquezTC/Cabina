﻿
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CabinaOperativa.Enums;
using CabinaOperativa.Modelo;
using CabinaOperativa.Orquestadores.Interfaces;
using CabinaOperativa.Repositories;

namespace CabinaOperativa.Orquestadores
{
    public class OrquestadorParaValidarSiFinalizoElPedido : IOrquestadorParaValidarSiFinalizoElPedido
    {
        private readonly IPedidoTramoProveedorUMovilHorarioRepository _pedidoTramoProveedorUMovilHorarioRepository;
        private readonly IPedidoTramoEfectorHorarioRepository _pedidoTramoEfectorHorarioRepository;
        private readonly IPedidoRepository _pedidoRepository;
        private readonly IPedidoEntidadLogRepository _pedidoEntidadLogRepository;

        public OrquestadorParaValidarSiFinalizoElPedido(IPedidoTramoProveedorUMovilHorarioRepository pedidoTramoProveedorUMovilHorarioRepository,
            IPedidoTramoEfectorHorarioRepository pedidoTramoEfectorHorarioRepository,
            IPedidoRepository pedidoRepository,
            IPedidoEntidadLogRepository pedidoEntidadLogRepository)
        {
            _pedidoTramoProveedorUMovilHorarioRepository = pedidoTramoProveedorUMovilHorarioRepository;
            _pedidoTramoEfectorHorarioRepository = pedidoTramoEfectorHorarioRepository;
            _pedidoRepository = pedidoRepository;
            _pedidoEntidadLogRepository = pedidoEntidadLogRepository;
        }

        public async Task ValidarSiDebeFinalizar(int pedidoId)
        {
            IEnumerable<PedidoTramoProveedorUMovilHorario> asignaciones = await _pedidoTramoProveedorUMovilHorarioRepository.ObtenerPorPedido(pedidoId);
            IEnumerable<PedidoTramoEfectorHorario> asignacionesEfector = await _pedidoTramoEfectorHorarioRepository.ObtenerPorPedido(pedidoId);

            if (asignaciones.Count() > 0 || asignacionesEfector.Count() > 0)
            {
                foreach (PedidoTramoProveedorUMovilHorario asignacion in asignaciones)
                {
                    if (asignacion.Origen && (asignacion.OrigenArribo is null || asignacion.OrigenPartida is null)) return;
                    if (asignacion.Destino && (asignacion.DestinoArribo is null || asignacion.DestinoArribo is null)) return;
                }

                foreach (PedidoTramoEfectorHorario asignacionEfector in asignacionesEfector)
                {
                    if (asignacionEfector.Origen && (asignacionEfector.OrigenArribo is null || asignacionEfector.OrigenPartida is null)) return;
                    if (asignacionEfector.Destino && (asignacionEfector.DestinoArribo is null || asignacionEfector.DestinoArribo is null)) return;
                }

                await _pedidoRepository.ActualizarEstado(pedidoId, (int)PedidoEstadoEnum.Finalizado, null, null);

                await _pedidoEntidadLogRepository.Crear(pedidoId,
                       pedidoId,
                       (int)EntidadLogTipoEstadoEnum.PedidoFinalizado,
                       $"OrquestadorParaValidarSiFinalizoElPedido/ValidarSiDebeFinalizar({pedidoId})");
            }
        }
    }
}
