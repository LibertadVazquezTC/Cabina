﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using CabinaOperativa.Modelo;
using Microsoft.EntityFrameworkCore;

namespace CabinaOperativa.Repositories
{
    public class GenericRepository<TEntity> : IGenericRepository<TEntity> where TEntity : class
    {
        public readonly TechMedContext _dbContext;

        public GenericRepository(TechMedContext dbContext)
        {
            _dbContext = dbContext;
        }

        #region Métodos asincrónicos
        public async Task<bool> AnyAsync(Expression<Func<TEntity, bool>> predicate)
        {
            return await _dbContext.Set<TEntity>().AnyAsync(predicate);
        }

        public async Task<TEntity> GetByIdAsync(int id)
        {
            return await _dbContext.Set<TEntity>().FindAsync(id);
        }

        public async Task<IEnumerable<TEntity>> GetAllAsync()
        {
            return await _dbContext.Set<TEntity>().ToListAsync();
        }

        public async Task<IEnumerable<TEntity>> GetManyAsync(Expression<Func<TEntity, bool>> predicate)
        {
            return await _dbContext.Set<TEntity>().Where(predicate).ToListAsync();
        }

        public async Task<TEntity> GetByConditionAsync(Expression<Func<TEntity, bool>> predicate)
        {
            return await _dbContext.Set<TEntity>().SingleOrDefaultAsync(predicate);
        }

        public async Task AddAsync(TEntity entity)
        {
            await _dbContext.Set<TEntity>().AddAsync(entity);
        }

        public async Task AddRangeAsync(TEntity entity)
        {
            await _dbContext.Set<TEntity>().AddRangeAsync(entity);
        }

        public async Task SaveChangesAsync()
        {
            await _dbContext.SaveChangesAsync();
        }

        public async Task ExecuteSqlCommandAsync(RawSqlString rawSqlString, params object[] sqlParameters)
        {
            await _dbContext.Database.ExecuteSqlCommandAsync(rawSqlString, sqlParameters);
        }

        public async Task ReloadAsync(TEntity entity)
        {
            await _dbContext.Entry(entity).ReloadAsync();
        }
        public async Task<TField> GetFieldByConditionAsync<TField>(Expression<Func<TEntity, bool>> predicate, Expression<Func<TEntity, TField>> fieldSelector)
        {
            return await _dbContext.Set<TEntity>().Where(predicate).Select(fieldSelector).FirstOrDefaultAsync();
        }
        #endregion

        #region Métodos sincrónicos
        public TEntity GetById(int id)
        {
            return _dbContext.Set<TEntity>().Find(id);
        }

        public IEnumerable<TEntity> GetAll()
        {
            return _dbContext.Set<TEntity>().ToList();
        }

        public IEnumerable<TEntity> GetMany(Expression<Func<TEntity, bool>> predicate)
        {
            return _dbContext.Set<TEntity>().Where(predicate).ToList();
        }

        public TEntity GetByCondition(Expression<Func<TEntity, bool>> predicate)
        {
            return _dbContext.Set<TEntity>().SingleOrDefault(predicate);
        }

        public void Add(TEntity entity)
        {
            _dbContext.Set<TEntity>().Add(entity);
        }

        public void AddRange(TEntity entity)
        {
            _dbContext.Set<TEntity>().AddRange(entity);
        }

        public void Update(TEntity entity)
        {
            _dbContext.Set<TEntity>().Update(entity);
        }

        public void UpdateRange(TEntity entity)
        {
            _dbContext.Set<TEntity>().UpdateRange(entity);
        }

        public void SaveChanges()
        {
            _dbContext.SaveChanges();
        }

        public void ExecuteSqlCommand(RawSqlString rawSqlString, params object[] sqlParameters)
        {
            _dbContext.Database.ExecuteSqlCommand(rawSqlString, sqlParameters);
        }
        #endregion
    }
}