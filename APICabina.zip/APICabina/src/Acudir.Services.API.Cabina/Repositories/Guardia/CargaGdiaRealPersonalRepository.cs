﻿using System;
using System.Threading.Tasks;
using CabinaOperativa.Enums;
using CabinaOperativa.Modelo;
using CabinaOperativa.Utilities;

namespace CabinaOperativa.Repositories
{
    public class CargaGdiaRealPersonalRepository : GenericRepository<CargaGdiaRealPersonal>, ICargaGdiaRealPersonalRepository
    {
        public CargaGdiaRealPersonalRepository(TechMedContext dbContext) : base(dbContext) { }

        public async Task AsignarCarga(CargaGdiaRealPersonal carga)
        {
            try
            {
                carga.CargaGdiaRealPersonalEstadoId = (int)CargaGdiaRealPersonalEstadoEnum.Asignado;
                carga.AuditoriaInsertDate = DateTime.Now;
                carga.AuditoriaInsertUser = SecurityUtility.UserName;
                carga.CargaCompleta = false;

                await AddAsync(carga);
                await SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task CancelarCarga(CargaGdiaRealPersonal carga)
        {
            try
            {
                carga.CargaGdiaRealPersonalEstadoId = (int)CargaGdiaRealPersonalEstadoEnum.Cancelado;
                carga.AuditoriaInsertDate = DateTime.Now;
                carga.AuditoriaInsertUser = SecurityUtility.UserName;
                carga.CargaCompleta = false;

                await AddAsync(carga);
                await SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task ReasignarCarga(CargaGdiaRealPersonal carga)
        {
            try
            {
                carga.CargaGdiaRealPersonalEstadoId = (int)CargaGdiaRealPersonalEstadoEnum.ReAsignado;
                carga.AuditoriaInsertDate = DateTime.Now;
                carga.AuditoriaInsertUser = SecurityUtility.UserName;
                carga.CargaCompleta = false;

                await AddAsync(carga);
                await SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}