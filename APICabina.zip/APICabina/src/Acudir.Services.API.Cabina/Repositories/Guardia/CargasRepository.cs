﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CabinaOperativa.Modelo;
using CabinaOperativa.Utilities;

namespace CabinaOperativa.Repositories
{
    public class CargasRepository : GenericRepository<Carga>, ICargaRepository
    {
        public CargasRepository(TechMedContext dbContext) : base(dbContext) { }

        public async Task Crear(Carga carga)
        {
            var ahora = DateTime.Now;
            carga.AuditoriaInsertDate = ahora;
            carga.AuditoriaInsertUser = SecurityUtility.UserName;
            carga.HoraFinal = ahora.AddMinutes(40);
            carga.ConfirmaInicio = false;
            carga.ConfirmaCalcelacion = false;

            await AddAsync(carga);
            await SaveChangesAsync();
        }

        public async Task Cancelar(int cargaId, string comentario)
        {
            var carga = GetById(cargaId);
            if (carga != null)
            {
                carga.Comentario = string.IsNullOrEmpty(carga.Comentario) ? ("Cancelación: " + comentario) : (carga.Comentario + " - Cancelación: " + comentario);
                carga.TiempoRestante = (int)(carga.HoraFinal - DateTime.Now).TotalMinutes;
                carga.AuditoriaUpdateDate = DateTime.Now;
                carga.AuditoriaUpdateUser = SecurityUtility.UserName;
                carga.ConfirmaCalcelacion = false;
                Update(carga);

                await SaveChangesAsync();
            }
        }
        public async Task Reasignar(int cargaId, string comentario)
        {
            var carga = GetById(cargaId);
            if (carga != null)
            {
                carga.Comentario = string.IsNullOrEmpty(carga.Comentario) ? ("Reasignación: " + comentario) : (carga.Comentario + " - Reasignación: " + comentario);
                carga.TiempoRestante = 0;
                carga.AuditoriaUpdateDate = DateTime.Now;
                carga.AuditoriaUpdateUser = SecurityUtility.UserName;
                carga.ConfirmaInicio = false;
                carga.ConfirmaCalcelacion = false;

                Update(carga);
                await SaveChangesAsync();
            }
        }
        public async Task<IEnumerable<Carga>> ObtenerUltimas10CargasPorMovil(int uMovilId)
        {
            try
            {
                var ultimas10Cargas = (await GetManyAsync(x => x.UMovilId == uMovilId)).OrderByDescending(y => y.CargaId).Take(10).ToList();
                return ultimas10Cargas;
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }
        }


    }
}