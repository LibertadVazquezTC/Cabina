﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

using CabinaOperativa.DTOs.sql_StoreProcedures;
using CabinaOperativa.Modelo;
using Dapper;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

namespace CabinaOperativa.Repositories
{
    public class GdiaRealEquipoMovilRepository : GenericRepository<GdiaRealEquipoMovil>, IGdiaRealEquipoMovilRepository
    {
   
        private readonly IConfiguration _config;
        public GdiaRealEquipoMovilRepository(TechMedContext dbContext,
         IConfiguration config) : base(dbContext)
        {
            _config = config;
        }
        public IDbConnection Connection => new SqlConnection(_config.GetConnectionString("TechMedDatabase"));
        public async Task<IEnumerable<GdiaRealEquipoMovil>> ObtenerPorGdiaRealEquipo(int gdiaRealEquipoId)
        {
            return await GetManyAsync(grem => grem.GdiaRealEquipoId == gdiaRealEquipoId);
        }

        public async Task<int> ObtenerCantidadMovilesPausados()
        {
            using (IDbConnection conn = Connection)
            {
                var jsonResponse = (await conn.QueryAsync<usp_GdiaMovilesEnPausa>("exec dbo.usp_GdiaMovilesEnPausa")).ToList();

                return jsonResponse.Count;
            }
        }
        public async Task<int> TiempoLimiteAletaPausas()
        {
            using (IDbConnection conn = Connection)
            {
                var MaximoAlertaPausas = (await conn.QueryAsync<int>("SELECT top 1 CAST([ValorProduccion] as int) as Maximo  FROM[dbo].[AppConfig]  where[Key] = 'AlertaPausas'")).FirstOrDefault();

                return MaximoAlertaPausas;
            }
        }
        public async Task<string> ObtenerMovilesPausados()
        {
            using (IDbConnection conn = Connection)
             {
               
                var jsonResponse = (await conn.QueryAsync<usp_GdiaMovilesEnPausa>("exec dbo.usp_GdiaMovilesEnPausa")).ToList();
              
               
                 return JsonConvert.SerializeObject( jsonResponse);
             }
        }

        public async Task<string> ObtenerMovilesPausadosPorFinalizar()
        {
            using (IDbConnection conn = Connection)
            {
                var jsonResponse = (await conn.QueryAsync<usp_GdiaMovilesEnPausa>("exec dbo.usp_GdiaMovilesEnPausa")).ToList();
                var MaximoAlertaPausas = (await conn.QueryAsync<int>("SELECT top 1 CAST([ValorProduccion] as int) as Maximo  FROM[dbo].[AppConfig]  where[Key] = 'AlertaPausas'")).FirstOrDefault();
               return JsonConvert.SerializeObject(jsonResponse.Where(x=> x.MinutosRestantes <= MaximoAlertaPausas).ToList());
            }
        }
    }
}