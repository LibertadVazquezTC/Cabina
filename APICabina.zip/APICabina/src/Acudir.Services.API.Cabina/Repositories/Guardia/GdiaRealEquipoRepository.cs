﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using CabinaOperativa.Enums;
using CabinaOperativa.Modelo;
using Dapper;
using Microsoft.Extensions.Configuration;

namespace CabinaOperativa.Repositories
{
    public class GdiaRealEquipoRepository : GenericRepository<GdiaRealPersonal>, IGdiaRealEquipoRepository
    {
        private readonly IConfiguration _config;

        public GdiaRealEquipoRepository(TechMedContext dbContext, 
            IConfiguration config) : base(dbContext)
        {
            _config = config;
        }

        public IDbConnection Connection => new SqlConnection(_config.GetConnectionString("TechMedDatabase"));

        public async Task<string> ListarGuardiasActivasJson(string gdiaEquipoIds, int filtroProveedor)
        {
            using (IDbConnection conn = Connection)
            {
                var jsonResponse = (await conn.QueryAsync<string>($"SELECT dbo.fn_JsonDTO_GdiasActivas(0, '{gdiaEquipoIds}', {filtroProveedor})")).ToList();
                var jsonResult = "";
                for (int i = 0; i < jsonResponse.Count(); i++) jsonResult += jsonResponse[i];
                return jsonResult;
            }
        }

        public async Task<string> ListarGuardiasActivasSugeridasPorPedidoTramoJson(int pedidoTramoId, string gdiaEquipoIds, int filtroProveedor)
        {
            using (IDbConnection conn = Connection)
            {
                var jsonResponse = (await conn.QueryAsync<string>($"SELECT dbo.fn_JsonDTO_GdiasActivas({pedidoTramoId}, '{gdiaEquipoIds}', {filtroProveedor})")).ToList();
                var jsonResult = "";
                for (int i = 0; i < jsonResponse.Count(); i++) jsonResult += jsonResponse[i];
                return jsonResult;
            }
        }
    }
}