﻿using System.Collections.Generic;
using System.Threading.Tasks;
using CabinaOperativa.Modelo;

namespace CabinaOperativa.Repositories
{
    public class GdiaRealPersonalDetalleRepository : GenericRepository<GdiaRealPersonalDetalle>, IGdiaRealPersonalDetalleRepository
    {
        public GdiaRealPersonalDetalleRepository(TechMedContext dbContext)
            : base(dbContext)
        {
        }

        public async Task<IEnumerable<GdiaRealPersonalDetalle>> ObtenerPorGdiaRealEquipo(int gdiaRealEquipoId)
        {
            return await GetManyAsync(grpd => grpd.GdiaRealEquipoId == gdiaRealEquipoId);
        }
    }
}