﻿using CabinaOperativa.Modelo;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public interface ICargaGdiaRealPersonalRepository
    {
        Task AsignarCarga(CargaGdiaRealPersonal carga);
        Task CancelarCarga(CargaGdiaRealPersonal carga);
        Task ReasignarCarga(CargaGdiaRealPersonal carga);
    }
}