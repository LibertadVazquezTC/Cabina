﻿using CabinaOperativa.Modelo;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public interface ICargaRepository
    {
        Task<IEnumerable<Carga>> ObtenerUltimas10CargasPorMovil(int uMovilId);
        Task Crear(Carga carga);
        Task Cancelar(int cargaId, string comentario);
        Task Reasignar(int cargaId, string comentario);
    }
}