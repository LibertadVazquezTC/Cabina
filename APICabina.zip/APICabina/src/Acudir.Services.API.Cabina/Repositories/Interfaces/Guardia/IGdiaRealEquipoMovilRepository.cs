﻿using CabinaOperativa.DTOs.sql_StoreProcedures;
using CabinaOperativa.Modelo;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public interface IGdiaRealEquipoMovilRepository
    {
        Task<IEnumerable<GdiaRealEquipoMovil>> ObtenerPorGdiaRealEquipo(int gdiaRealEquipoId);
        Task<int> ObtenerCantidadMovilesPausados();
        Task<string> ObtenerMovilesPausados();
        Task<string> ObtenerMovilesPausadosPorFinalizar();
        Task<int> TiempoLimiteAletaPausas();
    }
}