﻿using CabinaOperativa.Enums;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public interface IGdiaRealEquipoRepository
    {
        Task<string> ListarGuardiasActivasJson(string gdiaEquipoIds, int filtroProveedor);
        Task<string> ListarGuardiasActivasSugeridasPorPedidoTramoJson(int pedidoTramoId, string gdiaEquipoIds, int filtroProveedor);
    }
}