﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public interface IGenericRepository<TEntity> where TEntity : class
    {
        #region Métodos asincrónicos
        Task<bool> AnyAsync(Expression<Func<TEntity, bool>> predicate);
        Task<TEntity> GetByIdAsync(int id);

        Task<IEnumerable<TEntity>> GetAllAsync();

        Task<IEnumerable<TEntity>> GetManyAsync(Expression<Func<TEntity, bool>> predicate);

        Task AddAsync(TEntity entity);

        Task AddRangeAsync(TEntity entity);

        Task SaveChangesAsync();

        Task ExecuteSqlCommandAsync(RawSqlString rawSqlString, params object[] sqlParameters);

        Task ReloadAsync(TEntity entity);
        Task<TField> GetFieldByConditionAsync<TField>(Expression<Func<TEntity, bool>> predicate, Expression<Func<TEntity, TField>> fieldSelector);
        #endregion

        #region Métodos sincrónicos
        TEntity GetById(int id);

        IEnumerable<TEntity> GetAll();

        IEnumerable<TEntity> GetMany(Expression<Func<TEntity, bool>> predicate);

        TEntity GetByCondition(Expression<Func<TEntity, bool>> predicate);

        void Add(TEntity entity);

        void AddRange(TEntity entity);

        void Update(TEntity entity);

        void UpdateRange(TEntity entity);

        void SaveChanges();

        void ExecuteSqlCommand(RawSqlString rawSqlString, params object[] sqlParameters);
        #endregion
    }
}
