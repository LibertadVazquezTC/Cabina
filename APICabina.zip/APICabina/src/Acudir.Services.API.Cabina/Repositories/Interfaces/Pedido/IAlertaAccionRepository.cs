﻿using CabinaOperativa.Modelo;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public interface IAlertaAccionRepository
    {
        Task<IEnumerable<AlertaAccion>> ListarPorEntidadLogTipoEstado(int entidadLogTipoEstadoId);
    }
}