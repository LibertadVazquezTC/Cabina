﻿using CabinaOperativa.Modelo;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public interface ICmnCelularRepository
    {
        Task<CmnCelular> Obtener(int cmnCelularId);
        Task<string> ObtenerGpsCelularJson(int cmnCelularId);
        Task<string> ListarGpsCelularesJson();
        Task<string> ListarHistoricoGpsCelularJson(int cmnCelularId);
    }
}