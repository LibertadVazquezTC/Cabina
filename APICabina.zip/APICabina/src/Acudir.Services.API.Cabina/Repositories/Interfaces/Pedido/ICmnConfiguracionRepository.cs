﻿using CabinaOperativa.DTOs;
using CabinaOperativa.Modelo;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public interface ICmnConfiguracionRepository
    {
        Task<CmnConfiguracion> Obtener(int cmnConfiguracionId);
        Task<CmnConfiguracion> ObtenerByTipo(string tipo);
        Task<string> ListarPorTipoYUsuario(string tipo, int usuarioId);
        Task<string> ListarPorTipo(string tipo);
        Task<CmnConfiguracion> Crear(CmnConfiguracion cmnConfiguracion);
        Task<CmnConfiguracion> Actualizar(CmnConfiguracion cmnConfiguracion);
        Task Eliminar(int cmnConfiguracionId);
        Task<int> ObtenerCantidadMaximaDeAsignacionesPermitadas();
    }
}