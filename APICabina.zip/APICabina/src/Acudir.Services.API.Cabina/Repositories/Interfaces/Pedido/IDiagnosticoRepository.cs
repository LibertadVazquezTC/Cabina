﻿using CabinaOperativa.Modelo;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public interface IDiagnosticoRepository
    {
        Task<IEnumerable<Diagnostico>> Listar();
    }
}