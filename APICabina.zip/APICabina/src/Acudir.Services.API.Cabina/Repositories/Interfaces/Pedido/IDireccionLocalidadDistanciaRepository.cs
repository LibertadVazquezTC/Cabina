﻿using CabinaOperativa.Modelo;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public interface IDireccionLocalidadDistanciaRepository
    { 
        int? CalcularKilometros(DireccionLocalidad loc1, DireccionLocalidad loc2);
        void Insertar(DireccionLocalidad pivote, DireccionLocalidad puntoAB, int distanciaOrigenDestinoKmCero);
    }
}