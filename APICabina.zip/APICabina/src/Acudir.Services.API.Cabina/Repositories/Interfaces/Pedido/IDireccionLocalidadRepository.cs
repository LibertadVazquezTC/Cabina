﻿using CabinaOperativa.Modelo;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public interface IDireccionLocalidadRepository
    {
        Task<DireccionLocalidad> Obtener(int direccionLocalidadId);
        Task<IEnumerable<DireccionLocalidad>> Listar();

    }
}