﻿using CabinaOperativa.Modelo;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public interface IDireccionRepository
    {
        Task<Direccion> Crear(Direccion direccion);

    }
}