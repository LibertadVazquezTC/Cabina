﻿using CabinaOperativa.Modelo;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public interface IEfectorRepository
    {
        Task<Efector> Obtener(int efectorId);
        Task<string> ListarPorContratoJson(int contratoId);
    }
}