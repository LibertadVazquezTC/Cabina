﻿using CabinaOperativa.Modelo;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public interface IPedidoAdicionalRepository
    {
        Task<PedidoAdicional> ObtenerPorPedidoYTipo(int pedidoId, int pedidoAdicionalTipoId);
        Task<PedidoAdicional> Crear(PedidoAdicional pedidoAdicional);
        Task<PedidoAdicional> Actualizar(PedidoAdicional pedidoAdicional);
    }
}