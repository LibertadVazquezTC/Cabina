﻿using Acudir.Services.API.Cabina.DTOs;
using CabinaOperativa.DTOs;
using CabinaOperativa.Modelo;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public interface IPedidoAfiliadoRepository
    {
        Task<PedidoAfiliado> Obtener(int pedidoAfiliadoId);
        Task<PedidoAfiliado> ObtenerPorPedido(int pedidoId);
        Task<PedidoAfiliado> Actualizar(PedidoAfiliado pedidoAfiliado);
        Task<DatosAfiliadoDTO> ObtenerDatosEspecificos(int pedidoId);
    }
}