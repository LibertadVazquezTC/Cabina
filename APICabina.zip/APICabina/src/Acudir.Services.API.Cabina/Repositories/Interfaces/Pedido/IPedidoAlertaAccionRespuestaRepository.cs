﻿using CabinaOperativa.Modelo;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public interface IPedidoAlertaAccionRespuestaRepository
    {
        Task<PedidoAlertaAccionRespuesta> Crear(PedidoAlertaAccionRespuesta pedidoAlertaAccionRespuesta);
        Task<IEnumerable<PedidoAlertaAccionRespuesta>> ListarPorPedidoYValorYEntidadLogTipoEstado(int pedidoId, int valor, int entidadLogTipoEstadoId);
    }
}