﻿using CabinaOperativa.DTOs;
using CabinaOperativa.Modelo;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public interface IPedidoComentarioRepository
    {
        Task<IEnumerable<PedidoComentario>> Listar(int pedidoId, int[] cmnComentarioTipoIds);
        Task<PedidoComentario> Crear(int pedidoId, string descripcion, int cmnComentarioTipoId);
    }
}