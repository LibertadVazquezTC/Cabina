﻿using CabinaOperativa.Modelo;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public interface IPedidoCoseguroRepository
    {
        Task<PedidoCoseguro> Crear(int pedidoId, 
            int coseguro, 
            int? pedidoTramoProveedorUMovilHorarioId, 
            int? pedidoTramoEfectorHorarioId, 
            int? gdiaPersonalId);

        Task<PedidoCoseguro> Actualizar(PedidoCoseguro pedidoCoseguro,
            int coseguro, 
            int? pedidoTramoProveedorUMovilHorarioId, 
            int? pedidoTramoEfectorHorarioId, 
            int? gdiaPersonalId);

        Task<PedidoCoseguro> Obtener(int pedidoCoseguroId);
        Task<PedidoCoseguro> ObtenerPorPedido(int pedidoId);
        Task<PedidoCoseguro> ObtenerPorPedidoIncluyendoInactivos(int pedidoId);
        Task<PedidoCoseguro> Inactivar(PedidoCoseguro pedidoCoseguro);
        Task<PedidoCoseguro> InformarCierreCoseguro(PedidoCoseguro pedidoCoseguro, bool cobroCoseguro, int? pedidoCoseguroTipoNoCobroId);
        Task<int> ObtenerCoseguroACobrar(int pedidoTramoProveedorUMovilHorarioId, bool esPmi, bool esDiscapacitado, bool esInternacionDomiciliaria);
        Task<int> ObtenerCoseguroSugerido(int tipoPrestacionId, int contratoPlanId, int pedidoId, bool esPmi, bool esDiscapacitado, bool esInternacionDomiciliaria);
    }
}