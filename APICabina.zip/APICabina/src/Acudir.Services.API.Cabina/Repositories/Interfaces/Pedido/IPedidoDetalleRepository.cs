﻿using CabinaOperativa.Modelo;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public interface IPedidoDetalleRepository
    {
        Task<PedidoDetalle> ObtenerPorPedido(int pedidoId);
        Task<PedidoDetalle> Actualizar(PedidoDetalle pedidoDetalle);
        Task<string> ObtenerSintomaPorPedido(int pedidoId);

    }
}