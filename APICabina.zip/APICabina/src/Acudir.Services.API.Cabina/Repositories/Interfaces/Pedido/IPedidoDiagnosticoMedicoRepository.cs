﻿using CabinaOperativa.Modelo;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public interface IPedidoDiagnosticoMedicoRepository
    {
        Task<PedidoDiagnosticoMedico> ObtenerPorPedido(int pedidoId);
        Task<PedidoDiagnosticoMedico> Crear(int pedidoId, string descripcionManual, int? diagnosticoId);
        Task<PedidoDiagnosticoMedico> Actualizar(PedidoDiagnosticoMedico pedidoDiagnosticoMedico, string descripcionManual, int? diagnosticoId);
    }
}