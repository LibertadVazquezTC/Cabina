﻿using CabinaOperativa.DTOs;
using CabinaOperativa.Modelo;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public interface IPedidoEntidadLogRepository
    {
        Task<PedidoEntidadLog> Crear(int pedidoId, int valor, int entidadLogTipoEstadoId, string accion);
        Task<PedidoEntidadLog> ObtenerPorPedidoYValorYEntidadLogTipoEstado(int pedidoId, int valor, int entidadLogTipoEstadoId);
    }
}