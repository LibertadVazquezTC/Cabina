﻿using CabinaOperativa.Modelo;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public interface IPedidoRepository
    {
        Task<Pedido> Obtener(int pedidoId);
        Task<string> ObtenerJson(int pedidoId);
        Task<string> ListarJson();
        Task<string> ObtenerTrazabilidadJson(int pedidoId);
        Task<Pedido> Actualizar(Pedido pedido);
        Task<Pedido> ActualizarPacientePsiquiatrico(int pedidoId, bool pacientePsiquiatrico);
        Task<Pedido> ActualizarEstado(int pedidoId, int pedidoEstadoId, int? pedidoEstadoTipoId, string nuevoComentario);
        Task<Pedido> ActualizarRecurso(int pedidoId, int pedidoTipoDespachoId);
        Task<Pedido> AcualizarTipoPrestacion(int pedidoId, int tipoPrestacionId, int pedidoTipoDespachoId, string comentario);
        Task<int> RecategorizarPedido(int pedidoId, int tipoPrestacionId, string nuevoSintoma, string comentario, int? sintomaId);
    }
}