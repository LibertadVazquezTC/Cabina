﻿using CabinaOperativa.Modelo;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public interface IPedidoResultadoLaboratorioTipoPrestacionRepository
    {
        Task<IEnumerable<PedidoResultadoLaboratorioTipoPrestacion>> ListarByTipoPrestacion(int TipoPrestacionId);
    }
}