﻿using CabinaOperativa.DTOs;
using CabinaOperativa.Enums;
using CabinaOperativa.Modelo;
using System;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public interface IPedidoTramoDetalleRepository
    {
        Task<PedidoTramoDetalle> Obtener(int pedidoTramoDetalleId);
        Task<PedidoTramoDetalle> ObtenerPorPedidoTramoYTipo(int pedidoTramoId, OrigenDestinoEnum origenDestino);
        Task<PedidoTramoDetalle> Actualizar(PedidoTramoDetalle pedidoTramoDetalle);

    }
}