﻿using CabinaOperativa.Modelo;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public interface IPedidoTramoEfectorHorarioRepository
    {
        Task<PedidoTramoEfectorHorario> Obtener(int pedidoTramoEfectorHorarioId);
        Task<IEnumerable<PedidoTramoEfectorHorario>> ObtenerPorPedido(int pedidoId);
        Task<PedidoTramoEfectorHorario> ObtenerPrimeraAsignacionApoyoPorTramo(int pedidoTramoId);
        Task<PedidoTramoEfectorHorario> CrearAsignacion(int pedidoTramoId, int efectorId, bool esApoyo);
        Task<PedidoTramoEfectorHorario> ConvertirEnAsignacionPrincipal(PedidoTramoEfectorHorario pedidoTramoEfectorHorario);
        Task<PedidoTramoEfectorHorario> Desasignar(PedidoTramoEfectorHorario pedidoTramoEfectorHorario);
        Task<PedidoTramoEfectorHorario> ActualizarHorario(int pedidoTramoEfectorHorarioId, string tipoHorario, DateTime horario);
        Task<PedidoTramoEfectorHorario> Actualizar(PedidoTramoEfectorHorario pedidoTramoEfectorHorario);
        Task<PedidoTramoEfectorHorario> ActualizarEstado(int pedidoTramoEfectorHorarioId, int pedidoTramoEfectorHorarioEstadoId);
        Task<int> CantidadDeAsignacionesPrincipales(int pedidoTramoId);
        Task ValidarSiPuedeActualizarHorarios(int pedidoTramoEfectorHorarioId, string tipoHorario, DateTime horario);
    }
}