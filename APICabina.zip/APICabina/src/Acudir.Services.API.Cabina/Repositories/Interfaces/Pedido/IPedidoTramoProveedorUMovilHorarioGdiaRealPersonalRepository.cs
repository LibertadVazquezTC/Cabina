﻿using CabinaOperativa.Modelo;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public interface IPedidoTramoProveedorUMovilHorarioGdiaRealPersonalRepository
    {
        Task<IEnumerable<PedidoTramoProveedorUMovilHorarioGdiaRealPersonal>> GenerarIntegrantesDelEquipo(int pedidoTramoProveedorUMovilHorarioId, int? gdiaRealEquipoId);
        Task<PedidoTramoProveedorUMovilHorarioGdiaRealPersonal> ObtenerResponsableCoseguro(int pedidoTramoProveedorUMovilHorarioId);
        Task<IEnumerable<PedidoTramoProveedorUMovilHorarioGdiaRealPersonal>> ObtenerIntegrantesDeUnaAsignacion(int pedidoTramoProveedorUMovilHorarioId);
    }
}