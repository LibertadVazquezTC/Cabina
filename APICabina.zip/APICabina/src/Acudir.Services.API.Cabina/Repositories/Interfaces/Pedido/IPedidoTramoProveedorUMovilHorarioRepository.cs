﻿using CabinaOperativa.DTOs;
using CabinaOperativa.Enums;
using CabinaOperativa.Modelo;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public interface IPedidoTramoProveedorUMovilHorarioRepository
    {
        Task<PedidoTramoProveedorUMovilHorario> Obtener(int pedidoTramoProveedorUMovilHorarioId);
        Task<IEnumerable<PedidoTramoProveedorUMovilHorario>> ObtenerPorPedido(int pedidoId);
        Task<IEnumerable<PedidoTramoProveedorUMovilHorario>> ObtenerPorPedido(int pedidoId, bool conPreasignados);
        Task<IEnumerable<PedidoTramoProveedorUMovilHorario>> ObtenerPorPedidoTramoDetalle(int pedidoTramoDetalleId);
        Task<PedidoTramoProveedorUMovilHorario> ObtenerPorPedidoYGdiaRealEquipo(int pedidoId, int gdiaRealEquipoId);
        Task<PedidoTramoProveedorUMovilHorario> ObtenerPorPedidoTramoYGdiaRealEquipo(int pedidoTramoId, int gdiaRealEquipoId);
        Task<PedidoTramoProveedorUMovilHorario> ObtenerPrimeraAsignacionApoyoPorTramo(int pedidoTramoId);
        Task<PedidoTramoProveedorUMovilHorario> ConvertirEnAsignacionPrincipal(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario);
        Task<int> CantidadAsignacionesDelEquipo(int gdiaRealEquipoId);
        Task<PedidoTramoProveedorUMovilHorario> CrearAsignacion(int pedidoTramoId, int gdiaRealEquipoId, int proveedorId, bool esApoyo);
        Task<PedidoTramoProveedorUMovilHorario> CrearPreasignacion(int pedidoTramoId, int gdiaRealEquipoId, int proveedorId, bool esApoyo);
        Task<PedidoTramoProveedorUMovilHorario> DesasignarArchivar(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario);
        Task<PedidoTramoProveedorUMovilHorario> Desasignar(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario);
        Task<PedidoTramoProveedorUMovilHorario> DesasignarPedidoWorker(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario, bool esAmarillo);
        Task<PedidoTramoProveedorUMovilHorario> Actualizar(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario);
        Task<IEnumerable<PedidoTramoProveedorUMovilHorario>> Actualizar(IEnumerable<PedidoTramoProveedorUMovilHorario> listaAsignaciones);
        Task<PedidoTramoProveedorUMovilHorario> ActualizarHorarios(int pedidoTramoProveedorUMovilHorarioId, TipoHorarioEnum tipoHorario, DateTime fechaHora);
        Task<PedidoTramoProveedorUMovilHorario> ActualizarNroServicio(int pedidoTramoProveedorUMovilHorarioId, string nroServicio);
        Task ValidarSiPuedeActualizarHorarios(int pedidoTramoProveedorUMovilHorarioId, TipoHorarioEnum tipoHorario, DateTime fechaHora);
        Task<int> CantidadDeAsignacionesPrincipales(int pedidoTramoId);
        Task<bool> ExisteDespachadoActivo(int pedidoTramoId);
    }
}