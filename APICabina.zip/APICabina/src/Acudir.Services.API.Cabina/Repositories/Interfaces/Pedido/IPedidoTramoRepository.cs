﻿using CabinaOperativa.Modelo;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public interface IPedidoTramoRepository
    {
        Task<PedidoTramo> Obtener(int pedidoTramoId);
        Task<IEnumerable<PedidoTramo>> ListarPorPedido(int pedidoId);
    }
}