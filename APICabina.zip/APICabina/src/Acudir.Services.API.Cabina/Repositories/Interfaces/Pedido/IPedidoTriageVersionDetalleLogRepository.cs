﻿using CabinaOperativa.Modelo;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public interface IPedidoTriageVersionDetalleLogRepository
    {
        Task<IEnumerable<PedidoTriageVersionDetalleLog>> ListarPorPedido(int pedidoId);
    }
}