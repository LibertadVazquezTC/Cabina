﻿using CabinaOperativa.Modelo;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public interface IProveedorRepository
    {
        Task<Proveedor> Obtener(int proveedorId);
        Task<string> ListarJson(int pedidoId, bool mostrarTodos, bool requiereMovil);
    }
}