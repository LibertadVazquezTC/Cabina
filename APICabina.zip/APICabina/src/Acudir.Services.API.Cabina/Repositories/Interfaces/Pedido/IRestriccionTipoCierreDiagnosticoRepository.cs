﻿using CabinaOperativa.Modelo;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories.Interfaces.Pedido
{
    public interface IRestriccionTipoCierreDiagnosticoRepository
    {
        Task<IEnumerable<RestriccionTipoCierreDiagnostico>> ListarByDiagnosticoId(int diagnosticoId);
    }
}
