﻿using CabinaOperativa.Modelo;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories.Interfaces.Pedido
{
    public interface IRestriccionTipoCierrePrestacionRepository
    {
        Task<IEnumerable<RestriccionTipoCierrePrestacion>> ListarByTipoPrestacionId(int tipoPrestacionId);
    }
}
