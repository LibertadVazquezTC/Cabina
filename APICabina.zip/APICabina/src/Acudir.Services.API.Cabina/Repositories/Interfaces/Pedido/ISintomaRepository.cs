﻿using CabinaOperativa.Modelo;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public interface ISintomaRepository
    {
        Task<IEnumerable<Sintoma>> Listar();
        Task<Sintoma> Obtener(int sintomaId);
    }
}