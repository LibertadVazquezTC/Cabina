﻿using CabinaOperativa.Modelo;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public interface ITipoPrestacionContratoRepository
    {
        Task<IEnumerable<TipoPrestacionContrato>> ListarPorContratoYTipoPrestacionCategoria(int contratoId, int tipoPrestacionCategoriaId);

    }
}