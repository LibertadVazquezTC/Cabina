﻿using CabinaOperativa.Modelo;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public interface ITipoPrestacionRepository
    {
        Task<IEnumerable<TipoPrestacion>> Listar();
        Task<IEnumerable<TipoPrestacion>> ListarPorTipoPrestacionCategoria(int tipoPrestacionCategoriaId);
        Task<TipoPrestacion> Obtener(int tipoPrestacionId);
    }
}