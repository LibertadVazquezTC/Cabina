﻿using CabinaOperativa.Modelo;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public interface IUMovilRepository
    {
        Task<UMovil> Obtener(int uMovilId);
        Task<string> ObtenerUltimoReporteGpsMovilJson(int gpsMovilId);
    }
}