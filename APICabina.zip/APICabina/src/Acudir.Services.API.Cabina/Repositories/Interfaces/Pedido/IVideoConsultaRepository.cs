﻿using Acudir.Services.API.Cabina.Modelo;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Acudir.Services.API.Cabina.Repositories.Interfaces.Pedido
{
    public interface IVideoConsultaRepository
    {
        Task<int> ObtenerVideoConsultaByPedidoId(int pedidoId);
        Task<List<int>> ObtenerLogsVideoConsulta(int videoConsultaId);
    }
}
