﻿using System.Collections.Generic;
using System.Threading.Tasks;
using CabinaOperativa.Modelo;

namespace CabinaOperativa.Repositories
{
    public class AlertaAccionRepository : GenericRepository<AlertaAccion>, IAlertaAccionRepository
    {
        public AlertaAccionRepository(TechMedContext dbContext) : base(dbContext)
        {
        }

        public async Task<IEnumerable<AlertaAccion>> ListarPorEntidadLogTipoEstado(int entidadLogTipoEstadoId)
        {
            return await GetManyAsync(ac => ac.EntidadLogTipoEstadoId == entidadLogTipoEstadoId);
        }
    }
}