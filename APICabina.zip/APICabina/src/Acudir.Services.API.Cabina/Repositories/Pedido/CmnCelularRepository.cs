﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using CabinaOperativa.Modelo;
using Dapper;
using Microsoft.Extensions.Configuration;

namespace CabinaOperativa.Repositories
{
    public class CmnCelularRepository : GenericRepository<CmnCelular>, ICmnCelularRepository
    {
        private readonly IConfiguration _config;

        public CmnCelularRepository(TechMedContext dbContext, IConfiguration config) : base(dbContext)
        {
            _config = config;
        }

        public IDbConnection Connection => new SqlConnection(_config.GetConnectionString("TechMedDatabase"));
        public IDbConnection ConnectionUms => new SqlConnection(_config.GetConnectionString("UmsDatabase"));

        public async Task<CmnCelular> Obtener(int cmnCelularId)
        {
            return await GetByIdAsync(cmnCelularId);
        }


        public async Task<string> ListarGpsCelularesJson()
        {
            using (IDbConnection conn = Connection)
            {
                var jsonResponse = (await conn.QueryAsync<string>($"SELECT dbo.fn_JsonDTO_GpsCelulares(0)")).ToList();
                var jsonResult = "";
                for (int i = 0; i < jsonResponse.Count(); i++) jsonResult += jsonResponse[i];
                return jsonResult;
            }
        }

        public async Task<string> ObtenerGpsCelularJson(int cmnCelularId)
        {
            using (IDbConnection conn = Connection)
            {
                var jsonResponse = (await conn.QueryAsync<string>($"SELECT dbo.fn_JsonDTO_GpsCelulares({cmnCelularId})")).ToList();
                var jsonResult = "";
                for (int i = 0; i < jsonResponse.Count(); i++) jsonResult += jsonResponse[i];
                return jsonResult;
            }
        }

        public async Task<string> ListarHistoricoGpsCelularJson(int cmnCelularId)
        {
            CmnCelular cmnCelular = await GetByIdAsync(cmnCelularId);
            string imei = cmnCelular.Imei;

            List<string> response;
            string resultado = "[";

            using (IDbConnection conn = ConnectionUms)
                response = (await conn.QueryAsync<string>($"exec usp_TrazabilidadCelular_get '{imei}'")).ToList();
               
            for (int i = 0; i < response.Count(); i++)
            {
                resultado += response[i];
                if (i != response.Count() - 1)
                {
                    resultado += ",";
                }
            }

            resultado += "]";
            return resultado;
        }
    }
}