﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using CabinaOperativa.Constants;
using CabinaOperativa.Exceptions;
using CabinaOperativa.Modelo;
using CabinaOperativa.Utilities;
using Dapper;
using Microsoft.Extensions.Configuration;

namespace CabinaOperativa.Repositories
{
    public class CmnConfiguracionRepository : GenericRepository<CmnConfiguracion>, ICmnConfiguracionRepository
    {
        private readonly IConfiguration _config;

        public CmnConfiguracionRepository(TechMedContext dbContext, IConfiguration config) : base(dbContext)
        {
            _config = config;
        }

        public IDbConnection Connection => new SqlConnection(_config.GetConnectionString("TechMedDatabase"));

        public async Task<CmnConfiguracion> Obtener(int cmnConfiguracionId)
        {
            return await GetByIdAsync(cmnConfiguracionId);
        }

        public async Task<string> ListarPorTipoYUsuario(string tipo, int usuarioId)
        {
            ValidarTipo(tipo);

            using (IDbConnection conn = Connection)
            {
                var jsonString = (await conn.QueryAsync<string>($"SELECT dbo.fn_JsonDTO_CmnConfiguracion ('{tipo}',{usuarioId})")).ToList();
                var jsonResponse = "";
                for (int i = 0; i < jsonString.Count(); i++) jsonResponse += jsonString[i];
                return jsonResponse;
            }
        }

        public async Task<string> ListarPorTipo(string tipo)
        {
            ValidarTipo(tipo);

            using (IDbConnection conn = Connection)
            {
                var jsonString = (await conn.QueryAsync<string>($"SELECT dbo.fn_JsonDTO_CmnConfiguracion ('{tipo}',{0})")).ToList();
                var jsonResponse = "";
                for (int i = 0; i < jsonString.Count(); i++) jsonResponse += jsonString[i];
                return jsonResponse;
            }
        }

        public async Task<int> ObtenerCantidadMaximaDeAsignacionesPermitadas()
        {
            using (IDbConnection conn = Connection)
            {
                string query = string.Format($@"SELECT JSON_VALUE(cc.Configuracion, '$.cantidad') AS Cantidad
                                                                    FROM CmnConfiguracion cc
                                                                    WHERE cc.Activo = 1
                                                                    AND cc.Tipo = '{ConstantesCmnConfiguracion.TIPO_ASIGNACIONES_POR_MEDICO}'");

                var jsonResponse = (await conn.QueryAsync<int>(query)).ToList();
                return jsonResponse.FirstOrDefault();
            }
        }

        public async Task<CmnConfiguracion> Crear(CmnConfiguracion cmnConfiguracion)
        {
            ValidarTipo(cmnConfiguracion.Tipo);
            await ValidarTipoParaCrear(cmnConfiguracion.Tipo);

            cmnConfiguracion.UsuarioId = SecurityUtility.UsuarioId;
            cmnConfiguracion.Activo = true;
            cmnConfiguracion.AuditoriaInsertDate = DateTime.Now;
            cmnConfiguracion.AuditoriaInsertUser = SecurityUtility.UserName;

            await AddAsync(cmnConfiguracion);
            await SaveChangesAsync();

            return cmnConfiguracion;
        }

        public async Task<CmnConfiguracion> Actualizar(CmnConfiguracion cmnConfiguracion)
        {
            cmnConfiguracion.Activo = true;
            cmnConfiguracion.AuditoriaUpdateDate = DateTime.Now;
            cmnConfiguracion.AuditoriaUpdateUser = SecurityUtility.UserName;

            Update(cmnConfiguracion);
            await SaveChangesAsync();

            return cmnConfiguracion;
        }

        public async Task Eliminar(int cmnConfiguracionId)
        {
            CmnConfiguracion CmnConfiguracionExistente = await GetByIdAsync(cmnConfiguracionId);
            if (CmnConfiguracionExistente is null)
                throw new ArgumentException($"La configuración con id: {cmnConfiguracionId} no existe.");

            CmnConfiguracionExistente.Activo = false;
            CmnConfiguracionExistente.AuditoriaUpdateDate = DateTime.Now;
            CmnConfiguracionExistente.AuditoriaUpdateUser = SecurityUtility.UserName;

            Update(CmnConfiguracionExistente);
            await SaveChangesAsync();
        }

        public void ValidarTipo(string tipo)
        {
            if (string.IsNullOrEmpty(tipo))
                throw new ReglaDeNegocioException("El tipo no puede ser vacio");

            if (tipo != ConstantesCmnConfiguracion.TIPO_TABLA && tipo != ConstantesCmnConfiguracion.TIPO_ASIGNACIONES_POR_MEDICO)
                throw new ReglaDeNegocioException($"El tipo {tipo} no está dentro de los permitidos");
        }

        public async Task ValidarTipoParaCrear(string tipo)
        {
            if (tipo == ConstantesCmnConfiguracion.TIPO_ASIGNACIONES_POR_MEDICO)
            {
                bool yaExiste = await GetByConditionAsync(cc => cc.Tipo == tipo && cc.Activo) != null;
                if (yaExiste)
                    throw new ReglaDeNegocioException($"Ya existe una configuración para el tipo {tipo}");
            }               
        }

        public async Task<CmnConfiguracion> ObtenerByTipo(string tipo)
        {
            return await GetByConditionAsync(cc => cc.Tipo.Equals(tipo));
        }
    }
}
