﻿using System.Collections.Generic;
using System.Threading.Tasks;
using CabinaOperativa.Modelo;

namespace CabinaOperativa.Repositories
{
    public class DiagnosticoRepository : GenericRepository<Diagnostico>, IDiagnosticoRepository
    {
        public DiagnosticoRepository(TechMedContext dbContext) : base(dbContext)
        {       
        }

        public async Task<IEnumerable<Diagnostico>> Listar()
        {
            return await GetManyAsync(d => d.Activo);
        }
    }
}