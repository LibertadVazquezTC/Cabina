﻿using System;
using System.Linq;
using CabinaOperativa.Modelo;
using CabinaOperativa.Utilities;

namespace CabinaOperativa.Repositories
{
    public class DireccionLocalidadDistanciaRepository : GenericRepository<DireccionLocalidadDistancia>, IDireccionLocalidadDistanciaRepository
    {
        public DireccionLocalidadDistanciaRepository(TechMedContext dbContext)
            : base(dbContext)
        {
        }

        public int? CalcularKilometros(DireccionLocalidad loc1, DireccionLocalidad loc2)
        {
            var cantidadKilometros = GetMany(x =>
                (x.DireccionLocalidad1Id == loc1.DireccionLocalidadId && 
                x.DireccionLocalidad2Id == loc2.DireccionLocalidadId) || 
                (x.DireccionLocalidad1Id == loc2.DireccionLocalidadId && 
                x.DireccionLocalidad2Id == loc1.DireccionLocalidadId)).FirstOrDefault();
            
            if (cantidadKilometros != null)
            {
                return cantidadKilometros.CantidadKilometro;
            }

            return null;
        }

        public void Insertar(DireccionLocalidad pivote, DireccionLocalidad puntoAB, int distanciaOrigenDestinoKmCero)
        {
            try
            {
                DireccionLocalidadDistancia direccionLocalidadDistancia = new DireccionLocalidadDistancia();
                direccionLocalidadDistancia.CantidadKilometro = distanciaOrigenDestinoKmCero;
                direccionLocalidadDistancia.DireccionLocalidad1 = pivote;
                direccionLocalidadDistancia.DireccionLocalidad2 = puntoAB;

                direccionLocalidadDistancia.AuditoriaInsertDate = DateTime.Now;
                direccionLocalidadDistancia.AuditoriaInsertUser = SecurityUtility.UserName;
                direccionLocalidadDistancia.AuditoriaUpdateDate = DateTime.Now;
                direccionLocalidadDistancia.AuditoriaUpdateUser = SecurityUtility.UserName;

                Add(direccionLocalidadDistancia);
                SaveChanges();
            }
            catch (Exception ex)
            {
                throw new ArgumentException("Ocurrio un error al intentar insertar el registro: " + ex.Message);
            }
        }
    }
}