﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using CabinaOperativa.Modelo;

namespace CabinaOperativa.Repositories
{
    public class DireccionLocalidadRepository : GenericRepository<DireccionLocalidad>, IDireccionLocalidadRepository
    {
        public DireccionLocalidadRepository(TechMedContext dbContext)
            : base(dbContext)
        {
        }

        public async Task<IEnumerable<DireccionLocalidad>> Listar()
        {
            return await GetManyAsync(dl => !dl.Borrado);
        }

        public async Task<DireccionLocalidad> Obtener(int direccionLocalidadId)
        {
            return await GetByIdAsync(direccionLocalidadId);
        }
    }
}