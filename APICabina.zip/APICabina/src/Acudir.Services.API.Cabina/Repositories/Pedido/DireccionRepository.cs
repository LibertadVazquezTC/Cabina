﻿using System;
using System.Threading.Tasks;
using CabinaOperativa.Modelo;
using CabinaOperativa.Utilities;

namespace CabinaOperativa.Repositories
{
    public class DireccionRepository : GenericRepository<Direccion>, IDireccionRepository
    {
        public DireccionRepository(TechMedContext dbContext) : base(dbContext)
        {
        }

        public async Task<Direccion> Crear(Direccion direccion)
        {
            direccion.Borrado = false;
            direccion.AuditoriaInsertUser = SecurityUtility.UserName;
            direccion.AuditoriaInsertDate = DateTime.Now;

            await AddAsync(direccion);
            await SaveChangesAsync();

            return direccion;
        }
    }
}