﻿using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using CabinaOperativa.Modelo;
using Dapper;
using Microsoft.Extensions.Configuration;

namespace CabinaOperativa.Repositories
{
    public class EfectorRepository : GenericRepository<Efector>, IEfectorRepository
    {
        private readonly IConfiguration _config;

        public EfectorRepository(TechMedContext dbContext, IConfiguration config) : base(dbContext)
        {
            _config = config;
        }

        public IDbConnection Connection => new SqlConnection(_config.GetConnectionString("TechMedDatabase"));

        public async Task<Efector> Obtener(int efectorId)
        {
            return await GetByIdAsync(efectorId);
        }

        public async Task<string> ListarPorContratoJson(int contratoId)
        {
            using (IDbConnection conn = Connection)
            {
                var jsonResponse = (await conn.QueryAsync<string>($"SELECT dbo.fn_JsonDTO_EfectoresPorContrato({contratoId})")).ToList();
                var jsonResult = "";
                for (int i = 0; i < jsonResponse.Count(); i++) jsonResult += jsonResponse[i];
                return jsonResult;
            }
        }
    }
}