﻿using System;
using System.Threading.Tasks;
using CabinaOperativa.Modelo;
using CabinaOperativa.Utilities;

namespace CabinaOperativa.Repositories
{
    public class PedidoAdicionalRepository : GenericRepository<PedidoAdicional>, IPedidoAdicionalRepository
    {
        public PedidoAdicionalRepository(TechMedContext dbContext) : base(dbContext)
        {
        }

        public async Task<PedidoAdicional> ObtenerPorPedidoYTipo(int pedidoId, int pedidoAdicionalTipoId)
        {
            return await GetByConditionAsync(pa => pa.PedidoId == pedidoId &&
                 pa.PedidoAdicionalTipoId == pedidoAdicionalTipoId &&
                 pa.Activo.Value);
        }

        public async Task<PedidoAdicional> Crear(PedidoAdicional pedidoAdicional)
        {
            pedidoAdicional.Activo = true;
            pedidoAdicional.AuditoriaInsertDate = DateTime.Now;
            pedidoAdicional.AuditoriaInsertUser = SecurityUtility.UserName;

            Add(pedidoAdicional);
            await SaveChangesAsync();

            return pedidoAdicional;
        }

        public async Task<PedidoAdicional> Actualizar(PedidoAdicional pedidoAdicional)
        {
            pedidoAdicional.Activo = true;
            pedidoAdicional.AuditoriaInsertDate = DateTime.Now;
            pedidoAdicional.AuditoriaInsertUser = SecurityUtility.UserName;

            Update(pedidoAdicional);
            await SaveChangesAsync();

            return pedidoAdicional;
        }
    }
}