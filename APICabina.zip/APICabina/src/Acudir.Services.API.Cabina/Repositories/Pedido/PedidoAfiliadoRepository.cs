﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Acudir.Services.API.Cabina.DTOs;
using CabinaOperativa.DTOs;
using CabinaOperativa.Modelo;
using CabinaOperativa.Utilities;
using Microsoft.Extensions.Configuration;
using static Dapper.SqlMapper;

namespace CabinaOperativa.Repositories
{
    public class PedidoAfiliadoRepository : GenericRepository<PedidoAfiliado>, IPedidoAfiliadoRepository
    {
        public PedidoAfiliadoRepository(TechMedContext dbContext) : base(dbContext)
        {
        }

        public async Task<PedidoAfiliado> Obtener(int pedidoAfiliadoId)
        {
            return await GetByIdAsync(pedidoAfiliadoId);
        }

        public async Task<PedidoAfiliado> Actualizar(PedidoAfiliado pedidoAfiliado)
        {
            try
            {
                pedidoAfiliado.AuditoriaUpdateDate = DateTime.Now;
                pedidoAfiliado.AuditoriaUpdateUser = SecurityUtility.UserName;

                Update(pedidoAfiliado);
                await SaveChangesAsync();

                return pedidoAfiliado;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<PedidoAfiliado> ObtenerPorPedido(int pedidoId)
        {
            return await GetByConditionAsync(pa => pa.PedidoId == pedidoId);
        }
    
        public async Task<DatosAfiliadoDTO> ObtenerDatosEspecificos(int pedidoId)
        {
            return await GetFieldByConditionAsync(x => x.PedidoId == pedidoId,
                                                    x => new DatosAfiliadoDTO()
                                                    {
                                                        ContratoId = x.ContratoAfiliado.ContratoId,
                                                        Documento = x.ContratoAfiliado.DocumentoNro
                                                    });
        }
    }
}