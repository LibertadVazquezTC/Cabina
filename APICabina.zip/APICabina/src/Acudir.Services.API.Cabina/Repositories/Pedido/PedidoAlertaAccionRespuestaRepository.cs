﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using CabinaOperativa.Modelo;
using CabinaOperativa.Utilities;

namespace CabinaOperativa.Repositories
{
    public class PedidoAlertaAccionRespuestaRepository : GenericRepository<PedidoAlertaAccionRespuesta>, IPedidoAlertaAccionRespuestaRepository
    {
        public PedidoAlertaAccionRespuestaRepository(TechMedContext dbContext) : base(dbContext)
        {
        }

        public async Task<PedidoAlertaAccionRespuesta> Crear(PedidoAlertaAccionRespuesta pedidoAlertaAccionRespuesta)
        {
            pedidoAlertaAccionRespuesta.AuditoriaInsertDate = DateTime.Now;
            pedidoAlertaAccionRespuesta.AuditoriaInsertUser = SecurityUtility.UserName;

            await AddAsync(pedidoAlertaAccionRespuesta);
            await SaveChangesAsync();

            return pedidoAlertaAccionRespuesta;
        }

        public async Task<IEnumerable<PedidoAlertaAccionRespuesta>> ListarPorPedidoYValorYEntidadLogTipoEstado(int pedidoId, int valor, int entidadLogTipoEstadoId)
        {
            return await GetManyAsync(paar =>
                   paar.PedidoEntidadLog.PedidoId == pedidoId &&
                   paar.PedidoEntidadLog.Valor == valor &&
                   paar.AlertaAccion.EntidadLogTipoEstadoId == entidadLogTipoEstadoId);
        }


    }
}