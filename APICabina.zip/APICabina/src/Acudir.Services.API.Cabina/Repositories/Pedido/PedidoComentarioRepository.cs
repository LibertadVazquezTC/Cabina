﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CabinaOperativa.Modelo;
using CabinaOperativa.Utilities;
using Microsoft.EntityFrameworkCore;

namespace CabinaOperativa.Repositories
{
    public class PedidoComentarioRepository : GenericRepository<PedidoComentario>, IPedidoComentarioRepository
    {
        public PedidoComentarioRepository(TechMedContext dbContext) : base(dbContext)
        {
        }

        public async Task<IEnumerable<PedidoComentario>> Listar(int pedidoId, int[] cmnComentarioTipoIds)
        {
            return await GetManyAsync(pc => pc.PedidoId == pedidoId && cmnComentarioTipoIds.Contains(pc.CmnComentarioTipoId));
        }

        public async Task<PedidoComentario> Crear(int pedidoId, string descripcion, int cmnComentarioTipoId)
        {
            PedidoComentario pedidoComentario = new PedidoComentario();
            pedidoComentario.PedidoId = pedidoId;
            pedidoComentario.Descripcion = descripcion;
            pedidoComentario.CmnComentarioTipoId = cmnComentarioTipoId;
            pedidoComentario.Hora = DateTime.Now;
            pedidoComentario.Usuario = SecurityUtility.UserName;
            pedidoComentario.AuditoriaInsertDate = DateTime.Now;
            pedidoComentario.AuditoriaInsertUser = SecurityUtility.UserName;

            await AddAsync(pedidoComentario);
            await SaveChangesAsync();

            return pedidoComentario;
        }
    }
}