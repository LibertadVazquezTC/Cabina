﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using CabinaOperativa.Modelo;
using CabinaOperativa.Utilities;
using Dapper;
using Microsoft.Extensions.Configuration;

namespace CabinaOperativa.Repositories
{
    public class PedidoCoseguroRepository : GenericRepository<PedidoCoseguro>, IPedidoCoseguroRepository
    {
        private readonly IConfiguration _config;
        private readonly IPedidoTramoProveedorUMovilHorarioGdiaRealPersonalRepository _pedidoTramoProveedorUMovilHorarioGdiaRealPersonalRepository;
        private readonly IPedidoAfiliadoRepository _pedidoAfiliadoRepository;

        public PedidoCoseguroRepository(TechMedContext dbContext,
            IPedidoTramoProveedorUMovilHorarioGdiaRealPersonalRepository pedidoTramoProveedorUMovilHorarioGdiaRealPersonalRepository,
            IPedidoAfiliadoRepository pedidoAfiliadoRepository,
            IConfiguration config) : base(dbContext)
        {
            _pedidoTramoProveedorUMovilHorarioGdiaRealPersonalRepository = pedidoTramoProveedorUMovilHorarioGdiaRealPersonalRepository;
            _pedidoAfiliadoRepository = pedidoAfiliadoRepository;
            _config = config;
        }

        public IDbConnection Connection => new SqlConnection(_config.GetConnectionString("TechMedDatabase"));

        public async Task<PedidoCoseguro> Obtener(int pedidoCoseguroId)
        {
            return await GetByIdAsync(pedidoCoseguroId);
        }

        public async Task<PedidoCoseguro> ObtenerPorPedido(int pedidoId)
        {
            return await GetByConditionAsync(pc => pc.PedidoId == pedidoId && pc.Activo);
        }

        public async Task<PedidoCoseguro> ObtenerPorPedidoIncluyendoInactivos(int pedidoId)
        {
            return await GetByConditionAsync(pc => pc.PedidoId == pedidoId);
        }

        public async Task<PedidoCoseguro> InformarCierreCoseguro(PedidoCoseguro pedidoCoseguro, bool cobroCoseguro, int? pedidoCoseguroTipoNoCobroId)
        {
            pedidoCoseguro.InformadoCliente = true;
            pedidoCoseguro.PedidoCoseguroTipoNoCobroId = pedidoCoseguroTipoNoCobroId;
            pedidoCoseguro.Cobrado = cobroCoseguro;
            pedidoCoseguro.NumeroResolucion = null;
            pedidoCoseguro.InformadoPor = SecurityUtility.UserName;
            pedidoCoseguro.InformadoFecha = DateTime.Now;

            Update(pedidoCoseguro);
            await SaveChangesAsync();

            return pedidoCoseguro;
        }

        public async Task<PedidoCoseguro> Crear(int pedidoId,
            int coseguro,
            int? pedidoTramoProveedorUMovilHorarioId,
            int? pedidoTramoEfectorHorarioId,
            int? gdiaPersonalId)
        {
            try
            {
                PedidoCoseguro pedidoCoseguro = new PedidoCoseguro();
                pedidoCoseguro.PedidoId = pedidoId;
                pedidoCoseguro.PedidoTramoProveedorUMovilHorarioId = pedidoTramoProveedorUMovilHorarioId;
                pedidoCoseguro.PedidoTramoEfectorHorarioId = pedidoTramoEfectorHorarioId;
                pedidoCoseguro.GdiaPersonalId = gdiaPersonalId;
                pedidoCoseguro.Coseguro = coseguro;
                pedidoCoseguro.Recibido = false;
                pedidoCoseguro.FechaRecibido = null;
                pedidoCoseguro.Confirmado = false;
                pedidoCoseguro.FechaConfirmado = null;
                pedidoCoseguro.Cobrado = null;
                pedidoCoseguro.FechaCobrado = null;
                pedidoCoseguro.Activo = true;
                pedidoCoseguro.AuditoriaInsertUser = SecurityUtility.UserName;
                pedidoCoseguro.AuditoriaInsertDate = DateTime.Now;

                await AddAsync(pedidoCoseguro);
                await SaveChangesAsync();

                return pedidoCoseguro;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<PedidoCoseguro> Actualizar(PedidoCoseguro pedidoCoseguro,
            int coseguro,
            int? pedidoTramoProveedorUMovilHorarioId,
            int? pedidoTramoEfectorHorarioId,
            int? gdiaPersonalId)
        {
            try
            {
                pedidoCoseguro.PedidoTramoProveedorUMovilHorarioId = pedidoTramoProveedorUMovilHorarioId;
                pedidoCoseguro.PedidoTramoEfectorHorarioId = pedidoTramoEfectorHorarioId;
                pedidoCoseguro.GdiaPersonalId = gdiaPersonalId;
                pedidoCoseguro.Coseguro = coseguro;
                pedidoCoseguro.Recibido = false;
                pedidoCoseguro.FechaRecibido = null;
                pedidoCoseguro.Confirmado = false;
                pedidoCoseguro.FechaConfirmado = null;
                pedidoCoseguro.Cobrado = pedidoCoseguro?.Cobrado ?? null;
                pedidoCoseguro.FechaCobrado = pedidoCoseguro?.FechaCobrado ?? null;
                pedidoCoseguro.Activo = true;
                pedidoCoseguro.AuditoriaUpdateUser = SecurityUtility.UserName;
                pedidoCoseguro.AuditoriaUpdateDate = DateTime.Now;

                Update(pedidoCoseguro);
                await SaveChangesAsync();

                return pedidoCoseguro;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<PedidoCoseguro> Inactivar(PedidoCoseguro pedidoCoseguro)
        {
            pedidoCoseguro.Coseguro = 0;
            pedidoCoseguro.Activo = false;
            pedidoCoseguro.AuditoriaUpdateDate = DateTime.Now;
            pedidoCoseguro.AuditoriaInsertUser = SecurityUtility.UserName;

            Update(pedidoCoseguro);
            await SaveChangesAsync();

            return pedidoCoseguro;
        }

        public async Task<int> ObtenerCoseguroACobrar(int pedidoTramoProveedorUMovilHorarioId, bool esPmi, bool esDiscapacitado, bool esInternacionDomiciliaria)
        {
            //Esta lógica podria moverse a la función
            if (esPmi || esDiscapacitado || esInternacionDomiciliaria) return 0;

            using (IDbConnection conn = Connection)
            {
                var coseguroResponse = (await conn.QueryAsync<int>($"SELECT dbo.fn_PedidoCoseguroACobrar({pedidoTramoProveedorUMovilHorarioId})")).ToList();
                return coseguroResponse[0];
            }
        }

        public async Task<int> ObtenerCoseguroSugerido(int tipoPrestacionId, int contratoPlanId, int pedidoId, bool esPmi, bool esDiscapacitado, bool esInternacionDomiciliaria)
        {
            //Esta lógica podría moverse a la función
            if (esPmi || esDiscapacitado || esInternacionDomiciliaria) return 0;

            using (IDbConnection conn = Connection)
            {
                var coseguroResponse = (await conn.QueryAsync<int>($"SELECT dbo.fn_PedidoCosegurosSugerido({tipoPrestacionId}, {contratoPlanId}, {pedidoId}, 0)")).ToList();
                return coseguroResponse[0];
            }
        }
    }
}