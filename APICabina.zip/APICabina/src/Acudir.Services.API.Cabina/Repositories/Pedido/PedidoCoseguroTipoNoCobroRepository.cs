﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using CabinaOperativa.Enums;
using CabinaOperativa.Modelo;
using CabinaOperativa.Utilities;
using Dapper;
using Microsoft.Extensions.Configuration;

namespace CabinaOperativa.Repositories
{
    public class PedidoCoseguroTipoNoCobroRepository : GenericRepository<PedidoCoseguroTipoNoCobro>, IPedidoCoseguroTipoNoCobroRepository
    {

        public PedidoCoseguroTipoNoCobroRepository(TechMedContext dbContext) : base(dbContext)
        {
        }

        public async Task<IEnumerable<PedidoCoseguroTipoNoCobro>> Listar()
        {
            return await GetManyAsync(pctnc => pctnc.Activo);
        }
    }
}