﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CabinaOperativa.Modelo;
using CabinaOperativa.Utilities;
using Dapper;

namespace CabinaOperativa.Repositories
{
    public class PedidoDetalleRepository : GenericRepository<PedidoDetalle>, IPedidoDetalleRepository
    {
        private readonly IPedidoTriageVersionDetalleLogRepository _pedidoTriageVersionDetalleLogRepository;

        public PedidoDetalleRepository(TechMedContext dbContext,
            IPedidoTriageVersionDetalleLogRepository pedidoTriageVersionDetalleLogRepository) : base(dbContext)
        {
            _pedidoTriageVersionDetalleLogRepository = pedidoTriageVersionDetalleLogRepository;
        }

        public async Task<PedidoDetalle> ObtenerPorPedido(int pedidoId)
        {
            return await GetByConditionAsync(pd => pd.PedidoId == pedidoId);
        }

        public async Task<PedidoDetalle> Actualizar(PedidoDetalle pedidoDetalle)
        {
            pedidoDetalle.AuditoriaUpdateUser = SecurityUtility.UserName;
            pedidoDetalle.AuditoriaUpdateDate = DateTime.Now;

            Update(pedidoDetalle);
            await SaveChangesAsync();

            return pedidoDetalle;
        }

        public async Task<string> ObtenerSintomaPorPedido(int pedidoId)
        {
            try
            {
                PedidoDetalle pedidoDetalle = await ObtenerPorPedido(pedidoId);
                IEnumerable<PedidoTriageVersionDetalleLog> nodosDelTriageSeleccionados = await _pedidoTriageVersionDetalleLogRepository.ListarPorPedido(pedidoId);

                if (pedidoDetalle != null && pedidoDetalle.Sintoma != null)
                {
                    if (nodosDelTriageSeleccionados != null && nodosDelTriageSeleccionados.Count() > 0)
                    {
                        PedidoTriageVersionDetalleLog pedidoTriageVersionDetalleLog = nodosDelTriageSeleccionados.FirstOrDefault(
                            ptvdl => ptvdl.TriageVersionDetalle != null);

                        return pedidoTriageVersionDetalleLog != null ?
                            $"{pedidoTriageVersionDetalleLog.TriageVersionDetalle.Descripcion} - {pedidoDetalle.Sintoma.Descripcion}" :
                            $"{pedidoDetalle.Sintoma.Descripcion}";
                    }
                    else
                    {
                        return pedidoDetalle.Sintoma.Descripcion;
                    }
                }

                return string.Empty;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}