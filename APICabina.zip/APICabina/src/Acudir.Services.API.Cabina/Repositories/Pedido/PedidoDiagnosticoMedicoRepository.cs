﻿using System;
using System.Linq;
using System.Threading.Tasks;
using CabinaOperativa.Modelo;
using CabinaOperativa.Utilities;

namespace CabinaOperativa.Repositories
{
    public class PedidoDiagnosticoMedicoRepository : GenericRepository<PedidoDiagnosticoMedico>, IPedidoDiagnosticoMedicoRepository
    {   
        public PedidoDiagnosticoMedicoRepository(TechMedContext dbContext) : base(dbContext)
        {
        }

        public async Task<PedidoDiagnosticoMedico> ObtenerPorPedido(int pedidoId)
        {
            return (await GetManyAsync(pdm => pdm.PedidoId == pedidoId)).LastOrDefault();
        }

        public async Task<PedidoDiagnosticoMedico> Crear(int pedidoId, string descripcionManual, int? diagnosticoId)
        {
            PedidoDiagnosticoMedico pedidoDiagnosticoMedico = new PedidoDiagnosticoMedico();
            pedidoDiagnosticoMedico.PedidoId = pedidoId;
            pedidoDiagnosticoMedico.DiagnosticoId = diagnosticoId;
            pedidoDiagnosticoMedico.Descripcion = descripcionManual;
            pedidoDiagnosticoMedico.Hora = DateTime.Now;
            pedidoDiagnosticoMedico.Usuario = SecurityUtility.UserName;
            pedidoDiagnosticoMedico.AuditoriaInsertUser = SecurityUtility.UserName;
            pedidoDiagnosticoMedico.AuditoriaInsertDate = DateTime.Now;

            await AddAsync(pedidoDiagnosticoMedico);
            await SaveChangesAsync();

            return pedidoDiagnosticoMedico;
        }

        public async Task<PedidoDiagnosticoMedico> Actualizar(PedidoDiagnosticoMedico pedidoDiagnosticoMedico, string descripcionManual, int? diagnosticoId)
        {
            pedidoDiagnosticoMedico.DiagnosticoId = diagnosticoId;
            pedidoDiagnosticoMedico.Descripcion = descripcionManual;
            pedidoDiagnosticoMedico.Hora = DateTime.Now;
            pedidoDiagnosticoMedico.Usuario = SecurityUtility.UserName;
            pedidoDiagnosticoMedico.AuditoriaUpdateUser = SecurityUtility.UserName;
            pedidoDiagnosticoMedico.AuditoriaUpdateDate = DateTime.Now;

            Update(pedidoDiagnosticoMedico);
            await SaveChangesAsync();

            return pedidoDiagnosticoMedico;
        }
    }
}