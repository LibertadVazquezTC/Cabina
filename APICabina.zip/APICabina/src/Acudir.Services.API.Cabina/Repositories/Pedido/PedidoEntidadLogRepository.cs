﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using CabinaOperativa.DTOs;
using CabinaOperativa.Modelo;
using CabinaOperativa.Utilities;
using Dapper;
using Microsoft.Extensions.Configuration;

namespace CabinaOperativa.Repositories
{
    public class PedidoEntidadLogRepository : GenericRepository<PedidoEntidadLog>, IPedidoEntidadLogRepository
    {
        public PedidoEntidadLogRepository(TechMedContext dbContext) : base(dbContext)
        {
        }

        public async Task<PedidoEntidadLog> Crear(int pedidoId, int valor, int entidadLogTipoEstadoId, string accion)
        {
            try
            {
                PedidoEntidadLog pedidoEntidadLog = new PedidoEntidadLog();
                pedidoEntidadLog.PedidoId = pedidoId;
                pedidoEntidadLog.Valor = valor;
                pedidoEntidadLog.EntidadLogTipoEstadoId = entidadLogTipoEstadoId;
                pedidoEntidadLog.Fecha = DateTime.Now;
                pedidoEntidadLog.Usuario = SecurityUtility.UserName;
                pedidoEntidadLog.Accion = accion;
                pedidoEntidadLog.IP = SecurityUtility.RemoteIpAddress;

                await AddAsync(pedidoEntidadLog);
                await SaveChangesAsync();

                return pedidoEntidadLog;
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }

        }

        public async Task<PedidoEntidadLog> ObtenerPorPedidoYValorYEntidadLogTipoEstado(int pedidoId, int valor, int entidadLogTipoEstadoId)
        {
            return (await GetManyAsync(pel =>
                pel.PedidoId == pedidoId &&
                pel.Valor == valor &&
                pel.EntidadLogTipoEstadoId == entidadLogTipoEstadoId)).LastOrDefault();
        }
    }
}