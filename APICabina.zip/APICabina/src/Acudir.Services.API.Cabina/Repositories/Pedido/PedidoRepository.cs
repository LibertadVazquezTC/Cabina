﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using CabinaOperativa.Constants;
using CabinaOperativa.Enums;
using CabinaOperativa.Exceptions;
using CabinaOperativa.Modelo;
using CabinaOperativa.Utilities;
using Dapper;
using Microsoft.Extensions.Configuration;

namespace CabinaOperativa.Repositories
{
    public class PedidoRepository : GenericRepository<Pedido>, IPedidoRepository
    {
        private readonly IConfiguration _config;
        private readonly IPedidoComentarioRepository _pedidoComentarioRepository;

        public PedidoRepository(TechMedContext dbContext, IConfiguration config, IPedidoComentarioRepository pedidoComentarioRepository) : base(dbContext)
        {
            _config = config;
            _pedidoComentarioRepository = pedidoComentarioRepository;
        }

        public IDbConnection Connection => new SqlConnection(_config.GetConnectionString("TechMedDatabase"));

        public async Task<Pedido> Obtener(int pedidoId)
        {
            return await GetByIdAsync(pedidoId);
        }

        public async Task<Pedido> Actualizar(Pedido pedido)
        {
            pedido.AuditoriaUpdateUser = SecurityUtility.UserName;
            pedido.AuditoriaUpdateDate = DateTime.Now;

            Update(pedido);
            await SaveChangesAsync();

            return pedido;
        }

        public async Task<string> ListarJson()
        {
            using (IDbConnection conn = Connection)
            {
                var jsonResponse = (await conn.QueryAsync<string>($"SELECT dbo.fn_JsonDTO_Pedido({0})")).ToList();
                var jsonResult = "";
                for (int i = 0; i < jsonResponse.Count(); i++) jsonResult += jsonResponse[i];
                return jsonResult;
            }
        }

        public async Task<string> ObtenerJson(int pedidoId)
        {
            using (IDbConnection conn = Connection)
            {
                var jsonResponse = (await conn.QueryAsync<string>($"select dbo.fn_JsonDTO_Pedido({pedidoId})")).ToList();
                var jsonResult = "";
                for (int i = 0; i < jsonResponse.Count(); i++) jsonResult += jsonResponse[i];
                return jsonResult;
            }
        }

        public async Task<string> ObtenerTrazabilidadJson(int pedidoId)
        {
            using (IDbConnection conn = Connection)
            {
                var p = new DynamicParameters();
                p.Add("@PedidoId", pedidoId);

                var jsonResponse = (await conn.QueryAsync<string>("usp_JsonDTO_PedidoTrazabilidad_Log", p, commandType: CommandType.StoredProcedure)).ToList();
                var jsonResult = "";
                for (int i = 0; i < jsonResponse.Count(); i++) jsonResult += jsonResponse[i];
                return jsonResult;
            }
        }

        public async Task<Pedido> ActualizarEstado(int pedidoId, int pedidoEstadoId, int? pedidoEstadoTipoId, string nuevoComentario)
        {
            try
            {
                Pedido pedido = await GetByIdAsync(pedidoId);
                pedido.PedidoEstadoId = pedidoEstadoId;
                pedido.PedidoEstadoTipoId = pedidoEstadoTipoId;
                pedido.AuditoriaUpdateUser = SecurityUtility.UserName;
                pedido.AuditoriaUpdateDate = DateTime.Now;

                Update(pedido);
                await SaveChangesAsync();

                if (!string.IsNullOrEmpty(nuevoComentario))
                    await _pedidoComentarioRepository.Crear(pedidoId, nuevoComentario, (int)CmnComentarioTipoEnum.CambioDeEstado);

                return pedido;
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }
        }

        public async Task<Pedido> ActualizarPacientePsiquiatrico(int pedidoId, bool pacientePsiquiatrico)
        {
            try
            {
                Pedido pedido = await GetByIdAsync(pedidoId);
                if (pedido is null)
                    throw new DatoErroneoException($"No se encontró pedido con id: {pedidoId}.");

                pedido.PacientePsiquiatrico = pacientePsiquiatrico;
                pedido.AuditoriaUpdateUser = SecurityUtility.UserName;
                pedido.AuditoriaUpdateDate = DateTime.Now;

                Update(pedido);
                await SaveChangesAsync();

                return pedido;
            }

            catch (Exception)
            {
                throw;
            }
        }

        public async Task<Pedido> ActualizarRecurso(int pedidoId, int pedidoTipoDespachoId)
        {
            try
            {
                Pedido pedido = await GetByIdAsync(pedidoId);

                pedido.PedidoTipoDespachoId = pedidoTipoDespachoId;
                pedido.AuditoriaUpdateUser = SecurityUtility.UserName;
                pedido.AuditoriaUpdateDate = DateTime.Now;

                Update(pedido);
                await SaveChangesAsync();

                return pedido;

            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }
        }

        public async Task<int> RecategorizarPedido(int pedidoId, int tipoPrestacionId, string nuevoSintoma, string comentario, int? sintomaId)
        {
            try
            {
                int pedidoIdNuevo = 0;
                var pedidoIdNuevoParam = new SqlParameter("@PedidoIdNuevo", pedidoIdNuevo) { Direction = ParameterDirection.Output };

                await ExecuteSqlCommandAsync("exec usp_PedidoNuevoInsertClonadoParcial @PedidoId, @TipoPrestacionId, @SintomaTomado, @Usuario, @Comentario, @PedidoIdNuevo OUTPUT",
                    new SqlParameter("@PedidoId", pedidoId) { Direction = ParameterDirection.Input },
                    new SqlParameter("@TipoPrestacionId", tipoPrestacionId) { Direction = ParameterDirection.Input },
                    new SqlParameter("@SintomaTomado", nuevoSintoma) { Direction = ParameterDirection.Input },
                    new SqlParameter("@Usuario", SecurityUtility.UserName) { Direction = ParameterDirection.Input },
                    new SqlParameter("@Comentario", comentario) { Direction = ParameterDirection.Input },
                    pedidoIdNuevoParam);

                pedidoIdNuevo = Convert.ToInt32(pedidoIdNuevoParam.Value);
                return pedidoIdNuevo;
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }
        }

        public async Task<Pedido> AcualizarTipoPrestacion(int pedidoId, int tipoPrestacionId, int pedidoTipoDespachoId, string comentario)
        {
            Pedido pedido = await GetByIdAsync(pedidoId);
            pedido.PedidoTipoDespachoId = pedidoTipoDespachoId;
            pedido.TipoPrestacionId = tipoPrestacionId;
            pedido.AuditoriaUpdateUser = SecurityUtility.UserName;
            pedido.AuditoriaUpdateDate = DateTime.Now;

            Update(pedido);
            await SaveChangesAsync();

            await _pedidoComentarioRepository.Crear(pedidoId, comentario, (int)CmnComentarioTipoEnum.CambioDeEstado);

            return pedido;
        }
    }
}