﻿using CabinaOperativa.Modelo;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public class PedidoResultadoLaboratorioTipoPrestacionRepository : GenericRepository<PedidoResultadoLaboratorioTipoPrestacion>, IPedidoResultadoLaboratorioTipoPrestacionRepository
    {   
        public PedidoResultadoLaboratorioTipoPrestacionRepository(TechMedContext dbContext) : base(dbContext)
        {
        }

        public async Task<IEnumerable<PedidoResultadoLaboratorioTipoPrestacion>> ListarByTipoPrestacion(int tipoPrestacionId)
        {
            return await GetManyAsync(prltp => prltp.TipoPrestacion.TipoPrestacionId == tipoPrestacionId && prltp.Activo);
        }

    }
}