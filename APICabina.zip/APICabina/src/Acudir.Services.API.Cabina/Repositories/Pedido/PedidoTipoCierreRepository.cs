﻿using CabinaOperativa.Modelo;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public class PedidoTipoCierreRepository : GenericRepository<PedidoTipoCierre>, IPedidoTipoCierreRepository
    {   
        public PedidoTipoCierreRepository(TechMedContext dbContext) : base(dbContext)
        {
        }   
        
        public async Task<IEnumerable<PedidoTipoCierre>> Listar()
        {
           return await GetManyAsync(ptc => ptc.Activo);
        }
    }
}