﻿using System;
using System.Threading.Tasks;
using CabinaOperativa.Enums;
using CabinaOperativa.Modelo;
using CabinaOperativa.Utilities;
using Microsoft.EntityFrameworkCore;

namespace CabinaOperativa.Repositories
{
    public class PedidoTramoDetalleRepository : GenericRepository<PedidoTramoDetalle>, IPedidoTramoDetalleRepository
    {

        public PedidoTramoDetalleRepository(TechMedContext dbContext) : base(dbContext)
        {

        }

        public async Task<PedidoTramoDetalle> Obtener(int pedidoTramoDetalleId)
        {
            return await GetByIdAsync(pedidoTramoDetalleId);
        }

        public async Task<PedidoTramoDetalle> Actualizar(PedidoTramoDetalle pedidoTramoDetalle)
        {
            pedidoTramoDetalle.Activo = true;
            pedidoTramoDetalle.AuditoriaUpdateDate = DateTime.Now;
            pedidoTramoDetalle.AuditoriaUpdateUser = SecurityUtility.UserName;

            Update(pedidoTramoDetalle);
            await SaveChangesAsync();

            return pedidoTramoDetalle;
        }

        public async Task<PedidoTramoDetalle> ObtenerPorPedidoTramoYTipo(int pedidoTramoId, OrigenDestinoEnum origenDestino)
        {
            return await GetByConditionAsync(ptd => ptd.PedidoTramoId == pedidoTramoId &&
                ptd.OrigenDestino == (int)origenDestino &&
                ptd.Activo);
        }
    }
}