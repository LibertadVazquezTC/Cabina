﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using CabinaOperativa.DTOs;
using CabinaOperativa.Enums;
using CabinaOperativa.Exceptions;
using CabinaOperativa.Modelo;
using CabinaOperativa.Utilities;
using Microsoft.Extensions.Configuration;

namespace CabinaOperativa.Repositories
{
    public class PedidoTramoEfectorHorarioRepository : GenericRepository<PedidoTramoEfectorHorario>, IPedidoTramoEfectorHorarioRepository
    {
        private readonly IConfiguration _config;
        private readonly IPedidoEntidadLogRepository _pedidoEntidadLogRepository;

        public PedidoTramoEfectorHorarioRepository(TechMedContext dbContext, IConfiguration config, IPedidoEntidadLogRepository pedidoEntidadLogRepository) : base(dbContext)
        {
            _config = config;
            _pedidoEntidadLogRepository = pedidoEntidadLogRepository;
        }

        public IDbConnection Connection => new SqlConnection(_config.GetConnectionString("TechMedDatabase"));

        public async Task<PedidoTramoEfectorHorario> Obtener(int pedidoTramoEfectorHorarioId)
        {
            return await GetByIdAsync(pedidoTramoEfectorHorarioId);
        }

        public async Task<IEnumerable<PedidoTramoEfectorHorario>> ObtenerPorPedido(int pedidoId)
        {
            return await GetManyAsync(pteh =>
                pteh.PedidoTramo.PedidoId == pedidoId &&
                pteh.Activo &&
                pteh.PedidoTramo.Activo);
        }

        public async Task<PedidoTramoEfectorHorario> ActualizarHorario(int pedidoTramoEfectorHorarioId, string tipoHorario, DateTime horario)
        {
            try
            {
                await ExecuteSqlCommandAsync("usp_ApiInt_PedidoTramoEfectorHorario_update @PedidoTramoEfectorHorarioId, @Campo, @Horario, @ForzarUpdate",
                    new SqlParameter("@PedidoTramoEfectorHorarioId", pedidoTramoEfectorHorarioId),
                    new SqlParameter("@Campo", tipoHorario),
                    new SqlParameter("@Horario", horario),
                    new SqlParameter("@ForzarUpdate", true));

                PedidoTramoEfectorHorario pedidoTramoEfectorHorario = await GetByIdAsync(pedidoTramoEfectorHorarioId);
                await ReloadAsync(pedidoTramoEfectorHorario);
                return pedidoTramoEfectorHorario;
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }
        }

        public async Task<PedidoTramoEfectorHorario> ObtenerPrimeraAsignacionApoyoPorTramo(int pedidoTramoId)
        {
            return (await GetManyAsync(pteh =>
                pteh.PedidoTramoId == pedidoTramoId &&
                pteh.Activo &&
                pteh.Apoyo)).FirstOrDefault();
        }

        public async Task<PedidoTramoEfectorHorario> ConvertirEnAsignacionPrincipal(PedidoTramoEfectorHorario pedidoTramoEfectorHorario)
        {
            pedidoTramoEfectorHorario.Apoyo = false;
            pedidoTramoEfectorHorario.Activo = true;
            pedidoTramoEfectorHorario.AuditoriaUpdateDate = DateTime.Now;
            pedidoTramoEfectorHorario.AuditoriaUpdateUser = SecurityUtility.UserName;

            Update(pedidoTramoEfectorHorario);
            await SaveChangesAsync();

            return pedidoTramoEfectorHorario;
        }


        public async Task<PedidoTramoEfectorHorario> CrearAsignacion(int pedidoTramoId, int efectorId, bool esApoyo)
        {
            try
            {
                PedidoTramoEfectorHorario pedidoTramoEfectorHorario = new PedidoTramoEfectorHorario();

                pedidoTramoEfectorHorario.EfectorId = efectorId;
                pedidoTramoEfectorHorario.PedidoTramoId = pedidoTramoId;
                pedidoTramoEfectorHorario.Apoyo = esApoyo;
                pedidoTramoEfectorHorario.Origen = true;
                pedidoTramoEfectorHorario.Destino = false;
                pedidoTramoEfectorHorario.PedidoTramoEfectorHorarioEstadoId = (int)PedidoTramoEfectorHorarioEstadoEnum.Negociando;
                pedidoTramoEfectorHorario.Activo = true;
                pedidoTramoEfectorHorario.AuditoriaInsertDate = DateTime.Now;
                pedidoTramoEfectorHorario.AuditoriaInsertUser = SecurityUtility.UserName;

                await AddAsync(pedidoTramoEfectorHorario);
                await SaveChangesAsync();

                return pedidoTramoEfectorHorario;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<PedidoTramoEfectorHorario> Desasignar(PedidoTramoEfectorHorario pedidoTramoEfectorHorario)
        {
            try
            {
                pedidoTramoEfectorHorario.PedidoTramoEfectorHorarioEstadoId = (int)PedidoTramoEfectorHorarioEstadoEnum.Anulado;
                pedidoTramoEfectorHorario.Activo = false;
                pedidoTramoEfectorHorario.AuditoriaUpdateDate = DateTime.Now;
                pedidoTramoEfectorHorario.AuditoriaUpdateUser = SecurityUtility.UserName;

                Update(pedidoTramoEfectorHorario);
                await SaveChangesAsync();

                return pedidoTramoEfectorHorario;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<PedidoTramoEfectorHorario> Actualizar(PedidoTramoEfectorHorario pedidoTramoEfectorHorario)
        {
            try
            {
                pedidoTramoEfectorHorario.Activo = true;
                pedidoTramoEfectorHorario.AuditoriaUpdateDate = DateTime.Now;
                pedidoTramoEfectorHorario.AuditoriaUpdateUser = SecurityUtility.UserName;

                Update(pedidoTramoEfectorHorario);
                await SaveChangesAsync();

                return pedidoTramoEfectorHorario;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<PedidoTramoEfectorHorario> ActualizarEstado(int pedidoTramoEfectorHorarioId, int pedidoTramoEfectorHorarioEstadoId)
        {
            try
            {
                PedidoTramoEfectorHorario pedidoTramoEfectorHorario = await GetByIdAsync(pedidoTramoEfectorHorarioId);
                pedidoTramoEfectorHorario.Activo = true;
                pedidoTramoEfectorHorario.PedidoTramoEfectorHorarioEstadoId = pedidoTramoEfectorHorarioEstadoId;

                if (pedidoTramoEfectorHorarioEstadoId == (int)PedidoTramoEfectorHorarioEstadoEnum.Anulado || pedidoTramoEfectorHorarioEstadoId == (int)PedidoTramoEfectorHorarioEstadoEnum.Rechazado)
                    pedidoTramoEfectorHorario.Activo = false;

                Update(pedidoTramoEfectorHorario);
                await SaveChangesAsync();

                return pedidoTramoEfectorHorario;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<int> CantidadDeAsignacionesPrincipales(int pedidoTramoId)
        {
            return (await GetManyAsync(ptpeh => ptpeh.PedidoTramoId == pedidoTramoId &&
                ptpeh.Activo &&
                !ptpeh.Apoyo)).Count();
        }

        public async Task ValidarSiPuedeActualizarHorarios(int pedidoTramoEfectorHorarioId, string tipoHorario, DateTime horario)
        {
            PedidoTramoEfectorHorario pedidoTramoEfectorHorarioExistente = await GetByIdAsync(pedidoTramoEfectorHorarioId);

            //Valido que los horarios sean coherentes
            if (tipoHorario == "OrigenPartida")
            {
                if (pedidoTramoEfectorHorarioExistente.OrigenArribo is null)
                    throw new ReglaDeNegocioException("Debe ingresar primero el arribo al origen.");

                if (horario < pedidoTramoEfectorHorarioExistente.OrigenArribo)
                    throw new ReglaDeNegocioException("La partida del origen no puede ser menor que el arribo.");

                if (horario == pedidoTramoEfectorHorarioExistente.OrigenArribo)
                    throw new ReglaDeNegocioException("La partida del origen no puede ser la misma que la del arribo.");
            }

            if (tipoHorario == "OrigenArribo")
            {
                if (horario > pedidoTramoEfectorHorarioExistente.OrigenPartida)
                    throw new ReglaDeNegocioException("El arribo ingresado no puede ser mayor a la partida del origen.");

                if (horario == pedidoTramoEfectorHorarioExistente.OrigenPartida)
                    throw new ReglaDeNegocioException("El arribo ingresado no puede ser el mismo que la partida del origen.");
            }

            if (pedidoTramoEfectorHorarioExistente.PedidoTramo.Pedido.FechaInicioToma > horario)
                throw new ReglaDeNegocioException("No se puede introducir una fecha-hora menor que la del inicio de la toma.");
        }
    }
}