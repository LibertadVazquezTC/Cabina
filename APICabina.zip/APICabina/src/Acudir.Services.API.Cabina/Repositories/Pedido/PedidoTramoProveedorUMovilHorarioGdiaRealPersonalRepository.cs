﻿using CabinaOperativa.Enums;
using CabinaOperativa.Exceptions;
using CabinaOperativa.Modelo;
using CabinaOperativa.Utilities;
using Dapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public class PedidoTramoProveedorUMovilHorarioGdiaRealPersonalRepository : GenericRepository<PedidoTramoProveedorUMovilHorarioGdiaRealPersonal>, IPedidoTramoProveedorUMovilHorarioGdiaRealPersonalRepository
    {

        private readonly IConfiguration _config;
        private readonly IGdiaRealPersonalDetalleRepository _gdiaRealPersonalDetalleRepository;

        public PedidoTramoProveedorUMovilHorarioGdiaRealPersonalRepository(TechMedContext dbContext,
            IConfiguration config,
            IGdiaRealPersonalDetalleRepository gdiaRealPersonalDetalleRepository) : base(dbContext)
        {
            _config = config;
            _gdiaRealPersonalDetalleRepository = gdiaRealPersonalDetalleRepository;
        }

        public IDbConnection Connection => new SqlConnection(_config.GetConnectionString("TechMedDatabase"));

        public async Task<IEnumerable<PedidoTramoProveedorUMovilHorarioGdiaRealPersonal>> GenerarIntegrantesDelEquipo(int pedidoTramoProveedorUMovilHorarioId, int? gdiaRealEquipoId)
        {
            if (gdiaRealEquipoId is null || gdiaRealEquipoId == 0) return new List<PedidoTramoProveedorUMovilHorarioGdiaRealPersonal>();

            await InactivarIntegrantesAnteriores(pedidoTramoProveedorUMovilHorarioId);

            IEnumerable<GdiaRealPersonalDetalle> gdiaRealPersonalDetalles = await _gdiaRealPersonalDetalleRepository.ObtenerPorGdiaRealEquipo(gdiaRealEquipoId.Value);
            if (gdiaRealPersonalDetalles is null || gdiaRealPersonalDetalles.Count() == 0)
                throw new DatoErroneoException($"No se encontraron integrantes para la gdiaRealEquipo con id: {gdiaRealEquipoId}.");

            List<PedidoTramoProveedorUMovilHorarioGdiaRealPersonal> pedidoTramoProveedorUMovilHorarioGdiaRealPersonalIntegrantes = new List<PedidoTramoProveedorUMovilHorarioGdiaRealPersonal>();

            foreach (GdiaRealPersonalDetalle gdiaRealPersonalDetalle in gdiaRealPersonalDetalles)
            {
                PedidoTramoProveedorUMovilHorarioGdiaRealPersonal pedidoTramoProveedorUMovilHorarioGdiaRealPersonal = new PedidoTramoProveedorUMovilHorarioGdiaRealPersonal();
                pedidoTramoProveedorUMovilHorarioGdiaRealPersonal.PedidoTramoProveedorUMovilHorarioId = pedidoTramoProveedorUMovilHorarioId;
                pedidoTramoProveedorUMovilHorarioGdiaRealPersonal.GdiaRealPersonalId = gdiaRealPersonalDetalle.GdiaRealPersonalId;
                pedidoTramoProveedorUMovilHorarioGdiaRealPersonal.GdiaRealPersonalDetalleId = gdiaRealPersonalDetalle.GdiaRealPersonalDetalleId;
                pedidoTramoProveedorUMovilHorarioGdiaRealPersonal.Activo = true;
                pedidoTramoProveedorUMovilHorarioGdiaRealPersonal.AuditoriaInsertUser = SecurityUtility.UserName;
                pedidoTramoProveedorUMovilHorarioGdiaRealPersonal.AuditoriaInsertDate = DateTime.Now;

                using (IDbConnection connection = Connection)
                    pedidoTramoProveedorUMovilHorarioGdiaRealPersonal.GdiaComponenteId = await connection.ExecuteScalarAsync<int>($"SELECT dbo.fn_GdiaObtenerEstructuraRealComponenteId({gdiaRealPersonalDetalle.GdiaRealPersonalDetalleId})");

                if (pedidoTramoProveedorUMovilHorarioGdiaRealPersonal.GdiaComponenteId == 0)
                    pedidoTramoProveedorUMovilHorarioGdiaRealPersonal.GdiaComponenteId = null;

                pedidoTramoProveedorUMovilHorarioGdiaRealPersonalIntegrantes.Add(pedidoTramoProveedorUMovilHorarioGdiaRealPersonal);
                Update(pedidoTramoProveedorUMovilHorarioGdiaRealPersonal);
            }

            await SaveChangesAsync();

            return pedidoTramoProveedorUMovilHorarioGdiaRealPersonalIntegrantes;
        }

        private async Task InactivarIntegrantesAnteriores(int pedidoTramoProveedorUMovilHorarioId)
        {
            IEnumerable<PedidoTramoProveedorUMovilHorarioGdiaRealPersonal> integrantesDelEquipo = await GetManyAsync(ptpumhgrp => 
                ptpumhgrp.PedidoTramoProveedorUMovilHorarioId == pedidoTramoProveedorUMovilHorarioId &&
                ptpumhgrp.Activo);

            if (integrantesDelEquipo is null) return;
            if (integrantesDelEquipo.Count() == 0) return;

            foreach (PedidoTramoProveedorUMovilHorarioGdiaRealPersonal pedidoTramoProveedorUMovilHorarioGdiaRealPersonal in integrantesDelEquipo)
            {
                pedidoTramoProveedorUMovilHorarioGdiaRealPersonal.Activo = false;
                pedidoTramoProveedorUMovilHorarioGdiaRealPersonal.AuditoriaUpdateDate = DateTime.Now;
                pedidoTramoProveedorUMovilHorarioGdiaRealPersonal.AuditoriaUpdateUser = Thread.CurrentPrincipal.Identity.Name;

                Update(pedidoTramoProveedorUMovilHorarioGdiaRealPersonal);
            }
            await SaveChangesAsync();
        }

        public async Task<PedidoTramoProveedorUMovilHorarioGdiaRealPersonal> ObtenerResponsableCoseguro(int pedidoTramoProveedorUMovilHorarioId)
        {
            IEnumerable<PedidoTramoProveedorUMovilHorarioGdiaRealPersonal> pedidoTramoProveedorUMovilHorarioGdiaRealPersonalDotacion = await GetManyAsync(ptpuhgrp =>
                ptpuhgrp.PedidoTramoProveedorUMovilHorarioId == pedidoTramoProveedorUMovilHorarioId &&
                ptpuhgrp.Activo);

            PedidoTramoProveedorUMovilHorarioGdiaRealPersonal pedidoTramoProveedorUMovilHorarioGdiaRealPersonal = new PedidoTramoProveedorUMovilHorarioGdiaRealPersonal();

            pedidoTramoProveedorUMovilHorarioGdiaRealPersonal = pedidoTramoProveedorUMovilHorarioGdiaRealPersonalDotacion.FirstOrDefault(ptpuhgrp =>
                  ptpuhgrp.GdiaComponenteId == (int)ComponenteTipoEnum.Medico &&
                  ptpuhgrp.Activo);

            if (pedidoTramoProveedorUMovilHorarioGdiaRealPersonal == null)
            {
                pedidoTramoProveedorUMovilHorarioGdiaRealPersonal = pedidoTramoProveedorUMovilHorarioGdiaRealPersonalDotacion.FirstOrDefault(ptpuhgrp =>
                      ptpuhgrp.GdiaComponenteId == (int)ComponenteTipoEnum.Chofer &&
                      ptpuhgrp.Activo);
            }

            return pedidoTramoProveedorUMovilHorarioGdiaRealPersonal;
        }

        public async Task<IEnumerable<PedidoTramoProveedorUMovilHorarioGdiaRealPersonal>> ObtenerIntegrantesDeUnaAsignacion(int pedidoTramoProveedorUMovilHorarioId)
        {
            return await GetManyAsync(ptpuhgrp => ptpuhgrp.PedidoTramoProveedorUMovilHorarioId == pedidoTramoProveedorUMovilHorarioId &&
                ptpuhgrp.Activo);
        }
    }
}