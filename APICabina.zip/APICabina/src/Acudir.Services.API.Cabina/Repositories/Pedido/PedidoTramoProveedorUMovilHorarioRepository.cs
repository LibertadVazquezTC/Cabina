﻿using CabinaOperativa.Enums;
using CabinaOperativa.Exceptions;
using CabinaOperativa.Modelo;
using CabinaOperativa.Utilities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public class PedidoTramoProveedorUMovilHorarioRepository : GenericRepository<PedidoTramoProveedorUMovilHorario>, IPedidoTramoProveedorUMovilHorarioRepository
    {
        private readonly IConfiguration _config;
        private readonly IPedidoCoseguroRepository _pedidoCoseguroRepository;
        private readonly IUMovilRepository _uMovilRepository;
        private readonly IProveedorRepository _proveedorRepository;
        private readonly IGdiaRealEquipoMovilRepository _gdiaRealEquipoMovilRepository;
        private readonly IPedidoTramoRepository _pedidoTramoRepository;

        public PedidoTramoProveedorUMovilHorarioRepository(TechMedContext dbContext,
            IConfiguration config,
            IPedidoCoseguroRepository pedidoCoseguroRepository,
            IUMovilRepository uMovilRepository,
            IProveedorRepository proveedorRepository,
            IPedidoTramoRepository pedidoTramoRepository,
            IGdiaRealEquipoMovilRepository gdiaRealEquipoMovilRepository) : base(dbContext)
        {
            _config = config;
            _pedidoCoseguroRepository = pedidoCoseguroRepository;
            _uMovilRepository = uMovilRepository;
            _proveedorRepository = proveedorRepository;
            _gdiaRealEquipoMovilRepository = gdiaRealEquipoMovilRepository;
            _pedidoTramoRepository = pedidoTramoRepository;
        }

        public IDbConnection Connection => new SqlConnection(_config.GetConnectionString("TechMedDatabase"));

        public async Task<PedidoTramoProveedorUMovilHorario> Obtener(int pedidoTramoProveedorUMovilHorarioId)
        {
            return await GetByIdAsync(pedidoTramoProveedorUMovilHorarioId);
        }

        public async Task<IEnumerable<PedidoTramoProveedorUMovilHorario>> ObtenerPorPedido(int pedidoId)
        {
            return await GetManyAsync(ptpuh =>
                ptpuh.PedidoTramo.PedidoId == pedidoId &&
                ptpuh.Activo &&
                ptpuh.PedidoTramo.Activo);
        }

        public async Task<IEnumerable<PedidoTramoProveedorUMovilHorario>> ObtenerPorPedido(int pedidoId, bool conPreasignados)
        {
            if (conPreasignados)
                return await ObtenerPorPedido(pedidoId);

            return await GetManyAsync(ptpuh =>
                ptpuh.PedidoTramo.PedidoId == pedidoId &&
                ptpuh.PedidoTramoProveedorUMovilHorarioEstadoId != (int)PedidoTramoProveedorUMovilHorarioEstadoEnum.PreDespacho &&
                ptpuh.Activo &&
                ptpuh.PedidoTramo.Activo);
        }

        public async Task<PedidoTramoProveedorUMovilHorario> ObtenerPorPedidoTramoYGdiaRealEquipo(int pedidoTramoId, int gdiaRealEquipoId)
        {
            return await GetByConditionAsync(ptpuh =>
                ptpuh.PedidoTramoId == pedidoTramoId &&
                ptpuh.GdiaRealEquipoId == gdiaRealEquipoId &&
                ptpuh.Activo);
        }

        public async Task<PedidoTramoProveedorUMovilHorario> ObtenerPorPedidoYGdiaRealEquipo(int pedidoId, int gdiaRealEquipoId)
        {
            return await GetByConditionAsync(ptpuh =>
                ptpuh.PedidoTramo.PedidoId == pedidoId &&
                ptpuh.GdiaRealEquipoId == gdiaRealEquipoId &&
                ptpuh.Activo);
        }

        public async Task<IEnumerable<PedidoTramoProveedorUMovilHorario>> ObtenerPorPedidoTramoDetalle(int pedidoTramoDetalleId)
        {
            return await GetManyAsync(ptpuh =>
                ptpuh.Activo &&
                ptpuh.PedidoTramo.Activo &&
                ptpuh.PedidoTramo.PedidoTramoDetalle.Any(ptd => ptd.PedidoTramoDetalleId == pedidoTramoDetalleId));
        }

        public async Task<int> CantidadAsignacionesDelEquipo(int gdiaRealEquipoId)
        {
            //Esto puede fallar. Hay que tomar al médico del equipo y no al equipo entero.
            IEnumerable<PedidoTramoProveedorUMovilHorario> asignacionesDelEquipo = await GetManyAsync(ptpuh =>
                ptpuh.GdiaRealEquipoId == gdiaRealEquipoId &&
                ptpuh.PedidoTramoProveedorUMovilHorarioEstadoId == (int)PedidoTramoProveedorUMovilHorarioEstadoEnum.Despachado &&
                ptpuh.Activo &&
                ptpuh.PedidoTramo.Activo);

            return asignacionesDelEquipo.Count();
        }

        public async Task<PedidoTramoProveedorUMovilHorario> CrearAsignacion(int pedidoTramoId, int gdiaRealEquipoId, int proveedorId, bool esApoyo)
        {
            IEnumerable<GdiaRealEquipoMovil> gdiaRealEquipoMoviles = await _gdiaRealEquipoMovilRepository.ObtenerPorGdiaRealEquipo(gdiaRealEquipoId);

            int? uMovilId = gdiaRealEquipoMoviles?.LastOrDefault()?.UMovilId;
            UMovil uMovil = uMovilId.HasValue ? await _uMovilRepository.Obtener(uMovilId.Value) : null;

            Proveedor proveedor = await _proveedorRepository.Obtener(proveedorId);

            PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario = new PedidoTramoProveedorUMovilHorario();
            pedidoTramoProveedorUMovilHorario.PedidoTramoId = pedidoTramoId;
            pedidoTramoProveedorUMovilHorario.GdiaRealEquipoId = gdiaRealEquipoId != 0 ? gdiaRealEquipoId : (int?)null;
            pedidoTramoProveedorUMovilHorario.UMovil = uMovil;
            pedidoTramoProveedorUMovilHorario.UMovilId = uMovilId;
            pedidoTramoProveedorUMovilHorario.Proveedor = proveedor;
            pedidoTramoProveedorUMovilHorario.ProveedorId = proveedorId;
            pedidoTramoProveedorUMovilHorario.RequiereMovil = proveedor.RequiereMovil;
            pedidoTramoProveedorUMovilHorario.Factura = proveedor.Factura;
            pedidoTramoProveedorUMovilHorario.Audita = proveedor.Audita;

            pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioEstadoId = proveedor.RequiereMovil ?
                (int)PedidoTramoProveedorUMovilHorarioEstadoEnum.Despachado :
                (int)PedidoTramoProveedorUMovilHorarioEstadoEnum.NegociandoProveedor;

            pedidoTramoProveedorUMovilHorario.Origen = true;
            pedidoTramoProveedorUMovilHorario.Destino = false;
            pedidoTramoProveedorUMovilHorario.Apoyo = esApoyo;
            pedidoTramoProveedorUMovilHorario.ReportIngresado = false;
            pedidoTramoProveedorUMovilHorario.Activo = true;
            pedidoTramoProveedorUMovilHorario.AuditoriaInsertUser = SecurityUtility.UserName;
            pedidoTramoProveedorUMovilHorario.AuditoriaInsertDate = DateTime.Now;

            await AddAsync(pedidoTramoProveedorUMovilHorario);
            await SaveChangesAsync();
            var pedidoTramo = await _pedidoTramoRepository.Obtener(pedidoTramoId);
            if (pedidoTramo != null)
            {
                var pedidoCoseguro = await _pedidoCoseguroRepository.ObtenerPorPedido(pedidoTramo.PedidoId);
                if (pedidoCoseguro != null)
                {
                    await _pedidoCoseguroRepository.Actualizar(pedidoCoseguro, Convert.ToInt32(pedidoCoseguro.Coseguro), pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioId, pedidoCoseguro.PedidoTramoEfectorHorario?.PedidoTramoEfectorHorarioId, pedidoCoseguro.GdiaPersonalId );
                }
            }

            await SaveChangesAsync();

            return pedidoTramoProveedorUMovilHorario;
        }

        public async Task<PedidoTramoProveedorUMovilHorario> CrearPreasignacion(int pedidoTramoId, int gdiaRealEquipoId, int proveedorId, bool esApoyo)
        {
            IEnumerable<GdiaRealEquipoMovil> gdiaRealEquipoMoviles = await _gdiaRealEquipoMovilRepository.ObtenerPorGdiaRealEquipo(gdiaRealEquipoId);

            int? uMovilId = gdiaRealEquipoMoviles?.LastOrDefault()?.UMovilId;
            UMovil uMovil = uMovilId.HasValue ? await _uMovilRepository.Obtener(uMovilId.Value) : null;

            Proveedor proveedor = await _proveedorRepository.Obtener(proveedorId);

            PedidoTramoProveedorUMovilHorario PedidoTramoProveedorUMovilHorario = new PedidoTramoProveedorUMovilHorario();
            PedidoTramoProveedorUMovilHorario.PedidoTramoId = pedidoTramoId;
            PedidoTramoProveedorUMovilHorario.GdiaRealEquipoId = gdiaRealEquipoId != 0 ? gdiaRealEquipoId : (int?)null;
            PedidoTramoProveedorUMovilHorario.UMovil = uMovil;
            PedidoTramoProveedorUMovilHorario.UMovilId = uMovilId;
            PedidoTramoProveedorUMovilHorario.Proveedor = proveedor;
            PedidoTramoProveedorUMovilHorario.ProveedorId = proveedorId;
            PedidoTramoProveedorUMovilHorario.RequiereMovil = proveedor.RequiereMovil;
            PedidoTramoProveedorUMovilHorario.Factura = proveedor.Factura;
            PedidoTramoProveedorUMovilHorario.Audita = proveedor.Audita;

            PedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioEstadoId = proveedor.RequiereMovil ?
                (int)PedidoTramoProveedorUMovilHorarioEstadoEnum.PreDespacho :
                (int)PedidoTramoProveedorUMovilHorarioEstadoEnum.NegociandoProveedor;
            PedidoTramoProveedorUMovilHorario.Origen = true;
            PedidoTramoProveedorUMovilHorario.Destino = false;
            PedidoTramoProveedorUMovilHorario.Apoyo = esApoyo;
            PedidoTramoProveedorUMovilHorario.ReportIngresado = false;
            PedidoTramoProveedorUMovilHorario.Activo = true;
            PedidoTramoProveedorUMovilHorario.AuditoriaInsertUser = SecurityUtility.UserName;
            PedidoTramoProveedorUMovilHorario.AuditoriaInsertDate = DateTime.Now;

            await AddAsync(PedidoTramoProveedorUMovilHorario);
            await SaveChangesAsync();

            return PedidoTramoProveedorUMovilHorario;
        }
        public async Task<PedidoTramoProveedorUMovilHorario> DesasignarArchivar(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario)
        {
            try
            {
                await this.EliminarPtpumhSalaEspera(pedidoTramoProveedorUMovilHorario);

                pedidoTramoProveedorUMovilHorario.Activo = false;
                pedidoTramoProveedorUMovilHorario.AuditoriaUpdateDate = DateTime.Now;
                pedidoTramoProveedorUMovilHorario.AuditoriaUpdateUser = SecurityUtility.UserName;
                pedidoTramoProveedorUMovilHorario.GdiaRealEquipo.AuditoriaUpdateDate = DateTime.Now;

                Update(pedidoTramoProveedorUMovilHorario);
                await SaveChangesAsync();

                return pedidoTramoProveedorUMovilHorario;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<PedidoTramoProveedorUMovilHorario> Desasignar(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario)
        {
            try
            {
                var pedidoFinalizadoVCM = await _dbContext.PedidoTramoProveedorUMovilHorario.AnyAsync(
                    ptpumh => ptpumh.PedidoTramoProveedorUMovilHorarioId == pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioId 
                    && ptpumh.PedidoTramo.Pedido.PedidoEstadoId == (int)PedidoEstadoEnum.Finalizado 
                    && ptpumh.PedidoTramo.Pedido.TipoPrestacionId == (int)TipoPrestacionEnum.VideoConsulta);

                await EliminarPtpumhSalaEspera(pedidoTramoProveedorUMovilHorario);

                pedidoTramoProveedorUMovilHorario.Activo = pedidoFinalizadoVCM;
                pedidoTramoProveedorUMovilHorario.AuditoriaUpdateDate = DateTime.Now;
                pedidoTramoProveedorUMovilHorario.AuditoriaUpdateUser = SecurityUtility.UserName;
                pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioEstadoId = (int)PedidoTramoProveedorUMovilHorarioEstadoEnum.Desasignado;
                if (!pedidoFinalizadoVCM)
                {
                    pedidoTramoProveedorUMovilHorario.GdiaRealEquipo.CantidadDesasignaciones++;
                }
                pedidoTramoProveedorUMovilHorario.GdiaRealEquipo.AuditoriaUpdateDate = DateTime.Now;

                Update(pedidoTramoProveedorUMovilHorario);
                await SaveChangesAsync();

                if (!pedidoFinalizadoVCM)
                {
                    await CrearPreasignacion(pedidoTramoProveedorUMovilHorario.PedidoTramoId, (int)GdiaRealEquipoEnum.MovilFicticioVcmGdiaRealEquipoId, (int)ProveedorEnum.Acudir, false);
                }

                return pedidoTramoProveedorUMovilHorario;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<PedidoTramoProveedorUMovilHorario> DesasignarPedidoWorker(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario, bool esAmarillo)
        {
            try
            {
                if (esAmarillo) 
                {
                    var ptumh = await this.DesasignarArchivar(pedidoTramoProveedorUMovilHorario);
                    ptumh.PedidoTramoProveedorUMovilHorarioEstadoId = (int)PedidoTramoProveedorUMovilHorarioEstadoEnum.Desasignado;

                    Update(pedidoTramoProveedorUMovilHorario);
                    await SaveChangesAsync();
                }
                else
                {
                    await this.EliminarPtpumhSalaEspera(pedidoTramoProveedorUMovilHorario);

                    pedidoTramoProveedorUMovilHorario.Activo = false;
                    pedidoTramoProveedorUMovilHorario.AuditoriaUpdateDate = DateTime.Now;
                    pedidoTramoProveedorUMovilHorario.AuditoriaUpdateUser = SecurityUtility.UserName;
                    pedidoTramoProveedorUMovilHorario.GdiaRealEquipo.AuditoriaUpdateDate = DateTime.Now;
                    pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioEstadoId = (int)PedidoTramoProveedorUMovilHorarioEstadoEnum.Desasignado;

                    Update(pedidoTramoProveedorUMovilHorario);
                    await SaveChangesAsync();

                    await this.CrearPreasignacion(pedidoTramoProveedorUMovilHorario.PedidoTramoId, (int)GdiaRealEquipoEnum.MovilFicticioVcmGdiaRealEquipoId, (int)ProveedorEnum.Acudir, false);
                }


                return pedidoTramoProveedorUMovilHorario;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<PedidoTramoProveedorUMovilHorario> EliminarPtpumhSalaEspera(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario)
        {
            try
            {
                var ptpumhSalaEspera = await GetManyAsync(x => x.PedidoTramoId == pedidoTramoProveedorUMovilHorario.PedidoTramo.PedidoTramoId && x.Activo && x.PedidoTramoProveedorUMovilHorarioEstadoId == (int)PedidoTramoProveedorUMovilHorarioEstadoEnum.PreDespacho);
                if (ptpumhSalaEspera.Any())
                {
                    for (int i = 0; i < ptpumhSalaEspera.ToList().Count(); i++)
                    {
                        ptpumhSalaEspera.ToList()[i].Activo = false;
                        Update(ptpumhSalaEspera.ToList()[i]);
                        await SaveChangesAsync();
                    }
                }
                return ptpumhSalaEspera.FirstOrDefault();
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public async Task<PedidoTramoProveedorUMovilHorario> ObtenerPrimeraAsignacionApoyoPorTramo(int pedidoTramoId)
        {
            return (await GetManyAsync(ptpuh =>
                ptpuh.PedidoTramoId == pedidoTramoId &&
                ptpuh.Activo &&
                ptpuh.Apoyo)).FirstOrDefault();
        }

        public async Task<PedidoTramoProveedorUMovilHorario> ConvertirEnAsignacionPrincipal(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario)
        {
            pedidoTramoProveedorUMovilHorario.Apoyo = false;
            pedidoTramoProveedorUMovilHorario.Activo = true;
            pedidoTramoProveedorUMovilHorario.AuditoriaUpdateDate = DateTime.Now;
            pedidoTramoProveedorUMovilHorario.AuditoriaUpdateUser = SecurityUtility.UserName;

            Update(pedidoTramoProveedorUMovilHorario);
            await SaveChangesAsync();

            return pedidoTramoProveedorUMovilHorario;
        }
        public async Task ValidarSiPuedeActualizarHorarios(int pedidoTramoProveedorUMovilHorarioId, TipoHorarioEnum tipoHorario, DateTime fechaHora)
        {
            PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorarioExistente = await GetByIdAsync(pedidoTramoProveedorUMovilHorarioId);

            //Valido que los horarios sean coherentes
            if (tipoHorario == TipoHorarioEnum.OrigenPartida)
            {
                if (pedidoTramoProveedorUMovilHorarioExistente.OrigenArribo is null)
                    throw new ReglaDeNegocioException("Debe ingresar primero el arribo al origen.");

                /*if (fechaHora < pedidoTramoProveedorUMovilHorarioExistente.OrigenArribo)
                    throw new ReglaDeNegocioException("La partida del origen no puede ser menor que el arribo.");*/
            }

            if (tipoHorario == TipoHorarioEnum.OrigenArribo)
            {
                if (fechaHora > pedidoTramoProveedorUMovilHorarioExistente.OrigenPartida)
                    throw new ReglaDeNegocioException("El arribo ingresado no puede ser mayor a la partida del origen.");

                if (fechaHora == pedidoTramoProveedorUMovilHorarioExistente.OrigenPartida)
                    throw new ReglaDeNegocioException("El arribo ingresado no puede ser el mismo que la partida del origen.");
            }

            if (pedidoTramoProveedorUMovilHorarioExistente.PedidoTramo.Pedido.FechaInicioToma > fechaHora)
                throw new ReglaDeNegocioException("No se puede introducir una fecha-hora menor que la del inicio de la toma.");
        }

        public async Task<PedidoTramoProveedorUMovilHorario> Actualizar(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario)
        {
            pedidoTramoProveedorUMovilHorario.AuditoriaUpdateDate = DateTime.Now;
            pedidoTramoProveedorUMovilHorario.AuditoriaUpdateUser = SecurityUtility.UserName;

            Update(pedidoTramoProveedorUMovilHorario);
            await SaveChangesAsync();

            return pedidoTramoProveedorUMovilHorario;
        }
        public async Task<IEnumerable<PedidoTramoProveedorUMovilHorario>> Actualizar(IEnumerable<PedidoTramoProveedorUMovilHorario> listaAsignaciones)
        {
            foreach (var asignacion in listaAsignaciones)
            {
                asignacion.AuditoriaUpdateDate = DateTime.Now;
                asignacion.AuditoriaUpdateUser = SecurityUtility.UserName;

                Update(asignacion);
            }

            await SaveChangesAsync();

            return listaAsignaciones;
        }

        public async Task<PedidoTramoProveedorUMovilHorario> ActualizarHorarios(int pedidoTramoProveedorUMovilHorarioId, TipoHorarioEnum tipoHorario, DateTime fechaHora)
        {
            try
            {
                var tipoHorarioString = ConvertidorTipoHorario.Convertir(tipoHorario);

                await ExecuteSqlCommandAsync("usp_ApiInt_PedidoTramoProveedorUMovilHorario_update @PedidoTramoProveedorUMovilHorarioId, @Campo, @Horario, @ForzarUpdate",
                    new SqlParameter("@PedidoTramoProveedorUMovilHorarioId", pedidoTramoProveedorUMovilHorarioId),
                    new SqlParameter("@Campo", tipoHorarioString),
                    new SqlParameter("@Horario", fechaHora),
                    new SqlParameter("@ForzarUpdate", true));

                PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario = await GetByIdAsync(pedidoTramoProveedorUMovilHorarioId);
                await ReloadAsync(pedidoTramoProveedorUMovilHorario);

                return pedidoTramoProveedorUMovilHorario;

            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }
        }

        public async Task<PedidoTramoProveedorUMovilHorario> ActualizarNroServicio(int pedidoTramoProveedorUMovilHorarioId, string nroServicio)
        {
            PedidoTramoProveedorUMovilHorario PedidoTramoProveedorUMovilHorario = await GetByIdAsync(pedidoTramoProveedorUMovilHorarioId);
            if (PedidoTramoProveedorUMovilHorario is null)
                return null;

            PedidoTramoProveedorUMovilHorario.NroServicio = nroServicio;
            PedidoTramoProveedorUMovilHorario.AuditoriaUpdateDate = DateTime.Now;
            PedidoTramoProveedorUMovilHorario.AuditoriaUpdateUser = SecurityUtility.UserName;

            Update(PedidoTramoProveedorUMovilHorario);
            await SaveChangesAsync();

            return PedidoTramoProveedorUMovilHorario;
        }

        public async Task<int> CantidadDeAsignacionesPrincipales(int pedidoTramoId)
        {
            return (await GetManyAsync(ptpuh => ptpuh.PedidoTramoId == pedidoTramoId &&
                ptpuh.Activo &&
                !ptpuh.Apoyo)).Count();
        }

        public async Task<bool> ExisteDespachadoActivo(int pedidoTramoId)
        {
            return await AnyAsync(ptpuh => ptpuh.PedidoTramoId == pedidoTramoId &&
                                           ptpuh.Activo && 
                                           ptpuh.PedidoTramoProveedorUMovilHorarioEstadoId == (int)PedidoTramoProveedorUMovilHorarioEstadoEnum.Despachado);
        }
    }
}