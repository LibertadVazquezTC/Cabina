﻿using System.Collections.Generic;
using System.Threading.Tasks;
using CabinaOperativa.Modelo;

namespace CabinaOperativa.Repositories
{
    public class PedidoTramoRepository : GenericRepository<PedidoTramo>, IPedidoTramoRepository
    {
        public PedidoTramoRepository(TechMedContext dbContext) : base(dbContext)
        {
        }

        public async Task<PedidoTramo> Obtener(int pedidoTramoId)
        {
            return await GetByIdAsync(pedidoTramoId);
        }

        public async Task<IEnumerable<PedidoTramo>> ListarPorPedido(int pedidoId)
        {
            return await GetManyAsync(pt => pt.PedidoId == pedidoId && pt.Activo);
        }
    }
}