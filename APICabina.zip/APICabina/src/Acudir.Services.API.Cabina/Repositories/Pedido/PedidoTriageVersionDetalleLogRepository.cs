﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using CabinaOperativa.Enums;
using CabinaOperativa.Modelo;
using CabinaOperativa.Utilities;
using Dapper;
using Microsoft.Extensions.Configuration;

namespace CabinaOperativa.Repositories
{
    public class PedidoTriageVersionDetalleLogRepository : GenericRepository<PedidoTriageVersionDetalleLog>, IPedidoTriageVersionDetalleLogRepository
    {

        public PedidoTriageVersionDetalleLogRepository(TechMedContext dbContext) : base(dbContext)
        {
        }

        public async Task<IEnumerable<PedidoTriageVersionDetalleLog>> ListarPorPedido(int pedidoId)
        {
            return await GetManyAsync(ptvdl => ptvdl.PedidoId == pedidoId);
        }
    }
}