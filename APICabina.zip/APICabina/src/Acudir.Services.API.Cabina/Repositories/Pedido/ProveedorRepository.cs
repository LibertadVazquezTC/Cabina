﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using CabinaOperativa.Modelo;
using Dapper;
using Microsoft.Extensions.Configuration;

namespace CabinaOperativa.Repositories
{
    public class ProveedorRepository : GenericRepository<Proveedor>, IProveedorRepository
    {

        private readonly IConfiguration _config;

        public ProveedorRepository(TechMedContext dbContext, IConfiguration config) : base(dbContext)
        {
            _config = config;
        }

        public IDbConnection Connection => new SqlConnection(_config.GetConnectionString("TechMedDatabase"));

        public async Task<string> ListarJson(int pedidoId, bool mostrarTodos, bool requiereMovil)
        {
            using (IDbConnection conn = Connection)
            {
                var jsonResponse = (await conn.QueryAsync<string>($"SELECT dbo.fn_JsonDTO_ProveedorTipoPrestacionCobertura_Get({pedidoId}, '{mostrarTodos}', '{requiereMovil}')")).ToList();
                var jsonResult = "";
                for (int i = 0; i < jsonResponse.Count(); i++) jsonResult += jsonResponse[i];
                return jsonResult;
            }
        }

        public async Task<Proveedor> Obtener(int proveedorId)
        {
            return await GetByIdAsync(proveedorId);
        }
    }
}