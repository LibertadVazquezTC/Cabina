﻿using CabinaOperativa.Modelo;
using CabinaOperativa.Repositories.Interfaces.Pedido;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public class RestriccionTipoCierreDiagnosticoRepository : GenericRepository<RestriccionTipoCierreDiagnostico>, IRestriccionTipoCierreDiagnosticoRepository
    {   
        public RestriccionTipoCierreDiagnosticoRepository(TechMedContext dbContext) : base(dbContext)
        {
        }   
        
        public async Task<IEnumerable<RestriccionTipoCierreDiagnostico>> ListarByDiagnosticoId(int diagnosticoId)
        {
           return await GetManyAsync(ptc => ptc.Activo && ptc.DiagnosticoId == diagnosticoId);
        }
    }
}