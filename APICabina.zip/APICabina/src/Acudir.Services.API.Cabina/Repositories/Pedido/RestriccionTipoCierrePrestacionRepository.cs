﻿using CabinaOperativa.Modelo;
using CabinaOperativa.Repositories.Interfaces.Pedido;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CabinaOperativa.Repositories
{
    public class RestriccionTipoCierrePrestacionRepository : GenericRepository<RestriccionTipoCierrePrestacion>, IRestriccionTipoCierrePrestacionRepository
    {   
        public RestriccionTipoCierrePrestacionRepository(TechMedContext dbContext) : base(dbContext)
        {
        }   
        
        public async Task<IEnumerable<RestriccionTipoCierrePrestacion>> ListarByTipoPrestacionId(int tipoPrestacionId)
        {
           return await GetManyAsync(ptc => ptc.Activo && ptc.TipoPrestacionId == tipoPrestacionId);
        }
    }
}