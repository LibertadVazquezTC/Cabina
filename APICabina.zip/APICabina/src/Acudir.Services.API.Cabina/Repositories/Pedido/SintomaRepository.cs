﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using CabinaOperativa.Modelo;
using Dapper;
using Microsoft.Extensions.Configuration;

namespace CabinaOperativa.Repositories
{
    public class SintomaRepository : GenericRepository<Sintoma>, ISintomaRepository
    {
      
        public SintomaRepository(TechMedContext dbContext) : base(dbContext)
        {
        }
     
        public async Task<Sintoma> Obtener(int sintomaId)
        {
            return await GetByIdAsync(sintomaId);
        }

        public async Task<IEnumerable<Sintoma>> Listar()
        {
            return await GetManyAsync(s => s.Activo == true);
        }
    }
}