﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using CabinaOperativa.Modelo;
using Dapper;
using Microsoft.Extensions.Configuration;

namespace CabinaOperativa.Repositories
{
    public class TipoPrestacionContratoRepository : GenericRepository<TipoPrestacionContrato>, ITipoPrestacionContratoRepository
    {

        public TipoPrestacionContratoRepository(TechMedContext dbContext) : base(dbContext)
        {
        }

        public async Task<IEnumerable<TipoPrestacionContrato>> ListarPorContratoYTipoPrestacionCategoria(int contratoId, int tipoPrestacionCategoriaId)
        {
            return await GetManyAsync(tpc =>
                tpc.ContratoId == contratoId &&
                tpc.TipoPrestacion.TipoPrestacionCategoriaId == tipoPrestacionCategoriaId &&
                tpc.Activo.HasValue &&
                tpc.Activo.Value == true);
        }
    }
}