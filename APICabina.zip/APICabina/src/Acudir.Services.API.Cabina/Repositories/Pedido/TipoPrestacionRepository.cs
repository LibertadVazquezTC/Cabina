﻿using System.Collections.Generic;
using System.Threading.Tasks;
using CabinaOperativa.Modelo;

namespace CabinaOperativa.Repositories
{
    public class TipoPrestacionRepository : GenericRepository<TipoPrestacion>, ITipoPrestacionRepository
    {

        public TipoPrestacionRepository(TechMedContext dbContext) : base(dbContext)
        {
        }

        public async Task<IEnumerable<TipoPrestacion>> Listar()
        {
            return await GetAllAsync();
        }

        public async Task<IEnumerable<TipoPrestacion>> ListarPorTipoPrestacionCategoria(int tipoPrestacionCategoriaId)
        {
            return await GetManyAsync(tp => 
                tp.TipoPrestacionCategoriaId == tipoPrestacionCategoriaId);
        }

        public async Task<TipoPrestacion> Obtener(int tipoPrestacionId)
        {
            return await GetByIdAsync(tipoPrestacionId);
        }
    }
}