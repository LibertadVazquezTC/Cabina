﻿using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using CabinaOperativa.Modelo;
using Dapper;
using Microsoft.Extensions.Configuration;

namespace CabinaOperativa.Repositories
{
    public class UMovilRepository : GenericRepository<UMovil>, IUMovilRepository
    {

        private readonly IConfiguration _config;

        public UMovilRepository(TechMedContext dbContext,
             IConfiguration config) : base(dbContext)
        {
            _config = config;
        }

        public IDbConnection Connection => new SqlConnection(_config.GetConnectionString("TechMedDatabase"));

        public async Task<UMovil> Obtener(int uMovilId)
        {
            return await GetByIdAsync(uMovilId);
        }

        public async Task<string> ObtenerUltimoReporteGpsMovilJson(int gpsMovilId)
        {
            using (IDbConnection conn = Connection)
            {
                var jsonResponse = (await conn.QueryAsync<string>($"SELECT dbo.fn_JsonDTO_Gps({gpsMovilId})")).ToList();
                var jsonResult = "";
                for (int i = 0; i < jsonResponse.Count(); i++) jsonResult += jsonResponse[i];
                return jsonResult;
            }
        }
    }
}