﻿using Acudir.Services.API.Cabina.Modelo;
using Acudir.Services.API.Cabina.Repositories.Interfaces.Pedido;
using CabinaOperativa.Modelo;
using CabinaOperativa.Repositories;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Acudir.Services.API.Cabina.Repositories.Pedido
{
    public class VideoConsultaRepository : GenericRepository<VideoConsulta>, IVideoConsultaRepository
    {
        public VideoConsultaRepository(TechMedContext dbContext) : base(dbContext)
        {
        }

        public async Task<int> ObtenerVideoConsultaByPedidoId(int pedidoId)
        {
            return await _dbContext.VideoConsulta.Where(v => v.PedidoId == pedidoId).Select(v => v.VideoConsultaId).FirstOrDefaultAsync();
        }

        public async Task<List<int>> ObtenerLogsVideoConsulta(int videoConsultaId)
        {
            return await _dbContext.VideoConsultaLog.Where(v => v.VideoConsultaId == videoConsultaId).Select(v => v.VideoConsultaLogTipoId).ToListAsync();
        }
    }
}
