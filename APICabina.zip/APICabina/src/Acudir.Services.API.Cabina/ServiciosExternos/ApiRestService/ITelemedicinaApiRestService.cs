﻿using Acudir.Services.API.Cabina.ServiciosExternos.DTOs.EnvioNotificacion;
using Refit;
using System.Threading.Tasks;

namespace Acudir.Services.API.Cabina.ServiciosExternos.ApiRestService
{
    public interface ITelemedicinaApiRestService
    {
        [Post("/api/v1/Telemedicina/FirebaseNotificacion/EnviarNotificacionMobile")]
        Task<object> EnviarNotificacionMobile([Body] NotificacionFirebaseDTO notificacionFirebase);

        [Post("/api/v1/Telemedicina/Turnos/SacarPacienteSalaCambioPrestacion")]
        Task<object> SacarPacienteSala(int videoConsultaId);

    }
}
