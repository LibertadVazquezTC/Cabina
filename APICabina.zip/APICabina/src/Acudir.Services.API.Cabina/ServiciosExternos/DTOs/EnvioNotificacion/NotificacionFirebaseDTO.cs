﻿namespace Acudir.Services.API.Cabina.ServiciosExternos.DTOs.EnvioNotificacion
{
    public class NotificacionFirebaseDTO
    {
        public string Documento { get; set; }
        public int ContratoId { get; set; }
        public string PedidoId { get; set; }
        public string VideoConsultaId { get; set; }
        public string TipoNotificacion { get; set; }
    }
}
