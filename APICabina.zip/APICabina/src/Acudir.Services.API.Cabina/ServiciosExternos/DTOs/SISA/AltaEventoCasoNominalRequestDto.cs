﻿using Newtonsoft.Json;

namespace CabinaOperativa.ServiciosExternos.DTOs.SISA
{
    public class AltaEventoCasoNominalDto
    {
        [JsonProperty(PropertyName = "idEstablecimientoCarga")]
        public string EstablecimientoCargaId { get; set; }

        [JsonProperty(PropertyName = "idTipodoc")]
        public int TipoDocumentoId { get; set; }

        [JsonProperty(PropertyName = "nrodoc")]
        public string DocumentoNro { get; set; }

        [JsonProperty(PropertyName = "sexo")]
        public string Sexo { get; set; }

        [JsonProperty(PropertyName = "fechaNacimiento")]
        public string FechaNacimiento { get; set; }

        [JsonProperty(PropertyName = "idGrupoEvento")]
        public int GrupoEventoId { get; set; }

        [JsonProperty(PropertyName = "idEvento")]
        public int EventoId { get; set; }

        [JsonProperty(PropertyName = "idClasificacionManualCaso")]
        public int ClasificacionManualCasoId { get; set; }

        [JsonProperty(PropertyName = "fechaPapel")]
        public string FechaPapel { get; set; }
    }
}
