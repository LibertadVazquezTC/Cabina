﻿using Newtonsoft.Json;

namespace CabinaOperativa.ServiciosExternos.DTOs.SISA
{
    public class CrearEventoSISARequestDto
    {
        [JsonProperty(PropertyName = "usuario")]
        public string Usuario { get; set; }

        [JsonProperty(PropertyName = "clave")]
        public string Password { get; set; }

        [JsonProperty(PropertyName = "altaEventoCasoNominal")]
        public AltaEventoCasoNominalDto AltaEventoCasoNominalDto { get; set; } = new AltaEventoCasoNominalDto();
    }
}
