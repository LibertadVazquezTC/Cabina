﻿using Newtonsoft.Json;

namespace CabinaOperativa.ServiciosExternos.DTOs.SISA
{
    public class CrearEventoSISAResponseDto
    {
        public bool FueExitoso
        {
            get =>
                Respuesta != null &&
                Respuesta.Trim().ToLower() == "ok";
        }

        [JsonProperty(PropertyName = "resultado")]
        public string Respuesta { get; set; }

        [JsonProperty(PropertyName = "description")]
        public string Descripcion { get; set; }
    }
}
