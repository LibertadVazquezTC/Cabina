﻿using CabinaOperativa.DTOs;

namespace CabinaOperativa.ServiciosExternos.DTOs.SISA
{
    public class IngresarSISAResponse : BaseRequestResponse
    {
        public bool FueIngresadoSISA { get; set; }
        public CrearEventoSISARequestDto CrearEventoSISARequest { get; set; }
        public CrearEventoSISAResponseDto CrearEventoSISAResponse { get; set; }
    }
}
