﻿using Acudir.Services.API.Cabina.Constants;
using Acudir.Services.API.Cabina.Repositories.Interfaces.Pedido;
using Acudir.Services.API.Cabina.ServiciosExternos.ApiRestService;
using Acudir.Services.API.Cabina.ServiciosExternos.DTOs.EnvioNotificacion;
using Acudir.Services.API.Cabina.ServiciosExternos.Interfaces;
using CabinaOperativa.Repositories;
using System;
using System.Threading.Tasks;

namespace Acudir.Services.API.Cabina.ServiciosExternos
{
    public class EnvioNotificacionMobileService : IEnvioNotificacionMobileService

    {
        private readonly ITelemedicinaApiRestService _telemedicinaApiRestService;
        private readonly IPedidoAfiliadoRepository _pedidoAfiliadoRepository;
        private readonly IVideoConsultaRepository _videoConsultaRepository;

        public EnvioNotificacionMobileService(ITelemedicinaApiRestService telemedicinaApiRestService, 
                                                IPedidoAfiliadoRepository pedidoAfiliadoRepository, IVideoConsultaRepository videoConsultaRepository)
        {
            _telemedicinaApiRestService = telemedicinaApiRestService;
            _pedidoAfiliadoRepository = pedidoAfiliadoRepository;
            _videoConsultaRepository = videoConsultaRepository;
            
        }

        public async Task BuscarAfiliadoMobileYEnviarNotificacion(int pedidoId, string tipoNotificacion)
        {
            var datos = await _pedidoAfiliadoRepository.ObtenerDatosEspecificos(pedidoId);
            var videoConsultaId = await _videoConsultaRepository.ObtenerVideoConsultaByPedidoId(pedidoId);

            await EnviarNotificacion(new NotificacionFirebaseDTO
            {
                Documento = datos.Documento,
                ContratoId = datos.ContratoId,
                PedidoId = pedidoId.ToString(),
                VideoConsultaId = videoConsultaId.ToString(),
                TipoNotificacion = tipoNotificacion.ToString(),
            }); ;
        }

        private async Task EnviarNotificacion(NotificacionFirebaseDTO notificacion)
        {
            try
            {
                await _telemedicinaApiRestService.EnviarNotificacionMobile(notificacion);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message, ex);
            }
        }
    }
}
