﻿using System.Threading.Tasks;

namespace Acudir.Services.API.Cabina.ServiciosExternos.Interfaces
{
    public interface IEnvioNotificacionMobileService
    {
        Task BuscarAfiliadoMobileYEnviarNotificacion(int pedidoId, string tipoNotificacion);
    }
}
