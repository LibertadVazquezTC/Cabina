﻿using CabinaOperativa.Enums;
using CabinaOperativa.Modelo;
using CabinaOperativa.ServiciosExternos.DTOs.SISA;
using System.Threading.Tasks;

namespace CabinaOperativa.ServiciosExternos.Interfaces
{
    public interface ISISAConnector
    {
        Task<IngresarSISAResponse> IngresarEnSISA(Pedido pedido);
    }
}
