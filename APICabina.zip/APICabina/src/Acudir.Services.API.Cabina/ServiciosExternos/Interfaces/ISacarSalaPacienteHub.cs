﻿using System.Threading.Tasks;

namespace Acudir.Services.API.Cabina.ServiciosExternos.Interfaces
{
    public interface ISacarSalaPacienteHub
    {
        Task SacarPacienteSalaHub(int pedidoId);
    }
}
