﻿using AutoMapper;
using CabinaOperativa.Enums;
using CabinaOperativa.Exceptions;
using CabinaOperativa.Exceptions.SISA;
using CabinaOperativa.Modelo;
using CabinaOperativa.Repositories;
using CabinaOperativa.ServiciosExternos.DTOs;
using CabinaOperativa.ServiciosExternos.DTOs.SISA;
using CabinaOperativa.ServiciosExternos.Interfaces;
using CabinaOperativa.Utilities.Interfaces;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace CabinaOperativa.ServiciosExternos
{
    public class SISAConnector : ISISAConnector
    {
        private readonly IConfiguration _configuration;
        private readonly IMapper _mapper;
        private readonly IAppConfigUtility _appConfigUtility;

        public SISAConnector(IConfiguration configuration,
            IMapper mapper,
            IAppConfigUtility appConfigUtility)
        {
            _configuration = configuration;
            _mapper = mapper;
            _appConfigUtility = appConfigUtility;
        }

        public async Task<IngresarSISAResponse> IngresarEnSISA(Pedido pedido)
        {
            var createEventoCommandResponse = new IngresarSISAResponse();
            try
            {
                ValidarPedido(pedido);

                createEventoCommandResponse.CrearEventoSISARequest = await GenerarRequestSISA(pedido);
                createEventoCommandResponse.CrearEventoSISAResponse = await RequestSISA(createEventoCommandResponse.CrearEventoSISARequest);
                createEventoCommandResponse.FueIngresadoSISA = createEventoCommandResponse.CrearEventoSISAResponse != null &&
                    createEventoCommandResponse.CrearEventoSISAResponse.FueExitoso;
                return createEventoCommandResponse;
            }
            catch (Exception ex)
            {
                createEventoCommandResponse.SetStatus(false, ex.Message);
                return createEventoCommandResponse;
            }
        }

        private async Task<CrearEventoSISAResponseDto> RequestSISA(CrearEventoSISARequestDto crearEventoDto)
        {
            var crearEventoSISAResponseDto = new CrearEventoSISAResponseDto();
            try
            {
                using (HttpClient httpClient = new HttpClient())
                {
                    var urlSISA = _configuration.GetValue<string>("SISAUrl");
                    var urlSISAPath = _configuration.GetValue<string>("SISAUrlPath");
                    
                    httpClient.BaseAddress = new Uri(urlSISA);
                    httpClient.DefaultRequestHeaders.Accept.Clear();
                    httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    httpClient.Timeout = TimeSpan.FromSeconds(6);
                    HttpResponseMessage httpResponseMessage =
                        await httpClient.PostAsync(urlSISAPath,
                            new StringContent(JsonConvert.SerializeObject(crearEventoDto), Encoding.UTF8, "application/json"));

                    var jsonResponse = await httpResponseMessage.Content.ReadAsStringAsync();
                    if (httpResponseMessage.IsSuccessStatusCode)
                    {
                        crearEventoSISAResponseDto = JsonConvert.DeserializeObject<CrearEventoSISAResponseDto>(jsonResponse);
                        return crearEventoSISAResponseDto;
                    }
                    else
                    {
                        crearEventoSISAResponseDto.Respuesta = $"ERROR_REQUEST-{httpResponseMessage.StatusCode}";
                        crearEventoSISAResponseDto.Descripcion = jsonResponse;
                        return crearEventoSISAResponseDto;
                    }
                }
            }
            catch (Exception ex)
            {
                crearEventoSISAResponseDto.Respuesta = $"ERROR_REQUEST_EXCEPTION-{ex.Message}";
                crearEventoSISAResponseDto.Descripcion = ex.InnerException?.Message;
                return crearEventoSISAResponseDto;
            }
        }

        private async Task<CrearEventoSISARequestDto> CargarConfiguracionSISA()
        {
            var sisaConfiguration = await _appConfigUtility.ObtenerPorKey("ConfiguracionSISA");
            if (string.IsNullOrEmpty(sisaConfiguration))
                throw new DatoErroneoException("No se encontró 'ConfiguracionSISA'.");

            var crearEventoSISARequestDto = JsonConvert.DeserializeObject<CrearEventoSISARequestDto>(sisaConfiguration);
            if (crearEventoSISARequestDto is null)
                throw new DatoErroneoException("No se encontró la configuración de SISA.");

            return crearEventoSISARequestDto;
        }

        private async Task<CrearEventoSISARequestDto> GenerarRequestSISA(Pedido pedido)
        {
            var crearEventoSISARequest = await CargarConfiguracionSISA();
            crearEventoSISARequest.AltaEventoCasoNominalDto = _mapper.Map(pedido, crearEventoSISARequest.AltaEventoCasoNominalDto);
            ValidarCreacionEventoEnSisa(pedido, crearEventoSISARequest);
            return crearEventoSISARequest;
        }

        private void ValidarPedido(Pedido pedido)
        {
            if (pedido.TipoPrestacionId != (int)TipoPrestacionEnum.HIRA)
                throw new SISANoDebeIngresarseException("No se puede enviar a SISA: solo se pueden cargar las prestaciones del tipo 'HIRA'.");

            if (pedido.PedidoResultadoLaboratorioId != (int)PedidoResultadoLaboratorioEnum.Detectable)
                throw new SISANoDebeIngresarseException("No se puede enviar a SISA: solo se pueden cargar los resultados 'Detectables'.");

            var estadoIdsPosibles = new int[] { 10, 14 };
            if (!estadoIdsPosibles.Contains(pedido.PedidoEstadoId))
                throw new SISANoDebeIngresarseException("No se puede enviar a SISA: el estado del pedido debe ser 'Finalizado' o 'Archivado'.");
        }

        private void ValidarCreacionEventoEnSisa(Pedido pedido, CrearEventoSISARequestDto crearEventoDto)
        {
            if (crearEventoDto.AltaEventoCasoNominalDto.TipoDocumentoId == -1)
                throw new SISADatoFaltanteException("No se puede enviar a SISA: el afiliado no tiene cargado el tipo de documento, o el mismo es erroneo.");

            if (string.IsNullOrEmpty(crearEventoDto.AltaEventoCasoNominalDto.DocumentoNro))
                throw new SISADatoFaltanteException("No se puede enviar a SISA: el afiliado no tiene cargado el número de documento.");

            if (string.IsNullOrEmpty(crearEventoDto.AltaEventoCasoNominalDto.Sexo))
                throw new SISADatoFaltanteException("No se puede enviar a SISA: el afiliado no tiene cargado el sexo.");

            if (string.IsNullOrEmpty(crearEventoDto.AltaEventoCasoNominalDto.FechaNacimiento))
                throw new SISADatoFaltanteException("No se puede enviar a SISA: el afiliado no tiene cargada la fecha de nacimiento.");

            if (string.IsNullOrEmpty(crearEventoDto.AltaEventoCasoNominalDto.FechaPapel))
                throw new SISADatoFaltanteException("No se puede enviar a SISA: el pedido no tiene cargado el horario de arribo al origen.");
        }
    }
}

