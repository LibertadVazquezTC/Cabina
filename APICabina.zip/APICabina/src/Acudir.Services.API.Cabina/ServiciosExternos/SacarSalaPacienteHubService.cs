﻿using Acudir.Services.API.Cabina.Modelo;
using Acudir.Services.API.Cabina.Repositories.Interfaces.Pedido;
using Acudir.Services.API.Cabina.ServiciosExternos.ApiRestService;
using Acudir.Services.API.Cabina.ServiciosExternos.Interfaces;
using CabinaOperativa.Repositories;
using System;
using System.Threading.Tasks;

namespace Acudir.Services.API.Cabina.ServiciosExternos
{
    public class SacarSalaPacienteHubService : ISacarSalaPacienteHub
    {
        private readonly ITelemedicinaApiRestService _telemedicinaApiRestService;
        private readonly IVideoConsultaRepository _videoConsultaRepository;



        public SacarSalaPacienteHubService(ITelemedicinaApiRestService telemedicinaApiRestService, IVideoConsultaRepository videoConsultaRepository)
        {
            _telemedicinaApiRestService = telemedicinaApiRestService;
            _videoConsultaRepository = videoConsultaRepository;
        }

        public async Task SacarPacienteSalaHub(int pedidoId)
        {
            try
            {
                int videoConsultaId = await _videoConsultaRepository.ObtenerVideoConsultaByPedidoId(pedidoId);
                await _telemedicinaApiRestService.SacarPacienteSala(videoConsultaId);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message, ex);
            }
        }
    }
}
