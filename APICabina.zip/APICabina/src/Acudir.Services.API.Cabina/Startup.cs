﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using CabinaOperativa.Extensions;
using AutoMapper;
using CabinaOperativa.AutoMapper;
using CabinaOperativa.Modelo;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json.Serialization;
using Microsoft.AspNetCore.Http;
using System;
using CabinaOperativa.Utilities;
using Microsoft.AspNetCore.Mvc;
using Acudir.Services.API.Cabina.ServiciosExternos.ApiRestService;
using Refit;
using Acudir.Services.API.Cabina.Middlewares;

namespace CabinaOperativa
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public IServiceProvider ConfigureServices(IServiceCollection services)
        {
            services.ConfigureCors();
            services.ConfigureRepositories();
            services.ConfigureBussiness();
            services.ConfigureExternalServices();
            services.ConfigureSwagger();

            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            #region Mapper
            MapperConfiguration mapperConfiguration = new MapperConfiguration(mc => { mc.AddProfile(new MappingProfile()); });
            IMapper mapper = mapperConfiguration.CreateMapper();
            services.AddSingleton(mapper);
            #endregion

            services
             .AddRefitClient<ITelemedicinaApiRestService>()
             .ConfigureHttpClient(c => c.BaseAddress = new Uri(Configuration.GetSection("TelemedicinaUrl").Value));

            services.AddDbContext<TechMedContext>(
                options =>
                options.UseLazyLoadingProxies().UseSqlServer(Configuration.GetConnectionString("TechMedDatabase")));

            services.AddMvc()
                .AddJsonOptions(options => options.SerializerSettings.ContractResolver = new DefaultContractResolver())
                .SetCompatibilityVersion(CompatibilityVersion.Version_2_1);

            services.AddMemoryCache();
            services.AddResponseCaching();

            IServiceProvider serviceProvider = services.BuildServiceProvider();
            IHttpContextAccessor httpContextAccessor = serviceProvider.GetService<IHttpContextAccessor>();
            SecurityUtility.SetHttpContextAccessor(httpContextAccessor);
            return serviceProvider;
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {

            app.UseCors("CorsPolicy");
            app.UseSwagger();
            app.UseSwaggerUI();
            app.UseStaticFiles();

            app.UseSignalR(Configuration.GetConnectionString("TechMedDatabase"));

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            app.UseMiddleware<CustomHandlerMiddleware>();
            app.UseResponseCaching();

            app.UseMvc();
        }
    }
}
