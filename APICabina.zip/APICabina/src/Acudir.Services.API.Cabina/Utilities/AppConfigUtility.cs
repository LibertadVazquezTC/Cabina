﻿using CabinaOperativa.Utilities.Interfaces;
using Dapper;
using System.Linq;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace CabinaOperativa.Utilities
{
    public class AppConfigUtility : IAppConfigUtility
    {
        private readonly IConfiguration _configuration;

        public AppConfigUtility(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public IDbConnection Connection => new SqlConnection(_configuration.GetConnectionString("TechMedDatabase"));

        public async Task<string> ObtenerPorKey(string key)
        {
            using (IDbConnection connection = Connection)
            {
                var keyConfiguration = (await connection.QueryAsync<string>($"SELECT dbo.fn_AppConfigValue_get('{key}')")).FirstOrDefault();
                return keyConfiguration;
            }
        }
    }
}
