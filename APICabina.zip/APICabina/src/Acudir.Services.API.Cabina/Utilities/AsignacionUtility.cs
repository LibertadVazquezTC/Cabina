﻿using CabinaOperativa.Modelo;
using System.Linq;

namespace CabinaOperativa.Utilities
{
    public class AsignacionUtility
    {
        public static string ObtenerFechaArribo(Pedido pedido, string dateFormat)
        {
            if (pedido.PedidoTramo != null && pedido.PedidoTramo.Any(pt => pt.Activo))
            {
                var pedidoTramoProveedorUMovilHorario = pedido
                    .PedidoTramo
                    .Where(pt => pt.Activo)
                    .FirstOrDefault()
                    .PedidoTramoProveedorUMovilHorario.Where(p => p.Activo).FirstOrDefault();

                if (pedidoTramoProveedorUMovilHorario != null && pedidoTramoProveedorUMovilHorario.OrigenArribo != null)
                    return pedidoTramoProveedorUMovilHorario.OrigenArribo.Value.ToString(dateFormat);
            }

            return string.Empty;
        }
    }
}
