﻿using CabinaOperativa.Enums;

namespace CabinaOperativa.Utilities
{
    public class ConvertidorTipoHorario
    {
        public static TipoHorarioEnum Convertir(string tipoHorario)
        {
            switch (tipoHorario)
            {
                case "OrigenArribo":
                    return TipoHorarioEnum.OrigenArribo;
                case "OrigenPartida":
                    return TipoHorarioEnum.OrigenPartida;
                case "DestinoArribo":
                    return TipoHorarioEnum.DestinoArribo;
                case "DestinoPartida":
                    return TipoHorarioEnum.DestinoPartida;
                default:
                    return TipoHorarioEnum.OrigenArribo;
            }
        }

        public static string Convertir(TipoHorarioEnum tipoHorario)
        {
            switch (tipoHorario)
            {
                case TipoHorarioEnum.OrigenArribo:
                    return "OrigenArribo";
                case TipoHorarioEnum.OrigenPartida:
                    return "OrigenPartida";
                case TipoHorarioEnum.DestinoArribo:
                    return "DestinoArribo";
                case TipoHorarioEnum.DestinoPartida:
                    return "DestinoPartida";
                default:
                    return "OrigenArribo";
            }
        }
    }
}
