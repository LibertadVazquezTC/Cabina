﻿using CabinaOperativa.Modelo;
using System;
using System.Linq;

namespace CabinaOperativa.Utilities
{
    public class DatosAfiliadoUtility
    {
        public static bool ObtenerPersonajePublicoByPedido(Pedido pedido)
        {
            var pedidoAfiliado = pedido.PedidoAfiliado.LastOrDefault();
            if (pedidoAfiliado == null)
            {
                return false;
            }
            else
            {
                return pedidoAfiliado.PersonajePublico;
            }
        }

        public static bool ObtenerPacienteRecomendadoByPedido(Pedido pedido)
        {
            var pedidoAfiliado = pedido.PedidoAfiliado.LastOrDefault();
            if (pedidoAfiliado == null)
            {
                return false;
            }
            else
            {
                return pedidoAfiliado.PacienteRecomendado;
            }
        }

        public static string ObtenerContratoPlanByPedido(Pedido pedido)
        {
            var pedidoAfiliado = pedido.PedidoAfiliado.LastOrDefault();
            if (pedidoAfiliado == null)
            {
                return null;
            }
            else
            {
                return pedidoAfiliado.ContratoPlan.Descripcion;
            }
        }

        public static string ObtenerNombre(Pedido pedido)
        {
            if (pedido.PedidoAfiliado != null && pedido.PedidoAfiliado.Count > 0)
            {
                var contratoAfiliado = pedido.PedidoAfiliado.FirstOrDefault().ContratoAfiliado;
                if (contratoAfiliado != null)
                {
                    return contratoAfiliado.HistoriaClinicaPacienteId is null ?
                        contratoAfiliado.AfiliadoNombre :
                        contratoAfiliado.HistoriaClinicaPaciente.Nombre;
                }
            }

            return String.Empty;
        }

        public static string ObtenerTipoDocumento(Pedido pedido)
        {
            if (pedido.PedidoAfiliado != null && pedido.PedidoAfiliado.Count > 0)
            {
                var contratoAfiliado = pedido.PedidoAfiliado.FirstOrDefault().ContratoAfiliado;
                if (contratoAfiliado != null)
                {
                    return contratoAfiliado.HistoriaClinicaPacienteId is null ?
                        contratoAfiliado.TipoDocumento.Descripcion :
                        contratoAfiliado.HistoriaClinicaPaciente.TipoDocumento.Descripcion;
                }
            }

            return String.Empty;
        }

        public static string ObtenerNroDocumento(Pedido pedido)
        {
            if (pedido.PedidoAfiliado != null && pedido.PedidoAfiliado.Count > 0)
            {
                var contratoAfiliado = pedido.PedidoAfiliado.FirstOrDefault().ContratoAfiliado;
                if (contratoAfiliado != null)
                {
                    return contratoAfiliado.HistoriaClinicaPacienteId is null ?
                        contratoAfiliado.DocumentoNro :
                        contratoAfiliado.HistoriaClinicaPaciente.DocumentoNro;
                }
            }

            return String.Empty;
        }

        public static string ObtenerSexo(Pedido pedido)
        {
            if (pedido.PedidoAfiliado != null && pedido.PedidoAfiliado.Count > 0)
            {
                var contratoAfiliado = pedido.PedidoAfiliado.FirstOrDefault().ContratoAfiliado;
                if (contratoAfiliado != null && contratoAfiliado.HistoriaClinicaPaciente != null)
                    return contratoAfiliado.HistoriaClinicaPaciente.Sexo;
            }

            return pedido.Sexo;
        }

        public static string ObtenerEmail(Pedido pedido)
        {
            if (pedido.PedidoAfiliado != null && pedido.PedidoAfiliado.Count > 0)
            {
                var contratoAfiliado = pedido.PedidoAfiliado.FirstOrDefault().ContratoAfiliado;
                return ObtenerEmail(contratoAfiliado);
            }

            return String.Empty;
        }

        public static string ObtenerEmail(ContratoAfiliado contratoAfiliado)
        {

            if (contratoAfiliado != null)
            {
                return contratoAfiliado.HistoriaClinicaPacienteId is null ?
                    contratoAfiliado.AfiliadoEmail :
                    contratoAfiliado.HistoriaClinicaPaciente.Email;
            }

            return String.Empty;
        }

        public static string ObtenerPlan(Pedido pedido)
        {
            if (pedido.PedidoAfiliado != null && pedido.PedidoAfiliado.Count > 0)
            {
                var contratoPlan = pedido.PedidoAfiliado.FirstOrDefault().ContratoPlan;
                if (contratoPlan != null)
                {
                    return contratoPlan.Descripcion;
                }
            }

            return String.Empty;
        }

        public static string ObtenerFechaNacimiento(Pedido pedido, string dateFormat)
        {
            if (pedido.PedidoAfiliado != null && pedido.PedidoAfiliado.Count > 0)
            {
                var contratoAfiliado = pedido.PedidoAfiliado.FirstOrDefault().ContratoAfiliado;
                if (contratoAfiliado != null &&
                    contratoAfiliado.HistoriaClinicaPaciente != null &&
                    contratoAfiliado.HistoriaClinicaPaciente.FechaNacimiento.HasValue)
                {
                    return contratoAfiliado.HistoriaClinicaPaciente.FechaNacimiento.Value.ToString(dateFormat);
                }
            }
            return String.Empty;
        }
    }
}
