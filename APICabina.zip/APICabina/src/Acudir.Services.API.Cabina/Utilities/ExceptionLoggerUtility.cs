﻿using CabinaOperativa.Exceptions.SISA;
using CabinaOperativa.Exceptions;
using System;
using NLog;

namespace Acudir.Services.API.Cabina.Utilities
{
    public static class ExceptionLoggerUtility
    {
        public static void LogException(Exception ex)
        {
            ILogger logger = NLog.Web.NLogBuilder.ConfigureNLog("nlog.config").GetCurrentClassLogger();
            if (ex is ArgumentException ||
                ex is DatoErroneoException ||
                ex is FalloDeNotificacionException ||
                ex is ReglaDeNegocioException ||
                ex is SISADatoFaltanteException ||
                ex is SISAIngresoException ||
                ex is SISANoDebeIngresarseException) return;
            string firstLineStackTrace = string.Empty;
            if (ex.StackTrace != null)
                firstLineStackTrace = ex.StackTrace.Split(new[] { Environment.NewLine }, StringSplitOptions.None)[0];
            logger.Error($"Custom handler middleware exception: {ex.Message}|{ex.InnerException?.Message}|{firstLineStackTrace}");
        }
    }
}
