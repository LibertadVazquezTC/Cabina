﻿using System.Threading.Tasks;

namespace CabinaOperativa.Utilities.Interfaces
{
    public interface IAppConfigUtility
    {
        Task<string> ObtenerPorKey(string key);
    }
}
