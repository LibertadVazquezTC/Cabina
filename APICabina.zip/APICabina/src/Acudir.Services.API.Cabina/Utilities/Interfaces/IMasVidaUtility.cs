﻿using CabinaOperativa.DTOs.Asignaciones.Efector.MasVidaInterfaz;
using System.Threading.Tasks;

namespace CabinaOperativa.Utilities.Interfaces
{
    public interface IMasVidaUtility
    {
        Task<MasVidaResponseCrearDTO> EnviarPorInterfaz(int pedidoTramoProveedorUMovilHorarioId);
    }
}
