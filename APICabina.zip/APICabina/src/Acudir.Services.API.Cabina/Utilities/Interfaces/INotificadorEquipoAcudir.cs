﻿using CabinaOperativa.DTOs.sql_Functions;
using CabinaOperativa.Modelo;
using System.Threading.Tasks;

namespace CabinaOperativa.Utilities.Interfaces
{
    public interface INotificadorEquipoAcudir
    {
        Task NotificarCoronavirus(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorarioId,
            fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular);

        Task NotificarAsignacion(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorarioId,
            fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular);

        Task NotificarDesasignacion(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorarioId,
            fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular);

        Task NotificarActualizacionCoseguro(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorarioId,
            float coseguro,
            fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular);

        Task NotificarAnulacion(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorarioId,
            fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular);

        Task NotificarActualizacionHorario(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario,
            string tipoHorario,
            fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular);

        Task NotificarActualizacionTipoPrestacion(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario,
            int tipoPrestacionId,
            fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular);

        Task NotificarInicioDeCarga(fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular);
        Task NotificarCancelacionDeCarga(fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular);
    }
}
