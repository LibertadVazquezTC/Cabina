﻿using CabinaOperativa.DTOs.sql_Functions;
using CabinaOperativa.Modelo;
using System.Threading.Tasks;

namespace CabinaOperativa.Utilities.Interfaces
{
    public interface INotificadorMedicoDeVisitas
    {
        Task NotificarAsignacion(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorarioId, 
            fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular);

        Task NotificarDesasignacion(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorarioId,
            fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular);

        Task NotificarAnulacion(int pedidoId,
            fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular);

        Task NotificarActualizacionPunto(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario,
            PedidoTramoDetalle pedidoTramoDetalle,
            fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular);

        Task NotificarActualizacionHorario(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario,
            string tipoHorario,
            fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular);
    }
}
