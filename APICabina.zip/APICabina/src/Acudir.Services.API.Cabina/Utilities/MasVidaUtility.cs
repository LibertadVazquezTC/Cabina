﻿using CabinaOperativa.DTOs.Asignaciones.Efector.MasVidaInterfaz;
using CabinaOperativa.DTOs.sql_StoreProcedures;
using CabinaOperativa.Exceptions;
using CabinaOperativa.Modelo;
using CabinaOperativa.Repositories;
using CabinaOperativa.Utilities.Interfaces;
using Dapper;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace CabinaOperativa.Utilities
{
    public class MasVidaUtility : IMasVidaUtility
    {
        private readonly IConfiguration _config;
        private readonly IPedidoAfiliadoRepository _pedidoAfiliadoRepository;
        private readonly IPedidoDetalleRepository _pedidoDetalleRepository;
        private readonly IPedidoTramoProveedorUMovilHorarioRepository _pedidoTramoProveedorUMovilHorarioRepository;
        private readonly IPedidoCoseguroRepository _pedidoCoseguroRepository;
        private readonly IEfectorRepository _efectorRepository;

        public MasVidaUtility(IConfiguration config,
            IPedidoAfiliadoRepository pedidoAfiliadoRepository,
            IPedidoTramoRepository pedidoTramoRepository,
            IPedidoDetalleRepository pedidoDetalleRepository,
            IPedidoTramoProveedorUMovilHorarioRepository pedidoTramoProveedorUMovilHorarioRepository,
            IPedidoCoseguroRepository pedidoCoseguroRepository,
            IEfectorRepository efectorRepository)
        {
            _config = config;
            _pedidoAfiliadoRepository = pedidoAfiliadoRepository;
            _pedidoDetalleRepository = pedidoDetalleRepository;
            _pedidoTramoProveedorUMovilHorarioRepository = pedidoTramoProveedorUMovilHorarioRepository;
            _pedidoCoseguroRepository = pedidoCoseguroRepository;
            _efectorRepository = efectorRepository;
        }

        private IDbConnection Connection => new SqlConnection(_config.GetConnectionString("TechMedDatabase"));

        public async Task<MasVidaResponseCrearDTO> EnviarPorInterfaz(int pedidoTramoProveedorUMovilHorarioId)
        {

            PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario = await _pedidoTramoProveedorUMovilHorarioRepository.Obtener(pedidoTramoProveedorUMovilHorarioId);
            if (pedidoTramoProveedorUMovilHorario is null)
                throw new DatoErroneoException($"No existe un pedidoTramoProveedorUMovilHorario con id: {pedidoTramoProveedorUMovilHorarioId}.");

            int pedidoId = pedidoTramoProveedorUMovilHorario.PedidoTramo.PedidoId;
            int pedidoTramoId = pedidoTramoProveedorUMovilHorario.PedidoTramoId;

            PedidoAfiliado pedidoAfiliado = await _pedidoAfiliadoRepository.ObtenerPorPedido(pedidoId);
            PedidoCoseguro pedidoCoseguro = await _pedidoCoseguroRepository.ObtenerPorPedido(pedidoId);

            var esAtencionPrevia = false;
            var sintomaAtencionPrevia = string.Empty;

            if (pedidoAfiliado != null && pedidoAfiliado.PedidoAnteriorId.HasValue)
            {
                PedidoDetalle PedidoDetalleAnterior = await _pedidoDetalleRepository.ObtenerPorPedido(pedidoAfiliado.PedidoAnteriorId.Value);
                esAtencionPrevia = true;
                sintomaAtencionPrevia = string.IsNullOrEmpty(PedidoDetalleAnterior.SintomaTomado) ? "" : PedidoDetalleAnterior.SintomaTomado;
            }

            usp_PedidoTramo_get usp_PedidoTramo_get = null;
            using (IDbConnection connection = Connection)
                usp_PedidoTramo_get = (await connection.QueryAsync<usp_PedidoTramo_get>("usp_PedidoTramo_get", new { pedidoTramoId }, commandType: CommandType.StoredProcedure)).FirstOrDefault();

            if (usp_PedidoTramo_get is null)
                throw new DatoErroneoException($"No se encontró información del tramo {pedidoTramoId}. No se pudo enviar el servicio por interfaz.");

            usp_PedidoTramo_get.Despachador = SecurityUtility.UserName;
            usp_PedidoTramo_get.Coseguro = pedidoCoseguro is null ? 0 : (float)pedidoCoseguro.Coseguro;
            usp_PedidoTramo_get.EsAtencionPrevia = esAtencionPrevia;
            usp_PedidoTramo_get.SintomaAtencionPrevia = sintomaAtencionPrevia;

            string masVidaUrl = _config.GetValue<string>("MasVidaUrl");

            HttpResponseMessage httpResponseMessage = new HttpResponseMessage();
            using (var httpClient = new HttpClient())
            {
                httpClient.BaseAddress = new Uri(masVidaUrl);
                httpClient.DefaultRequestHeaders.Accept.Clear();
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("0", "27AC1E72101ED957057666584EBBDE6A8E1D0BAB201067767AF7BF2A678E8330");
                httpResponseMessage = httpClient.PostAsync($"api/v1/efector/11/pedidos/asignaciones", new StringContent(JsonConvert.SerializeObject(usp_PedidoTramo_get), Encoding.UTF8, "application/json")).Result;
            }

            if (httpResponseMessage.StatusCode == HttpStatusCode.OK)
            {
                MasVidaResponseCrearDTO masVidaResponseCrearDTO = JsonConvert.DeserializeObject<MasVidaResponseCrearDTO>(httpResponseMessage.Content.ReadAsStringAsync().Result);
                if (masVidaResponseCrearDTO != null && masVidaResponseCrearDTO.EstadoOperacion == 0)
                    await _pedidoTramoProveedorUMovilHorarioRepository.ActualizarNroServicio(pedidoTramoProveedorUMovilHorarioId, masVidaResponseCrearDTO.CodigoCliente);
                return masVidaResponseCrearDTO;
            }

            throw new DatoErroneoException($"Fallo el request a la api de MasVida. Status code: {httpResponseMessage.StatusCode.ToString()}");
        }
    }
}

