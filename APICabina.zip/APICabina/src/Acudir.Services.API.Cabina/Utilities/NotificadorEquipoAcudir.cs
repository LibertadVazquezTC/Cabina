﻿using CabinaOperativa.Constants;
using CabinaOperativa.DTOs;
using CabinaOperativa.DTOs.sql_Functions;
using CabinaOperativa.Enums;
using CabinaOperativa.Exceptions;
using CabinaOperativa.Modelo;
using CabinaOperativa.Repositories;
using CabinaOperativa.Utilities.Interfaces;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace CabinaOperativa.Utilities
{
    public class NotificadorEquipoAcudir : UmsUtility, INotificadorEquipoAcudir
    {
        private readonly IConfiguration _config;
        private readonly IPedidoDetalleRepository _pedidoDetalleRepository;
        private readonly IPedidoTramoDetalleRepository _pedidoTramoDetalleRepository;
        private readonly IPedidoTriageVersionDetalleLogRepository _pedidoTriageVersionDetalleLogRepository;
        private readonly IPedidoTramoProveedorUMovilHorarioRepository _pedidoTramoProveedorUMovilHorarioRepository;

        public NotificadorEquipoAcudir(IConfiguration config,
            IPedidoDetalleRepository pedidoDetalleRepository,
            IPedidoTramoDetalleRepository pedidoTramoDetalleRepository,
            IPedidoTriageVersionDetalleLogRepository pedidoTriageVersionDetalleLogRepository,
            IPedidoTramoProveedorUMovilHorarioRepository pedidoTramoProveedorUMovilHorarioRepository) : base(config)
        {
            _config = config;
            _pedidoTramoDetalleRepository = pedidoTramoDetalleRepository;
            _pedidoDetalleRepository = pedidoDetalleRepository;
            _pedidoTriageVersionDetalleLogRepository = pedidoTriageVersionDetalleLogRepository;
            _pedidoTramoProveedorUMovilHorarioRepository = pedidoTramoProveedorUMovilHorarioRepository;
        }

        private IDbConnection Connection => new SqlConnection(_config.GetConnectionString("TechMedDatabase"));

        #region Coronavirus
        public async Task NotificarCoronavirus(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario,
            fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular)
        {
            int tipoDeEnvio = 0;

            if (!string.IsNullOrEmpty(cmnCelular.Numero) && !string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.PushSms;
            else if (string.IsNullOrEmpty(cmnCelular.Numero) && !string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.Push;
            else if (!string.IsNullOrEmpty(cmnCelular.Numero) && string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.Sms;
            else return;

            UmsSendDTO umsSendDTO = new UmsSendDTO();
            umsSendDTO.Tipo = ConstantesUms.TIPO_MENSAJE_MOVIL;
            umsSendDTO.SubTipo = ConstantesUms.SUBTIPO_MENSAJE_MOVIL_MENSAJE;
            umsSendDTO.Imei = cmnCelular.Imei;
            umsSendDTO.Title = "¡Atención!";
            umsSendDTO.UMovilId = pedidoTramoProveedorUMovilHorario.UMovilId;
            umsSendDTO.TipoEnvio = tipoDeEnvio;
            umsSendDTO.Celular = 11 + cmnCelular.Numero;
            umsSendDTO.RegistrationFCMId = cmnCelular.FcmTokenNotify;
            umsSendDTO.CelularModoPrueba = cmnCelular.EstaModoPrueba;

            #region Generación de Mensaje Push
            umsSendDTO.Contenido = ConstantesUms.TIPO_MENSAJE_MOVIL + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES + ConstantesUms.SUBTIPO_MENSAJE_MOVIL_MENSAJE + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += "Sospecha Coronavirus - utilizar Kit" + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += "";
            #endregion

            #region Generación Mensaje Sms
            umsSendDTO.ContenidoSMS = ConstantesUms.TIPO_MENSAJE_MOVIL + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES + ConstantesUms.SUBTIPO_MENSAJE_MOVIL_MENSAJE + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += "Sospecha Coronavirus - utilizar Kit" + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += "";
            if (umsSendDTO.ContenidoSMS.Length > 145) umsSendDTO.ContenidoSMS.Substring(0, 145);
            #endregion

            HttpResponseMessage httpResponseMessage = await EnviarRequest(umsSendDTO);
            if (!httpResponseMessage.IsSuccessStatusCode)
                throw new FalloDeNotificacionException(httpResponseMessage.Content.ReadAsStringAsync().Result);
        }
        #endregion

        #region Asignación
        public async Task NotificarAsignacion(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario,
            fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular)
        {
            PedidoTramoDetalle pedidoTramoDetalleOrigen = await _pedidoTramoDetalleRepository.ObtenerPorPedidoTramoYTipo(pedidoTramoProveedorUMovilHorario.PedidoTramoId, OrigenDestinoEnum.Origen);
            int pedidoId = pedidoTramoProveedorUMovilHorario.PedidoTramo.PedidoId;
            PedidoDetalle pedidoDetalle = await _pedidoDetalleRepository.ObtenerPorPedido(pedidoId);
            IEnumerable<PedidoTriageVersionDetalleLog> pedidoTriageVersionDetalleLogs = await _pedidoTriageVersionDetalleLogRepository.ListarPorPedido(pedidoId);

            string sintomaCompleto = "";
            if (pedidoTriageVersionDetalleLogs != null && pedidoTriageVersionDetalleLogs.Count() > 0)
            {
                PedidoTriageVersionDetalleLog triageVersionDetalleLogRaiz = pedidoTriageVersionDetalleLogs.FirstOrDefault();
                sintomaCompleto = triageVersionDetalleLogRaiz != null && triageVersionDetalleLogRaiz.TriageVersionDetalle != null ? triageVersionDetalleLogRaiz.TriageVersionDetalle.Descripcion.Trim() + " - " : "";
            }

            if (pedidoDetalle != null)
            {
                sintomaCompleto += !string.IsNullOrEmpty(pedidoDetalle.SintomaTomado) ? pedidoDetalle.SintomaTomado.Trim() : "";
                sintomaCompleto += !string.IsNullOrEmpty(pedidoDetalle.DiagnosticoTomado) ? pedidoDetalle.DiagnosticoTomado.Trim() : "";
                sintomaCompleto += (!string.IsNullOrEmpty(pedidoDetalle.Observacion)) ? " obs.:" + pedidoDetalle.Observacion.Trim() : "";
            }

            var domicilio = pedidoTramoDetalleOrigen.Direccion.Domicilio.Trim().Split(',').ToList().ElementAt(0).ToUpper();

            domicilio += "-  Piso: " + pedidoTramoDetalleOrigen.Direccion.Piso + "-  Dpto: " + pedidoTramoDetalleOrigen.Direccion.Depto;
            if ((pedidoTramoDetalleOrigen.PedidoTramo.Pedido.TipoPrestacion.Descripcion == "Rojo") && (pedidoDetalle != null))
            {
                domicilio += "  Tel:";//+ pedidoDetalle.Telefono;
            }

            if (!string.IsNullOrEmpty(pedidoTramoDetalleOrigen.Direccion.CalleAdyacente1))
            {
                domicilio += _umsViejo.RecortarCalles(pedidoTramoDetalleOrigen.Direccion.CalleAdyacente1.ToUpper());
            }
            if (!string.IsNullOrEmpty(pedidoTramoDetalleOrigen.Direccion.CalleAdyacente2))
            {
                domicilio += _umsViejo.RecortarCalles(pedidoTramoDetalleOrigen.Direccion.CalleAdyacente2.ToUpper());
            }

            int tipoDeEnvio = 0;

            if (!string.IsNullOrEmpty(cmnCelular.Numero) && !string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.PushSms;
            else if (string.IsNullOrEmpty(cmnCelular.Numero) && !string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.Push;
            else if (!string.IsNullOrEmpty(cmnCelular.Numero) && string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.Sms;
            else return;

            UmsSendDTO umsSendDTO = new UmsSendDTO();
            umsSendDTO.Tipo = ConstantesUms.TIPO_MENSAJE_PEDIDO;
            umsSendDTO.SubTipo = ConstantesUms.SUBTIPO_MENSAJE_ASIGNACION;
            umsSendDTO.Imei = cmnCelular.Imei;
            umsSendDTO.TipoEnvio = tipoDeEnvio;
            umsSendDTO.Celular = 11 + cmnCelular.Numero;
            umsSendDTO.RegistrationFCMId = cmnCelular.FcmTokenNotify;
            umsSendDTO.CelularModoPrueba = cmnCelular.EstaModoPrueba;

            #region Generación de Mensaje Push
            umsSendDTO.Contenido = _umsViejo.ObtenerHojaDeRutaMobilePorMovilYPedidoId(pedidoTramoProveedorUMovilHorario.UMovilId.Value, pedidoId, false);
            #endregion

            #region Generación Mensaje Sms
            umsSendDTO.ContenidoSMS = ConstantesUms.TIPO_MENSAJE_PEDIDO + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES + ConstantesUms.SUBTIPO_MENSAJE_ASIGNACION + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += pedidoId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += pedidoDetalle.Pedido.TipoPrestacionId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += "1" + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += "1" + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += (pedidoDetalle.Pedido.EsProtocoloIAM ? "S" : "N") + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += (pedidoDetalle.Pedido.EsProtocoloStroke ? "S" : "N") + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += "N" + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += (pedidoDetalle.Pedido.Sexo + "-" + pedidoDetalle.Pedido.Edad).Trim(new char[] { ' ' }) + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += pedidoTramoDetalleOrigen.Direccion.DireccionLocalidadId.ToString() + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += pedidoTramoDetalleOrigen.Direccion.Domicilio.Trim().Split(',').ToList().ElementAt(0).ToUpper() + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += QuitarCaracteresEspeciales(sintomaCompleto);
            if (umsSendDTO.ContenidoSMS.Length > 145) umsSendDTO.ContenidoSMS.Substring(0, 145);
            #endregion

            HttpResponseMessage httpResponseMessage = await EnviarRequest(umsSendDTO);
            if (!httpResponseMessage.IsSuccessStatusCode)
                throw new FalloDeNotificacionException(httpResponseMessage.Content.ReadAsStringAsync().Result);
        }
        #endregion

        #region Anulación
        public async Task NotificarAnulacion(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario,
            fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular)
        {
            int tipoDeEnvio = 0;

            if (!string.IsNullOrEmpty(cmnCelular.Numero) && !string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.PushSms;
            else if (string.IsNullOrEmpty(cmnCelular.Numero) && !string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.Push;
            else if (!string.IsNullOrEmpty(cmnCelular.Numero) && string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.Sms;
            else return;

            UmsSendDTO umsSendDTO = new UmsSendDTO();
            umsSendDTO.Tipo = ConstantesUms.TIPO_MENSAJE_PEDIDO;
            umsSendDTO.SubTipo = ConstantesUms.SUBTIPO_MENSAJE_DESASIGNACION;
            umsSendDTO.Imei = cmnCelular.Imei;
            umsSendDTO.TipoEnvio = tipoDeEnvio;
            umsSendDTO.Celular = 11 + cmnCelular.Numero;
            umsSendDTO.RegistrationFCMId = cmnCelular.FcmTokenNotify;
            umsSendDTO.CelularModoPrueba = cmnCelular.EstaModoPrueba;

            #region Generación Mensaje Push
            umsSendDTO.Contenido = ConstantesUms.TIPO_MENSAJE_PEDIDO + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES + ConstantesUms.SUBTIPO_MENSAJE_ANULACION + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += pedidoTramoProveedorUMovilHorario.PedidoTramo.PedidoId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += "1" + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES + "1";
            #endregion

            #region Generación Mensaje Sms
            umsSendDTO.ContenidoSMS = ConstantesUms.TIPO_MENSAJE_PEDIDO + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES + ConstantesUms.SUBTIPO_MENSAJE_ANULACION + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += pedidoTramoProveedorUMovilHorario.PedidoTramo.PedidoId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += "1" + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES + "1";
            #endregion

            HttpResponseMessage httpResponseMessage = await EnviarRequest(umsSendDTO);
            if (!httpResponseMessage.IsSuccessStatusCode)
                throw new FalloDeNotificacionException(httpResponseMessage.Content.ReadAsStringAsync().Result);
        }
        #endregion

        #region Desasignación
        public async Task NotificarDesasignacion(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario,
            fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular)
        {
            int tipoDeEnvio = 0;

            if (!string.IsNullOrEmpty(cmnCelular.Numero) && !string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.PushSms;
            else if (string.IsNullOrEmpty(cmnCelular.Numero) && !string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.Push;
            else if (!string.IsNullOrEmpty(cmnCelular.Numero) && string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.Sms;
            else return;

            UmsSendDTO umsSendDTO = new UmsSendDTO();
            umsSendDTO.Tipo = ConstantesUms.TIPO_MENSAJE_PEDIDO;
            umsSendDTO.SubTipo = ConstantesUms.SUBTIPO_MENSAJE_DESASIGNACION;
            umsSendDTO.Imei = cmnCelular.Imei;
            umsSendDTO.TipoEnvio = tipoDeEnvio;
            umsSendDTO.Celular = 11 + cmnCelular.Numero;
            umsSendDTO.RegistrationFCMId = cmnCelular.FcmTokenNotify;
            umsSendDTO.CelularModoPrueba = cmnCelular.EstaModoPrueba;

            #region Generación Mensaje Push
            umsSendDTO.Contenido = ConstantesUms.TIPO_MENSAJE_PEDIDO + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES + ConstantesUms.SUBTIPO_MENSAJE_DESASIGNACION + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += pedidoTramoProveedorUMovilHorario.PedidoTramo.PedidoId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += "1" + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES + "1";
            #endregion

            #region Generación Mensaje Sms
            umsSendDTO.ContenidoSMS = ConstantesUms.TIPO_MENSAJE_PEDIDO + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES + ConstantesUms.SUBTIPO_MENSAJE_DESASIGNACION + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += pedidoTramoProveedorUMovilHorario.PedidoTramo.PedidoId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += "1" + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES + "1";
            #endregion

            HttpResponseMessage httpResponseMessage = await EnviarRequest(umsSendDTO);
            if (!httpResponseMessage.IsSuccessStatusCode)
                throw new FalloDeNotificacionException(httpResponseMessage.Content.ReadAsStringAsync().Result);
        }
        #endregion

        #region Actualizacion coseguro
        public async Task NotificarActualizacionCoseguro(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario,
            float coseguro,
            fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular)
        {
            int tipoDeEnvio = 0;

            if (!string.IsNullOrEmpty(cmnCelular.Numero) && !string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.PushSms;
            else if (string.IsNullOrEmpty(cmnCelular.Numero) && !string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.Push;
            else if (!string.IsNullOrEmpty(cmnCelular.Numero) && string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.Sms;
            else return;

            UmsSendDTO umsSendDTO = new UmsSendDTO();
            umsSendDTO.Tipo = ConstantesUms.TIPO_MENSAJE_PEDIDO;
            umsSendDTO.SubTipo = ConstantesUms.SUBTIPO_MENSAJE_PEDIDO_ACTUALIZA_COSEGURO;
            umsSendDTO.Imei = cmnCelular.Imei;
            umsSendDTO.TipoEnvio = tipoDeEnvio;
            umsSendDTO.Celular = 11 + cmnCelular.Numero;
            umsSendDTO.RegistrationFCMId = cmnCelular.FcmTokenNotify;
            umsSendDTO.CelularModoPrueba = cmnCelular.EstaModoPrueba;

            #region Generación Mensaje Push
            umsSendDTO.Contenido = ConstantesUms.TIPO_MENSAJE_PEDIDO + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES + ConstantesUms.SUBTIPO_MENSAJE_PEDIDO_ACTUALIZA_COSEGURO + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += pedidoTramoProveedorUMovilHorario.PedidoTramo.PedidoId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += coseguro.ToString() + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            #endregion

            #region Generación Mensaje Sms
            umsSendDTO.ContenidoSMS = ConstantesUms.TIPO_MENSAJE_PEDIDO + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES + ConstantesUms.SUBTIPO_MENSAJE_PEDIDO_ACTUALIZA_COSEGURO + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += pedidoTramoProveedorUMovilHorario.PedidoTramo.PedidoId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += coseguro.ToString() + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;

            if (umsSendDTO.ContenidoSMS.Length > 145) umsSendDTO.ContenidoSMS.Substring(0, 145);
            #endregion

            HttpResponseMessage httpResponseMessage = await EnviarRequest(umsSendDTO);
            if (!httpResponseMessage.IsSuccessStatusCode)
                throw new FalloDeNotificacionException(httpResponseMessage.Content.ReadAsStringAsync().Result);
        }
        #endregion

        #region Actualización horario 
        public async Task NotificarActualizacionHorario(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario,
            string tipoHorario,
            fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular)
        {
            int tipoDeEnvio = 0;

            if (!string.IsNullOrEmpty(cmnCelular.Numero) && !string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.PushSms;
            else if (string.IsNullOrEmpty(cmnCelular.Numero) && !string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.Push;
            else if (!string.IsNullOrEmpty(cmnCelular.Numero) && string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.Sms;
            else return;

            UmsSendDTO umsSendDTO = new UmsSendDTO();
            umsSendDTO.Tipo = ConstantesUms.TIPO_MENSAJE_PEDIDO;
            umsSendDTO.SubTipo = ConstantesUms.SUBTIPO_MENSAJE_PEDIDO_ACTUALIZA_COSEGURO;
            umsSendDTO.Imei = cmnCelular.Imei;
            umsSendDTO.TipoEnvio = tipoDeEnvio;
            umsSendDTO.Celular = 11 + cmnCelular.Numero;
            umsSendDTO.RegistrationFCMId = cmnCelular.FcmTokenNotify;
            umsSendDTO.CelularModoPrueba = cmnCelular.EstaModoPrueba;

            string subTipo = tipoHorario == "OrigenArribo" ?
                ConstantesUms.SUBTIPO_MENSAJE_PEDIDO_ORIGEN_ARRIBO :
                ConstantesUms.SUBTIPO_MENSAJE_PEDIDO_ORIGEN_PARTIDA;

            string horario = tipoHorario == "OrigenArribo" ?
                pedidoTramoProveedorUMovilHorario.OrigenArribo.Value.ToString("dd/MM/yyyy HH:mm:ss") :
                pedidoTramoProveedorUMovilHorario.OrigenPartida.Value.ToString("dd/MM/yyyy HH:mm:ss");

            #region Generación Mensaje Push
            umsSendDTO.Contenido = ConstantesUms.TIPO_MENSAJE_PEDIDO + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES + subTipo + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += pedidoTramoProveedorUMovilHorario.PedidoTramo.PedidoId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += horario;
            #endregion

            #region Generación Mensaje Sms
            umsSendDTO.ContenidoSMS = ConstantesUms.TIPO_MENSAJE_PEDIDO + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES + subTipo + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += pedidoTramoProveedorUMovilHorario.PedidoTramo.PedidoId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += horario;

            if (umsSendDTO.ContenidoSMS.Length > 145) umsSendDTO.ContenidoSMS.Substring(0, 145);
            #endregion

            HttpResponseMessage httpResponseMessage = await EnviarRequest(umsSendDTO);
            if (!httpResponseMessage.IsSuccessStatusCode)
                throw new FalloDeNotificacionException(httpResponseMessage.Content.ReadAsStringAsync().Result);

        }
        #endregion

        #region Actualización tipo prestación
        public async Task NotificarActualizacionTipoPrestacion(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario,
            int tipoPrestacionId,
            fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular)
        {
            int tipoDeEnvio = 0;

            if (!string.IsNullOrEmpty(cmnCelular.Numero) && !string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.PushSms;
            else if (string.IsNullOrEmpty(cmnCelular.Numero) && !string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.Push;
            else if (!string.IsNullOrEmpty(cmnCelular.Numero) && string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.Sms;
            else return;

            UmsSendDTO umsSendDTO = new UmsSendDTO();
            umsSendDTO.Tipo = ConstantesUms.TIPO_MENSAJE_PEDIDO;
            umsSendDTO.SubTipo = ConstantesUms.SUBTIPO_MENSAJE_PEDIDO_ACTUALIZA_COSEGURO;
            umsSendDTO.Imei = cmnCelular.Imei;
            umsSendDTO.TipoEnvio = tipoDeEnvio;
            umsSendDTO.Celular = 11 + cmnCelular.Numero;
            umsSendDTO.RegistrationFCMId = cmnCelular.FcmTokenNotify;
            umsSendDTO.CelularModoPrueba = cmnCelular.EstaModoPrueba;

            #region Generación Mensaje Push
            umsSendDTO.Contenido = ConstantesUms.TIPO_MENSAJE_PEDIDO + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES + ConstantesUms.SUBTIPO_MENSAJE_PEDIDO_ACTUALIZA_TIPO_PRESTACION + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += pedidoTramoProveedorUMovilHorario.PedidoTramo.PedidoId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += tipoPrestacionId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            #endregion

            #region Generación Mensaje Sms
            umsSendDTO.ContenidoSMS = ConstantesUms.TIPO_MENSAJE_PEDIDO + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES + ConstantesUms.SUBTIPO_MENSAJE_PEDIDO_ACTUALIZA_TIPO_PRESTACION + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += pedidoTramoProveedorUMovilHorario.PedidoTramo.PedidoId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += tipoPrestacionId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;

            if (umsSendDTO.ContenidoSMS.Length > 145) umsSendDTO.ContenidoSMS.Substring(0, 145);
            #endregion

            HttpResponseMessage httpResponseMessage = await EnviarRequest(umsSendDTO);
            if (!httpResponseMessage.IsSuccessStatusCode)
                throw new FalloDeNotificacionException(httpResponseMessage.Content.ReadAsStringAsync().Result);
        }
        #endregion

        #region Inicio de carga
        public async Task NotificarInicioDeCarga(fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular)
        {
            int tipoDeEnvio = 0;

            if (!string.IsNullOrEmpty(cmnCelular.Numero) && !string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.PushSms;
            else if (string.IsNullOrEmpty(cmnCelular.Numero) && !string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.Push;
            else if (!string.IsNullOrEmpty(cmnCelular.Numero) && string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.Sms;
            else return;

            UmsSendDTO umsSendDTO = new UmsSendDTO();
            umsSendDTO.Tipo = ConstantesUms.TIPO_MENSAJE_MOVIL;
            umsSendDTO.SubTipo = ConstantesUms.SUBTIPO_MENSAJE_MOVIL_INICIO_DE_CARGA;
            umsSendDTO.Imei = cmnCelular.Imei;
            umsSendDTO.TipoEnvio = tipoDeEnvio;
            umsSendDTO.Celular = 11 + cmnCelular.Numero;
            umsSendDTO.RegistrationFCMId = cmnCelular.FcmTokenNotify;
            umsSendDTO.CelularModoPrueba = cmnCelular.EstaModoPrueba;

            #region Generación Mensaje Push
            umsSendDTO.Contenido = ConstantesUms.TIPO_MENSAJE_MOVIL + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES + ConstantesUms.SUBTIPO_MENSAJE_MOVIL_INICIO_DE_CARGA + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += DateTime.Now.ToString();
            #endregion

            #region Generación Mensaje Sms
            umsSendDTO.ContenidoSMS = ConstantesUms.TIPO_MENSAJE_MOVIL + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES + ConstantesUms.SUBTIPO_MENSAJE_MOVIL_INICIO_DE_CARGA + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += DateTime.Now.ToString();

            if (umsSendDTO.ContenidoSMS.Length > 145) umsSendDTO.ContenidoSMS.Substring(0, 145);
            #endregion

            HttpResponseMessage httpResponseMessage = await EnviarRequest(umsSendDTO);
            if (!httpResponseMessage.IsSuccessStatusCode)
                throw new FalloDeNotificacionException(httpResponseMessage.Content.ReadAsStringAsync().Result);
        }
        #endregion

        #region Cancelación de carga
        public async Task NotificarCancelacionDeCarga(fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular)
        {
            int tipoDeEnvio = 0;

            if (!string.IsNullOrEmpty(cmnCelular.Numero) && !string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.PushSms;
            else if (string.IsNullOrEmpty(cmnCelular.Numero) && !string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.Push;
            else if (!string.IsNullOrEmpty(cmnCelular.Numero) && string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.Sms;
            else return;

            UmsSendDTO umsSendDTO = new UmsSendDTO();
            umsSendDTO.Tipo = ConstantesUms.TIPO_MENSAJE_MOVIL;
            umsSendDTO.SubTipo = ConstantesUms.SUBTIPO_MENSAJE_MOVIL_CANCELACION_DE_CARGA;
            umsSendDTO.Imei = cmnCelular.Imei;
            umsSendDTO.TipoEnvio = tipoDeEnvio;
            umsSendDTO.Celular = 11 + cmnCelular.Numero;
            umsSendDTO.RegistrationFCMId = cmnCelular.FcmTokenNotify;
            umsSendDTO.CelularModoPrueba = cmnCelular.EstaModoPrueba;

            #region Generación Mensaje Push
            umsSendDTO.Contenido = ConstantesUms.TIPO_MENSAJE_MOVIL + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES + ConstantesUms.SUBTIPO_MENSAJE_MOVIL_CANCELACION_DE_CARGA + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += DateTime.Now.ToString();
            #endregion

            #region Generación Mensaje Sms
            umsSendDTO.ContenidoSMS = ConstantesUms.TIPO_MENSAJE_MOVIL + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES + ConstantesUms.SUBTIPO_MENSAJE_MOVIL_CANCELACION_DE_CARGA + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += DateTime.Now.ToString();

            if (umsSendDTO.ContenidoSMS.Length > 145) umsSendDTO.ContenidoSMS.Substring(0, 145);
            #endregion

            HttpResponseMessage httpResponseMessage = await EnviarRequest(umsSendDTO);
            if (!httpResponseMessage.IsSuccessStatusCode)
                throw new FalloDeNotificacionException(httpResponseMessage.Content.ReadAsStringAsync().Result);
        }
        #endregion
    }
}
