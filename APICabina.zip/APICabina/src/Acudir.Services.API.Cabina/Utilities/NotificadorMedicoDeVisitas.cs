﻿using CabinaOperativa.Constants;
using CabinaOperativa.DTOs;
using CabinaOperativa.DTOs.sql_Functions;
using CabinaOperativa.DTOs.sql_StoreProcedures;
using CabinaOperativa.Enums;
using CabinaOperativa.Exceptions;
using CabinaOperativa.Modelo;
using CabinaOperativa.Utilities.Interfaces;
using Dapper;
using Microsoft.Extensions.Configuration;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace CabinaOperativa.Utilities
{
    public class NotificadorMedicoDeVisitas : UmsUtility, INotificadorMedicoDeVisitas
    {
        private readonly IConfiguration _config;

        public NotificadorMedicoDeVisitas(IConfiguration config) : base(config)
        {
            _config = config;
        }

        private IDbConnection Connection => new SqlConnection(_config.GetConnectionString("TechMedDatabase"));

        #region Asignación
        public async Task NotificarAsignacion(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario,
            fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular)
        {
            usp_PedidoTramoDespacho_Visita_get informacionAsignacion = null;
            using (IDbConnection connection = Connection)
                informacionAsignacion = (await connection.QueryAsync<usp_PedidoTramoDespacho_Visita_get>("usp_PedidoTramoDespacho_Visita_get", new { pedidoTramoProveedorUMovilHorario.GdiaRealEquipoId, pedidoTramoProveedorUMovilHorario.PedidoTramo.PedidoId }, commandType: CommandType.StoredProcedure)).FirstOrDefault();

            int tipoDeEnvio = 0;

            if (!string.IsNullOrEmpty(informacionAsignacion.Numero) && !string.IsNullOrEmpty(informacionAsignacion.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.PushSms;
            else if (string.IsNullOrEmpty(informacionAsignacion.Numero) && !string.IsNullOrEmpty(informacionAsignacion.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.Push;
            else if (!string.IsNullOrEmpty(informacionAsignacion.Numero) && string.IsNullOrEmpty(informacionAsignacion.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.Sms;
            else return;

            UmsSendDTO umsSendDTO = new UmsSendDTO();
            umsSendDTO.Tipo = ConstantesUms.TIPO_MENSAJE_PEDIDO;
            umsSendDTO.SubTipo = ConstantesUms.SUBTIPO_MENSAJE_DESPACHO_COMPLETO;
            umsSendDTO.TipoEnvio = tipoDeEnvio;
            umsSendDTO.Celular = 11 + informacionAsignacion.Numero;
            umsSendDTO.RegistrationFCMId = informacionAsignacion.FcmTokenNotify;
            umsSendDTO.CelularModoPrueba = cmnCelular.EstaModoPrueba;

            #region Generación Mensaje Push
            umsSendDTO.Contenido = ConstantesUms.TIPO_MENSAJE_PEDIDO + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES + ConstantesUms.SUBTIPO_MENSAJE_DESPACHO_COMPLETO + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += informacionAsignacion.PedidoId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += informacionAsignacion.TipoPrestacionId + ConstantesUms.SEPARADOR_CAMPOS;
            umsSendDTO.Contenido += RemoverCaracteresProhibidos(informacionAsignacion.ContratoDescripcion) + ConstantesUms.SEPARADOR_CAMPOS;
            umsSendDTO.Contenido += RemoverCaracteresProhibidos(informacionAsignacion.AfiliadoNombre) + ConstantesUms.SEPARADOR_CAMPOS;
            umsSendDTO.Contenido += RemoverCaracteresProhibidos(informacionAsignacion.ContratoPlan) + ConstantesUms.SEPARADOR_CAMPOS;
            umsSendDTO.Contenido += RemoverCaracteresProhibidos(informacionAsignacion.AfiliadoObservacion) + ConstantesUms.SEPARADOR_CAMPOS;
            umsSendDTO.Contenido += RemoverCaracteresProhibidos(informacionAsignacion.PedidoDetalleObservacion) + ConstantesUms.SEPARADOR_CAMPOS;
            umsSendDTO.Contenido += RemoverCaracteresProhibidos(informacionAsignacion.SexoEdad) + ConstantesUms.SEPARADOR_CAMPOS;
            umsSendDTO.Contenido += RemoverCaracteresProhibidos(informacionAsignacion.CodigoReferenteDeCliente) + ConstantesUms.SEPARADOR_CAMPOS;
            umsSendDTO.Contenido += RemoverCaracteresProhibidos(informacionAsignacion.SintomaTomado) + ConstantesUms.SEPARADOR_CAMPOS;
            umsSendDTO.Contenido += "" + ConstantesUms.SEPARADOR_CAMPOS;
            //  umsSendDTO.Contenido += RemoverCaracteresProhibidos(informacionAsignacion.AfiliadoTelefono) + ConstantesUms.SEPARADOR_CAMPOS;
            umsSendDTO.Contenido += informacionAsignacion.Coseguro + ConstantesUms.SEPARADOR_CAMPOS;
            umsSendDTO.Contenido += (informacionAsignacion.Art ? 'S' : 'N') + ConstantesUms.SEPARADOR_CAMPOS;
            umsSendDTO.Contenido += informacionAsignacion.PermiteRechazo;

            umsSendDTO.Contenido += ConstantesUms.SEPARADOR_CABECERA;

            umsSendDTO.Contenido += informacionAsignacion.PedidoTramoId + ConstantesUms.SEPARADOR_CAMPOS;
            umsSendDTO.Contenido += informacionAsignacion.PedidoTramoProveedorUMovilHorarioId + ConstantesUms.SEPARADOR_CAMPOS;
            umsSendDTO.Contenido += informacionAsignacion.PedidoTramoProveedorUMovilHorarioEstadoId + ConstantesUms.SEPARADOR_CAMPOS;
            umsSendDTO.Contenido += (informacionAsignacion.OrigenHorarioProgramado.HasValue ? informacionAsignacion.OrigenHorarioProgramado.Value.ToString("dd/MM/yyyy HH:mm:ss") : "") + ConstantesUms.SEPARADOR_CAMPOS;
            umsSendDTO.Contenido += RemoverCaracteresProhibidos(informacionAsignacion.OrigenDomicilio) + ConstantesUms.SEPARADOR_CAMPOS;
            umsSendDTO.Contenido += informacionAsignacion.OrigenDireccionLocalidadId + ConstantesUms.SEPARADOR_CAMPOS;
            umsSendDTO.Contenido += RemoverCaracteresProhibidos(informacionAsignacion.OrigenPiso) + ConstantesUms.SEPARADOR_CAMPOS;
            umsSendDTO.Contenido += RemoverCaracteresProhibidos(informacionAsignacion.OrigenDepto) + ConstantesUms.SEPARADOR_CAMPOS;
            umsSendDTO.Contenido += RemoverCaracteresProhibidos(informacionAsignacion.OrigenObservacion) + ConstantesUms.SEPARADOR_CAMPOS;
            umsSendDTO.Contenido += RemoverCaracteresProhibidos(informacionAsignacion.OrigenCalleAdyacente1) + ConstantesUms.SEPARADOR_CAMPOS;
            umsSendDTO.Contenido += RemoverCaracteresProhibidos(informacionAsignacion.OrigenCalleAdyacente2) + ConstantesUms.SEPARADOR_CAMPOS;
            umsSendDTO.Contenido += (informacionAsignacion.OrigenArribo.HasValue ? informacionAsignacion.OrigenArribo.Value.ToString("dd/MM/yyyy HH:mm:ss") : "") + ConstantesUms.SEPARADOR_CAMPOS;
            umsSendDTO.Contenido += (informacionAsignacion.OrigenPartida.HasValue ? informacionAsignacion.OrigenPartida.Value.ToString("dd/MM/yyyy HH:mm:ss") : "") + ConstantesUms.SEPARADOR_CAMPOS;
            umsSendDTO.Contenido += (informacionAsignacion.OrigenLatitud.HasValue ? informacionAsignacion.OrigenLatitud.Value.ToString().Replace(",", ".") : "") + ConstantesUms.SEPARADOR_CAMPOS;
            umsSendDTO.Contenido += (informacionAsignacion.OrigenLongitud.HasValue ? informacionAsignacion.OrigenLongitud.Value.ToString().Replace(",", ".") : "");
            #endregion

            #region Generación Mensaje Sms
            umsSendDTO.ContenidoSMS = ConstantesUms.TIPO_MENSAJE_PEDIDO + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES + ConstantesUms.SUBTIPO_MENSAJE_ASIGNACION + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += informacionAsignacion.PedidoId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += informacionAsignacion.PedidoTramoProveedorUMovilHorarioId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += informacionAsignacion.TipoPrestacionId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += informacionAsignacion.PermiteRechazo + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += RemoverCaracteresProhibidos(informacionAsignacion.SexoEdad) + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += (informacionAsignacion.OrigenHorarioProgramado.HasValue ? informacionAsignacion.OrigenHorarioProgramado.Value.ToString("dd/MM/yyyy HH:mm:ss") : "") + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += informacionAsignacion.OrigenDireccionLocalidadId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += RemoverCaracteresProhibidos(informacionAsignacion.OrigenDomicilio) + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += RemoverCaracteresProhibidos(informacionAsignacion.SintomaTomado);
            if (umsSendDTO.ContenidoSMS.Length > 145) umsSendDTO.ContenidoSMS.Substring(0, 145);
            #endregion

            HttpResponseMessage httpResponseMessage = await EnviarRequest(umsSendDTO);
            if (!httpResponseMessage.IsSuccessStatusCode)
                throw new FalloDeNotificacionException(httpResponseMessage.Content.ReadAsStringAsync().Result);
        }
        #endregion

        #region Desasignación
        public async Task NotificarDesasignacion(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario,
            fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular)
        {
            int tipoDeEnvio = 0;

            if (!string.IsNullOrEmpty(cmnCelular.Numero) && !string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.PushSms;
            else if (string.IsNullOrEmpty(cmnCelular.Numero) && !string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.Push;
            else if (!string.IsNullOrEmpty(cmnCelular.Numero) && string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.Sms;
            else return;


            UmsSendDTO umsSendDTO = new UmsSendDTO();
            umsSendDTO.Tipo = ConstantesUms.TIPO_MENSAJE_PEDIDO;
            umsSendDTO.SubTipo = ConstantesUms.SUBTIPO_MENSAJE_DESASIGNACION;
            umsSendDTO.TipoEnvio = tipoDeEnvio;
            umsSendDTO.Celular = 11 + cmnCelular.Numero;
            umsSendDTO.RegistrationFCMId = cmnCelular.FcmTokenNotify;
            umsSendDTO.CelularModoPrueba = cmnCelular.EstaModoPrueba;

            #region Generación Mensaje Push
            umsSendDTO.Contenido = ConstantesUms.TIPO_MENSAJE_PEDIDO + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES + ConstantesUms.SUBTIPO_MENSAJE_DESASIGNACION + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += cmnCelular + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioId;
            #endregion

            #region Generación Mensaje Sms
            umsSendDTO.ContenidoSMS = ConstantesUms.TIPO_MENSAJE_PEDIDO + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES + ConstantesUms.SUBTIPO_MENSAJE_DESASIGNACION + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += pedidoTramoProveedorUMovilHorario.PedidoTramo.PedidoId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioId;
            #endregion

            HttpResponseMessage httpResponseMessage = await EnviarRequest(umsSendDTO);
            if (!httpResponseMessage.IsSuccessStatusCode)
                throw new FalloDeNotificacionException(httpResponseMessage.Content.ReadAsStringAsync().Result);
        }
        #endregion

        #region Anulación
        public async Task NotificarAnulacion(int pedidoId, fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular)
        {
            int tipoDeEnvio = 0;

            if (!string.IsNullOrEmpty(cmnCelular.Numero) && !string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.PushSms;
            else if (string.IsNullOrEmpty(cmnCelular.Numero) && !string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.Push;
            else if (!string.IsNullOrEmpty(cmnCelular.Numero) && string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.Sms;
            else return;

            UmsSendDTO umsSendDTO = new UmsSendDTO();
            umsSendDTO.Tipo = ConstantesUms.TIPO_MENSAJE_PEDIDO;
            umsSendDTO.SubTipo = ConstantesUms.SUBTIPO_MENSAJE_ANULACION;
            umsSendDTO.TipoEnvio = tipoDeEnvio;
            umsSendDTO.Celular = 11 + cmnCelular.Numero;
            umsSendDTO.RegistrationFCMId = cmnCelular.FcmTokenNotify;
            umsSendDTO.CelularModoPrueba = cmnCelular.EstaModoPrueba;

            #region Generación Mensaje Push
            umsSendDTO.Contenido = ConstantesUms.TIPO_MENSAJE_PEDIDO + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES + ConstantesUms.SUBTIPO_MENSAJE_ANULACION + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += pedidoId;
            #endregion

            #region Generación Mensaje Sms
            umsSendDTO.Contenido = ConstantesUms.TIPO_MENSAJE_PEDIDO + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES + ConstantesUms.SUBTIPO_MENSAJE_ANULACION + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += pedidoId;
            #endregion

            HttpResponseMessage httpResponseMessage = await EnviarRequest(umsSendDTO);
            if (!httpResponseMessage.IsSuccessStatusCode)
                throw new FalloDeNotificacionException(httpResponseMessage.Content.ReadAsStringAsync().Result);
        }
        #endregion

        #region Actualización punto
        public async Task NotificarActualizacionPunto(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario,
            PedidoTramoDetalle pedidoTramoDetalle,
            fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular)
        {
            int tipoDeEnvio = 0;

            if (!string.IsNullOrEmpty(cmnCelular.Numero) && !string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.PushSms;
            else if (string.IsNullOrEmpty(cmnCelular.Numero) && !string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.Push;
            else if (!string.IsNullOrEmpty(cmnCelular.Numero) && string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.Sms;
            else return;

            UmsSendDTO umsSendDTO = new UmsSendDTO();
            umsSendDTO.Tipo = ConstantesUms.TIPO_MENSAJE_PEDIDO;
            umsSendDTO.SubTipo = ConstantesUms.SUBTIPO_MENSAJE_PEDIDO_ACTUALIZA_TRAMO;
            umsSendDTO.TipoEnvio = tipoDeEnvio;
            umsSendDTO.Celular = 11 + cmnCelular.Numero;
            umsSendDTO.RegistrationFCMId = cmnCelular.FcmTokenNotify;
            umsSendDTO.CelularModoPrueba = cmnCelular.EstaModoPrueba;

            #region Generación Mensaje Push
            umsSendDTO.Contenido = ConstantesUms.TIPO_MENSAJE_PEDIDO + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES + ConstantesUms.SUBTIPO_MENSAJE_PEDIDO_ACTUALIZA_TRAMO + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += pedidoTramoDetalle.PedidoTramo.PedidoId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += RemoverCaracteresProhibidos(pedidoTramoDetalle.HorarioProgramado.HasValue ? pedidoTramoDetalle.HorarioProgramado.Value.ToString("dd/MM/yyyy HH:mm") : "") + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += pedidoTramoDetalle.Direccion.DireccionLocalidadId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += RemoverCaracteresProhibidos(pedidoTramoDetalle.Direccion.Domicilio) + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += pedidoTramoDetalle.Direccion.Piso + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += pedidoTramoDetalle.Direccion.Depto + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += RemoverCaracteresProhibidos(pedidoTramoDetalle.Direccion.CalleAdyacente1) + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += RemoverCaracteresProhibidos(pedidoTramoDetalle.Direccion.CalleAdyacente2) + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += RemoverCaracteresProhibidos(pedidoTramoDetalle.Observacion);
            #endregion

            #region Generación Mensaje Sms
            umsSendDTO.ContenidoSMS = ConstantesUms.TIPO_MENSAJE_PEDIDO + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES + ConstantesUms.SUBTIPO_MENSAJE_PEDIDO_ACTUALIZA_TRAMO + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += pedidoTramoDetalle.PedidoTramo.PedidoId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += RemoverCaracteresProhibidos(pedidoTramoDetalle.HorarioProgramado.HasValue ? pedidoTramoDetalle.HorarioProgramado.Value.ToString("dd/MM/yyyy HH:mm") : "") + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += pedidoTramoDetalle.Direccion.DireccionLocalidadId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += RemoverCaracteresProhibidos(pedidoTramoDetalle.Direccion.Domicilio) + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += pedidoTramoDetalle.Direccion.Piso + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += pedidoTramoDetalle.Direccion.Depto + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += RemoverCaracteresProhibidos(pedidoTramoDetalle.Direccion.CalleAdyacente1) + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += RemoverCaracteresProhibidos(pedidoTramoDetalle.Direccion.CalleAdyacente2) + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += RemoverCaracteresProhibidos(pedidoTramoDetalle.Observacion);

            if (umsSendDTO.ContenidoSMS.Length > 145) umsSendDTO.ContenidoSMS.Substring(0, 145);
            #endregion

            HttpResponseMessage httpResponseMessage = await EnviarRequest(umsSendDTO);
            if (!httpResponseMessage.IsSuccessStatusCode)
                throw new FalloDeNotificacionException(httpResponseMessage.Content.ReadAsStringAsync().Result);
        }
        #endregion

        #region Actualización horario
        public async Task NotificarActualizacionHorario(PedidoTramoProveedorUMovilHorario pedidoTramoProveedorUMovilHorario,
            string tipoHorario,
            fn_CmnCelular_ByPedidoTramoProveedorUMovilHorarioId cmnCelular)
        {
            int tipoDeEnvio = 0;

            if (!string.IsNullOrEmpty(cmnCelular.Numero) && !string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.PushSms;
            else if (string.IsNullOrEmpty(cmnCelular.Numero) && !string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.Push;
            else if (!string.IsNullOrEmpty(cmnCelular.Numero) && string.IsNullOrEmpty(cmnCelular.FcmTokenNotify)) tipoDeEnvio = (int)TipoEnvioEnum.Sms;
            else return;

            string subtipoHorario = tipoHorario == "OrigenArribo" ? ConstantesUms.SUBTIPO_MENSAJE_PEDIDO_ORIGEN_ARRIBO : ConstantesUms.SUBTIPO_MENSAJE_PEDIDO_ORIGEN_PARTIDA;
            DateTime? horario = tipoHorario == "OrigenArribo" ? pedidoTramoProveedorUMovilHorario.OrigenArribo : pedidoTramoProveedorUMovilHorario.OrigenPartida;

            if (!horario.HasValue) return;

            UmsSendDTO umsSendDTO = new UmsSendDTO();
            umsSendDTO.Tipo = ConstantesUms.TIPO_MENSAJE_PEDIDO;
            umsSendDTO.SubTipo = subtipoHorario;
            umsSendDTO.TipoEnvio = tipoDeEnvio;
            umsSendDTO.Celular = 11 + cmnCelular.Numero;
            umsSendDTO.RegistrationFCMId = cmnCelular.FcmTokenNotify;
            umsSendDTO.CelularModoPrueba = cmnCelular.EstaModoPrueba;

            #region Generación Mensaje Push
            umsSendDTO.Contenido = ConstantesUms.TIPO_MENSAJE_PEDIDO + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES + subtipoHorario + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += pedidoTramoProveedorUMovilHorario.PedidoTramo.PedidoId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.Contenido += horario.Value.ToString("dd/MM/yyyy HH:mm");
            #endregion

            #region Generación Mensaje Sms
            umsSendDTO.ContenidoSMS = ConstantesUms.TIPO_MENSAJE_PEDIDO + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES + subtipoHorario + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += pedidoTramoProveedorUMovilHorario.PedidoTramo.PedidoId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += pedidoTramoProveedorUMovilHorario.PedidoTramoProveedorUMovilHorarioId + ConstantesUms.SEPARADOR_DATOS_PRINCIPALES;
            umsSendDTO.ContenidoSMS += horario.Value.ToString("dd/MM/yyyy HH:mm");
            #endregion

            HttpResponseMessage httpResponseMessage = await EnviarRequest(umsSendDTO);
            if (!httpResponseMessage.IsSuccessStatusCode)
                throw new FalloDeNotificacionException(httpResponseMessage.Content.ReadAsStringAsync().Result);
        }
        #endregion
    }
}
