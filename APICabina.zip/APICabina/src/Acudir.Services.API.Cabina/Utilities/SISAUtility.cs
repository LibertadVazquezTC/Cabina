﻿using CabinaOperativa.Modelo;
using System.Linq;

namespace CabinaOperativa.Utilities
{
    public class SISAUtility
    {
        public static int ObtenerTipoDocumentoId(Pedido pedido)
        {
            int tipoDocumentoIdInvalido = -1;

            if (pedido.PedidoAfiliado != null && pedido.PedidoAfiliado.Count > 0)
            {
                var contratoAfiliado = pedido.PedidoAfiliado.FirstOrDefault().ContratoAfiliado;
                if (contratoAfiliado != null)
                {
                    var tipoDocumentoId = contratoAfiliado.HistoriaClinicaPaciente is null ?
                        contratoAfiliado.TipoDocumentoId :
                        contratoAfiliado.HistoriaClinicaPaciente.TipoDocumentoId;

                    if (tipoDocumentoId.HasValue)
                    {
                        switch (tipoDocumentoId)
                        {
                            case 2: //DNI
                                return 1;
                            case 3: //Cédula
                                return 4;
                            case 4: //LC
                                return 2;
                            case 5: //LE
                                return 3;
                            case 6: //Otro
                                return tipoDocumentoIdInvalido;
                            case 7: //Pasaporte
                                return 5;
                            default:
                                return tipoDocumentoIdInvalido;
                        }
                    }
                }
            }

            return tipoDocumentoIdInvalido;
        }
    }
}
