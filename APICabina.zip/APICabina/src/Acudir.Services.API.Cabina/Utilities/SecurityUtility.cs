﻿using Microsoft.AspNetCore.Http;
using System;
using System.Linq;
using System.Text;
using System.Web;

namespace CabinaOperativa.Utilities
{
    public class SecurityUtility
    {
        private static IHttpContextAccessor _httpContextAccessor;

        public static void SetHttpContextAccessor(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        public static string UserName
        {
            get
            {
                string userName = "S/D";
                if (_httpContextAccessor.HttpContext?.Request != null)
                {
                    IHeaderDictionary headers = _httpContextAccessor.HttpContext.Request.Headers;
                    if (headers != null && headers.TryGetValue("UserName", out var values))
                    {
                        string firstValue = values.FirstOrDefault();
                        if (!string.IsNullOrEmpty(firstValue))
                        {
                            try
                            {
                                if (IsBase64String(firstValue))
                                {
                                    byte[] bytes = Convert.FromBase64String(firstValue);
                                    string decodedString = Encoding.UTF8.GetString(bytes);

                                    userName = HttpUtility.UrlDecode(decodedString);
                                }
                                else
                                {
                                    userName = _httpContextAccessor.HttpContext.Request.Headers["UserName"];
                                    return string.IsNullOrEmpty(userName) ? "S/D" : userName;
                                }
                            }
                            catch (Exception ex) { throw new Exception(ex.Message, ex); }
                        }
                    }
                }
                return userName;
            }
        }

        private static bool IsBase64String(string s)
        {
            s = s.Trim();

            if (s.Length % 4 != 0)
            {
                return false;
            }

            return System.Text.RegularExpressions.Regex.IsMatch(s, @"^[a-zA-Z0-9\+/]*={0,3}$", System.Text.RegularExpressions.RegexOptions.None);
        }

        public static string RemoteIpAddress
        {
            get
            {
                string remoteIpAddress = _httpContextAccessor.HttpContext.Request.Headers["RemoteIpAddress"];
                return string.IsNullOrEmpty(remoteIpAddress) ? "S/D" : remoteIpAddress;

            }
        }

        public static int UsuarioId
        {
            get
            {
                string usuarioIdString = _httpContextAccessor.HttpContext.Request.Headers["UsuarioId"];
                int usuarioId = 0;
                if (!int.TryParse(usuarioIdString, out usuarioId))
                    return 0;
                return usuarioId;
            }
        }
    }
}
