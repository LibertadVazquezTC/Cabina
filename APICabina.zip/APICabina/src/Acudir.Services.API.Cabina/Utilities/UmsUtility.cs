﻿using CabinaOperativa.DTOs;
using CabinaOperativa.Repositories;
using Dapper;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace CabinaOperativa.Utilities
{
    public class UmsUtility
    {
        private readonly IConfiguration _config;
        protected readonly UmsViejo _umsViejo;

        string[,] caracteresProhibidos = new string[,]
                                {{"&" , ""},{@"""" , ""},{ "'" , ""},
                                {"<" , ""},{">" , ""},{"[" , ")"},
                                {@"\" , "/"},{"]" , ")"},{"^" , ""},
                                {"_" , "-"},{"`" , ""},{"{" , "("},
                                {"}" , ")"},{"~" , ""},{"Ç" , ""},
                                {"ü" , "u"},{"é" , "e"},{"â" , "a"},
                                {"ä" , "a"},{"à" , "a"},{"å" , "a"},
                                {"ç" , ""},{"ê" , "e"},{"ë" , "e"},
                                {"è" , "e"},{"ï" , "i"},{"î" , "i"},
                                {"ì" , "i"},{"Ä" , "A"},{"Å" , "A"},
                                {"É" , "E"},{"æ" , ""},{"Æ" , ""},
                                {"ô" , "o"},{"ö" , "o"},{"ò" , "o"},
                                {"û" , "u"},{"ù" , "u"},{"ÿ" , "y"},
                                {"Ö" , "O"},{"Ü" , "U"},{"ø" , "o"},
                                {"£" , ""},{"Ø" , "O"},{"×" , ""},
                                {"ƒ" , ""},{"á" , "a"},{"í" , "i"},
                                {"ó" , "o"},{"ú" , "u"},{"ñ" , "n"},
                                {"Ñ" , "N"},{"ª" , ""},{"º" , ""},
                                {"¿" , ""},{"®" , ""},{"¬" , ""},
                                {"½" , ""},{"¼" , ""},{"¡" , ""},
                                {"«" , ""},{"»" , ""},{"¦" , ""},
                                {"Á" , "A"},{"Â" , "A"},{"À" , "A"},
                                {"©" , ""},{"¦" , ""},{"¦" , ""},
                                {"¢" , ""},{"¥" , ""},{"ã" , "a"},
                                {"Ã" , "A"},{"¤" , ""},{"ð" , "o"},
                                {"Ð" , ""},{"Ê" , "E"},{"Ë" , "E"},
                                {"È" , "E"},{"Í" , "I"},{"Î" , "I"},
                                {"Ï" , "I"},{"Ì" , "I"},{"¯" , ""},
                                {"Ó" , "O"},{"ß" , ""},{"Ô" , "O"},
                                {"Ò" , "O"},{"õ" , "o"},{"Õ" , "O"},
                                {"µ" , ""},{"þ" , ""},{"Þ" , ""},
                                {"Ú" , "U"},{"Û" , "U"},{"Ù" , "U"},
                                {"ý" , "y"},{"Ý" , "Y"},{"¯" , ""},
                                {"´" , ""},{"±" , ""},{"¾" , ""},
                                {"¶" , ""},{"§" , ""},{"°" , ""},
                                {"¨" , ""},{"·" , ""},{"¹" , ""},
                                {"³" , ""},{"²" , ""},{"÷" , "/"},
                                {"¸" , "."},{"$" , ""},{"#" , ""}};


        protected readonly IPedidoAfiliadoRepository _pedidoAfiliadoRepository;
        protected readonly IPedidoCoseguroRepository _pedidoCoseguroRepository;

        public UmsUtility(IConfiguration config)
        {
            _config = config;
            _umsViejo = new UmsViejo(config);
        }

        private IDbConnection Connection => new SqlConnection(_config.GetConnectionString("TechMedDatabase"));

        protected async Task<HttpResponseMessage> EnviarRequest(UmsSendDTO umsSendDTO)
        {
            if (!PuedeEnviar(umsSendDTO)) return new HttpResponseMessage(HttpStatusCode.OK);

            using (HttpClient httpClient = new HttpClient())
            {
                string umsUrl = _config.GetValue<string>("UmsUrl");

                httpClient.BaseAddress = new Uri(umsUrl);
                httpClient.DefaultRequestHeaders.Accept.Clear();
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage httpResponseMessage = await httpClient.PostAsync("Api/Enviar", new StringContent(JsonConvert.SerializeObject(umsSendDTO), Encoding.UTF8, "application/json"));
                return httpResponseMessage;
            }
        }

        protected string RemoverCaracteresProhibidos(string cadenaAVerificar)
        {
            if (string.IsNullOrEmpty(cadenaAVerificar)) return "";
            for (int i = 0; i <= (caracteresProhibidos.Length / 2) - 1; i++)
                cadenaAVerificar = cadenaAVerificar.Replace(caracteresProhibidos[i, 0], caracteresProhibidos[i, 1]);
            return cadenaAVerificar.Trim();
        }

        protected string QuitarCaracteresEspeciales(string cadena)
        {
            try
            {
                for (int i = 0; i <= (caracteresProhibidos.Length / 2) - 1; i++)
                {
                    cadena = cadena.Replace(caracteresProhibidos[i, 0], caracteresProhibidos[i, 1]);
                }
                return cadena;
            }
            catch (Exception exception)
            {
                throw new Exception(exception.Message);
            }
        }

        private bool PuedeEnviar(UmsSendDTO umsSendDTO)
        {
            //Entornos posibles:
            //Test 
            //Produccion 
            //Desarrollo
            string entorno = _config.GetValue<string>("Entorno");
            if (entorno == "Test" || entorno == "Desarrollo" || entorno == "Dev")
            {
                if (umsSendDTO.CelularModoPrueba) return true;
                else return false;
            }
            else if (entorno == "Produccion")
            {
                if (umsSendDTO.CelularModoPrueba) return false;
                else return true;
            }
            return false;
        }
    }
}

