﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace CabinaOperativa.Utilities
{
    public class UmsViejo
    {
        private readonly IConfiguration _config;

        string[,] arrayDict = new string[,]
                                {{"&" , ""},{@"""" , ""},{ "'" , ""},
                                {"<" , ""},{">" , ""},{"[" , ")"},
                                {@"\" , "/"},{"]" , ")"},{"^" , ""},
                                {"_" , "-"},{"`" , ""},{"{" , "("},
                                {"}" , ")"},{"~" , ""},{"Ç" , ""},
                                {"ü" , "u"},{"é" , "e"},{"â" , "a"},
                                {"ä" , "a"},{"à" , "a"},{"å" , "a"},
                                {"ç" , ""},{"ê" , "e"},{"ë" , "e"},
                                {"è" , "e"},{"ï" , "i"},{"î" , "i"},
                                {"ì" , "i"},{"Ä" , "A"},{"Å" , "A"},
                                {"É" , "E"},{"æ" , ""},{"Æ" , ""},
                                {"ô" , "o"},{"ö" , "o"},{"ò" , "o"},
                                {"û" , "u"},{"ù" , "u"},{"ÿ" , "y"},
                                {"Ö" , "O"},{"Ü" , "U"},{"ø" , "o"},
                                {"£" , ""},{"Ø" , "O"},{"×" , ""},
                                {"ƒ" , ""},{"á" , "a"},{"í" , "i"},
                                {"ó" , "o"},{"ú" , "u"},{"ñ" , "n"},
                                {"Ñ" , "N"},{"ª" , ""},{"º" , ""},
                                {"¿" , ""},{"®" , ""},{"¬" , ""},
                                {"½" , ""},{"¼" , ""},{"¡" , ""},
                                {"«" , ""},{"»" , ""},{"¦" , ""},
                                {"Á" , "A"},{"Â" , "A"},{"À" , "A"},
                                {"©" , ""},{"¦" , ""},{"¦" , ""},
                                {"¢" , ""},{"¥" , ""},{"ã" , "a"},
                                {"Ã" , "A"},{"¤" , ""},{"ð" , "o"},
                                {"Ð" , ""},{"Ê" , "E"},{"Ë" , "E"},
                                {"È" , "E"},{"Í" , "I"},{"Î" , "I"},
                                {"Ï" , "I"},{"Ì" , "I"},{"¯" , ""},
                                {"Ó" , "O"},{"ß" , ""},{"Ô" , "O"},
                                {"Ò" , "O"},{"õ" , "o"},{"Õ" , "O"},
                                {"µ" , ""},{"þ" , ""},{"Þ" , ""},
                                {"Ú" , "U"},{"Û" , "U"},{"Ù" , "U"},
                                {"ý" , "y"},{"Ý" , "Y"},{"¯" , ""},
                                {"´" , ""},{"±" , ""},{"¾" , ""},
                                {"¶" , ""},{"§" , ""},{"°" , ""},
                                {"¨" , ""},{"·" , ""},{"¹" , ""},
                                {"³" , ""},{"²" , ""},{"÷" , "/"},
                                {"¸" , "."},{"$" , ""},{"#" , ""}};

        public UmsViejo(IConfiguration config)
        {
            _config = config;
        }

        public IEnumerable<PedidoSP> ObtenerHojaDeRutaPorMovil(int movilId)
        {
            var connectionString = _config.GetConnectionString("TechMedDatabase");

            var pedidos = new List<PedidoSP>();
            string SqlQ = string.Format("exec usp_PedidoTramoDespacho_get '{0}', '{1}','{2}','{3}','{4}'", 9, null, null, null, movilId);
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(SqlQ, con))
                {
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    ConvertTo(rdr, pedidos, typeof(PedidoSP));
                    con.Close();
                    rdr.Close();
                }
            }
            return pedidos;
        }

        public static void ConvertTo<T>(SqlDataReader sqlDr, IList<T> list, Type type)
        {
            var campo = "";
            int j = 0;
            int k = 0;

            try
            {
                while (sqlDr.Read())
                {
                    T item = (T)Activator.CreateInstance(type);

                    // Get all the properties of the type
                    PropertyInfo[] properties = ((Type)item.GetType()).GetProperties();
                    j = 0;
                    for (j = 0; j < sqlDr.FieldCount; j++)
                    {
                        k = 0;

                        for (k = 0; k < properties.Count(); k++)
                        {
                            if (sqlDr.GetName(j) == properties[k].Name)
                            {
                                campo = sqlDr.GetName(j);
                                if (sqlDr[j] != DBNull.Value)
                                    properties[k].SetValue(item, sqlDr[j]);
                            }
                        }
                    }
                    list.Add(item);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private string QuitarCaracteresEspeciales(string cadena)
        {
            try
            {
                for (int i = 0; i <= (arrayDict.Length / 2) - 1; i++)
                {
                    cadena = cadena.Replace(arrayDict[i, 0], arrayDict[i, 1]);
                }
                return cadena;
            }
            catch (Exception ex)
            {
                throw new ArgumentException("Ocurrio un error: " + ex.InnerException.Message);
            }
        }

        public string ObtenerHojaDeRutaMobilePorMovilYPedidoId(int movilId, int pedidoId1, bool permiteRechazo)
        {
            string hojaDeRutaStr;
            var list = ObtenerHojaDeRutaPorMovil(movilId);

            List<int> list1;


            if (pedidoId1 != 0)
                list1 = list.Where(x => !(bool)x.TramoTerminado & x.PedidoId == pedidoId1).Select(y => y.PedidoId).ToList();
            else
                list1 = list.Where(x => !(bool)x.TramoTerminado).Select(y => y.PedidoId).ToList();

            var listdef = list.Where(x => list1.Contains(x.PedidoId)).ToList();

            bool newtramo = true;
            bool newPedido = true;
            var cadena = "P|DC|";
            var sepadadorcabe = "|";
            var sepadadorcampos = "#";
            var sepadadorcamposint = "^";
            var sepadadortramos = "@";
            var sepadadorPedido = "%";
            var pedidoId = 0;
            foreach (var _uspPedidoTramoDespachoGetResult in listdef)
            {

                if (pedidoId != _uspPedidoTramoDespachoGetResult.PedidoId)
                {
                    if (!newPedido)
                        cadena += sepadadorPedido + "P|DC|";

                    newtramo = true;
                    cadena += _uspPedidoTramoDespachoGetResult.PedidoId;
                    cadena += sepadadorcabe;
                    cadena += _uspPedidoTramoDespachoGetResult.PedidoTramoId;
                    cadena += sepadadorcabe;
                    cadena += 1;
                    cadena += sepadadorcabe;
                    cadena += 1;
                    cadena += sepadadorcabe;
                    var centuryBegin = (DateTime)_uspPedidoTramoDespachoGetResult.FechaPedido.Value;
                    DateTime currentDate = DateTime.Now;
                    long elapsedTicks = centuryBegin.Ticks;
                    cadena += elapsedTicks;
                    cadena += sepadadorcampos;
                    cadena += _uspPedidoTramoDespachoGetResult.TipoPrestacionId;
                    cadena += sepadadorcampos;
                    cadena += QuitarCaracteresEspeciales(_uspPedidoTramoDespachoGetResult.Contrato.Trim());
                    cadena += sepadadorcampos;
                    cadena += _uspPedidoTramoDespachoGetResult.AfiliadoNombre != null ? QuitarCaracteresEspeciales(_uspPedidoTramoDespachoGetResult.AfiliadoNombre.Trim()) : "";
                    cadena += sepadadorcampos;
                    cadena += _uspPedidoTramoDespachoGetResult.Contratoplan != null ? QuitarCaracteresEspeciales(_uspPedidoTramoDespachoGetResult.Contratoplan.Trim()) : "";
                    cadena += sepadadorcampos;
                    cadena += _uspPedidoTramoDespachoGetResult.ObservacionesAfiliado != null ? QuitarCaracteresEspeciales(_uspPedidoTramoDespachoGetResult.ObservacionesAfiliado.Trim()) : "";
                    cadena += sepadadorcampos;
                    cadena += _uspPedidoTramoDespachoGetResult.PedidoDetalleObservacion != null ? QuitarCaracteresEspeciales(_uspPedidoTramoDespachoGetResult.PedidoDetalleObservacion.Trim()) : "";
                    cadena += sepadadorcampos;
                    cadena += _uspPedidoTramoDespachoGetResult.SE;
                    cadena += sepadadorcampos;
                    cadena += QuitarCaracteresEspeciales(_uspPedidoTramoDespachoGetResult.NroIncidente);
                    cadena += sepadadorcampos;
                    cadena += _uspPedidoTramoDespachoGetResult.SintomaTomado != null ? QuitarCaracteresEspeciales(_uspPedidoTramoDespachoGetResult.SintomaTomado.Trim()) : "";
                    cadena += sepadadorcampos;
                    //cadena += _uspPedidoTramoDespachoGetResult.Telefono != null ? QuitarCaracteresEspeciales(_uspPedidoTramoDespachoGetResult.Telefono.Trim()) : "";
                    cadena += "";
                    cadena += sepadadorcampos;
                    cadena += _uspPedidoTramoDespachoGetResult.Coseguro;
                    cadena += sepadadorcampos;
                    cadena += _uspPedidoTramoDespachoGetResult.Adicionales == "-" || _uspPedidoTramoDespachoGetResult.Adicionales == "" ? "" : _uspPedidoTramoDespachoGetResult.Adicionales.Substring(0, _uspPedidoTramoDespachoGetResult.Adicionales.Length - 1);
                    cadena += sepadadorcampos;
                    cadena += _uspPedidoTramoDespachoGetResult.DiagnosticoAnteriorCodigoCIE;
                    cadena += sepadadorcampos;
                    cadena += _uspPedidoTramoDespachoGetResult.DiagnosticoAnterior;
                    cadena += sepadadorcampos;
                    cadena += _uspPedidoTramoDespachoGetResult.DiagnosticoActualCodigoCIE;
                    cadena += sepadadorcampos;
                    cadena += _uspPedidoTramoDespachoGetResult.DiagnosticoActual;
                    cadena += sepadadorcampos;
                    cadena += "157";
                    cadena += sepadadorcampos;
                    cadena += (bool)_uspPedidoTramoDespachoGetResult.Art ? "S" : "N";
                    cadena += sepadadorcampos;
                    cadena += (bool)_uspPedidoTramoDespachoGetResult.PedidoReiterado ? "S" : "N";
                    cadena += sepadadorcampos;
                    cadena += _uspPedidoTramoDespachoGetResult.EsProtocoloIAM ? "S" : "N";
                    cadena += sepadadorcampos;
                    cadena += _uspPedidoTramoDespachoGetResult.EsProtocoloStroke ? "S" : "N";
                    cadena += sepadadorcampos;
                    cadena += permiteRechazo ? "S" : "N";
                    cadena += sepadadorcampos;
                    cadena += _uspPedidoTramoDespachoGetResult.EsProtocoloSepsis ? "S" : "N";
                    cadena += sepadadorcampos;
                    cadena += _uspPedidoTramoDespachoGetResult.EsProtocoloDerivacion ? "S" : "N";

                    cadena += sepadadorcamposint;
                    newPedido = false;
                    pedidoId = (int)_uspPedidoTramoDespachoGetResult.PedidoId;
                }
                if (!newtramo)
                    cadena += sepadadortramos;

                cadena += _uspPedidoTramoDespachoGetResult.PedidoTramoId;
                cadena += sepadadorcampos;
                cadena += _uspPedidoTramoDespachoGetResult.TramoNro;
                cadena += sepadadorcampos;
                cadena += _uspPedidoTramoDespachoGetResult.PedidoTramoProveedorUMovilHorarioId;
                cadena += sepadadorcampos;
                cadena += _uspPedidoTramoDespachoGetResult.PedidoTramoProveedorUMovilHorarioEstadoId;
                cadena += sepadadorcampos;
                cadena += (bool)_uspPedidoTramoDespachoGetResult.Origen ? "S" : "N";
                cadena += sepadadorcampos;
                cadena += (bool)_uspPedidoTramoDespachoGetResult.Destino ? "S" : "N";
                cadena += sepadadorcampos;
                cadena += (_uspPedidoTramoDespachoGetResult.EsProgramacion || _uspPedidoTramoDespachoGetResult.EsTurno || _uspPedidoTramoDespachoGetResult.TipoPrestacionCategoriaId == 4) ? _uspPedidoTramoDespachoGetResult.HorarioOrigen : null;
                cadena += sepadadorcampos;
                cadena += (_uspPedidoTramoDespachoGetResult.EsProgramacion || _uspPedidoTramoDespachoGetResult.EsTurno || _uspPedidoTramoDespachoGetResult.TipoPrestacionCategoriaId == 4) ? _uspPedidoTramoDespachoGetResult.HorarioDestino : null;
                cadena += sepadadorcampos;
                cadena += _uspPedidoTramoDespachoGetResult.OrigenDomicilio != null ? QuitarCaracteresEspeciales(_uspPedidoTramoDespachoGetResult.OrigenDomicilio.Trim()) : "";
                cadena += sepadadorcampos;
                cadena += _uspPedidoTramoDespachoGetResult.OrigenDireccionLocalidadId;
                cadena += sepadadorcampos;
                cadena += _uspPedidoTramoDespachoGetResult.OrigenPiso;
                cadena += sepadadorcampos;
                cadena += _uspPedidoTramoDespachoGetResult.OrigenDepto != null ? QuitarCaracteresEspeciales(_uspPedidoTramoDespachoGetResult.OrigenDepto.Trim()) : "";
                cadena += sepadadorcampos;
                cadena += _uspPedidoTramoDespachoGetResult.OrigenCalleAdyacente1 != null ? QuitarCaracteresEspeciales(_uspPedidoTramoDespachoGetResult.OrigenCalleAdyacente1.Trim()) : "";
                cadena += sepadadorcampos;
                cadena += _uspPedidoTramoDespachoGetResult.OrigenCalleAdyacente2 != null ? QuitarCaracteresEspeciales(_uspPedidoTramoDespachoGetResult.OrigenCalleAdyacente2.Trim()) : "";
                cadena += sepadadorcampos;
                cadena += _uspPedidoTramoDespachoGetResult.DestinoDireccionLocalidadId;
                cadena += sepadadorcampos;
                cadena += _uspPedidoTramoDespachoGetResult.DestinoDomicilio != null ? QuitarCaracteresEspeciales(_uspPedidoTramoDespachoGetResult.DestinoDomicilio.Trim()) : "";
                cadena += sepadadorcampos;
                cadena += _uspPedidoTramoDespachoGetResult.DestinoPiso;
                cadena += sepadadorcampos;
                cadena += _uspPedidoTramoDespachoGetResult.DestinoDepto != null ? QuitarCaracteresEspeciales(_uspPedidoTramoDespachoGetResult.DestinoDepto.Trim()) : "";
                cadena += sepadadorcampos;
                cadena += _uspPedidoTramoDespachoGetResult.DestinoCalleAdyacente1 != null ? QuitarCaracteresEspeciales(_uspPedidoTramoDespachoGetResult.DestinoCalleAdyacente1.Trim()) : "";
                cadena += sepadadorcampos;
                cadena += _uspPedidoTramoDespachoGetResult.DestinoCalleAdyacente2 != null ? QuitarCaracteresEspeciales(_uspPedidoTramoDespachoGetResult.DestinoCalleAdyacente2.Trim()) : "";
                cadena += sepadadorcampos;
                cadena += _uspPedidoTramoDespachoGetResult.OrigenArribo;
                cadena += sepadadorcampos;
                cadena += _uspPedidoTramoDespachoGetResult.OrigenPartida;
                cadena += sepadadorcampos;
                cadena += _uspPedidoTramoDespachoGetResult.DestinoArribo;
                cadena += sepadadorcampos;
                cadena += _uspPedidoTramoDespachoGetResult.DestinoPartida;
                cadena += sepadadorcampos;
                cadena += _uspPedidoTramoDespachoGetResult.DestinoSanatorioDescripcion != null ? QuitarCaracteresEspeciales(_uspPedidoTramoDespachoGetResult.DestinoSanatorioDescripcion.Trim()) : "";
                cadena += sepadadorcampos;
                cadena += _uspPedidoTramoDespachoGetResult.SolicitudDerivacionMedicoReceptor != null ? QuitarCaracteresEspeciales(_uspPedidoTramoDespachoGetResult.SolicitudDerivacionMedicoReceptor.Trim()) : "";
                cadena += sepadadorcampos;
                cadena += _uspPedidoTramoDespachoGetResult.SolicitudDerivacionObservacion != null ? QuitarCaracteresEspeciales(_uspPedidoTramoDespachoGetResult.SolicitudDerivacionObservacion.Trim()) : "";
                cadena += sepadadorcampos;
                cadena += _uspPedidoTramoDespachoGetResult.SolicitudDerivacionComplejidad != null ? QuitarCaracteresEspeciales(_uspPedidoTramoDespachoGetResult.SolicitudDerivacionComplejidad.Trim()) : "";
                cadena += sepadadorcampos;
                cadena += (bool)_uspPedidoTramoDespachoGetResult.TramoTerminado ? "S" : "N";
                cadena += sepadadorcampos;
                cadena += (bool)_uspPedidoTramoDespachoGetResult.Apoyo ? "S" : "N";
                cadena += sepadadorcampos;
                cadena += _uspPedidoTramoDespachoGetResult.OrigenObservacion != null ? QuitarCaracteresEspeciales(_uspPedidoTramoDespachoGetResult.OrigenObservacion.Trim()) : "";
                cadena += sepadadorcampos;
                cadena += _uspPedidoTramoDespachoGetResult.DestinoObservacion != null ? QuitarCaracteresEspeciales(_uspPedidoTramoDespachoGetResult.DestinoObservacion.Trim()) : "";

                newtramo = false;
            }

            hojaDeRutaStr = cadena == "P|DC|" ? "Ninguno" : cadena;
            return hojaDeRutaStr;

        }

        public string RecortarCalles(string calle)
        {
            int largo = 30;
            string str = "";

            if (calle.IndexOf(" (AL") < 30)
            {
                if (calle.IndexOf(" (AL") < 0)
                {
                    if (calle.Length < 30)
                        largo = calle.Length;
                    else
                        largo = 30;
                }
                else
                    largo = calle.IndexOf(" (AL");
            }
            else
                largo = 30;

            str = calle.Substring(0, largo);
            return str;
        }

        public class PedidoSP
        {
            public int PedidoId { get; set; }
            public DateTime? FechaPedido { get; set; }
            public int? TT { get; set; }
            public int? VT { get; set; }
            public String Contrato { get; set; }
            public String TipoPrestacion { get; set; }
            public String TipoPrestacionAbreviada { get; set; }
            public int? TipoPrestacionId { get; set; }
            public int? TipoPrestacionCategoriaId { get; set; }
            public int? ContratoAfiliadoId { get; set; }
            public String SE { get; set; }
            public String Tomador { get; set; }
            public String Zona { get; set; }
            public String ZonaHasta { get; set; }
            public string UMovil { get; set; }
            public int? UMovilId { get; set; }
            public int? ProveedorId { get; set; }
            public string ProveedorDescripcion { get; set; }
            public string OrigenDomicilio { get; set; }
            public DateTime? OrigenArribo { get; set; }
            public DateTime? OrigenPartida { get; set; }
            public string OrigenDistancia { get; set; }
            public string DestinoDomicilio { get; set; }
            public DateTime? DestinoArribo { get; set; }
            public DateTime? DestinoPartida { get; set; }
            public string DestinoDistancia { get; set; }
            public string QuienLlama { get; set; }
            public string Despachador { get; set; }
            public DateTime? FechaDespacho { get; set; }
            public string Estado { get; set; }
            public string SemaforoEstado { get; set; }
            public string Diagnostico { get; set; }
            public bool? TramoTerminado { get; set; }
            public float? Coseguro { get; set; }
            public bool? Art { get; set; }
            public string Adicionales { get; set; }
            public bool? Apoyo { get; set; }
            public bool? PedidoReiterado { get; set; }
            public bool RequiereDerivacionSegundaAtencion { get; set; }

            //FALTAN EN EL STORE        
            public string SintomaTomado { get; set; }
            public int? PedidoTramoId { get; set; }
            public int? TramoNro { get; set; }
            public DateTime? HorarioOrigen { get; set; }
            public DateTime? HorarioDestino { get; set; }
            public DateTime? HorarioOrden { get; set; }
            public string NroIncidente { get; set; }
            public string AfiliadoNro { get; set; }
            public string AfiliadoNombre { get; set; }
            public string Chofer { get; set; }
            public string AfiliadoObservacion { get; set; }
            public string ObservacionesAfiliado { get; set;  }
            public bool? PacienteRecomendado { get; set; }
            public bool? PersonajePublico { get; set; }
            public string Contratoplan { get; set; }
            public string Telefono { get; set; }
            public bool? Origen { get; set; }
            public double? OrigenLatitud { get; set; }
            public string Lat { get; set; }
            public string Long { get; set; }
            public double? OrigenLongitud { get; set; }
            public bool? Destino { get; set; }
            public string OrigenLocalidad { get; set; }
            public string OrigenCalleAdyacente1 { get; set; }
            public string OrigenCalleAdyacente2 { get; set; }
            public string OrigenDepto { get; set; }
            public int? OrigenPiso { get; set; }
            public string DestinoLocalidad { get; set; }
            public string DestinoCalleAdyacente1 { get; set; }
            public string DestinoCalleAdyacente2 { get; set; }
            public string DestinoDepto { get; set; }
            public int? DestinoPiso { get; set; }
            public int? PedidoTramoProveedorUMovilHorarioEstadoId { get; set; }
            public int? PedidoTramoProveedorUMovilHorarioId { get; set; }

            public string SolicitudDerivacion { get; set; }
            public string PedidoDetalleObservacion { get; set; }
            public int? CantidadApoyos { get; set; }
            public bool? PacientePsiquiatrico { get; set; }
            public bool? SuperRojo { get; set; }
            public int? Alerta { get; set; }
            public int? AlertaCoseguro { get; set; }
            public int? AlertaSirena { get; set; }

            public bool? AlertaMovimiento { get; set; }
            public bool? AlertaMovilEnZona { get; set; }
            public bool? AlertaPartida { get; set; }

            public int? TD { get; set; }
            public int? TV { get; set; }
            public int? TA { get; set; }
            public int? TX { get; set; }
            public int? TS { get; set; }

            public int? CantidadReclamos { get; set; }

            public string PedidoTipoCierreDescripcion { get; set; }
            public string PedidoTipoCierreDescAbreviada { get; set; }


            public bool? GPSReportando { get; set; }
            public DateTime? GPSFechaLog { get; set; }

            public bool? AlertaGeneraEvento { get; set; }

            public DateTime? OrigenArriboGps { get; set; }
            public DateTime? OrigenPartidaGps { get; set; }

            public DateTime? DestinoArriboGps { get; set; }
            public DateTime? DestinoPartidaGps { get; set; }
            public bool? AlarmaTieneRespuesta { get; set; }
            public bool? AlarmaCoseguroTieneRespuesta { get; set; }
            public bool? AutoCheckGpsOk { get; set; }
            public bool? AlertaSirenaTieneRespuesta { get; set; }
            public bool? AlertaMovimientoTieneRespuesta { get; set; }
            public bool? AlertaMovilEnZonaTieneRespuesta { get; set; }
            public bool? AlertaPartidaTieneRespuesta { get; set; }

            public int? CandidatoUMovilId { get; set; }
            public string CandidatoUMovilDescripcion { get; set; }
            public DateTime? HorarioDespacho { get; set; }
            public bool EsProgramacion { get; set; }

            //public DateTime? OrigenEsperaAutorizadaCliente  { get; set; }
            //public bool?  OrigenEsperaAutorizadaIlimitadaCliente  { get; set; }
            //public DateTime?  DestinoEsperaAutorizadaCliente  { get; set; }
            //public bool? DestinoEsperaAutorizadaIlimitadaCliente { get; set; }

            public string OrigenSanatorioDescripcion { get; set; }
            public string OrigenSanatorioTelefono { get; set; }
            public string OrigenSanatorioTelefonoGdia { get; set; }
            public string DestinoSanatorioDescripcion { get; set; }
            public string DestinoSanatorioTelefono { get; set; }
            public string DestinoSanatorioTelefonoGdia { get; set; }
            public string SolicitudDerivacionDestinoPreferencia { get; set; }
            public string SolicitudDerivacionObservacion { get; set; }
            public string SolicitudDerivacionMedicoReceptor { get; set; }
            public string SolicitudDerivacionComplejidad { get; set; }
            public string TipoPrestacionBackground { get; set; }
            public string TipoPrestacionColor { get; set; }
            public int? EventoDetalleLocacionId { get; set; }

            public int? PedidoComentarioId { get; set; }
            public string ConsultaDespachador { get; set; }
            public bool ConDerivacion { get; set; }

            public string DiagnosticoAnterior { get; set; }
            public string DiagnosticoAnteriorCodigoCIE { get; set; }
            public string DiagnosticoActual { get; set; }
            public string DiagnosticoActualCodigoCIE { get; set; }

            public int? ContratoRelevanciaTipoId { get; set; }

            public string ContratoTransaccionId { get; set; }

            public int? Grupo0 { get; set; }

            public int? PedidoPadreId { get; set; }

            public string ContratoRelevanciaTipoBackground { get; set; }
            public string ContratoRelevanciaTipoColor { get; set; }
            public int? OrigenDireccionLocalidadId { get; set; }
            public int? DestinoDireccionLocalidadId { get; set; }
            public string CmnCelularNumero { get; set; }
            public bool DespachaEfector { get; set; }
            public bool? AlertaEfectorTiempo { get; set; }
            public int PedidoEstadoId { get; set; }
            public int? EfectorId { get; set; }
            public int? PedidoTramoEfectorHorarioEstadoId { get; set; }
            public int? PedidoTramoEfectorHorarioId { get; set; }
            public bool? NegociaInterfaz { get; set; }
            public string SolicitudDerivacionSemaforo { get; set; }
            public string PedidoAdicionalTipoDescripcion { get; set; }
            public string CoseguroEstado { get; set; }
            public int? DesdeLocalidadId { get; set; }
            public string Notificaciones { get; set; }
            public string NotificacionesConsultaDespachador { get; set; }
            public int NotificacionesNoLeidasDestacado { get; set; }
            public string OrigenDireccionZonaGeograficaTextColor { get; set; }
            public string OrigenDireccionZonaGeograficaBackGroundColor { get; set; }
            public string DestinoDireccionZonaGeograficaTextColor { get; set; }
            public string DestinoDireccionZonaGeograficaBackGroundColor { get; set; }
            public int? PedidoCoseguroTipoNoCobroId { get; set; }
            public bool FinalizoToma { get; set; }
            public string OrigenObservacion { get; set; }
            public string DestinoObservacion { get; set; }
            public bool EsTurno { get; set; }
            public bool EsProtocoloIAM { get; set; }
            public int? PedidoProtocoloStrokeId { get; set; }
            public bool EsProtocoloStroke { get { return PedidoProtocoloStrokeId.HasValue && PedidoProtocoloStrokeId != 0; } }
            public bool EsProtocoloSepsis { get; set; }
            public bool EsProtocoloDerivacion { get; set; }
            public int? StrokeEscalaCincinnati1 { get; set; }// levante los brazos
            public int? StrokeEscalaCincinnati2 { get; set; }//sonria
            public int? StrokeEscalaCincinnati3 { get; set; }//diga el cielo es azul
            public int? StrokeTiempoEvolucion { get; set; }
            public int? StrokeGlucemia { get; set; }
            public int? StrokeTASistolica { get; set; }
            public int? StrokeTADiastolica { get; set; }
            public bool? StrokeAntiCoagulado { get; set; }
            public DateTime? StrokeInformadoFecha { get; set; }
            public DateTime? StrokeFinalizadoFecha { get; set; }
            public int PedidoTipoDespachoId { get; set; }
            public bool? OrigenGeocoded { get; set; }
            public bool? DestinoGeocoded { get; set; }
            public int? OrigenPedidoTramoDetalleId { get; set; }
            public int? DestinoPedidoTramoDetalleId { get; set; }
        }

    }
}
